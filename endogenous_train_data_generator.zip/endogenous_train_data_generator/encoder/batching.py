"""Shared exact quota allocation and batch packing, without an unused loader."""
import numpy as np
import torch

def quotas(total, weights):
    denominator = sum(weights)
    raw = [total * w / denominator for w in weights]
    result = [int(x) for x in raw]
    order = sorted(range(len(raw)), key=lambda i: (-(raw[i] - result[i]), i))
    for i in order[:total-sum(result)]:
        result[i] += 1
    return result

def collate(rows):
    return dict(target=torch.tensor(np.stack([r[0] for r in rows])),
                target_mask=torch.tensor(np.stack([r[1] for r in rows])),
                sequence_length=torch.tensor([r[2] for r in rows]),
                source_type=torch.tensor([r[3] for r in rows], dtype=torch.uint8),
                source_dataset=[r[4] for r in rows], source_term=[r[5] for r in rows])
