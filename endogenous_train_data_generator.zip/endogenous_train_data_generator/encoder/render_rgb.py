"""Canonical RGB renderer, extracted unchanged from the original generator."""
from __future__ import annotations
import torch

CURVE_COLORS = ((220, 40, 40), (35, 150, 70), (40, 90, 210))

def masked_quantile(values: torch.Tensor, valid: torch.Tensor, q: float) -> torch.Tensor:
    safe = torch.where(valid, values, torch.full_like(values, float("inf")))
    ordered = torch.sort(safe, dim=-1).values
    counts = valid.sum(dim=-1)
    position = (counts.clamp_min(1).float() - 1.0) * q
    lower = position.floor().long()
    upper = position.ceil().long()
    weight = position - lower.float()
    lo = ordered.gather(-1, lower.unsqueeze(-1)).squeeze(-1)
    hi = ordered.gather(-1, upper.unsqueeze(-1)).squeeze(-1)
    result = lo + (hi - lo) * weight
    return torch.where(counts > 0, result, torch.zeros_like(result))

def scale_curves(
    raw: torch.Tensor,
    raw_valid: torch.Tensor,
    diff1: torch.Tensor,
    diff2: torch.Tensor,
) -> tuple[torch.Tensor, torch.Tensor]:
    """Scale raw independently and both differences with one shared robust scale."""
    d1_valid = torch.isfinite(diff1)
    d2_valid = torch.isfinite(diff2)

    raw_lo = masked_quantile(raw, raw_valid, 0.01)
    raw_hi = masked_quantile(raw, raw_valid, 0.99)
    raw_min = masked_quantile(raw, raw_valid, 0.0)
    raw_max = masked_quantile(raw, raw_valid, 1.0)
    degenerate = raw_hi <= raw_lo
    raw_lo = torch.where(degenerate, raw_min, raw_lo)
    raw_hi = torch.where(degenerate, raw_max, raw_hi)
    raw_span = (raw_hi - raw_lo).clamp_min(1e-6)
    raw_scaled = ((raw - raw_lo[:, None]) / raw_span[:, None]).clamp(0.0, 1.0)
    raw_scaled = torch.where(raw_valid, raw_scaled, torch.zeros_like(raw_scaled))

    d1_abs_q = masked_quantile(diff1.abs(), d1_valid, 0.99)
    d2_abs_q = masked_quantile(diff2.abs(), d2_valid, 0.99)
    shared_scale = torch.maximum(d1_abs_q, d2_abs_q).clamp_min(1e-6)
    d1_scaled = (0.5 + 0.45 * (diff1 / shared_scale[:, None]).clamp(-1.0, 1.0))
    d2_scaled = (0.5 + 0.45 * (diff2 / shared_scale[:, None]).clamp(-1.0, 1.0))
    d1_scaled = torch.where(d1_valid, d1_scaled, torch.zeros_like(d1_scaled))
    d2_scaled = torch.where(d2_valid, d2_scaled, torch.zeros_like(d2_scaled))

    scaled = torch.stack((raw_scaled, d1_scaled, d2_scaled), dim=1)
    valid = torch.stack((raw_valid, d1_valid, d2_valid), dim=1)
    return scaled, valid

def render_rgb_overlay(
    raw: torch.Tensor,
    raw_valid: torch.Tensor,
    diff1: torch.Tensor,
    diff2: torch.Tensor,
) -> torch.Tensor:
    """Render three true RGB curves on one white 224x224 canvas per patch."""
    scaled, valid = scale_curves(raw, raw_valid, diff1, diff2)
    batch, _, length = scaled.shape
    height = width = 224
    canvas = torch.full((batch, 3, height, width), 255, dtype=torch.uint8, device=raw.device)
    colors = torch.tensor(CURVE_COLORS, dtype=torch.uint8, device=raw.device)

    x_float = torch.arange(width, device=raw.device, dtype=torch.float32)
    x_float.mul_((length - 1) / (width - 1))
    left = x_float.floor().long()
    right = x_float.ceil().long().clamp_max(length - 1)
    alpha = (x_float - left.float()).view(1, width)

    point_x = torch.round(
        torch.arange(length, device=raw.device, dtype=torch.float32)
        * (width - 1) / max(length - 1, 1)
    ).long()

    for curve in range(3):
        curve_values = scaled[:, curve]
        curve_valid = valid[:, curve]
        interpolated = curve_values[:, left] * (1.0 - alpha) + curve_values[:, right] * alpha
        y_index = torch.round((height - 1) * (1.0 - interpolated)).long()
        line_valid = curve_valid[:, left] & curve_valid[:, right]
        b_idx, x_idx = line_valid.nonzero(as_tuple=True)
        if b_idx.numel():
            y_idx = y_index[b_idx, x_idx]
            color = colors[curve].view(1, 3)
            for offset in (-1, 0, 1):
                canvas[b_idx, :, (y_idx + offset).clamp(0, height - 1), x_idx] = color

        point_y = torch.round((height - 1) * (1.0 - curve_values)).long()
        b_idx, p_idx = curve_valid.nonzero(as_tuple=True)
        if b_idx.numel():
            canvas[b_idx, :, point_y[b_idx, p_idx], point_x[p_idx]] = colors[curve].view(1, 3)
    return canvas

