"""Original 210w GIF loaders + audited Chronos/TIME cache, exact FAMILY quotas."""
import json
import os
from pathlib import Path
import random
import sys
import numpy as np
from torch.utils.data import IterableDataset
from batching import quotas, collate

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT/"gift210_loader"), str(ROOT/"vendor/gift_src")]

def unbatch(dataset, kind):
    for batch in dataset:
        for i in range(len(batch["target"])):
            yield (batch["target"][i].numpy(), batch["target_mask"][i].numpy(),
                   int(batch["sequence_length"][i]), kind,
                   str(batch["source_dataset"][i]), str(batch["source_term"][i]))

class Mixed(IterableDataset):
    def __init__(self, batch_size, seed, **kwargs):
        self.batch_size, self.seed = batch_size, seed
        self.sample_pool_size = int(kwargs.get("sample_pool_size", 61440))
        self.skip_samples = int(kwargs.get("skip_samples", 0))

    def __iter__(self):
        cache = Path(os.environ["FOUR_SOURCE_CACHE"])
        ready = json.loads((cache/"READY.json").read_text())
        cfg = ready["config"]
        names = ["gifteval_pretrain", "gifteval_train", "chronos", "time_train"]
        ratios = [cfg["source_ratios"][n] for n in names]
        if any(w < 0 for w in ratios) or sum(ratios) <= 0:
            raise ValueError("Invalid source_ratios")
        total = int(os.environ["FOUR_SOURCE_TOTAL"])
        counts = quotas(total, ratios)
        rank, world = int(os.getenv("RANK",0)), int(os.getenv("WORLD_SIZE",1))
        local_counts, offset = [], 0
        for count in counts:
            first = (rank-offset)%world
            local_counts.append(max(0,(count-first+world-1)//world))
            offset += count
        os.environ["GIFT_EVAL"] = cfg["roots"]["gifteval_train"]
        from load_gifteval_toto2_cpm_pretrain import Toto2CPMPretrainDataset, Toto2CPMGIFTEvalDataset
        class NoUnusedTestHistory:
            def _set_official_history_lengths(self, values_by_config):
                # CPM overrides _sample_short_windows with full-window sampling.
                # Do not read test_data.input merely to populate unused short-history tables.
                self.official_history_lengths = {}
                self.official_history_configs = ()
                self.eligible_histories_by_horizon = {}
                self.eligible_configs_by_horizon = {}
        class Pretrain(NoUnusedTestHistory, Toto2CPMPretrainDataset):
            pass
        class Gift(NoUnusedTestHistory, Toto2CPMGIFTEvalDataset):
            pass
        common = dict(toto2_sequence_length=8192, max_seq_len=8192, max_pred_len=8192,
            batch_size=self.batch_size, output_patch_size=32, patch_len=32,
            min_history_len=2,min_pred_len=1,history_patch_multiple=False,
            prediction_patch_multiple=False,curriculum_enable=False,
            short_prediction_lengths=[32],official_history_lengths={},
            sample_pool_size=self.sample_pool_size,samples_per_dataset_block=128,windows_per_series=16,log_interval=1024)
        streams = {}
        if local_counts[0]:
            streams[0] = iter(unbatch(Pretrain(data_dir=cfg["roots"][names[0]],
                seed=self.seed+11,samples_per_arrow=512,arrow_row_chunk_size=4096,
                prefetch_pools=32,arrow_cache_size=512,**common),0))
        if local_counts[1]:
            streams[1] = iter(unbatch(Gift(gift_eval_path=cfg["roots"][names[1]],
                gift_eval_src=str(ROOT/"vendor/gift_src"),dataset_names="all",terms="all",
                seed=self.seed+29,**common),1))
        def cached(kind):
            rng = random.Random(self.seed+rank*1009+kind*9176)
            sources = [s for s in ready["sources"] if s["kind"]==names[kind]]
            if not sources:
                raise ValueError(f"No audited cache for {names[kind]}")
            banks = []
            for s in sources:
                base = cache/s["cache"]
                records = json.loads((base/"index.json").read_text())
                banks.append((s, records, np.memmap(base/"values.f32",dtype="<f4",mode="r")))
            while True:
                pool=[]
                order=list(range(len(banks)))
                rng.shuffle(order)
                for b in order:
                    s, records, flat=banks[b]
                    indices=list(range(len(records)))
                    rng.shuffle(indices)
                    block=[]
                    for index in indices:
                        r=records[index]
                        x=flat[r["offset"]:r["offset"]+r["length"]]
                        for _ in range(1 if len(x)<=8192 else 16):
                            start=0 if len(x)<=8192 else rng.randint(0,len(x)-8192)
                            values=x[start:start+8192]
                            out=np.full(8192,np.nan,dtype=np.float32)
                            out[-len(values):]=values
                            mask=np.isfinite(out).astype(np.float32)
                            if (mask.reshape(-1,32).sum(-1)>0).sum()<2:
                                continue
                            block.append((out,mask,len(values),2 if kind==2 else 4,s["dataset"],s.get("term","none")))
                            if len(block)>=128: break
                        if len(block)>=128: break
                    pool.extend(block)
                if not pool:
                    raise ValueError("No >=2-valid-patch windows in audited source")
                rng.shuffle(pool)
                yield from pool
        for kind in (2,3):
            if local_counts[kind]: streams[kind]=iter(cached(kind))
        # Exact totals, but batches interleave source families rather than four long runs.
        remaining=local_counts.copy()
        rng=random.Random(self.seed+rank*1543)
        batch=[]
        skip=self.skip_samples
        while sum(remaining):
            kind=rng.choices(range(4),weights=remaining,k=1)[0]
            item=next(streams[kind])
            remaining[kind]-=1
            if skip>0:
                skip-=1
                continue
            batch.append(item)
            if len(batch)==self.batch_size:
                yield collate(batch)
                batch=[]
        if batch: yield collate(batch)

def create_toto2_cpm_pretraining_dataset(**kwargs):
    return Mixed(**kwargs)
