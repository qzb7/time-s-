"""Official test-history views, without accessing future labels."""
import json
import os
from pathlib import Path
import sys

import numpy as np
from torch.utils.data import IterableDataset
from batching import collate

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from test_inputs import open_dataset,rank_views


def history_segment(entry, width):
    """Tail-crop the history, preserving NaN missingness and left padding."""
    history=np.asarray(entry['target'],dtype=np.float32)
    if history.ndim!=1 or not 0 < width <= 8192:
        raise ValueError('Unexpected history shape or crop width')
    segment=history[-width:]
    values=np.full(8192,np.nan,dtype=np.float32)
    if len(segment):
        values[-len(segment):]=segment
    mask=np.isfinite(values).astype(np.float32)
    info=dict(segment_length=len(segment),full_history_length=len(history),
        history_start=max(0,len(history)-width),history_end=len(history),
        left_padding=8192-len(segment))
    return values,mask,info


class TestInputDataset(IterableDataset):
    def __init__(self,batch_size,seed,**kwargs):
        self.batch_size=batch_size

    def __iter__(self):
        plan=json.loads(Path(os.environ['TEST_INPUT_PLAN']).read_text())
        if plan.get('version')!=3 or plan.get('labels_accessed') is not False:
            raise ValueError('Expected a version-3 history-only test plan')
        rank,world=int(os.getenv('RANK',0)),int(os.getenv('WORLD_SIZE',1))
        out=Path(os.environ['TEST_INPUT_SHARDS'])
        out.mkdir(parents=True,exist_ok=True)
        expected=max(0,(plan['total']-rank+world-1)//world)
        done=0
        batch=[]
        with (out/f'samples-rank-{rank:04d}.jsonl').open('x') as audit:
            for task in plan['tasks']:
                desired=rank_views(task,rank,world)
                if not desired:
                    continue
                ds=open_dataset(task)
                if ds.hf_dataset._fingerprint!=task['fingerprint']:
                    raise ValueError('Dataset fingerprint changed after test plan')
                remaining=set(desired)
                # Deliberately access input only. NEVER access test_data.label.
                for index,entry in enumerate(ds.test_data.input):
                    if index not in remaining:
                        continue
                    for global_id,view_index,width in desired[index]:
                        values,mask,info=history_segment(entry,width)
                        audit.write(json.dumps(dict(global_id=global_id,local_row=done,
                            benchmark=task['benchmark'],dataset=task['dataset'],term=task['term'],
                            official_input_index=index,item_id=str(entry.get('item_id','')),
                            view_index=view_index,requested_crop_length=width,**info,
                            prediction_length=task['horizon'],series_start=str(entry.get('start','')),
                            labels_accessed=False))+'\n')
                        done+=1
                        batch.append((values,mask,info['segment_length'],task['source_type'],task['dataset'],task['term']))
                        if len(batch)==self.batch_size:
                            audit.flush()
                            yield collate(batch)
                            batch=[]
                    remaining.remove(index)
                    if not remaining:
                        break
                if remaining:
                    raise ValueError(f'Official input stream ended early:{task["key"]}')
            if batch:
                audit.flush()
                yield collate(batch)
        if done!=expected:
            raise ValueError(f'Rank count mismatch:{done}!={expected}')


def create_toto2_cpm_pretraining_dataset(**kwargs):
    return TestInputDataset(**kwargs)
