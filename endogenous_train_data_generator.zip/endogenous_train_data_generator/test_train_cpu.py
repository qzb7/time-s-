"""CPU contracts for retained training loaders, with external I/O stubbed."""
import ast
import hashlib
import importlib
import json
import os
from pathlib import Path
import random
import sys
import tempfile
import types

import numpy as np

ROOT=Path(__file__).resolve().parent
sys.path[:0]=[str(ROOT/'encoder'),str(ROOT/'gift210_loader')]
torch=types.ModuleType('torch')
torch.tensor=np.asarray
torch.uint8=np.uint8
torch.Tensor=np.ndarray
data=types.ModuleType('torch.utils.data')
data.IterableDataset=object
data.get_worker_info=lambda:None
hf=types.ModuleType('datasets')
hf.Dataset=object
sys.modules.update({'torch':torch,'torch.utils.data':data,'datasets':hf,'pyarrow':types.ModuleType('pyarrow')})

# All retained top-level definitions have the original AST signatures.
def canonical(node):
    if isinstance(node,ast.AST):
        return [type(node).__name__,[(name,canonical(value)) for name,value in ast.iter_fields(node) if name!='type_params']]
    if isinstance(node,list): return [canonical(value) for value in node]
    return node

signatures=json.loads((ROOT/'core_code_signatures.json').read_text())
for file,expected in signatures.items():
    tree=ast.parse((ROOT/file).read_text())
    definitions={n.name:n for n in tree.body if isinstance(n,(ast.ClassDef,ast.FunctionDef))}
    for name,wanted in expected.items():
        actual=hashlib.sha256(json.dumps(canonical(definitions[name]),sort_keys=True).encode()).hexdigest()
        assert actual==wanted,(file,name)

cpm=importlib.import_module('load_gifteval_toto2_cpm_pretrain')
sample=cpm.Toto2CPMPretrainDataset.__new__(cpm.Toto2CPMPretrainDataset)
sample.max_sequence_length=8192
sample.patch_len=32
sample.windows_per_series=16
for length in (16,80,10000):
    x=np.arange(length,dtype=np.float32)
    if length>32: x[10:20]=np.nan
    windows=sample._sample_toto2_windows(x,random.Random(42),16)
    if length==16:
        assert windows==[]  # Original minimum two-valid-patch training rule.
    else:
        assert len(windows)==(1 if length<=8192 else 16)
        for window in windows:
            assert len(window['target'])==8192
            assert np.all(window['target_mask']==np.isfinite(window['target']))
            assert (window['target_mask'].reshape(-1,32).sum(-1)>0).sum()>=2

from batching import quotas
for total in (1,32,103,10000000):
    assert sum(quotas(total,[40,25,20,15]))==total

# Substitute only external GIFTEval reading; keep Mixed and cached sampling real.
mix=importlib.import_module('gift210_mix_loader')
class FakeGift:
    def __init__(self,**kwargs): pass
    def __iter__(self):
        x=np.full(8192,np.nan,dtype=np.float32)
        x[-80:]=np.arange(80,dtype=np.float32)
        while True: yield (x,np.isfinite(x).astype(np.float32),80)
fake=types.ModuleType('load_gifteval_toto2_cpm_pretrain')
fake.Toto2CPMPretrainDataset=FakeGift
fake.Toto2CPMGIFTEvalDataset=FakeGift
sys.modules['load_gifteval_toto2_cpm_pretrain']=fake
mix.unbatch=lambda dataset,kind:((x,mask,length,kind,f'fake-{kind}','none') for x,mask,length in dataset)

with tempfile.TemporaryDirectory(prefix='generator-training-') as tmp:
    cache=Path(tmp)
    sources=[]
    for kind in ('chronos','time_train'):
        base=cache/kind
        base.mkdir()
        x=np.arange(100,dtype='<f4')
        x[10:20]=np.nan
        (base/'values.f32').write_bytes(x.tobytes())
        (base/'index.json').write_text(json.dumps([dict(offset=0,length=100)]))
        sources.append(dict(kind=kind,cache=kind,dataset=kind,term='short'))
    cfg=dict(roots={kind:'unused-mocked' for kind in ('gifteval_pretrain','gifteval_train','chronos','time_train')},
        source_ratios=dict(gifteval_pretrain=40,gifteval_train=25,chronos=20,time_train=15))
    (cache/'READY.json').write_text(json.dumps(dict(sources=sources,config=cfg)))
    os.environ.update(FOUR_SOURCE_CACHE=str(cache),FOUR_SOURCE_TOTAL='103')
    for world in (6,32):
        counts={0:0,1:0,2:0,4:0}
        os.environ['WORLD_SIZE']=str(world)
        for rank in range(world):
            os.environ['RANK']=str(rank)
            batches=list(mix.Mixed(batch_size=7,seed=42))
            assert sum(len(b['target']) for b in batches)==max(0,(103-rank+world-1)//world)
            for batch in batches:
                assert np.all(batch['target_mask']==np.isfinite(batch['target']))
                for kind in batch['source_type']: counts[int(kind)]+=1
        assert list(counts.values())==quotas(103,[40,25,20,15]),counts
print('PASS CPU training: retained-code signatures, original window rule, missingness, exact four-family quotas across 6/32 ranks')
