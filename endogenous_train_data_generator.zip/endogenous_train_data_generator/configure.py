"""Validate and atomically record launch/source configuration; no launching."""
import argparse
import hashlib
import json
import math
from pathlib import Path

ROOT=Path(__file__).resolve().parent
FAMILIES=dict(pretrain='gifteval_pretrain',gifteval='gifteval_train',chronos='chronos',time='time_train')

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--config',type=Path,default=ROOT/'sources.json')
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--clip-checkpoint',type=Path,required=True)
    p.add_argument('--total',type=int,required=True)
    p.add_argument('--gifteval-test-count',type=int,default=0)
    p.add_argument('--time-test-count',type=int,default=0)
    p.add_argument('--seed',type=int,required=True)
    p.add_argument('--dry-run',action='store_true')
    for name in FAMILIES:
        p.add_argument('--'+name+'-dir',type=Path,required=True)
        p.add_argument('--'+name+'-ratio',type=float,required=True)
    a=p.parse_args()
    if a.total<0 or min(a.gifteval_test_count,a.time_test_count)<-1:
        p.error('total >= 0; test count must be -1, 0, or a positive integer')
    if a.total==a.gifteval_test_count==a.time_test_count==0:
        p.error('No generation requested')
    cfg=json.loads(a.config.read_text())
    if cfg.get('loader_mode')!='gift210_four_source':
        p.error('Only the original gift210_four_source loader is supported')
    for short,kind in FAMILIES.items():
        cfg['roots'][kind]=str(getattr(a,short+'_dir').resolve())
        ratio=getattr(a,short+'_ratio')
        if not math.isfinite(ratio) or ratio<0:
            p.error('Source weights must be finite and nonnegative')
        cfg['source_ratios'][kind]=ratio
    if a.total and sum(cfg['source_ratios'].values())<=0:
        p.error('Training source weights must sum to a positive number')
    launch=dict(training_count=a.total,gifteval_test_count=a.gifteval_test_count,
        time_test_count=a.time_test_count,seed=a.seed,labels_accessed=False,
        clip_checkpoint=str(a.clip_checkpoint.resolve()))
    if a.dry_run:
        print(json.dumps(dict(launch=launch,sources=cfg),indent=2))
        return
    if a.output.exists() and any(a.output.iterdir()):
        raise FileExistsError(f'Choose a NEW/empty output directory: {a.output}')
    h=hashlib.sha256()
    with a.clip_checkpoint.open('rb') as stream:
        for chunk in iter(lambda:stream.read(1024*1024),b''): h.update(chunk)
    if h.hexdigest()!='40d365715913c9da98579312b702a82c18be219cc2a73407c4526f58eba950af':
        raise ValueError('CLIP checkpoint checksum mismatch')
    a.output.mkdir(parents=True,exist_ok=True)
    (a.output/'sources.resolved.json').write_text(json.dumps(cfg,indent=2))
    temp=a.output/'launch.tmp.json'
    temp.write_text(json.dumps(launch,indent=2))
    temp.replace(a.output/'launch.json')

if __name__=='__main__':
    main()
