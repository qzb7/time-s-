"""Scan existing zarr shards and report the safe resume start_block.

一个 block 只有在其 written_count 达到该 rank 的每-block 样本数时才视为完整。
安全断点 = 所有 rank 都完整写好的最大 block 号 + 1；再往后的 block 可能是
半成品（某个 rank 写了一半或未写），续跑时由 extract 的 writer 覆盖重建。
"""
import argparse
import shutil
import sys
from pathlib import Path

import zarr


def scan(shards: Path, world: int, block_size: int) -> int:
    local_block_size = (block_size + world - 1) // world
    complete_by_rank = {}
    for p in shards.glob("block-*.rank-*.zarr"):
        stem = p.name[: -len(".zarr")]  # block-000001.rank-00
        block_part, rank_part = stem.split(".rank-")
        block_idx = int(block_part.split("-")[1])
        rank = int(rank_part)
        try:
            g = zarr.open_group(str(p), mode="r")
            written = int(g.attrs.get("written_count", 0))
        except Exception:
            written = 0
        if written >= local_block_size:
            complete_by_rank.setdefault(rank, set()).add(block_idx)

    if len(complete_by_rank) != world:
        # 至少有一个 rank 连一个完整 block 都没有，只能从头开始。
        return 0

    common = set.intersection(*complete_by_rank.values())
    if not common:
        return 0
    return max(common) + 1


def clean(shards: Path, start_block: int) -> None:
    """删除 >= start_block 的 block 分片以及旧 DONE 标记，避免残留半成品。"""
    if start_block <= 0:
        return
    for p in shards.glob("block-*.rank-*.zarr"):
        stem = p.name[: -len(".zarr")]
        block_idx = int(stem.split(".rank-")[0].split("-")[1])
        if block_idx >= start_block:
            shutil.rmtree(p, ignore_errors=True)
    for p in shards.glob("block-*.rank-*.zarr.metadata.jsonl"):
        stem = p.name[: -len(".zarr.metadata.jsonl")]
        block_idx = int(stem.split(".rank-")[0].split("-")[1])
        if block_idx >= start_block:
            p.unlink(missing_ok=True)
    for p in shards.glob("DONE-rank-*.json"):
        p.unlink(missing_ok=True)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--shards", type=Path, required=True)
    ap.add_argument("--world", type=int, required=True)
    ap.add_argument("--block-size", type=int, required=True)
    ap.add_argument("--clean", action="store_true", help="删除断点之后的半成品分片和旧 DONE 标记")
    a = ap.parse_args()

    start_block = scan(a.shards, a.world, a.block_size)
    print(start_block, flush=True)
    if a.clean:
        clean(a.shards, start_block)
        print(f"cleaned shards >= block {start_block}", file=sys.stderr, flush=True)
    sys.exit(0)
