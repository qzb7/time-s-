# 内源多模态数据生成器：简化 torchrun 版

只保留当前生成流程使用的代码。`start_generator.sh` 直接执行准备、torchrun
生成和合并，不再通过 `generate.py` / 多层启动器。

## 直接运行

激活已有 CUDA Torch 环境，数据路径与默认 `/data/...` 一致时：

```bash
bash start_generator.sh \
  --total 10000000 \
  --gifteval-test-count 200000 \
  --time-test-count 200000 \
  --output /data/multimodal_10m_testhistory_400k_simple
```

完整命令（可覆盖默认数据路径）：

```bash
bash start_generator.sh \
  --pretrain-dir /data/GIFTEvalPretrain \
  --gifteval-dir /data/GIFTEval \
  --chronos-dir /data/chronos \
  --time-dir /data/TIME \
  --pretrain-ratio 40 --gifteval-ratio 25 --chronos-ratio 20 --time-ratio 15 \
  --total 10000000 \
  --gifteval-test-count 200000 \
  --time-test-count 200000 \
  --batch-size 64 --group-size 128 --clip-batch 16384 \
  --workers 16 --prefetch 6 --seed 20260911 \
  --output /data/multimodal_10m_testhistory_400k_simple
```

也可直接修改 `start_generator.sh` 开头的路径、配额和编码批大小，然后：

```bash
bash start_generator.sh
```

默认训练100万条，两个测试历史 count 默认0。省略 `--gpus` 自动检测本节点
可见CUDA GPU，不会识别哪些卡空闲。CLIP默认读取包内权重。
使用当前 `python -m torch.distributed.run`，与 `torchrun` 是同一入口；不依赖
可能来自其他环境的独立 torchrun 命令。可用 `--python /path/to/python` 覆盖。
此脚本需要 Bash，不能用 `sh start_generator.sh`。

## 配额

| 参数 | 含义 |
| --- | --- |
| `--total N` | 四源训练部分合计 N 条；0跳过训练生成 |
| `--gifteval-ratio R` | GIFTEval训练家族的相对权重，按四项权重之和归一化 |
| `--gifteval-test-count N` | GIFTEval官方测试历史视图合计N条，与训练配额独立 |
| `--time-test-count N` | TIME官方测试历史视图合计N条，与训练配额独立 |

测试 count：0跳过；正数精确生成该数量；-1取已安装setting的所有官方单变量
测试窗口各一次。数量分配在已安装setting间均分，余数按固定种子排序分配。
不是每个setting各N条，也不是N条互不重叠的独立序列。
若quota超过该setting可用窗口数，循环窗口并按
`8192, 6144, 4096, 3072, 2048` 切换尾部裁剪长度。

测试阶段**仅读取 `test_data.input`，不访问 `test_data.label`**。
每个滚动窗口读取预测起点前的历史，多变量先拆成单变量。短历史左padding至8192，
padding与缺失保留mask，不当成观测零。若测试历史用来继续训练，应声明为
transductive adaptation，而不是严格零样本。

## 多机：例如4节点，每节点8卡

每个节点执行相同生成命令一次，并设置节点信息：

```bash
# 所有节点NNODES/MASTER_ADDR相同，NODE_RANK依次为0、1、2、3。
export NNODES=4
export NODE_RANK=0
export MASTER_ADDR=10.0.0.1
export MASTER_PORT=29777

bash start_generator.sh \
  --total 10000000 \
  --gifteval-test-count 200000 \
  --time-test-count 200000 \
  --output /shared/multimodal_10m_testhistory_400k_simple
```

主节点地址必须改为其他节点可访问的实际地址，output必须是共享目录。
若调度器已经提供节点变量，不需重复export。默认master port29777；可CLI覆盖。
`--gpus`指**每节点**卡数，不要把4×8卡写成`--gpus 32`。
平台已提供完整`RANK/WORLD_SIZE/LOCAL_RANK`时，直接执行rank worker，不嵌套torchrun。

## 预览与后台

在命令末尾加 `--dry-run`，检查参数和编码启动命令，不启动GPU。
为精简入口，删除内部后台启动/序列化包装；`--launch-mode foreground`仍接受，
background不再支持。单机后台使用标准方式：

```bash
nohup bash start_generator.sh \
  --total 10000000 \
  --gifteval-test-count 200000 \
  --time-test-count 200000 \
  --output /data/multimodal_simple_background \
  > generator.log 2>&1 < /dev/null &
```

多机平台提交作业时使用前台命令，由调度器管理。

## 输出与安全检查

- 训练结果：`OUTPUT/merged/COMPLETE.json`。
- 测试历史结果：`OUTPUT/test_inputs/merged/COMPLETE.json`。
- 训练来源：`OUTPUT/sources.resolved.json`；启动配额：`OUTPUT/launch.json`。
- 测试计划与逐样本审计：`OUTPUT/test_inputs/plan.json` 与 `samples-rank-XXXX.jsonl`。

全局rank0准备一次，其他节点等待共享ready标记；每张卡分片生成；全局rank0在
全部DONE标记齐全、数量核对一致后合并。失败后不合并，留下`FAILED-*`。
原始分片保留。output必须是新/空目录，不覆盖旧结果，不停止其他GPU任务。
等待超时默认86400秒，可用 `GENERATOR_TIMEOUT` 环境变量覆盖。

## 核心逻辑与验证

沿用原32点patch、8192点宽度、文本模板、CLIP编码、RGB原值/单步差分/两步差分
渲染，以及FP16 token+scale保存格式。保留的训练类和渲染函数已核对原代码AST一致。
删除项与调用关系见 [CALL_GRAPH.md](CALL_GRAPH.md)。

```bash
bash -n start_generator.sh
python test_launch.py
python test_discovery.py
python test_test_inputs.py
python test_train_cpu.py
```

这些为CPU契约测试，Torch/外部数据读取或encoder有桩替代，**不是实际GPU/CLIP
数值或真实多机吞吐验收**。本次没有启动GPU生成、安装依赖或改动服务器。
`requirements.txt` 补充原文本模板需要的 `statsmodels==0.14.6`；不要盲目升级已有Torch。
