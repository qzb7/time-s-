# 当前代码调用关系与清理记录

## 主调用链

```text
start_generator.sh
│
├─ configure.py                          校验参数/CLIP，写启动配置和来源配置
│
├─ [训练部分，total > 0]
│  ├─ prepare.py                         全局rank0准备训练缓存
│  │  ├─ discover_sources.py             发现TIME/Chronos来源、验证准入映射
│  │  └─ vendor/*/data.py                官方训练split与Chronos训练前缀验证
│  ├─ python -m torch.distributed.run
│  │  └─ encoder/extract.py              每张GPU执行同一个编码器
│  │     └─ encoder/gift210_mix_loader.py 精确四源配额和源内采样
│  │        ├─ gift210_loader/*           原GIFTEval训练采样类及必要父类
│  │        ├─ prepare产生的TIME/Chronos缓存
│  │        └─ encoder/batching.py        配额取整和batch打包
│  └─ merge.py                          全部rank完成后合并训练结果
│
└─ [测试历史部分，任一test count非0]
   ├─ prepare_test_inputs.py             全局rank0建立setting/视图配额计划
   │  ├─ gifteval_test_catalogue.json     GIFTEval 97 setting目录
   │  ├─ vendor/time_src/.../datasets.yaml
   │  └─ test_inputs.py + vendor/*/data.py 官方窗口数量与确定性裁剪规划
   ├─ python -m torch.distributed.run
   │  └─ encoder/extract.py              与训练部分相同的编码器
   │     └─ encoder/test_input_loader.py 只读test_data.input，按全局rank分片
   │        ├─ test_inputs.py             打开官方数据/分配窗口视图
   │        └─ encoder/batching.py        batch打包
   └─ merge.py                          全部rank完成后合并测试历史结果
```

`encoder/extract.py` 的共同编码链：

```text
数值+mask
  ├─ encoder/toto2_stats_template.py -> patch文本 -> CLIP文本编码
  └─ encoder/render_rgb.py           -> patch图像 -> CLIP图像编码
                    ↓
              每rank Zarr分片+DONE标记
                    ↓
                merge.py
```

`render_rgb.py`从原重写脚本中提取三个渲染函数，函数实现保持原AST一致。
单步差分为相邻点之差；两步差分沿用原实现，为间隔两个点之差，未改成二次离散导数。

## 文件责任边界

| 文件 | 修改时应关注什么 |
| --- | --- |
| `start_generator.sh` | 默认数据路径、训练/测试数量、GPU/节点、编码批量；只负责顺序和启动 |
| `configure.py` | 权重/数量校验、来源配置落盘，不启动子进程 |
| `prepare.py`、`discover_sources.py` | 训练数据来源和前缀保护，不读取测试输入或标签 |
| `encoder/gift210_mix_loader.py` | 四源训练比例、交错混合；实际GIFTEval采样依赖原训练类 |
| `prepare_test_inputs.py`、`test_inputs.py` | 测试setting数量、视图重复及裁剪策略 |
| `encoder/test_input_loader.py` | 只读取测试历史；mask、padding、逐样本审计 |
| `encoder/extract.py` | CLIP编码、进程池和分片保存，不决定测试配额 |
| `encoder/render_rgb.py`、`encoder/toto2_stats_template.py` | 图像/文本生成规则 |
| `merge.py` | 检查全局完成/样本总数，合并并保留原始分片 |

## 新版包删除的无用路径

只在新包中精简；此前原包和v4包均保留，随时可以恢复。

- 删除旧 `generate.py`、`options.py`、`resolve_sources.py` 多层入口。
  唯一入口是 `start_generator.sh`，必要配置校验合并到 `configure.py`。
- 删除 `legacy/` 的重复loader及旧GIFTEval启动脚本。
- 删除未使用的 `FourSourceDataset`；只提取仍使用的 `quotas`、`collate` 到 `batching.py`。
- 删除旧Zarr后处理重写入口；只提取使用中的渲染函数到 `render_rgb.py`。
- 从三个原GIFTEval loader删除当前流程未引用的旧混合策略、工厂函数、prepared
  Arrow及多变量训练类。保留两个实际CPM类、必要父类和所有依赖辅助函数。
  这是生成器固定单变量训练流程的精简，不是把官方多变量测试窗口删除。
- vendor只保留数据API、包初始化、TIME配置；删除评测metrics/saver/model、feature、
  analysis、builder/preprocess及 `.bak` 文件，并去掉包初始化中对已删评测模块的导入。
- 删除旧README/MULTINODE/TEST_HISTORY的重复或过时说明，整合为当前README和本文。
- 删除旧入口/旧loader的过时测试；保留当前入口、历史读取、发现与训练契约测试。
- 不打包 `.DS_Store`、`__pycache__`、`.pyc`。

没有删除模型生成实际需要的CLIP权重、文本模板、原采样父类、官方data API，
也没有删除保留源码中的版权/许可声明。

## 验证边界

通过语法、参数传递、预启动rank不嵌套torchrun、mock双节点同步、失败不合并、
旧输出保护、训练配额和裁剪mask，以及标签访问禁止测试。
`core_code_signatures.json` 记录保留的训练类/辅助函数/图像渲染函数原AST签名，
`test_train_cpu.py` 逐项验证未改写它们。没有进行真实数据GPU生成验收。
