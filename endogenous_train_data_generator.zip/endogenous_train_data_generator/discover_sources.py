"""Expand all into a recorded allow-list, never silently waive Chronos audit."""
from pathlib import Path

# Candidate mappings only; prepare.py still proves exact value-prefix equality.
GIFT_MATCHES = {
    "electricity_15min": ("electricity/15T", ["short","medium","long"], ["consumption_kW"]),
    "m4_daily": ("m4_daily", ["short"], ["target"]),
    "m4_hourly": ("m4_hourly", ["short"], ["target"]),
    "m4_yearly": ("m4_yearly", ["short"], ["target"]),
    "m4_monthly": ("m4_monthly", ["short"], ["target"]),
    "m4_quarterly": ("m4_quarterly", ["short"], ["target"]),
    "m4_weekly": ("m4_weekly", ["short"], ["target"]),
    "solar_1h": ("solar/H", ["short","medium","long"], ["power_mw"]),
    "solar": ("solar/10T", ["short","medium","long"], ["power_mw"]),
    "monash_kdd_cup_2018": ("kdd_cup_2018_with_missing/H", ["short","medium","long"], ["target"]),
    "monash_temperature_rain": ("temperature_rain_with_missing", ["short"], ["t_mean","prcp_sum","t_max","t_min"]),
}

def expand(cfg, time_config):
    result, excluded = [], []
    for source in cfg["sources"]:
        kind=source["kind"]
        if source["dataset"]!="all" or kind in {"gifteval_pretrain","gifteval_train"}:
            result.append(source)
            continue
        root=Path(cfg["roots"][kind])
        if kind=="time_train":
            for name, setting in sorted(time_config["datasets"].items()):
                if not (root/name).is_dir():
                    excluded.append(dict(kind=kind,dataset=name,reason="not_installed"))
                    continue
                terms=[term for term in ("short","medium","long") if term in setting]
                if not terms:
                    raise ValueError(f"No official terms for TIME {name}")
                result.append(dict(kind=kind,dataset=name,train_terms=terms,auto_discovered=True))
        elif kind=="chronos":
            names=sorted({str(p.parent.relative_to(root)) for p in root.rglob("*.parquet")})
            overrides=source.get("reference_overrides",{})
            for name in names:
                if name in overrides:
                    item=dict(overrides[name],kind=kind,dataset=name,auto_discovered=True)
                elif name in GIFT_MATCHES:
                    gift,terms,columns=GIFT_MATCHES[name]
                    item=dict(kind=kind,dataset=name,target_columns=columns,auto_discovered=True,
                              train_reference=dict(kind="gifteval_train",dataset=gift,terms=terms))
                else:
                    excluded.append(dict(kind=kind,dataset=name,reason="no_verified_reference_mapping"))
                    continue
                ref=item["train_reference"]
                if not (Path(cfg["roots"][ref["kind"]])/ref["dataset"]).is_dir():
                    excluded.append(dict(kind=kind,dataset=name,reason="reference_not_installed"))
                    continue
                result.append(item)
        else:
            raise ValueError(kind)
    for kind in ("chronos","time_train"):
        if cfg.get("source_ratios",{}).get(kind,0)>0 and not any(s["kind"]==kind for s in result):
            raise ValueError(f"No eligible {kind} discovered; cannot satisfy its quota")
    return result, excluded
