"""Build an immutable, training-only float32 cache; no GPU use."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import sys
import numpy as np

ROOT = Path(__file__).resolve().parent
sys.path[:0] = [str(ROOT / "vendor/gift_src"), str(ROOT / "vendor/time_src")]

def channels(value):
    x = np.asarray(value, dtype=np.float32)
    if x.ndim == 1:
        return [x]
    if x.ndim == 2:
        return list(x)
    raise ValueError(f"Expected [time] or [variable,time], got {x.shape}")

def digest(x):
    x = np.array(x, dtype="<f4", copy=True)
    x[np.isnan(x)] = np.nan
    x[x == 0] = 0
    return hashlib.sha256(x.tobytes()).hexdigest()

def safe_prefix(x, references):
    """Only return bytes contained in an exact official TRAIN prefix."""
    best = 0
    for ref in references:
        n = min(len(x), len(ref))
        if n >= 32 and np.array_equal(x[:n], ref[:n], equal_nan=True):
            best = max(best, n)
    return best

def main():
    p = argparse.ArgumentParser()
    p.add_argument("config", type=Path)
    p.add_argument("output", type=Path)
    a = p.parse_args()
    cfg = json.loads(a.config.read_text())
    if a.output.exists():
        raise FileExistsError("Choose a new cache directory; never overwrite a prepared cache")
    a.output.mkdir(parents=True)
    os.environ["GIFT_EVAL"] = cfg["roots"]["gifteval_train"]
    os.environ["TIME_DATASET"] = cfg["roots"]["time_train"]
    from gift_eval.data import Dataset as GiftDataset
    from timebench.evaluation.data import Dataset as TimeDataset, get_dataset_settings, load_dataset_config
    from datasets import Dataset as ArrowDataset
    import pyarrow.parquet as pq
    time_config = load_dataset_config(ROOT / "vendor/time_src/timebench/config/datasets.yaml")
    from discover_sources import expand
    expanded, exclusions = expand(cfg, time_config)
    (a.output/"discovery.json").write_text(json.dumps({"sources":expanded,"excluded":exclusions},indent=2))
    summary = {"sources": [], "excluded": [], "policy": "official_training_split_and_chronos_exact_train_prefix_v1"}
    summary["excluded"].extend(exclusions)
    reference_cache = {}

    def official(kind, name, term):
        if kind == "gifteval_train":
            ds = GiftDataset(name=name, term=term, to_univariate=False)
        elif kind == "time_train":
            settings = get_dataset_settings(name, term, time_config)
            ds = TimeDataset(name=name, term=term, to_univariate=False,
                             storage_path=cfg["roots"][kind], **settings)
        else:
            raise ValueError(kind)
        # No test_data.input or test_data.label access here.
        for i, row in enumerate(ds.training_dataset):
            for v, x in enumerate(channels(row["target"])):
                yield x, {"shard": "official_train", "row": i, "variable": v,
                          "item_id": str(row.get("item_id", i))}

    def references(spec):
        key = (spec["kind"], spec["dataset"], tuple(spec.get("terms", ["short", "medium", "long"])))
        if key in reference_cache:
            return reference_cache[key]
        # Require caller to enumerate valid terms; invalid/unsupported terms fail.
        by_series = {}
        for term in key[2]:
            for x, meta in official(key[0], key[1], term):
                identity = (meta["item_id"], meta["variable"])
                if identity not in by_series or len(x) < len(by_series[identity]):
                    by_series[identity] = x
        table = {}
        for x in by_series.values():
            if len(x) >= 32:
                table.setdefault(digest(x[:32]), []).append(x)
        reference_cache[key] = table
        return table

    def conservative_train(source):
        # Protect every evaluation horizon named in train_terms, not just the
        # short split (which can otherwise extend into a longer-horizon holdout).
        terms = source.get("train_terms")
        if not terms:
            raise ValueError("GIFTEval/TIME training sources require explicit train_terms covering evaluated horizons")
        rows = None
        for term in terms:
            current = {(m["row"], m["variable"]): (x, m)
                       for x, m in official(source["kind"], source["dataset"], term)}
            if rows is None:
                rows = current
                continue
            if rows.keys() != current.keys():
                raise ValueError("Training series identities differ across horizons; cannot safely align")
            for key, (x, meta) in current.items():
                previous, _ = rows[key]
                n = min(len(previous), len(x))
                if not np.array_equal(previous[:n], x[:n], equal_nan=True):
                    raise ValueError("Training prefixes differ across horizons")
                if len(x) < len(previous):
                    rows[key] = (x, meta)
        yield from rows.values()

    for index, source in enumerate(expanded):
        if cfg.get("loader_mode") == "gift210_four_source" and source["kind"] in {"gifteval_pretrain", "gifteval_train"}:
            summary["sources"].append(dict(source, streaming_original=True))
            continue
        kind, name = source["kind"], source["dataset"]
        if kind not in {"gifteval_pretrain", "gifteval_train", "time_train", "chronos"}:
            raise ValueError(kind)
        if source.get("weight", 1) <= 0:
            raise ValueError("Source weight must be positive")
        base = a.output / f"source-{index:04d}"
        base.mkdir()
        entries = []
        offset = 0
        with (base / "values.f32").open("wb") as values_file:
            def save(x, meta):
                nonlocal offset
                x = np.asarray(x, dtype="<f4").copy()
                x[~np.isfinite(x)] = np.nan
                if len(x) < 2 or not np.isfinite(x).any():
                    return
                values_file.write(x.tobytes())
                entries.append(dict(meta, offset=offset, length=len(x), sha256=digest(x)))
                offset += len(x)

            if kind in {"gifteval_train", "time_train"}:
                for x, meta in conservative_train(source):
                    save(x, meta)
            elif kind == "gifteval_pretrain":
                directory = Path(cfg["roots"][kind]) / name
                files = sorted(directory.rglob("*.arrow"))
                if not files:
                    raise ValueError(f"No Arrow files: {directory}")
                for file in files:
                    # Explicit pretrain corpus, not arbitrary benchmark test folders.
                    dataset = ArrowDataset.from_file(str(file))
                    for row_index, row in enumerate(dataset):
                        for v, x in enumerate(channels(row[source.get("target_column", "target")])):
                            save(x, {"shard": str(file.relative_to(directory)), "row": row_index, "variable": v})
            else:
                # Unknown Chronos corpora do NOT fall back to an arbitrary fixed tail cutoff.
                ref_spec = source.get("train_reference")
                if not ref_spec:
                    raise ValueError(f"Chronos {name} requires an official train_reference")
                reference = references(ref_spec)
                directory = Path(cfg["roots"][kind]) / name
                files = sorted(directory.rglob("*.parquet"))
                if not files:
                    raise ValueError(f"No Parquet files: {directory}")
                skipped = kept = 0
                columns = source.get("target_columns", ["target"])
                for file in files:
                    row_index = 0
                    for batch in pq.ParquetFile(file).iter_batches(batch_size=128, columns=columns):
                        for row in batch.to_pylist():
                            for column in columns:
                                for v, x in enumerate(channels(row[column])):
                                    candidates = reference.get(digest(x[:32]), []) if len(x) >= 32 else []
                                    n = safe_prefix(x, candidates)
                                    if not n:
                                        skipped += 1
                                        continue
                                    kept += 1
                                    save(x[:n], {"shard": str(file.relative_to(directory)), "row": row_index,
                                                 "variable": v, "column": column, "original_length": len(x),
                                                 "safe_end_exclusive": n, "proof": "exact_official_train_prefix"})
                            row_index += 1
                summary["excluded"].append({"dataset": name, "unmatched_channels": skipped, "kept_channels": kept})
        if not entries:
            if source.get("auto_discovered"):
                summary["excluded"].append(dict(kind=kind,dataset=name,reason="no_eligible_training_sequences"))
                continue
            raise ValueError(f"No eligible training sequences for {kind}/{name}; inspect configuration, do not relax safety silently")
        (base / "index.json").write_text(json.dumps(entries))
        result = dict(source, cache=base.name, series_count=len(entries), points=offset,
                      shards=len({r["shard"] for r in entries}))
        summary["sources"].append(result)
        print(json.dumps(result), flush=True)
    summary["config"] = cfg
    for kind in ("chronos","time_train"):
        if cfg.get("source_ratios",{}).get(kind,0)>0 and not any(s["kind"]==kind for s in summary["sources"]):
            (a.output/"FAILED_AUDIT.json").write_text(json.dumps(summary,indent=2))
            raise ValueError(f"No verified usable {kind}; cannot generate its requested quota")
    # Other nodes must never observe a partially written READY.json.
    ready_temp=a.output / "READY.tmp.json"
    ready_temp.write_text(json.dumps(summary, indent=2))
    ready_temp.replace(a.output / "READY.json")
    print("Prepared:", a.output, flush=True)

if __name__ == "__main__":
    main()
