"""Plan official test-history views. Future labels are never accessed."""
import hashlib
import os
from pathlib import Path
import random
import sys

ROOT = Path(__file__).resolve().parent
CROP_LENGTHS = (8192, 6144, 4096, 3072, 2048)


def view_counts(requested, capacities):
    """Positive N is an exact view quota; -1 uses each official window once."""
    if requested < -1 or any(n < 0 for n in capacities):
        raise ValueError('Invalid requested count/capacity')
    if requested == -1:
        return list(capacities)
    active = [i for i, n in enumerate(capacities) if n > 0]
    if requested and not active:
        raise ValueError('No available official test windows')
    result = [0] * len(capacities)
    if active:
        quotient, remainder = divmod(requested, len(active))
        for position, i in enumerate(active):
            result[i] = quotient + (position < remainder)
    return result


def context_order(available, count, seed, key):
    """Seeded order, then repeat it with different tail-crop lengths."""
    salt = int(hashlib.sha256(key.encode()).hexdigest()[:16], 16)
    return random.Random(seed ^ salt).sample(range(available), min(count, available))


def rank_views(task, rank, world):
    """Map an official window to all its requested views owned by this rank."""
    result = {}
    order = task['context_indices']
    if not order:
        return result
    offset = task['global_offset']
    for position in range((rank-offset) % world, task['selected'], world):
        index = order[position % len(order)]
        cycle = position // len(order)
        width = CROP_LENGTHS[cycle % len(CROP_LENGTHS)]
        result.setdefault(index, []).append((offset+position, position, width))
    return result


def dataset_api():
    sys.path[:0] = [str(ROOT/'vendor/gift_src'),str(ROOT/'vendor/time_src')]
    from gift_eval.data import Dataset as GiftDataset
    from timebench.evaluation.data import Dataset as TimeDataset
    return GiftDataset,TimeDataset


def open_dataset(task):
    GiftDataset,TimeDataset = dataset_api()
    if task['benchmark'] == 'gifteval':
        os.environ['GIFT_EVAL'] = task['data_root']
        return GiftDataset(name=task['dataset'],term=task['term'],
            to_univariate=task['num_variates'] > 1)
    return TimeDataset(name=task['dataset'],term=task['term'],
        to_univariate=task['num_variates'] > 1,storage_path=task['data_root'],
        **task['settings'])
