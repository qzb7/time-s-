import os

import queue

import random

import re

import threading

import time

import math

import sys

from collections import OrderedDict

from pathlib import Path

import numpy as np

import pyarrow as pa

import torch

from datasets import Dataset as HFDataset

from torch.utils.data import IterableDataset, get_worker_info

REPO_ROOT = Path(__file__).resolve().parent

LOCAL_GIFT_EVAL_SRC = REPO_ROOT / "foundTS-main" / "GIFT-Eval" / "src"

FALLBACK_GIFT_EVAL_SRC = Path("/home/gift-eval-scan/src")

GIFT_EVAL_SHORT_DATASETS = [
    "m4_yearly",
    "m4_quarterly",
    "m4_monthly",
    "m4_weekly",
    "m4_daily",
    "m4_hourly",
    "electricity/15T",
    "electricity/H",
    "electricity/D",
    "electricity/W",
    "solar/10T",
    "solar/H",
    "solar/D",
    "solar/W",
    "hospital",
    "covid_deaths",
    "us_births/D",
    "us_births/M",
    "us_births/W",
    "saugeenday/D",
    "saugeenday/M",
    "saugeenday/W",
    "temperature_rain_with_missing",
    "kdd_cup_2018_with_missing/H",
    "kdd_cup_2018_with_missing/D",
    "car_parts_with_missing",
    "restaurant",
    "hierarchical_sales/D",
    "hierarchical_sales/W",
    "LOOP_SEATTLE/5T",
    "LOOP_SEATTLE/H",
    "LOOP_SEATTLE/D",
    "SZ_TAXI/15T",
    "SZ_TAXI/H",
    "M_DENSE/H",
    "M_DENSE/D",
    "ett1/15T",
    "ett1/H",
    "ett1/D",
    "ett1/W",
    "ett2/15T",
    "ett2/H",
    "ett2/D",
    "ett2/W",
    "jena_weather/10T",
    "jena_weather/H",
    "jena_weather/D",
    "bitbrains_fast_storage/5T",
    "bitbrains_fast_storage/H",
    "bitbrains_rnd/5T",
    "bitbrains_rnd/H",
    "bizitobs_application",
    "bizitobs_service",
    "bizitobs_l2c/5T",
    "bizitobs_l2c/H",
]

CHRONOS2_DOWNSTREAM_GIFTEVAL_TRAIN_DATASETS = [
    # Electricity: electricity_15min, monash_electricity_hourly,
    # monash_electricity_weekly
    "electricity/15T",
    "electricity/H",
    "electricity/W",
    # KDD Cup (2018): monash_kdd_cup_2018
    "kdd_cup_2018_with_missing/H",
    "kdd_cup_2018_with_missing/D",
    # M4 downstream splits
    "m4_yearly",
    "m4_quarterly",
    "m4_monthly",
    "m4_weekly",
    "m4_daily",
    "m4_hourly",
    # Solar: solar, solar_1h
    "solar/10T",
    "solar/H",
    "solar/D",
    "solar/W",
    # Taxi: taxi_1h, taxi_30min.  The local GIFT-Eval config exposes the same
    # source through SZ_TAXI at 15-minute and hourly granularities.
    "SZ_TAXI/15T",
    "SZ_TAXI/H",
    # Temperature-Rain: monash_temperature_rain
    "temperature_rain_with_missing",

    "ett1/15T",
    "ett1/H",
    "ett1/D",
    "ett1/W",
    "ett2/15T",
    "ett2/H",
    "ett2/D",
    "ett2/W",

    "jena_weather/10T",
    "jena_weather/H",
    "jena_weather/D",

    "hierarchical_sales/D",
    "hierarchical_sales/W",
    "LOOP_SEATTLE/5T",
    "LOOP_SEATTLE/H",
    "LOOP_SEATTLE/D",
]

GIFT_EVAL_REAL_MULTIVARIATE_DATASETS = [
    # Table 13: target variates > 1
    "jena_weather/10T",
    "jena_weather/H",
    "jena_weather/D",
    "bizitobs_application",
    "bizitobs_service",
    "bizitobs_l2c/5T",
    "bizitobs_l2c/H",
    "bitbrains_fast_storage/5T",
    "bitbrains_fast_storage/H",
    "bitbrains_rnd/5T",
    "bitbrains_rnd/H",
    "ett1/15T",
    "ett1/H",
    "ett1/D",
    "ett1/W",
    "ett2/15T",
    "ett2/H",
    "ett2/D",
    "ett2/W",
    # Larger GIFT-Eval table entries; kept here if supported by the local API.
    "era5/H",
    "era5/D",
    "azure_vm_traces_2017/5T",
    "azure_vm_traces_2017/H",
    "alibaba_cluster_trace_2018/5T",
    "alibaba_cluster_trace_2018/H",
    "pems04/5T",
    "pems08/5T",
    "pems_bay/5T",
    "q_traffic/H",
]

CHRONOS2_PRETRAIN_TARGET_MULTIVARIATE_DATASETS = [
    "cmip6",
    "era5",
    "borg_cluster_data_2011",
    "alibaba_cluster_trace_2018",
    "pems04",
    "pems08",
    "beijing_subway",
    "shmetro",
    "hzmetro",
    "subseasonal",
    "godaddy",
    "china_air_quality",
    "beijing_air_quality",
    "residential_load_power",
    "residential_pv_power",
    "cdc_fluview_ilinet",
    "cdc_fluview_who_nrevss",
]

GIFT_EVAL_DATASET_ALIASES = {
    "chronos2_downstream": CHRONOS2_DOWNSTREAM_GIFTEVAL_TRAIN_DATASETS,
    "chronos2_table6": CHRONOS2_DOWNSTREAM_GIFTEVAL_TRAIN_DATASETS,
    "chronos2_multivariate": GIFT_EVAL_REAL_MULTIVARIATE_DATASETS,
    "gift_eval_multivariate": GIFT_EVAL_REAL_MULTIVARIATE_DATASETS,
    "real_multivariate": GIFT_EVAL_REAL_MULTIVARIATE_DATASETS,
    "downstream": CHRONOS2_DOWNSTREAM_GIFTEVAL_TRAIN_DATASETS,
    "electricity_15min": ["electricity/15T"],
    "monash_electricity_hourly": ["electricity/H"],
    "monash_electricity_weekly": ["electricity/W"],
    "monash_kdd_cup_2018": ["kdd_cup_2018_with_missing/H"],
    "solar": ["solar/10T"],
    "solar_1h": ["solar/H"],
    "taxi_1h": ["SZ_TAXI/H"],
    "taxi_30min": ["SZ_TAXI/15T"],
    "monash_temperature_rain": ["temperature_rain_with_missing"],
}

PRETRAIN_DATASET_ALIASES = {
    "chronos2_pretrain_multivariate": CHRONOS2_PRETRAIN_TARGET_MULTIVARIATE_DATASETS,
    "chronos2_table14_multivariate": CHRONOS2_PRETRAIN_TARGET_MULTIVARIATE_DATASETS,
    "pretrain_multivariate": CHRONOS2_PRETRAIN_TARGET_MULTIVARIATE_DATASETS,
    "real_pretrain_multivariate": CHRONOS2_PRETRAIN_TARGET_MULTIVARIATE_DATASETS,
}

GIFT_EVAL_MED_LONG_DATASETS = [
    "electricity/15T",
    "electricity/H",
    "solar/10T",
    "solar/H",
    "kdd_cup_2018_with_missing/H",
    "LOOP_SEATTLE/5T",
    "LOOP_SEATTLE/H",
    "SZ_TAXI/15T",
    "M_DENSE/H",
    "ett1/15T",
    "ett1/H",
    "ett2/15T",
    "ett2/H",
    "jena_weather/10T",
    "jena_weather/H",
    "bitbrains_fast_storage/5T",
    "bitbrains_rnd/5T",
    "bizitobs_application",
    "bizitobs_service",
    "bizitobs_l2c/5T",
    "bizitobs_l2c/H",
]

def split_arg_list(value, default=None):
    if value is None:
        return default or []
    if isinstance(value, (list, tuple)):
        return [str(item) for item in value]
    return [item for item in str(value).replace(",", " ").split() if item]

def gifteval_requested_datasets(value):
    datasets = split_arg_list(value, default=["all"])
    if len(datasets) == 1 and datasets[0].lower() == "all":
        return GIFT_EVAL_SHORT_DATASETS
    selected = []
    for dataset in datasets:
        alias = GIFT_EVAL_DATASET_ALIASES.get(dataset.lower())
        if alias is None:
            selected.append(dataset)
        else:
            selected.extend(alias)
    return list(OrderedDict.fromkeys(selected))

def pretrain_requested_datasets(value):
    datasets = split_arg_list(value, default=["all"])
    if len(datasets) == 1 and datasets[0].lower() == "all":
        return None
    selected = []
    for dataset in datasets:
        alias = PRETRAIN_DATASET_ALIASES.get(dataset.lower())
        if alias is None:
            selected.append(dataset)
        else:
            selected.extend(alias)
    return list(OrderedDict.fromkeys(selected))

def normalize_pretrain_dataset_name(dataset_name):
    return re.sub(r"[^a-z0-9]+", "_", str(dataset_name).lower()).strip("_")

def pretrain_dataset_matches(name, requested_names):
    if requested_names is None:
        return True
    normalized_name = normalize_pretrain_dataset_name(name)
    for requested_name in requested_names:
        normalized_requested = normalize_pretrain_dataset_name(requested_name)
        if normalized_name == normalized_requested or normalized_name.startswith(f"{normalized_requested}_"):
            return True
    return False

def gifteval_requested_terms(value):
    terms = split_arg_list(value, default=["short"])
    if len(terms) == 1 and terms[0].lower() == "all":
        return ["short", "medium", "long"]
    return terms

def gifteval_should_run_dataset_term(dataset_name, term):
    if term == "short":
        return True
    return dataset_name in GIFT_EVAL_MED_LONG_DATASETS

def sample_prediction_length(
        available_steps,
        max_pred_len,
        min_pred_len,
        output_patch_size,
        prediction_patch_multiple,
        rng,
):
    available_steps = min(int(available_steps), int(max_pred_len))
    min_pred_len = int(min_pred_len)
    if available_steps < min_pred_len:
        return None
    if not prediction_patch_multiple:
        return available_steps

    output_patch_size = int(output_patch_size)
    min_pred_len = max(output_patch_size, math.ceil(min_pred_len / output_patch_size) * output_patch_size)
    max_pred_len = (available_steps // output_patch_size) * output_patch_size
    if max_pred_len < min_pred_len:
        return None
    min_patches = min_pred_len // output_patch_size
    max_patches = max_pred_len // output_patch_size
    return rng.randint(min_patches, max_patches) * output_patch_size

def interpolate_int(start, end, progress):
    progress = min(1.0, max(0.0, float(progress)))
    return int(round(float(start) + (float(end) - float(start)) * progress))

def curriculum_limits(
        batch_index,
        enabled,
        max_seq_len,
        max_pred_len,
        initial_max_history_len,
        mid_max_history_len,
        final_max_history_len,
        history_mid_batches,
        history_final_batches,
        initial_max_pred_len,
        mid_max_pred_len,
        final_max_pred_len,
        pred_mid_batches,
        pred_final_batches,
):
    if not enabled:
        return int(max_seq_len), int(max_pred_len)

    batch_index = max(0, int(batch_index or 0))
    max_seq_len = int(max_seq_len)
    max_pred_len = int(max_pred_len)
    initial_max_history_len = min(max_seq_len, int(initial_max_history_len or max_seq_len))
    mid_max_history_len = min(max_seq_len, int(mid_max_history_len or max_seq_len))
    final_max_history_len = min(max_seq_len, int(final_max_history_len or max_seq_len))
    initial_max_pred_len = min(max_pred_len, int(initial_max_pred_len or max_pred_len))
    final_max_pred_len = min(max_pred_len, int(final_max_pred_len or max_pred_len))
    pred_mid_batches = int(pred_mid_batches or 0)
    pred_final_batches = int(pred_final_batches or 0)
    if mid_max_pred_len is None:
        mid_max_pred_len = initial_max_pred_len if pred_mid_batches > 0 else final_max_pred_len
    mid_max_pred_len = min(max_pred_len, int(mid_max_pred_len or max_pred_len))

    if history_mid_batches <= 0 or batch_index <= history_mid_batches:
        denom = max(1, int(history_mid_batches or 1))
        history_limit = interpolate_int(initial_max_history_len, mid_max_history_len, batch_index / denom)
    elif history_final_batches <= history_mid_batches or batch_index <= history_final_batches:
        denom = max(1, int(history_final_batches - history_mid_batches))
        history_limit = interpolate_int(
            mid_max_history_len,
            final_max_history_len,
            (batch_index - history_mid_batches) / denom,
        )
    else:
        history_limit = final_max_history_len

    if pred_mid_batches <= 0:
        if pred_final_batches <= 0 or batch_index <= pred_final_batches:
            pred_limit = interpolate_int(
                initial_max_pred_len,
                final_max_pred_len,
                batch_index / max(1, pred_final_batches or 1),
            )
        else:
            pred_limit = final_max_pred_len
    elif batch_index <= pred_mid_batches:
        pred_limit = interpolate_int(initial_max_pred_len, mid_max_pred_len, batch_index / max(1, pred_mid_batches))
    elif pred_final_batches <= pred_mid_batches or batch_index <= pred_final_batches:
        denom = max(1, pred_final_batches - pred_mid_batches)
        pred_limit = interpolate_int(
            mid_max_pred_len,
            final_max_pred_len,
            (batch_index - pred_mid_batches) / denom,
        )
    else:
        pred_limit = final_max_pred_len

    return max(1, min(max_seq_len, history_limit)), max(1, min(max_pred_len, pred_limit))

def import_gifteval_dataset(gift_eval_path, gift_eval_src=None):
    os.environ["GIFT_EVAL"] = str(gift_eval_path)
    os.environ["GIFT_EVAL_PATH"] = str(gift_eval_path)
    if gift_eval_src:
        os.environ["GIFT_EVAL_SRC"] = str(gift_eval_src)

    src_candidates = [
        Path(gift_eval_src).expanduser() if gift_eval_src else None,
        Path(os.environ["GIFT_EVAL_SRC"]).expanduser() if os.environ.get("GIFT_EVAL_SRC") else None,
        Path(gift_eval_path).expanduser() / "src" if gift_eval_path else None,
        LOCAL_GIFT_EVAL_SRC,
        FALLBACK_GIFT_EVAL_SRC,
    ]
    for src_path in src_candidates:
        if src_path and (src_path / "gift_eval").exists() and str(src_path) not in sys.path:
            sys.path.append(str(src_path))

    try:
        from gift_eval.data import Dataset
    except ImportError as exc:
        raise ImportError(
            "Could not import gift_eval.data.Dataset. Install GIFT-Eval or set "
            "GIFT_EVAL_SRC=/path/to/GIFT-Eval/src. The data root should be /data/GIFTEval."
        ) from exc
    return Dataset

class GIFTEvalTrainPartStreamingDataset(IterableDataset):
    """
    Use the train/history part of GIFT-Eval evaluation windows for Chronos-2 pretraining.

    For each requested GIFT-Eval dataset config, this reads Dataset(...).test_data.input
    and samples supervised windows from those historical target series only. The future
    labels from test_data.label are intentionally not used.
    """

    def __init__(
            self,
            gift_eval_path,
            gift_eval_src,
            dataset_names,
            terms,
            max_seq_len,
            max_pred_len,
            batch_size,
            output_patch_size,
            patch_len=48,
            log_interval=1000,
            file_shuffle=True,
            sample_pool_size=8192,
            samples_per_dataset_block=512,
            windows_per_series=16,
            min_history_len=48,
            min_pred_len=1,
            history_patch_multiple=True,
            prediction_patch_multiple=True,
            curriculum_enable=False,
            curriculum_initial_max_history_len=2048,
            curriculum_mid_max_history_len=4096,
            curriculum_final_max_history_len=None,
            curriculum_history_mid_batches=80000,
            curriculum_history_final_batches=150000,
            curriculum_initial_max_pred_len=256,
            curriculum_mid_max_pred_len=None,
            curriculum_final_max_pred_len=None,
            curriculum_pred_mid_batches=0,
            curriculum_pred_final_batches=80000,
            seed=5252,
    ):
        self.gift_eval_path = gift_eval_path
        self.gift_eval_src = gift_eval_src
        self.max_seq_len = int(max_seq_len)
        self.max_pred_len = int(max_pred_len)
        self.batch_size = int(batch_size)
        self.output_patch_size = int(output_patch_size)
        self.patch_len = int(patch_len)
        self.num_output_patches = math.ceil(self.max_pred_len / self.output_patch_size)
        self.log_interval = max(0, int(log_interval or 0))
        self.file_shuffle = bool(file_shuffle)
        self.sample_pool_size = max(1, int(sample_pool_size or 1))
        self.samples_per_dataset_block = max(1, int(samples_per_dataset_block or 1))
        self.windows_per_series = max(1, int(windows_per_series or 1))
        self.min_history_len = max(1, int(min_history_len or 1))
        self.min_pred_len = max(1, int(min_pred_len or 1))
        self.history_patch_multiple = bool(history_patch_multiple)
        self.prediction_patch_multiple = bool(prediction_patch_multiple)
        self.curriculum_enable = bool(curriculum_enable)
        self.curriculum_initial_max_history_len = int(curriculum_initial_max_history_len or self.max_seq_len)
        self.curriculum_mid_max_history_len = int(curriculum_mid_max_history_len or self.max_seq_len)
        self.curriculum_final_max_history_len = int(curriculum_final_max_history_len or self.max_seq_len)
        self.curriculum_history_mid_batches = int(curriculum_history_mid_batches or 0)
        self.curriculum_history_final_batches = int(curriculum_history_final_batches or 0)
        self.curriculum_initial_max_pred_len = int(curriculum_initial_max_pred_len or self.max_pred_len)
        self.curriculum_mid_max_pred_len = (
            int(curriculum_mid_max_pred_len) if curriculum_mid_max_pred_len is not None else None
        )
        self.curriculum_final_max_pred_len = int(curriculum_final_max_pred_len or self.max_pred_len)
        self.curriculum_pred_mid_batches = int(curriculum_pred_mid_batches or 0)
        self.curriculum_pred_final_batches = int(curriculum_pred_final_batches or 0)
        self.seed = int(seed)

        if self.history_patch_multiple and self.min_history_len < self.patch_len:
            self.min_history_len = self.patch_len
        if self.prediction_patch_multiple and self.min_pred_len < self.output_patch_size:
            self.min_pred_len = self.output_patch_size
        self.invalid_dataset_configs = set()

        self.dataset_configs = [
            (dataset_name, term)
            for dataset_name in gifteval_requested_datasets(dataset_names)
            for term in gifteval_requested_terms(terms)
            if gifteval_should_run_dataset_term(dataset_name, term)
        ]
        if not self.dataset_configs:
            raise ValueError("No GIFT-Eval dataset configs selected for gifteval_train mode.")

        print(
            "Use GIFT-Eval train-part streaming dataset: "
            f"gift_eval_path={self.gift_eval_path}, configs={len(self.dataset_configs)}, "
            f"max_seq_len={self.max_seq_len}, max_pred_len={self.max_pred_len}, "
            f"batch_size={self.batch_size}, output_patch_size={self.output_patch_size}, "
            f"patch_len={self.patch_len}, sample_pool_size={self.sample_pool_size}, "
            f"samples_per_dataset_block={self.samples_per_dataset_block}, "
            f"windows_per_series={self.windows_per_series}, "
            f"prediction_patch_multiple={self.prediction_patch_multiple}, "
            f"curriculum_enable={self.curriculum_enable}, "
            f"curriculum_history=({self.curriculum_initial_max_history_len}->{self.curriculum_mid_max_history_len}->{self.curriculum_final_max_history_len}), "
            f"curriculum_pred=({self.curriculum_initial_max_pred_len}->{self.curriculum_mid_max_pred_len}->{self.curriculum_final_max_pred_len}), "
            f"curriculum_pred_batches=({self.curriculum_pred_mid_batches}->{self.curriculum_pred_final_batches})",
            flush=True,
        )

    def _curriculum_limits(self, batch_index):
        return curriculum_limits(
            batch_index=batch_index,
            enabled=self.curriculum_enable,
            max_seq_len=self.max_seq_len,
            max_pred_len=self.max_pred_len,
            initial_max_history_len=self.curriculum_initial_max_history_len,
            mid_max_history_len=self.curriculum_mid_max_history_len,
            final_max_history_len=self.curriculum_final_max_history_len,
            history_mid_batches=self.curriculum_history_mid_batches,
            history_final_batches=self.curriculum_history_final_batches,
            initial_max_pred_len=self.curriculum_initial_max_pred_len,
            mid_max_pred_len=self.curriculum_mid_max_pred_len,
            final_max_pred_len=self.curriculum_final_max_pred_len,
            pred_mid_batches=self.curriculum_pred_mid_batches,
            pred_final_batches=self.curriculum_pred_final_batches,
        )

    def __iter__(self):
        worker_info = get_worker_info()
        worker_id = worker_info.id if worker_info is not None else 0
        num_workers = worker_info.num_workers if worker_info is not None else 1
        rank = int(os.getenv("RANK", "0"))
        world_size = int(os.getenv("WORLD_SIZE", "1"))
        global_shard_id = rank * num_workers + worker_id
        global_num_shards = max(1, world_size * num_workers)
        rng = random.Random(self.seed + global_shard_id * 1009)
        dataset_rng = random.Random(self.seed + global_shard_id * 9176)
        Dataset = import_gifteval_dataset(self.gift_eval_path, self.gift_eval_src)

        if rank == 0 and worker_id == 0:
            print(
                f"GIFT-Eval train-part shard: world_size={world_size}, workers={num_workers}, "
                f"global_shards={global_num_shards}, configs={len(self.dataset_configs)}",
                flush=True,
            )

        raw_iter = self._iter_pool_generator(
            Dataset=Dataset,
            rng=rng,
            dataset_rng=dataset_rng,
            shard_id=global_shard_id,
            num_shards=global_num_shards,
            global_num_shards=global_num_shards,
            rank=rank,
            worker_id=worker_id,
        )
        yield from self._iter_chronos2_batches(raw_iter)

    def _iter_chronos2_batches(self, raw_iter):
        batch = []
        for sample in raw_iter:
            batch.append(sample)
            if len(batch) >= self.batch_size:
                yield self._collate_chronos2_batch(batch)
                batch = []
        if batch:
            yield self._collate_chronos2_batch(batch)

    def _iter_pool_generator(self, Dataset, rng, dataset_rng, shard_id, num_shards, global_num_shards, rank, worker_id):
        emitted = 0
        skipped = 0
        pool_epoch = 0
        start_time = time.time()

        while True:
            pool = []
            config_order = list(self.dataset_configs)
            if self.file_shuffle:
                dataset_rng.shuffle(config_order)
            batch_index = (emitted * max(1, global_num_shards)) // max(1, self.batch_size)
            max_history_len, max_pred_len = self._curriculum_limits(batch_index)
            pool_rounds = 0

            while len(pool) < self.sample_pool_size:
                pool_rounds += 1
                if pool and getattr(self, "allow_partial_pool", False) and pool_rounds > getattr(self, "partial_pool_after_rounds", 1):
                    break
                if not pool and getattr(self, "allow_partial_pool", False) and pool_rounds > getattr(self, "empty_pool_error_rounds", 4):
                    raise RuntimeError(
                        "No multivariate GIFT-Eval train windows found after scanning multiple dataset rounds. "
                        "Check --gift_eval_mv_datasets/--gift_eval_mv_terms or lower --mv_min_variates."
                    )
                for dataset_name, term in config_order:
                    if len(pool) >= self.sample_pool_size:
                        break
                    target_windows = min(self.samples_per_dataset_block, self.sample_pool_size - len(pool))
                    block = self._sample_dataset_config(
                        Dataset=Dataset,
                        dataset_name=dataset_name,
                        term=term,
                        rng=rng,
                        shard_id=shard_id,
                        num_shards=num_shards,
                        target_windows=target_windows,
                        max_history_len=max_history_len,
                        max_pred_len=max_pred_len,
                    )
                    if block:
                        pool.extend(block)
                    else:
                        skipped += 1

            rng.shuffle(pool)
            pool_epoch += 1
            emitted += len(pool)
            if self.log_interval and rank == 0 and worker_id == 0 and emitted % self.log_interval < len(pool):
                elapsed = time.time() - start_time
                print(
                    f"[gifteval train rank={rank} worker={worker_id}] "
                    f"pool_epoch={pool_epoch} configs_in_pool={len(config_order)} "
                    f"pool_ready={len(pool)} worker_windows={emitted} "
                    f"batch_index={batch_index} max_history_len={max_history_len} max_pred_len={max_pred_len} "
                    f"global_windows_est={emitted * max(1, global_num_shards)} skipped={skipped} "
                    f"elapsed={elapsed:.1f}s",
                    flush=True,
                )
            while pool:
                yield pool.pop()

    def _sample_dataset_config(self, Dataset, dataset_name, term, rng, shard_id, num_shards, target_windows, max_history_len, max_pred_len):
        try:
            to_univariate = Dataset(name=dataset_name, term=term, to_univariate=False).target_dim != 1
            dataset = Dataset(name=dataset_name, term=term, to_univariate=to_univariate)
            input_iter = dataset.training_dataset
        except Exception as exc:
            raise RuntimeError(f"Failed to load GIFT-Eval train part: dataset={dataset_name}, term={term}") from exc

        windows = []
        for item_idx, entry in enumerate(input_iter):
            if item_idx % num_shards != shard_id:
                continue
            target = np.asarray(entry["target"], dtype=np.float32)
            windows.extend(self._sample_from_target(target, rng, target_windows - len(windows), max_history_len, max_pred_len))
            if len(windows) >= target_windows:
                break
        return windows

    def _sample_from_target(self, target, rng, max_windows, max_history_len, max_pred_len):
        if max_windows <= 0:
            return []
        if target.ndim == 1:
            target = target.reshape(1, -1)
        elif target.ndim != 2:
            return []

        windows = []
        channel_indices = list(range(target.shape[0]))
        rng.shuffle(channel_indices)
        for channel_idx in channel_indices:
            series = fill_missing_values(target[channel_idx].astype(np.float32))
            if series is None:
                continue
            windows.extend(self._sample_windows_from_series(series, rng, max_windows - len(windows), max_history_len, max_pred_len))
            if len(windows) >= max_windows:
                return windows
        return windows

    def _sample_windows_from_series(self, series, rng, max_windows, max_history_len=None, max_pred_len=None):
        windows = []
        series_len = int(len(series))
        min_total = self.min_history_len + self.min_pred_len
        if series_len < min_total:
            return windows
        max_history_len = int(max_history_len or self.max_seq_len)
        max_pred_len = int(max_pred_len or self.max_pred_len)

        for _ in range(min(self.windows_per_series, max_windows)):
            max_total = min(series_len, max_history_len + max_pred_len)
            if max_total < min_total:
                continue
            total_len = rng.randint(min_total, max_total)
            max_history = min(max_history_len, total_len - self.min_pred_len)
            min_history = min(self.min_history_len, max_history)
            if self.history_patch_multiple:
                max_history = (max_history // self.patch_len) * self.patch_len
                min_history = max(self.patch_len, ((min_history + self.patch_len - 1) // self.patch_len) * self.patch_len)
                if max_history < min_history:
                    continue
                history_steps = rng.randint(min_history // self.patch_len, max_history // self.patch_len) * self.patch_len
            else:
                history_steps = rng.randint(min_history, max_history)
            pred_steps = sample_prediction_length(
                available_steps=total_len - history_steps,
                max_pred_len=max_pred_len,
                min_pred_len=self.min_pred_len,
                output_patch_size=self.output_patch_size,
                prediction_patch_multiple=self.prediction_patch_multiple,
                rng=rng,
            )
            if pred_steps is None:
                continue

            valid_offsets = series_len - history_steps - pred_steps + 1
            if valid_offsets <= 0:
                continue
            offset = rng.randrange(valid_offsets)
            history = np.nan_to_num(series[offset:offset + history_steps], nan=0.0, posinf=0.0, neginf=0.0)
            future = np.nan_to_num(
                series[offset + history_steps:offset + history_steps + pred_steps],
                nan=0.0,
                posinf=0.0,
                neginf=0.0,
            )

            context = np.zeros(self.max_seq_len, dtype=np.float32)
            context_mask = np.zeros(self.max_seq_len, dtype=np.float32)
            future_target = np.zeros(self.max_pred_len, dtype=np.float32)
            future_target_mask = np.zeros(self.max_pred_len, dtype=np.float32)
            context[-history_steps:] = history
            context_mask[-history_steps:] = 1.0
            future_target[:pred_steps] = future
            future_target_mask[:pred_steps] = 1.0
            windows.append({
                "context": context,
                "context_mask": context_mask,
                "future_target": future_target,
                "future_target_mask": future_target_mask,
            })
        return windows

    def _collate_chronos2_batch(self, samples):
        context = torch.as_tensor(np.stack([x["context"] for x in samples]), dtype=torch.float32)
        context_mask = torch.as_tensor(np.stack([x["context_mask"] for x in samples]), dtype=torch.float32)
        future_target = torch.as_tensor(np.stack([x["future_target"] for x in samples]), dtype=torch.float32)
        future_target_mask = torch.as_tensor(
            np.stack([x["future_target_mask"] for x in samples]), dtype=torch.float32
        )
        return {
            "context": context,
            "context_mask": context_mask,
            "future_target": future_target,
            "future_target_mask": future_target_mask,
            "group_ids": torch.arange(len(samples), dtype=torch.long),
            "future_covariates": None,
            "future_covariates_mask": None,
            "num_output_patches": self.num_output_patches,
        }

class GIFTEvalDynamicStreamingDataset(IterableDataset):
    """
    Falcon-X style streaming sampler.

    Iteration yields Chronos-2 batches:
      context             [batch_size, max_seq_len], left padded
      context_mask        [batch_size, max_seq_len], 1 for real history points
      future_target       [batch_size, max_pred_len], right padded
      future_target_mask  [batch_size, max_pred_len], 1 for real future targets
      group_ids           [batch_size], unique group per series
      num_output_patches  scalar int

    The actual history length and prediction length are sampled dynamically per
    window. Pools are composed from small dataset blocks and shuffled, so a large
    micro-batch can see multiple datasets without forcing one Arrow read per
    sample.
    """

    def __init__(
            self,
            data_dir,
            max_seq_len,
            max_pred_len,
            batch_size,
            output_patch_size,
            patch_len=48,
            log_interval=1000,
            window_stride=1,
            file_shuffle=True,
            sample_pool_size=8192,
            samples_per_arrow=512,
            samples_per_dataset_block=512,
            arrow_row_chunk_size=4096,
            windows_per_series=16,
            prefetch_pools=4,
            arrow_cache_size=512,
            min_history_len=48,
            min_pred_len=1,
            history_patch_multiple=True,
            prediction_patch_multiple=True,
            curriculum_enable=False,
            curriculum_initial_max_history_len=2048,
            curriculum_mid_max_history_len=4096,
            curriculum_final_max_history_len=None,
            curriculum_history_mid_batches=80000,
            curriculum_history_final_batches=150000,
            curriculum_initial_max_pred_len=256,
            curriculum_mid_max_pred_len=None,
            curriculum_final_max_pred_len=None,
            curriculum_pred_mid_batches=0,
            curriculum_pred_final_batches=80000,
            dataset_names=None,
            seed=5252,
    ):
        self.data_dir = data_dir
        self.max_seq_len = int(max_seq_len)
        self.max_pred_len = int(max_pred_len)
        self.batch_size = int(batch_size)
        self.output_patch_size = int(output_patch_size)
        self.patch_len = int(patch_len)
        self.num_output_patches = math.ceil(self.max_pred_len / self.output_patch_size)
        self.log_interval = max(0, int(log_interval or 0))
        self.window_stride = max(1, int(window_stride or 1))
        self.file_shuffle = bool(file_shuffle)
        self.sample_pool_size = max(1, int(sample_pool_size or 1))
        self.samples_per_arrow = max(1, int(samples_per_arrow or 1))
        self.samples_per_dataset_block = max(1, int(samples_per_dataset_block or self.sample_pool_size))
        self.arrow_row_chunk_size = max(1, int(arrow_row_chunk_size or 1))
        self.windows_per_series = max(1, int(windows_per_series or 1))
        self.prefetch_pools = max(0, int(prefetch_pools or 0))
        self.arrow_cache_size = max(1, int(arrow_cache_size or 1))
        self.min_history_len = max(1, int(min_history_len or 1))
        self.min_pred_len = max(1, int(min_pred_len or 1))
        self.history_patch_multiple = bool(history_patch_multiple)
        self.prediction_patch_multiple = bool(prediction_patch_multiple)
        self.curriculum_enable = bool(curriculum_enable)
        self.curriculum_initial_max_history_len = int(curriculum_initial_max_history_len or self.max_seq_len)
        self.curriculum_mid_max_history_len = int(curriculum_mid_max_history_len or self.max_seq_len)
        self.curriculum_final_max_history_len = int(curriculum_final_max_history_len or self.max_seq_len)
        self.curriculum_history_mid_batches = int(curriculum_history_mid_batches or 0)
        self.curriculum_history_final_batches = int(curriculum_history_final_batches or 0)
        self.curriculum_initial_max_pred_len = int(curriculum_initial_max_pred_len or self.max_pred_len)
        self.curriculum_mid_max_pred_len = (
            int(curriculum_mid_max_pred_len) if curriculum_mid_max_pred_len is not None else None
        )
        self.curriculum_final_max_pred_len = int(curriculum_final_max_pred_len or self.max_pred_len)
        self.curriculum_pred_mid_batches = int(curriculum_pred_mid_batches or 0)
        self.curriculum_pred_final_batches = int(curriculum_pred_final_batches or 0)
        self.requested_dataset_names = pretrain_requested_datasets(dataset_names)
        self.seed = int(seed)

        if self.batch_size <= 0:
            raise ValueError("batch_size must be positive")
        if self.output_patch_size <= 0:
            raise ValueError("output_patch_size must be positive")
        if self.max_seq_len < self.patch_len:
            raise ValueError("max_seq_len must be at least patch_len")
        if self.history_patch_multiple and self.min_history_len < self.patch_len:
            self.min_history_len = self.patch_len
        if self.prediction_patch_multiple and self.min_pred_len < self.output_patch_size:
            self.min_pred_len = self.output_patch_size
        self.dataset_to_arrow_files = self._collect_arrow_files(data_dir, self.requested_dataset_names)
        self.dataset_names = sorted(self.dataset_to_arrow_files)
        self.total_arrow_files = sum(len(paths) for paths in self.dataset_to_arrow_files.values())
        if not self.dataset_names:
            raise ValueError(f"No data-*.arrow files found in {data_dir}")

        print(
            "Use dynamic streaming GIFTEval dataset: "
            f"datasets={len(self.dataset_names)}, files={self.total_arrow_files}, "
            f"dataset_filter={len(self.requested_dataset_names) if self.requested_dataset_names is not None else 'all'}, "
            f"max_seq_len={self.max_seq_len}, max_pred_len={self.max_pred_len}, "
            f"batch_size={self.batch_size}, output_patch_size={self.output_patch_size}, "
            f"patch_len={self.patch_len}, min_history_len={self.min_history_len}, "
            f"min_pred_len={self.min_pred_len}, sample_pool_size={self.sample_pool_size}, "
            f"samples_per_dataset_block={self.samples_per_dataset_block}, "
            f"samples_per_arrow={self.samples_per_arrow}, arrow_row_chunk_size={self.arrow_row_chunk_size}, "
            f"windows_per_series={self.windows_per_series}, prefetch_pools={self.prefetch_pools}, "
            f"arrow_cache_size={self.arrow_cache_size}, "
            f"prediction_patch_multiple={self.prediction_patch_multiple}, "
            f"curriculum_enable={self.curriculum_enable}, "
            f"curriculum_history=({self.curriculum_initial_max_history_len}->{self.curriculum_mid_max_history_len}->{self.curriculum_final_max_history_len}), "
            f"curriculum_pred=({self.curriculum_initial_max_pred_len}->{self.curriculum_mid_max_pred_len}->{self.curriculum_final_max_pred_len}), "
            f"curriculum_pred_batches=({self.curriculum_pred_mid_batches}->{self.curriculum_pred_final_batches})",
            flush=True,
        )

    def _curriculum_limits(self, batch_index):
        return curriculum_limits(
            batch_index=batch_index,
            enabled=self.curriculum_enable,
            max_seq_len=self.max_seq_len,
            max_pred_len=self.max_pred_len,
            initial_max_history_len=self.curriculum_initial_max_history_len,
            mid_max_history_len=self.curriculum_mid_max_history_len,
            final_max_history_len=self.curriculum_final_max_history_len,
            history_mid_batches=self.curriculum_history_mid_batches,
            history_final_batches=self.curriculum_history_final_batches,
            initial_max_pred_len=self.curriculum_initial_max_pred_len,
            mid_max_pred_len=self.curriculum_mid_max_pred_len,
            final_max_pred_len=self.curriculum_final_max_pred_len,
            pred_mid_batches=self.curriculum_pred_mid_batches,
            pred_final_batches=self.curriculum_pred_final_batches,
        )

    @staticmethod
    def _collect_arrow_files(data_dir, requested_dataset_names=None):
        dataset_to_arrow_files = {}
        for name in sorted(os.listdir(data_dir)):
            subdir = os.path.join(data_dir, name)
            if not os.path.isdir(subdir) or name.startswith("."):
                continue
            if not pretrain_dataset_matches(name, requested_dataset_names):
                continue
            files = [
                os.path.join(subdir, filename)
                for filename in sorted(os.listdir(subdir))
                if filename.startswith("data-") and filename.endswith(".arrow")
            ]
            if files:
                dataset_to_arrow_files[name] = files
        return dataset_to_arrow_files

    def __iter__(self):
        worker_info = get_worker_info()
        worker_id = worker_info.id if worker_info is not None else 0
        num_workers = worker_info.num_workers if worker_info is not None else 1
        rank = int(os.getenv("RANK", "0"))
        world_size = int(os.getenv("WORLD_SIZE", "1"))
        global_shard_id = rank * num_workers + worker_id
        global_num_shards = max(1, world_size * num_workers)

        rng = random.Random(self.seed + global_shard_id * 1009)
        dataset_rng = random.Random(self.seed + global_shard_id * 9176)
        arrow_orders = {name: self._new_arrow_order(name, rng) for name in self.dataset_names}
        arrow_positions = {name: 0 for name in self.dataset_names}

        if rank == 0 and worker_id == 0:
            print(
                f"Dynamic streaming shard: world_size={world_size}, workers={num_workers}, "
                f"global_shards={global_num_shards}, datasets={len(self.dataset_names)}",
                flush=True,
            )

        generator_kwargs = dict(
            arrow_orders=arrow_orders,
            arrow_positions=arrow_positions,
            rng=rng,
            dataset_rng=dataset_rng,
            shard_id=0,
            num_shards=1,
            global_num_shards=global_num_shards,
            rank=rank,
            worker_id=worker_id,
        )
        if self.prefetch_pools <= 0:
            raw_iter = self._iter_pool_generator(**generator_kwargs)
        else:
            raw_iter = self._iter_prefetch(**generator_kwargs)
        yield from self._iter_chronos2_batches(raw_iter)

    def _iter_chronos2_batches(self, raw_iter):
        batch = []
        for sample in raw_iter:
            batch.append(sample)
            if len(batch) >= self.batch_size:
                yield self._collate_chronos2_batch(batch)
                batch = []
        if batch:
            yield self._collate_chronos2_batch(batch)

    def _collate_chronos2_batch(self, samples):
        context = torch.as_tensor(np.stack([x["context"] for x in samples]), dtype=torch.float32)
        context_mask = torch.as_tensor(np.stack([x["context_mask"] for x in samples]), dtype=torch.float32)
        future_target = torch.as_tensor(np.stack([x["future_target"] for x in samples]), dtype=torch.float32)
        future_target_mask = torch.as_tensor(
            np.stack([x["future_target_mask"] for x in samples]), dtype=torch.float32
        )
        group_ids = torch.arange(len(samples), dtype=torch.long)

        return {
            "context": context,
            "context_mask": context_mask,
            "future_target": future_target,
            "future_target_mask": future_target_mask,
            "group_ids": group_ids,
            "future_covariates": None,
            "future_covariates_mask": None,
            "num_output_patches": self.num_output_patches,
        }

    def _iter_prefetch(self, **kwargs):
        pool_queue = queue.Queue(maxsize=self.prefetch_pools)
        stop_event = threading.Event()

        def producer():
            try:
                for pool in self._iter_pool_generator(**kwargs):
                    if stop_event.is_set():
                        break
                    while not stop_event.is_set():
                        try:
                            pool_queue.put(pool, timeout=0.5)
                            break
                        except queue.Full:
                            continue
            except BaseException as exc:
                pool_queue.put(exc)

        thread = threading.Thread(target=producer, daemon=True)
        thread.start()
        try:
            while True:
                item = pool_queue.get()
                if isinstance(item, BaseException):
                    raise item
                yield item
        finally:
            stop_event.set()

    def _iter_pool_generator(
            self,
            arrow_orders,
            arrow_positions,
            rng,
            dataset_rng,
            shard_id,
            num_shards,
            global_num_shards,
            rank,
            worker_id,
    ):
        arrow_cache = OrderedDict()
        invalid_arrow_paths = set()
        dataset_order = []
        dataset_position = 0
        dataset_round = 0
        datasets_seen = set()
        emitted = 0
        skipped = 0
        pool_epoch = 0
        start_time = time.time()

        while True:
            pool = []
            pool_datasets = []
            batch_index = (emitted * max(1, global_num_shards)) // max(1, self.batch_size)
            max_history_len, max_pred_len = self._curriculum_limits(batch_index)
            pool_round_start = dataset_round
            while len(pool) < self.sample_pool_size:
                if dataset_position >= len(dataset_order):
                    scanned_rounds = dataset_round - pool_round_start
                    if pool and getattr(self, "allow_partial_pool", False) and scanned_rounds >= getattr(self, "partial_pool_after_rounds", 1):
                        break
                    if not pool and getattr(self, "allow_partial_pool", False) and scanned_rounds >= getattr(self, "empty_pool_error_rounds", 4):
                        raise RuntimeError(
                            "No multivariate Arrow windows found after scanning multiple dataset rounds. "
                            "Check --real_mv_data_dir or lower --mv_min_variates."
                        )
                    dataset_order = list(self.dataset_names)
                    if self.file_shuffle:
                        dataset_rng.shuffle(dataset_order)
                    dataset_position = 0
                    dataset_round += 1
                    datasets_seen = set()
                dataset_name = dataset_order[dataset_position]
                dataset_position += 1
                datasets_seen.add(dataset_name)
                pool_datasets.append(dataset_name)

                target = min(
                    self.samples_per_dataset_block,
                    self.sample_pool_size - len(pool),
                )
                block = []
                skipped += self._fill_dataset_block(
                    block=block,
                    dataset_name=dataset_name,
                    arrow_orders=arrow_orders,
                    arrow_positions=arrow_positions,
                    rng=rng,
                    shard_id=shard_id,
                    num_shards=num_shards,
                    arrow_cache=arrow_cache,
                    invalid_arrow_paths=invalid_arrow_paths,
                    target_windows=target,
                    max_history_len=max_history_len,
                    max_pred_len=max_pred_len,
                )
                pool.extend(block)

            rng.shuffle(pool)
            pool_epoch += 1
            emitted += len(pool)
            if self.log_interval and rank == 0 and worker_id == 0 and emitted % self.log_interval < len(pool):
                elapsed = time.time() - start_time
                print(
                    f"[dynamic stream rank={rank} worker={worker_id}] "
                    f"pool_epoch={pool_epoch} datasets_in_pool={len(set(pool_datasets))} "
                    f"dataset_round={dataset_round} datasets_seen={len(datasets_seen)}/{len(self.dataset_names)} "
                    f"pool_ready={len(pool)} worker_windows={emitted} "
                    f"batch_index={batch_index} max_history_len={max_history_len} max_pred_len={max_pred_len} "
                    f"global_windows_est={emitted * max(1, global_num_shards)} skipped={skipped} "
                    f"dataset_head={pool_datasets[:6]} elapsed={elapsed:.1f}s",
                    flush=True,
                )
            while pool:
                yield pool.pop()

    def _fill_dataset_block(
            self,
            block,
            dataset_name,
            arrow_orders,
            arrow_positions,
            rng,
            shard_id,
            num_shards,
            arrow_cache,
            invalid_arrow_paths,
            target_windows,
            max_history_len,
            max_pred_len,
    ):
        skipped = 0
        draws = 0
        max_draws = max(8, (target_windows // self.samples_per_arrow + 1) * 8)
        while len(block) < target_windows and draws < max_draws:
            draws += 1
            arrow_path = self._next_arrow_path(dataset_name, arrow_orders, arrow_positions, rng)
            windows = self._sample_from_arrow(
                arrow_path=arrow_path,
                shard_id=shard_id,
                num_shards=num_shards,
                rng=rng,
                arrow_cache=arrow_cache,
                invalid_arrow_paths=invalid_arrow_paths,
                max_windows=min(self.samples_per_arrow, target_windows - len(block)),
                max_history_len=max_history_len,
                max_pred_len=max_pred_len,
            )
            if windows:
                block.extend(windows)
            else:
                skipped += 1
        return skipped

    def _new_arrow_order(self, dataset_name, rng):
        files = list(self.dataset_to_arrow_files[dataset_name])
        if self.file_shuffle:
            rng.shuffle(files)
        return files

    def _next_arrow_path(self, dataset_name, arrow_orders, arrow_positions, rng):
        if arrow_positions[dataset_name] >= len(arrow_orders[dataset_name]):
            arrow_orders[dataset_name] = self._new_arrow_order(dataset_name, rng)
            arrow_positions[dataset_name] = 0
        path = arrow_orders[dataset_name][arrow_positions[dataset_name]]
        arrow_positions[dataset_name] += 1
        return path

    def _get_arrow_dataset(self, arrow_path, arrow_cache):
        dataset = arrow_cache.get(arrow_path)
        if dataset is not None:
            arrow_cache.move_to_end(arrow_path)
            return dataset
        try:
            dataset = HFDataset.from_file(arrow_path, in_memory=False)
        except Exception as exc:
            try:
                with pa.memory_map(arrow_path, "r") as source:
                    table = pa.ipc.open_file(source).read_all()
                dataset = HFDataset(table)
            except Exception as fallback_exc:
                raise RuntimeError(f"Failed to read arrow file: {arrow_path}") from fallback_exc
        arrow_cache[arrow_path] = dataset
        if len(arrow_cache) > self.arrow_cache_size:
            arrow_cache.popitem(last=False)
        return dataset

    def _sample_from_arrow(
            self,
            arrow_path,
            shard_id,
            num_shards,
            rng,
            arrow_cache,
            invalid_arrow_paths,
            max_windows,
            max_history_len,
            max_pred_len,
    ):
        if arrow_path in invalid_arrow_paths:
            return []
        dataset = self._get_arrow_dataset(arrow_path, arrow_cache)
        if len(dataset) <= shard_id:
            invalid_arrow_paths.add(arrow_path)
            return []
        candidate_count = (len(dataset) - 1 - shard_id) // num_shards + 1
        chunk_count = min(candidate_count, self.arrow_row_chunk_size)
        chunk_start = rng.randrange(candidate_count - chunk_count + 1)
        indices = list(range(chunk_start, chunk_start + chunk_count))
        rng.shuffle(indices)

        windows = []
        for local_idx in indices:
            sample_idx = shard_id + local_idx * num_shards
            windows.extend(
                self._sample_from_record(
                    dataset[int(sample_idx)],
                    rng=rng,
                    max_windows=max_windows - len(windows),
                    max_history_len=max_history_len,
                    max_pred_len=max_pred_len,
                )
            )
            if len(windows) >= max_windows:
                break
        return windows

    def _sample_from_record(self, sample, rng, max_windows, max_history_len=None, max_pred_len=None):
        target = np.asarray(sample["target"], dtype=np.float32)
        if target.ndim == 1:
            target = target.reshape(1, -1)
        elif target.ndim != 2:
            return []

        windows = []
        max_history_len = int(max_history_len or self.max_seq_len)
        max_pred_len = int(max_pred_len or self.max_pred_len)
        channel_indices = list(range(target.shape[0]))
        rng.shuffle(channel_indices)
        for channel_idx in channel_indices:
            series = fill_missing_values(target[channel_idx].astype(np.float32))
            if series is None:
                continue
            series_len = int(len(series))
            min_total = self.min_history_len + self.min_pred_len
            if series_len < min_total:
                continue

            for _ in range(min(self.windows_per_series, max_windows - len(windows))):
                max_total = min(series_len, max_history_len + max_pred_len)
                if max_total < min_total:
                    continue
                total_len = rng.randint(min_total, max_total)
                max_history = min(max_history_len, total_len - self.min_pred_len)
                min_history = min(self.min_history_len, max_history)
                if self.history_patch_multiple:
                    max_history = (max_history // self.patch_len) * self.patch_len
                    min_history = max(self.patch_len, ((min_history + self.patch_len - 1) // self.patch_len) * self.patch_len)
                    if max_history < min_history:
                        continue
                    history_steps = rng.randint(min_history // self.patch_len, max_history // self.patch_len) * self.patch_len
                else:
                    history_steps = rng.randint(min_history, max_history)
                pred_steps = sample_prediction_length(
                    available_steps=total_len - history_steps,
                    max_pred_len=max_pred_len,
                    min_pred_len=self.min_pred_len,
                    output_patch_size=self.output_patch_size,
                    prediction_patch_multiple=self.prediction_patch_multiple,
                    rng=rng,
                )
                if pred_steps is None:
                    continue

                valid_offsets = series_len - history_steps - pred_steps + 1
                if valid_offsets <= 0:
                    continue
                if self.window_stride <= 1:
                    offset = rng.randrange(valid_offsets)
                else:
                    offset = rng.randrange((valid_offsets - 1) // self.window_stride + 1) * self.window_stride

                history = np.nan_to_num(
                    series[offset:offset + history_steps],
                    nan=0.0,
                    posinf=0.0,
                    neginf=0.0,
                ).astype(np.float32, copy=False)
                future = np.nan_to_num(
                    series[offset + history_steps:offset + history_steps + pred_steps],
                    nan=0.0,
                    posinf=0.0,
                    neginf=0.0,
                ).astype(np.float32, copy=False)

                context = np.zeros(self.max_seq_len, dtype=np.float32)
                context_mask = np.zeros(self.max_seq_len, dtype=np.float32)
                future_target = np.zeros(self.max_pred_len, dtype=np.float32)
                future_target_mask = np.zeros(self.max_pred_len, dtype=np.float32)
                context[-history_steps:] = history
                context_mask[-history_steps:] = 1.0
                future_target[:pred_steps] = future
                future_target_mask[:pred_steps] = 1.0
                windows.append({
                    "context": context,
                    "context_mask": context_mask,
                    "future_target": future_target,
                    "future_target_mask": future_target_mask,
                    "history_length": history_steps,
                    "prediction_length": pred_steps,
                })
                if len(windows) >= max_windows:
                    return windows
        return windows

def fill_missing_values(series):
    finite_mask = np.isfinite(series)
    if finite_mask.all():
        return series
    if not finite_mask.any():
        return None
    indices = np.arange(len(series), dtype=np.float32)
    filled = np.interp(
        indices,
        indices[finite_mask],
        series[finite_mask],
    ).astype(np.float32)
    return filled

