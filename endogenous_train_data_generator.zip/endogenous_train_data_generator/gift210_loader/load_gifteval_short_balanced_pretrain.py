from __future__ import annotations

import os

import random

import time

from collections import OrderedDict

import numpy as np

import torch

from load_gifteval_pretrain_dataset_dynamic import GIFTEvalDynamicStreamingDataset

MASE_HARD_CONFIGS = (
    "m4_hourly",
    "us_births/M",
    "bizitobs_application",
    "m4_daily",
    "ett2/D",
    "solar/10T",
    "bizitobs_service",
    "m4_monthly",
    "covid_deaths",
    "bizitobs_l2c/H",
    "solar/D",
)

CRPS_HARD_CONFIGS = (
    "bitbrains_rnd/H",
    "bitbrains_rnd/5T",
    "bitbrains_fast_storage/H",
    "bitbrains_fast_storage/5T",
    "bizitobs_application",
    "us_births/M",
    "covid_deaths",
)

SHORT_IRREGULAR_PRETRAIN_DATASETS = {
    "monash_m3_yearly",
    "m1_yearly",
    "tourism_yearly",
    "cif_2016_6",
    "godaddy",
    "m1_quarterly",
    "monash_m3_quarterly",
    "monash_m3_other",
    "m1_monthly",
    "vehicle_trips_with_missing",
    "traffic_weekly",
    "tourism_quarterly",
    "nn5_weekly",
    "cif_2016_12",
    "kaggle_web_traffic_weekly",
    "monash_m3_monthly",
    "uber_tlc_daily",
    "cdc_fluview_who_nrevss",
    "tourism_monthly",
    "rideshare_with_missing",
    "m5",
    "favorita_sales",
    "taxi_30min",
}

HIGH_FREQUENCY_KEYWORDS = (
    "building",
    "azure",
    "borg",
    "alibaba",
    "taxi",
    "metro",
    "pems",
    "traffic",
    "electric",
    "solar",
    "wind",
    "web",
    "load",
)

class ShortNaNPaddingMixin:
    history_length = 2048
    padded_prediction_length = 192
    pretrain_uniform_horizon_ratio = 0.20

    def _set_official_history_lengths(self, values_by_config) -> None:
        normalized = {}
        for config, values in values_by_config.items():
            clipped = tuple(
                max(1, min(self.history_length, int(value)))
                for value in values
                if int(value) > 0
            )
            if clipped:
                normalized[tuple(config)] = clipped
        if len(normalized) != 55:
            raise ValueError(
                f"Expected history distributions for 55 short configs, got {len(normalized)}"
            )
        self.official_history_lengths = normalized
        self.official_history_configs = tuple(normalized)
        self.eligible_histories_by_horizon = {}
        self.eligible_configs_by_horizon = {}
        for prediction_length in range(1, self.padded_prediction_length + 1):
            by_config = {
                config: tuple(
                    value for value in values if value > prediction_length
                )
                for config, values in normalized.items()
            }
            by_config = {
                config: values for config, values in by_config.items() if values
            }
            self.eligible_histories_by_horizon[prediction_length] = by_config
            self.eligible_configs_by_horizon[prediction_length] = tuple(by_config)

    @staticmethod
    def _sanitize_series(series: np.ndarray) -> np.ndarray:
        series = np.asarray(series, dtype=np.float32).copy()
        series[~np.isfinite(series)] = np.nan
        return series

    def _sample_history_length(
        self,
        rng: random.Random,
        prediction_length: int,
        history_config: tuple[str, str] | None = None,
    ) -> int | None:
        prediction_length = int(prediction_length)
        eligible_by_config = self.eligible_histories_by_horizon.get(
            prediction_length, {}
        )
        if history_config is None:
            # Pretraining data has no matching GIFT-Eval config. Choose
            # uniformly among configs that can provide history > horizon.
            eligible_configs = self.eligible_configs_by_horizon.get(
                prediction_length, ()
            )
            if not eligible_configs:
                return None
            history_config = rng.choice(eligible_configs)
        elif tuple(history_config) not in self.official_history_lengths:
            raise KeyError(f"Missing official history distribution for {history_config}")
        eligible_histories = eligible_by_config.get(tuple(history_config), ())
        if not eligible_histories:
            return None
        return int(rng.choice(eligible_histories))

    def _sample_prediction_length(
        self,
        rng: random.Random,
        series_length: int,
        fixed_prediction_length: int | None,
    ) -> int | None:
        if fixed_prediction_length is not None:
            choices = (int(fixed_prediction_length),)
        elif rng.random() < self.pretrain_uniform_horizon_ratio:
            choices = tuple(range(self.output_patch_size, self.padded_prediction_length + 1, self.output_patch_size))
        else:
            choices = self.short_prediction_lengths
        valid = [value for value in choices if 0 < int(value) < series_length]
        return int(rng.choice(valid)) if valid else None

    def _sample_short_windows(
        self,
        series: np.ndarray,
        rng: random.Random,
        max_windows: int,
        fixed_prediction_length: int | None = None,
        history_config: tuple[str, str] | None = None,
    ) -> list[dict]:
        series = self._sanitize_series(series)
        series_length = int(series.shape[0])
        windows = []
        for _ in range(min(self.windows_per_series, max_windows)):
            prediction_length = self._sample_prediction_length(
                rng, series_length, fixed_prediction_length
            )
            if prediction_length is None:
                continue
            requested_history = self._sample_history_length(
                rng,
                prediction_length=prediction_length,
                history_config=history_config,
            )
            if requested_history is None:
                continue
            latest_start = series_length - prediction_length
            # Match official short evaluation geometry: every forecast must
            # have a strictly longer observed history than its horizon.
            if latest_start <= prediction_length:
                continue
            if latest_start >= requested_history:
                forecast_start = rng.randint(requested_history, latest_start)
            else:
                forecast_start = latest_start
            history = series[
                max(0, forecast_start - requested_history) : forecast_start
            ]
            future = series[
                forecast_start : forecast_start + prediction_length
            ]
            history_valid = np.isfinite(history)
            future_valid = np.isfinite(future)
            if history.shape[0] <= prediction_length:
                continue
            if not history_valid.any() or not future_valid.any():
                continue

            context = np.full(self.history_length, np.nan, dtype=np.float32)
            context_mask = np.zeros(self.history_length, dtype=np.float32)
            future_target = np.full(
                self.padded_prediction_length, np.nan, dtype=np.float32
            )
            future_target_mask = np.zeros(
                self.padded_prediction_length, dtype=np.float32
            )
            context[-history.shape[0] :] = history
            context_mask[-history.shape[0] :] = history_valid.astype(np.float32)
            future_target[:prediction_length] = future
            future_target_mask[:prediction_length] = future_valid.astype(np.float32)
            windows.append(
                {
                    "context": context,
                    "context_mask": context_mask,
                    "future_target": future_target,
                    "future_target_mask": future_target_mask,
                    "history_length": int(history_valid.sum()),
                    "prediction_length": prediction_length,
                }
            )
        return windows

    def _curriculum_limits(self, batch_index):
        return self.history_length, self.padded_prediction_length

    def _collate_chronos2_batch(self, samples):
        context = torch.as_tensor(
            np.stack([item["context"] for item in samples]), dtype=torch.float32
        )
        context_mask = torch.as_tensor(
            np.stack([item["context_mask"] for item in samples]), dtype=torch.float32
        )
        future_target = torch.as_tensor(
            np.stack([item["future_target"] for item in samples]), dtype=torch.float32
        )
        future_target_mask = torch.as_tensor(
            np.stack([item["future_target_mask"] for item in samples]),
            dtype=torch.float32,
        )
        return {
            "context": context,
            "context_mask": context_mask,
            "future_target": future_target,
            "future_target_mask": future_target_mask,
            "group_ids": torch.arange(len(samples), dtype=torch.long),
            "future_covariates": None,
            "future_covariates_mask": None,
            "num_output_patches": self.padded_prediction_length
            // self.output_patch_size,
        }

class BalancedShortPretrainDataset(
    ShortNaNPaddingMixin, GIFTEvalDynamicStreamingDataset
):
    def __init__(
        self,
        *args,
        short_prediction_lengths,
        official_history_lengths,
        **kwargs,
    ):
        super().__init__(*args, **kwargs)
        self.short_prediction_lengths = tuple(int(x) for x in short_prediction_lengths)
        self._set_official_history_lengths(official_history_lengths)
        self.dataset_buckets = self._build_dataset_buckets()
        print(
            "Balanced pretrain buckets: "
            + ", ".join(
                f"{name}={len(values)}" for name, values in self.dataset_buckets.items()
            ),
            flush=True,
        )

    def _build_dataset_buckets(self):
        buckets = {
            "general": [],
            "cmip6": [],
            "era5": [],
            "short_irregular": [],
            "high_frequency": [],
        }
        for dataset_name in self.dataset_names:
            normalized = dataset_name.lower()
            if normalized.startswith("cmip6_"):
                bucket = "cmip6"
            elif normalized.startswith("era5_"):
                bucket = "era5"
            elif normalized in SHORT_IRREGULAR_PRETRAIN_DATASETS:
                bucket = "short_irregular"
            elif any(token in normalized for token in HIGH_FREQUENCY_KEYWORDS):
                bucket = "high_frequency"
            else:
                bucket = "general"
            buckets[bucket].append(dataset_name)
        if any(not values for values in buckets.values()):
            raise ValueError(f"Empty pretrain sampling bucket: {buckets}")
        return buckets

    def _choose_dataset(self, rng: random.Random) -> tuple[str, str]:
        draw = rng.random()
        if draw < 0.50:
            bucket = "general"
        elif draw < 0.60:
            bucket = "cmip6"
        elif draw < 0.70:
            bucket = "era5"
        elif draw < 0.90:
            bucket = "short_irregular"
        else:
            bucket = "high_frequency"
        return bucket, rng.choice(self.dataset_buckets[bucket])

    def _sample_from_record(
        self, sample, rng, max_windows, max_history_len=None, max_pred_len=None
    ):
        target = np.asarray(sample["target"], dtype=np.float32)
        if target.ndim == 1:
            target = target.reshape(1, -1)
        elif target.ndim != 2:
            return []
        windows = []
        channel_indices = list(range(target.shape[0]))
        rng.shuffle(channel_indices)
        for channel_idx in channel_indices:
            windows.extend(
                self._sample_short_windows(
                    target[channel_idx],
                    rng,
                    max_windows - len(windows),
                )
            )
            if len(windows) >= max_windows:
                break
        return windows

    def _iter_pool_generator(
        self,
        arrow_orders,
        arrow_positions,
        rng,
        dataset_rng,
        shard_id,
        num_shards,
        global_num_shards,
        rank,
        worker_id,
    ):
        arrow_cache = OrderedDict()
        invalid_arrow_paths = set()
        emitted = 0
        skipped = 0
        pool_epoch = 0
        start_time = time.time()
        while True:
            pool = []
            bucket_counts = {name: 0 for name in self.dataset_buckets}
            while len(pool) < self.sample_pool_size:
                bucket, dataset_name = self._choose_dataset(dataset_rng)
                bucket_counts[bucket] += 1
                target = min(
                    self.samples_per_dataset_block,
                    self.sample_pool_size - len(pool),
                )
                block = []
                skipped += self._fill_dataset_block(
                    block=block,
                    dataset_name=dataset_name,
                    arrow_orders=arrow_orders,
                    arrow_positions=arrow_positions,
                    rng=rng,
                    shard_id=shard_id,
                    num_shards=num_shards,
                    arrow_cache=arrow_cache,
                    invalid_arrow_paths=invalid_arrow_paths,
                    target_windows=target,
                    max_history_len=self.history_length,
                    max_pred_len=self.padded_prediction_length,
                )
                for sample in block:
                    sample["source_type"] = 0
                    sample["source_dataset"] = dataset_name
                    sample["source_term"] = "pretrain"
                pool.extend(block)
            rng.shuffle(pool)
            pool_epoch += 1
            emitted += len(pool)
            if (
                self.log_interval
                and rank == 0
                and worker_id == 0
                and emitted % self.log_interval < len(pool)
            ):
                print(
                    f"[balanced pretrain rank={rank} worker={worker_id}] "
                    f"pool_epoch={pool_epoch} pool_ready={len(pool)} "
                    f"worker_windows={emitted} bucket_blocks={bucket_counts} "
                    f"skipped={skipped} elapsed={time.time() - start_time:.1f}s",
                    flush=True,
                )
            while pool:
                yield pool.pop()

