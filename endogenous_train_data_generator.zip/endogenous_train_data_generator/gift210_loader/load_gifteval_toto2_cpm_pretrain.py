from __future__ import annotations

import os

import random

import time

import numpy as np

import torch

from load_gifteval_pretrain_dataset_dynamic import GIFTEvalTrainPartStreamingDataset

from load_gifteval_short_balanced_pretrain import BalancedShortPretrainDataset, CRPS_HARD_CONFIGS, MASE_HARD_CONFIGS

CHECKPOINT_4000_DEGRADED_SHORT_CONFIGS = (
    "bitbrains_fast_storage/5T", "bitbrains_fast_storage/H",
    "bitbrains_rnd/5T", "bitbrains_rnd/H",
    "bizitobs_application/10S", "bizitobs_l2c/H", "covid_deaths/D",
    "electricity/15T", "ett1/D", "ett1/W-THU", "ett2/D", "ett2/W-THU",
    "hierarchical_sales/D", "hierarchical_sales/W-WED", "hospital/M",
    "jena_weather/10T", "jena_weather/D", "kdd_cup_2018/D",
    "loop_seattle/5T", "loop_seattle/D", "m4_daily/D", "m4_monthly/M",
    "m4_quarterly/Q-DEC", "m4_weekly/W-SUN", "m4_yearly/A-DEC",
    "saugeen/D", "saugeen/M", "solar/D", "solar/H", "solar/W-FRI",
    "us_births/D", "us_births/M",
)

class Toto2SequenceMixin:
    """Sample fixed-width Toto-2 sequences while preserving natural missingness."""

    max_sequence_length = 8192
    history_length = 8192
    # CPM uses the complete fixed-width sequence; no synthetic future patch.
    padded_prediction_length = 8192

    def __init__(self, *args, toto2_sequence_length=8192, **kwargs):
        self.max_sequence_length = int(toto2_sequence_length)
        self.history_length = int(toto2_sequence_length)
        super().__init__(*args, **kwargs)

    @staticmethod
    def _sanitize_series(series: np.ndarray) -> np.ndarray:
        series = np.asarray(series, dtype=np.float32).copy()
        series[~np.isfinite(series)] = np.nan
        return series

    def _sample_toto2_windows(
        self,
        series: np.ndarray,
        rng: random.Random,
        max_windows: int,
    ) -> list[dict]:
        series = self._sanitize_series(series)
        series_length = int(series.shape[0])
        if series_length < 2 or not np.isfinite(series).any():
            return []

        # A short series contributes its longest available sequence once.
        # A long series contributes independently sampled 8192-point windows.
        num_windows = 1 if series_length <= self.max_sequence_length else min(
            self.windows_per_series, max_windows
        )
        windows = []
        for _ in range(num_windows):
            if series_length <= self.max_sequence_length:
                start = 0
            else:
                start = rng.randint(0, series_length - self.max_sequence_length)
            values = series[start : start + self.max_sequence_length]
            valid = np.isfinite(values)
            if not valid.any():
                continue

            target = np.full(self.max_sequence_length, np.nan, dtype=np.float32)
            target_mask = np.zeros(self.max_sequence_length, dtype=np.float32)
            target[-values.shape[0] :] = values
            target_mask[-values.shape[0] :] = valid.astype(np.float32)

            patch_valid = target_mask.reshape(-1, self.patch_len).sum(axis=-1) > 0
            # The first valid patch has no preceding hidden position from which
            # a next-patch prediction can be supervised.
            if int(patch_valid.sum()) < 2:
                continue
            windows.append(
                {
                    "target": target,
                    "target_mask": target_mask,
                    "sequence_length": int(values.shape[0]),
                }
            )
            if len(windows) >= max_windows:
                break
        return windows

    def _collate_chronos2_batch(self, samples):
        return {
            "target": torch.as_tensor(
                np.stack([item["target"] for item in samples]), dtype=torch.float32
            ),
            "target_mask": torch.as_tensor(
                np.stack([item["target_mask"] for item in samples]),
                dtype=torch.float32,
            ),
            "sequence_length": torch.as_tensor(
                [item["sequence_length"] for item in samples], dtype=torch.long
            ),
            "source_type": torch.as_tensor(
                [item.get("source_type", 255) for item in samples], dtype=torch.uint8
            ),
            "source_dataset": [item.get("source_dataset", "unknown") for item in samples],
            "source_term": [item.get("source_term", "unknown") for item in samples],
        }

    def _curriculum_limits(self, batch_index):
        return self.max_sequence_length, self.patch_len

class Toto2CPMPretrainDataset(Toto2SequenceMixin, BalancedShortPretrainDataset):
    def _sample_from_record(
        self, sample, rng, max_windows, max_history_len=None, max_pred_len=None
    ):
        target = np.asarray(sample["target"], dtype=np.float32)
        if target.ndim == 1:
            target = target.reshape(1, -1)
        elif target.ndim != 2:
            return []
        windows = []
        channel_indices = list(range(target.shape[0]))
        rng.shuffle(channel_indices)
        for channel_idx in channel_indices:
            windows.extend(
                self._sample_toto2_windows(
                    target[channel_idx],
                    rng,
                    max_windows - len(windows),
                )
            )
            if len(windows) >= max_windows:
                break
        return windows

class Toto2CPMGIFTEvalDataset(
    Toto2SequenceMixin, GIFTEvalTrainPartStreamingDataset
):
    def __init__(
        self,
        *args,
        short_prediction_lengths=None,
        official_history_lengths=None,
        **kwargs,
    ):
        super().__init__(*args, **kwargs)
        self.mase_hard_configs = [
            (name, "short")
            for name in MASE_HARD_CONFIGS
            if (name, "short") in self.dataset_configs
        ]
        self.crps_hard_configs = [
            (name, "short")
            for name in CRPS_HARD_CONFIGS
            if (name, "short") in self.dataset_configs
        ]
        self.degraded_4000_configs = self._resolve_degraded_configs()
        if len(self.dataset_configs) != 97:
            raise ValueError(
                "Expected 97 GIFT-Eval training configs "
                f"(short/medium/long), got {len(self.dataset_configs)}"
            )
        if not self.mase_hard_configs or not self.crps_hard_configs:
            raise ValueError("Hard short config pools did not resolve.")
        if not self.degraded_4000_configs:
            raise ValueError("Checkpoint-4000 degraded short pool is empty.")
        previous_hard_bases = set(MASE_HARD_CONFIGS) | set(CRPS_HARD_CONFIGS)
        previous_hard = [
            config
            for config in self.dataset_configs
            if any(
                config[0] == base
                or config[0].startswith(f"{base}/")
                or config[0].split("/")[0] == base
                for base in previous_hard_bases
            )
        ]
        # The concrete difficult datasets come from the previous registry and
        # checkpoint-4000 degraded list. Expand each source to all available
        # short/medium/long terms, then remove overlaps once.
        hard_order = list(dict.fromkeys(self.degraded_4000_configs + previous_hard))
        hard_used = set()
        hard_by_term = {"short": [], "medium": [], "long": []}
        for config in hard_order:
            if config in hard_used:
                continue
            hard_used.add(config)
            if config[1] in hard_by_term:
                hard_by_term[config[1]].append(config)
        self.pool_configs = {
            "uniform_all": list(self.dataset_configs),
            "hard_short": hard_by_term["short"],
            "hard_medium": hard_by_term["medium"],
            "hard_long": hard_by_term["long"],
            "balanced_short": [c for c in self.dataset_configs if c[1] == "short"],
            "balanced_medium": [c for c in self.dataset_configs if c[1] == "medium"],
            "balanced_long": [c for c in self.dataset_configs if c[1] == "long"],
        }
        self.pool_names = tuple(self.pool_configs)
        self.pool_weights = (
            0.60,
            0.25 * 0.50,
            0.25 * 0.25,
            0.25 * 0.25,
            0.15 / 3.0,
            0.15 / 3.0,
            0.15 / 3.0,
        )
        if any(not self.pool_configs[name] for name in self.pool_names[1:]):
            raise ValueError(f"One or more hard/balanced pools are empty: {self.pool_configs}")
        print(
            "Balanced GIFT-Eval train pools: "
            f"configs={len(self.dataset_configs)} "
            f"hard_short={len(self.pool_configs['hard_short'])} "
            f"hard_medium={len(self.pool_configs['hard_medium'])} "
            f"hard_long={len(self.pool_configs['hard_long'])} "
            "mix=uniform60/hard_short50/hard_medium25/hard_long25/balanced15",
            flush=True,
        )

    def _choose_config(self, rng: random.Random, pool_state):
        pool_name = rng.choices(
            self.pool_names, weights=self.pool_weights, k=1
        )[0]
        queue = pool_state[pool_name]
        if not queue:
            queue.extend(self.pool_configs[pool_name])
            rng.shuffle(queue)
        return pool_name, queue.pop()

    def _resolve_degraded_configs(self):
        """Map evaluation aliases to the corresponding train-part configs."""
        lookup = {
            (str(name).lower(), str(term).lower()): (name, term)
            for name, term in self.dataset_configs
        }
        aliases = {
            "saugeen": "saugeenday",
            "kdd_cup_2018": "kdd_cup_2018_with_missing",
            "loop_seattle": "LOOP_SEATTLE",
        }
        resolved = []
        for config in CHECKPOINT_4000_DEGRADED_SHORT_CONFIGS:
            name, frequency = config.rsplit("/", 1)
            name_candidates = (name, aliases.get(name.lower(), name))
            frequency = {
                "A-DEC": "A",
                "Q-DEC": "Q",
                "W-SUN": "W",
                "W-WED": "W",
                "W-THU": "W",
                "W-FRI": "W",
            }.get(frequency, frequency)
            candidates = []
            for candidate_name in name_candidates:
                candidates.extend(
                    (
                        (candidate_name, frequency),
                        (candidate_name, "short"),
                        (f"{candidate_name}/{frequency}", "short"),
                    )
                )
            for candidate_name, candidate_term in candidates:
                match = lookup.get(
                    (candidate_name.lower(), candidate_term.lower())
                )
                if match is not None:
                    resolved.append(match)
                    break
        return list(dict.fromkeys(resolved))

    def _iter_pool_generator(
        self,
        Dataset,
        rng,
        dataset_rng,
        shard_id,
        num_shards,
        global_num_shards,
        rank,
        worker_id,
    ):
        emitted = 0
        skipped = 0
        pool_epoch = 0
        start_time = time.time()
        while True:
            pool = []
            pool_counts = {name: 0 for name in self.pool_names}
            pool_state = {name: list(configs) for name, configs in self.pool_configs.items()}
            for configs in pool_state.values():
                rng.shuffle(configs)
            while len(pool) < self.sample_pool_size:
                pool_name, (dataset_name, term) = self._choose_config(dataset_rng, pool_state)
                pool_counts[pool_name] += 1
                target_windows = min(
                    self.samples_per_dataset_block,
                    self.sample_pool_size - len(pool),
                )
                block = self._sample_dataset_config(
                    Dataset=Dataset,
                    dataset_name=dataset_name,
                    term=term,
                    rng=rng,
                    shard_id=shard_id,
                    num_shards=num_shards,
                    target_windows=target_windows,
                    max_history_len=self.max_sequence_length,
                    max_pred_len=self.max_sequence_length,
                )
                if block:
                    pool.extend(block)
                else:
                    skipped += 1
            rng.shuffle(pool)
            pool_epoch += 1
            emitted += len(pool)
            if (
                self.log_interval
                and rank == 0
                and worker_id == 0
                and emitted % self.log_interval < len(pool)
            ):
                print(
                    f"[balanced gifteval rank={rank} worker={worker_id}] "
                    f"pool_epoch={pool_epoch} pool_ready={len(pool)} "
                    f"worker_windows={emitted} pool_blocks={pool_counts} "
                    f"skipped={skipped} elapsed={time.time() - start_time:.1f}s",
                    flush=True,
                )
            while pool:
                yield pool.pop()

    def _sample_dataset_config(
        self,
        Dataset,
        dataset_name,
        term,
        rng,
        shard_id,
        num_shards,
        target_windows,
        max_history_len,
        max_pred_len,
    ):
        metadata = Dataset(name=dataset_name, term=term, to_univariate=False)
        dataset = Dataset(
            name=dataset_name,
            term=term,
            to_univariate=metadata.target_dim != 1,
        )
        windows = []
        for entry in dataset.training_dataset:
            target = np.asarray(entry["target"], dtype=np.float32)
            if target.ndim == 1:
                target = target.reshape(1, -1)
            elif target.ndim != 2:
                continue
            channel_indices = list(range(target.shape[0]))
            rng.shuffle(channel_indices)
            for channel_idx in channel_indices:
                sampled = self._sample_toto2_windows(
                    target[channel_idx],
                    rng,
                    target_windows - len(windows),
                )
                for sample in sampled:
                    sample["source_type"] = 1
                    sample["source_dataset"] = dataset_name
                    sample["source_term"] = term
                windows.extend(sampled)
                if len(windows) >= target_windows:
                    return windows
        return windows

