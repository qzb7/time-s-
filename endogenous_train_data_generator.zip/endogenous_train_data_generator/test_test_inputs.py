"""CPU contract tests; no real Torch, official dataset or CLIP inference."""
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import types

import numpy as np

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'encoder'))
from test_inputs import context_order,rank_views,view_counts

stub=types.ModuleType('torch')
stub.tensor=np.asarray
stub.uint8=np.uint8
data=types.ModuleType('torch.utils.data')
data.IterableDataset=object
sys.modules.update({'torch':stub,'torch.utils.data':data})
spec=importlib.util.spec_from_file_location('test_input_loader',ROOT/'encoder/test_input_loader.py')
loader=importlib.util.module_from_spec(spec)
spec.loader.exec_module(loader)

assert view_counts(200000,[1,10,0,2])==[66667,66667,0,66666]
assert view_counts(-1,[1,10,0,2])==[1,10,0,2]
assert view_counts(0,[1,2])==[0,0]

class NoLabels:
    @property
    def label(self):
        raise AssertionError('Future labels must NEVER be accessed')

    @property
    def input(self):
        short=np.arange(19,dtype=np.float32)
        short[4]=np.nan
        return iter([
            dict(target=short,item_id='short',start='synthetic'),
            dict(target=np.arange(10000,dtype=np.float32),item_id='long',start='synthetic')])

class FakeDataset:
    hf_dataset=types.SimpleNamespace(_fingerprint='fake')
    test_data=NoLabels()

loader.open_dataset=lambda task:FakeDataset()
task=dict(key='time/fake/short',benchmark='time',dataset='fake',term='short',
    source_type=5,available=2,horizon=96,fingerprint='fake',
    selected=103,global_offset=0,context_indices=context_order(2,103,42,'fake'))
plan=dict(version=3,total=103,tasks=[task],labels_accessed=False)
logical=[]
with tempfile.TemporaryDirectory(prefix='test-history-') as tmp:
    tmp=Path(tmp)
    planfile=tmp/'plan.json'
    planfile.write_text(json.dumps(plan))
    for world in (6,32):
        out=tmp/f'world{world}'
        os.environ.update(TEST_INPUT_PLAN=str(planfile),TEST_INPUT_SHARDS=str(out),WORLD_SIZE=str(world))
        ids=[]
        views={}
        for rank in range(world):
            os.environ['RANK']=str(rank)
            batches=list(loader.TestInputDataset(batch_size=3,seed=42))
            n=sum(len(b['target']) for b in batches)
            assert n==max(0,(103-rank+world-1)//world)
            metadata=[json.loads(s) for s in (out/f'samples-rank-{rank:04d}.jsonl').read_text().splitlines()]
            rows=[row for b in batches for row in b['target']]
            for batch in batches:
                assert batch['target'].shape[1]==8192
                assert np.all(batch['target_mask']==np.isfinite(batch['target']))
            for meta,row in zip(metadata,rows):
                assert meta['labels_accessed'] is False
                assert row[-1] in (18,9999)
                if meta['item_id']=='short':
                    assert meta['segment_length']==19 and meta['left_padding']==8173
                    assert np.isnan(row[:-19]).all() and np.isnan(row[-15])
                else:
                    assert meta['segment_length']==meta['requested_crop_length']
                ids.append(meta['global_id'])
                views[meta['global_id']]=(meta['official_input_index'],meta['history_start'],meta['history_end'])
        assert sorted(ids)==list(range(103))
        logical.append(views)
assert logical[0]==logical[1]
assert {width for rows in rank_views(task,0,1).values() for _,_,width in rows}=={8192,6144,4096,3072,2048}

# A task offset and more workers than rows must also preserve all IDs.
small=dict(task,selected=1,global_offset=7,context_indices=[0])
small_ids=[gid for r in range(32) for rows in rank_views(small,r,32).values() for gid,_,_ in rows]
assert small_ids==[7]

# Dry-run must forward counts, skip training and never start an encoder.
env=dict(os.environ,GENERATOR_PYTHON=sys.executable)
for key in ('RANK','WORLD_SIZE','LOCAL_RANK','LOCAL_WORLD_SIZE'):
    env.pop(key,None)
output=subprocess.run(['bash',str(ROOT/'start_generator.sh'),'--dry-run','--gpus=8',
    '--total=0','--gifteval_test_count=7','--time-test-count','9'],
    env=env,capture_output=True,text=True,check=True).stdout
assert '--gifteval-test-count 7' in output and '--time-test-count 9' in output
assert str(ROOT/'prepare.py') not in output
assert 'TEST HISTORY ONLY' in output
print('PASS history-only: label guard, exact quotas, crop cycle, masks/padding, 6/32 ranks, test-only CLI')
