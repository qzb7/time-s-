"""CPU launch contracts with a mocked encoder; never starts Torch/GPU jobs."""
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile

ROOT=Path(__file__).resolve().parent
env=dict(os.environ,GENERATOR_PYTHON=sys.executable)
for key in ('RANK','WORLD_SIZE','LOCAL_RANK','LOCAL_WORLD_SIZE','NNODES','NODE_RANK','MASTER_ADDR','SLURM_NNODES','SLURM_NODEID'):
    env.pop(key,None)

def dry(extra,custom_env=None):
    result=subprocess.run(['bash',str(ROOT/'start_generator.sh'),'--dry-run','--gpus=8',*extra],
        env=custom_env or env,capture_output=True,text=True)
    assert result.returncode==0,result.stderr
    return result.stdout

assert '-m torch.distributed.run' in dry(['--total','103'])
assert '--nproc_per_node 8' in dry(['--total','103'])
assert '--nnodes 4' in dry(['--nodes','4','--node-rank','2','--master-addr','10.0.0.1'])
assert 'prepare.py ->' not in dry(['--total','0','--time-test-count','10'])
pre=dict(env,RANK='9',WORLD_SIZE='32',LOCAL_RANK='1')
assert '-m torch.distributed.run' not in dry(['--total','103'],pre)
for args in (['--total','-1'],['--total','0'],['--nodes','2'],['--gpus','32','--launch-mode','background'],['--bad-option','1']):
    result=subprocess.run(['bash',str(ROOT/'start_generator.sh'),'--dry-run','--gpus','8',*args],
        env=env,capture_output=True,text=True)
    assert result.returncode!=0,args

# This temporary fake Python handles ONLY the integration test's GPU-free path.
BACKEND=r'''#!/usr/bin/env python3
import json,os,pathlib,subprocess,sys
args=sys.argv[1:]
def value(flag): return args[args.index(flag)+1]
if args[:1]==['-c']:
    if 'torch.cuda.device_count' in args[1]: print(8); sys.exit(0)
    sys.exit(subprocess.call([sys.executable,*args]))
if args[:1]==['-u']: args=args[1:]
name=pathlib.Path(args[0]).name
log=pathlib.Path(os.environ['TEST_LAUNCH_LOG'])
with log.open('a') as stream: stream.write(json.dumps(args)+'\n')
if name=='configure.py':
    sys.exit(subprocess.call([sys.executable,*args]))
elif name=='prepare.py':
    output=pathlib.Path(args[2]); output.mkdir(); (output/'READY.json').write_text('{}')
elif name=='prepare_test_inputs.py':
    output=pathlib.Path(value('--output')); output.parent.mkdir()
    total=max(0,int(value('--gifteval-test-count')))+max(0,int(value('--time-test-count')))
    output.write_text(json.dumps(dict(total=total,labels_accessed=False)))
elif args[:2]==['-m','torch.distributed.run']:
    if os.getenv('TEST_FAIL_PHASE')==os.environ['GENERATOR_DATA_SPLIT']: sys.exit(7)
    nodes=int(value('--nnodes')); local=int(value('--nproc_per_node')); node=int(value('--node_rank'))
    world=nodes*local; total=int(value('--num_samples')); output=pathlib.Path(value('--output_dir'))
    assert str(output)==os.environ['ZARR_RANK_ROOT']
    expected_loader='test_input_loader' if os.environ['GENERATOR_DATA_SPLIT']=='test_inputs' else 'gift210_mix_loader'
    assert value('--loader_module')==expected_loader
    assert int(value('--block_size'))%world==0
    for rank in range(node*local,(node+1)*local):
        n=max(0,(total-rank+world-1)//world)
        (output/f'DONE-rank-{rank:04d}.json').write_text(json.dumps(dict(rank=rank,world=world,samples=n,expected=n,total=total)))
elif name=='merge.py':
    if os.getenv('TEST_FAIL_MERGE'): sys.exit(9)
    source=pathlib.Path(args[1]); output=pathlib.Path(args[2]); expected=int(value('--expected'))
    markers=[json.loads(p.read_text()) for p in source.glob('DONE-rank-*.json')]
    assert len(markers)==markers[0]['world']
    assert sum(m['samples'] for m in markers)==expected
    output.mkdir(); (output/'COMPLETE.json').write_text(json.dumps(dict(written_count=expected)))
else: raise AssertionError(args)
'''

with tempfile.TemporaryDirectory(prefix='generator-launch-') as tmp:
    tmp=Path(tmp)
    backend=tmp/'python-mock'
    backend.write_text(BACKEND)
    backend.chmod(0o755)
    base=dict(env,TEST_LAUNCH_LOG=str(tmp/'calls.jsonl'),GENERATOR_TIMEOUT='15')
    common=['bash',str(ROOT/'start_generator.sh'),'--python',str(backend),'--gpus','2']
    train=tmp/'train-and-test'
    subprocess.run([*common,'--output',str(train),'--total','103',
        '--gifteval-test-count','7','--time-test-count','9'],env=base,check=True,capture_output=True)
    assert json.loads((train/'merged/COMPLETE.json').read_text())['written_count']==103
    assert json.loads((train/'test_inputs/merged/COMPLETE.json').read_text())['written_count']==16
    calls=[json.loads(s) for s in (tmp/'calls.jsonl').read_text().splitlines()]
    names=[Path(c[0]).name for c in calls]
    assert names==['configure.py','prepare.py','-m','merge.py','prepare_test_inputs.py','-m','merge.py']
    # Real configure.py guards against output overwrite; no second prepare happens.
    failed=subprocess.run([*common,'--output',str(train),'--total','103'],env=base,capture_output=True)
    assert failed.returncode!=0
    # A failed encoder must never trigger merge.
    failure=tmp/'failure'
    failed=subprocess.run([*common,'--output',str(failure),'--total','103'],
        env=dict(base,TEST_FAIL_PHASE='training'),capture_output=True)
    assert failed.returncode==7
    assert list(failure.glob('FAILED-*')) and not (failure/'merged').exists()
    merge_failure=tmp/'merge-failure'
    failed=subprocess.run([*common,'--output',str(merge_failure),'--total','103'],
        env=dict(base,TEST_FAIL_MERGE='1'),capture_output=True)
    assert failed.returncode==9 and (merge_failure/'FAILED-training-merge').exists()
    # Two node launchers: rank-zero prepares once, global markers precede merge.
    multi=tmp/'multi'
    jobs=[]
    for rank in (0,1):
        jobs.append(subprocess.Popen([*common,'--output',str(multi),'--total','0',
            '--time-test-count','3','--nodes','2','--node-rank',str(rank),
            '--master-addr','127.0.0.1'],env=base,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True))
    for job in jobs:
        out,err=job.communicate(timeout=25)
        assert job.returncode==0,(out,err)
    assert json.loads((multi/'test_inputs/merged/COMPLETE.json').read_text())['written_count']==3
print('PASS CPU launch: direct torchrun, dry-run, test-only, prelaunched ranks, exact phase order, output protection, failure/no-merge, two-node coordination')
