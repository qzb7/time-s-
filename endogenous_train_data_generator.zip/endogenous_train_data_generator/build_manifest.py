import ast
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent
manifest = {}
for path in sorted(root.rglob("*")):
    if not path.is_file() or "__pycache__" in path.parts or "legacy" in path.parts or path.name in ("SHA256.json", ".DS_Store") or path.name.startswith("._") or path.suffix == ".pyc":
        continue
    if path.suffix == ".py":
        ast.parse(path.read_text())
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024*1024), b""):
            h.update(chunk)
    manifest[str(path.relative_to(root))] = h.hexdigest()
(root / "SHA256.json").write_text(json.dumps(manifest, indent=2))
print("Syntax + SHA256 manifest:", len(manifest), "files")
