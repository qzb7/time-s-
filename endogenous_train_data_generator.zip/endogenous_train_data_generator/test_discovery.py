import tempfile
from pathlib import Path
from discover_sources import expand

with tempfile.TemporaryDirectory() as tmp:
    root=Path(tmp)
    for name in ("chronos/m4_hourly","chronos/unknown","gift/m4_hourly","time/Example/H"):
        (root/name).mkdir(parents=True)
    for name in ("m4_hourly","unknown"):
        (root/"chronos"/name/"train.parquet").touch()
    cfg=dict(roots=dict(chronos=str(root/"chronos"),gifteval_train=str(root/"gift"),time_train=str(root/"time")),
             source_ratios=dict(chronos=20,time_train=15),
             sources=[dict(kind=k,dataset="all") for k in ("gifteval_pretrain","gifteval_train","chronos","time_train")])
    sources,excluded=expand(cfg,{"datasets":{"Example/H":{"short":{},"long":{}},"Absent/H":{"short":{}}}})
    assert len(sources)==4
    assert next(s for s in sources if s["kind"]=="time_train")["train_terms"]==["short","long"]
    assert {s["reason"] for s in excluded}=={"not_installed","no_verified_reference_mapping"}
    assert next(s for s in sources if s["kind"]=="chronos")["train_reference"]["dataset"]=="m4_hourly"
print("PASS all discovery: installed TIME terms; Chronos mapping; unknown exclusion; four families")
