#!/usr/bin/env python3
"""Portable presets. Dry run unless --execute; no automatic process termination."""
import argparse
import json
import os
from pathlib import Path
import shlex
import subprocess
import sys

ROOT = Path(__file__).resolve().parent

def main():
    p = argparse.ArgumentParser()
    p.add_argument("mode", choices=["timeonly", "multimodal", "resume22000", "generate"])
    p.add_argument("--paths", default=str(ROOT / "configs/paths.example.json"))
    p.add_argument("--gpus", type=int, default=6, help="GPUs per node")
    p.add_argument("--nodes", type=int, default=1)
    p.add_argument("--node-rank", type=int, default=0)
    p.add_argument("--master-addr", default="127.0.0.1")
    p.add_argument("--master-port", type=int, default=29677)
    p.add_argument("--quotas", help="TIME source/term/count JSON; default historical 200k")
    p.add_argument("--workers", type=int, default=16, help="CPU workers PER GPU")
    p.add_argument("--prefetch", type=int, default=6)
    p.add_argument("--execute", action="store_true")
    a = p.parse_args()
    if a.gpus < 1 or a.nodes < 1 or not 0 <= a.node_rank < a.nodes:
        p.error("invalid topology")
    mapping = json.loads(Path(a.paths).read_text())
    mapping.update({
        "/home/chronos-forecasting-main": str(ROOT / "stage1/chronos"),
        "/home/toto-main/dd_unit_scaling": str(ROOT / "stage1/dd_unit_scaling"),
        "/home/toto-main/toto2": str(ROOT / ("stage1" if a.mode == "timeonly" else "stage3") / "toto2"),
    })
    def relocate(value):
        if isinstance(value, list):
            return [relocate(v) for v in value]
        if isinstance(value, str):
            for old in sorted(mapping, key=len, reverse=True):
                if value == old or value.startswith(old + "/"):
                    return mapping[old] + value[len(old):]
        return value
    env = dict(os.environ, OMP_NUM_THREADS="1", MKL_NUM_THREADS="1")
    if a.mode == "generate":
        script = ROOT / "generator/extract_gifteval_test_context_transductive_105k_latest107.py"
        total = 200000
        if a.quotas:
            quota_path = Path(a.quotas).resolve()
            rows = json.loads(quota_path.read_text())
            total = sum(row["count"] for row in rows)
            env["REPRO_QUOTAS"] = str(quota_path)
        if total < a.gpus * a.nodes:
            p.error("sample count must be at least total rank count")
        env["REPRO_TIME_ROOT"] = str(ROOT / "vendor/TIME")
        env["REPRO_TIME_DATA"] = relocate("/public_data/TIME")
        # Avoid ceil(block/world)*world exceeding 100k.
        world = a.gpus * a.nodes
        config = dict(output_dir=str(Path(mapping["OUTPUT_ROOT"]) / "generation_shards"),
                      loader_module="time_test_context_targeted_200k_loader", num_samples=total,
                      start_block=0, block_size=(100000 // world) * world,
                      batch_size=64, sample_group_size=64, workers=a.workers,
                      prefetch_groups=a.prefetch, zarr_write_batch_size=64,
                      clip_model="ViT-B/32", clip_checkpoint=mapping["CLIP_CHECKPOINT"],
                      clip_batch_size=16384, seed=20260901, log_interval=1024)
    else:
        preset, folder, entry = {
            "timeonly": ("stage1.original.json", "stage1", "pretrain_toto2_short_balanced.py"),
            "multimodal": ("stage3_from27000.original.json", "stage3", "pretrain_toto2_313m_multimodal_layer16_all7_tailcpm_globalavg_additive.py"),
            "resume22000": ("stage3.original.json", "stage3", "pretrain_toto2_nonmetadata_natural_mix.py"),
        }[a.mode]
        script = ROOT / folder / entry
        config = {k: relocate(v) for k, v in json.loads((ROOT / "configs" / preset).read_text()).items()}
        config["output_dir"] = str(Path(mapping["OUTPUT_ROOT"]) / a.mode)
        if a.mode == "timeonly":
            config.pop("patch_size", None)  # derived from model, saved in args but not a CLI option
            config["stop_after_steps"] = 27000
    output = Path(config["output_dir"])
    if a.execute and a.node_rank == 0 and output.exists() and any(output.iterdir()):
        p.error(f"Refusing to overwrite nonempty output: {output}; choose a fresh OUTPUT_ROOT")
    cmd = [sys.executable, "-m", "torch.distributed.run", f"--nproc_per_node={a.gpus}",
           f"--nnodes={a.nodes}", f"--node_rank={a.node_rank}",
           f"--master_addr={a.master_addr}", f"--master_port={a.master_port}", str(script)]
    for key, value in config.items():
        if value is None:
            continue
        cmd.append("--" + key)
        cmd.extend(str(v).lower() if isinstance(v, bool) else str(v)
                   for v in (value if isinstance(value, list) else [value]))
    print(shlex.join(cmd), flush=True)
    if a.execute:
        subprocess.run(cmd, env=env, check=True, cwd=str(script.parent))

if __name__ == "__main__":
    main()
