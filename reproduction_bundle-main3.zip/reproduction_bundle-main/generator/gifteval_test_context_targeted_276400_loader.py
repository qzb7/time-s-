from __future__ import annotations

import hashlib
import os
import random
import sys

import numpy as np
import torch
from torch.utils.data import IterableDataset


# Exact requested quota. Keys are (GIFTEval dataset name, horizon term).
# Solar and M4 are intentionally excluded: the new bank focuses on configs
# that remain behind TiRex-2 and have enough contexts/channels for diverse views.
CONFIG_QUOTAS = {
    # LOOP Seattle/H: 60,000
    ("LOOP_SEATTLE/H", "short"): 25000,
    ("LOOP_SEATTLE/H", "medium"): 20000,
    ("LOOP_SEATTLE/H", "long"): 15000,
    # Electricity: 52,000
    ("electricity/W", "short"): 20000,
    ("electricity/H", "short"): 18000,
    ("electricity/15T", "short"): 9000,
    ("electricity/D", "short"): 5000,
    # BizITObs Application: 30,000
    ("bizitobs_application", "short"): 30000,
    # Jena Weather: 25,000
    ("jena_weather/D", "short"): 18000,
    ("jena_weather/10T", "long"): 7000,
    # US Births: 5,000
    ("us_births/D", "short"): 5000,
    # ETT: 37,000 (ETT1 32,000 + ETT2 5,000)
    ("ett1/H", "medium"): 12000,
    ("ett1/H", "long"): 14000,
    ("ett1/15T", "long"): 6000,
    ("ett2/W", "short"): 5000,
    # BizITObs Service: 16,000
    ("bizitobs_service", "short"): 4000,
    ("bizitobs_service", "long"): 12000,
    # Bitbrains Fast Storage: 32,000
    ("bitbrains_fast_storage/5T", "medium"): 17000,
    ("bitbrains_fast_storage/5T", "long"): 15000,
    # Remaining targeted configs: 19,400
    ("hierarchical_sales/W", "short"): 8000,
    ("hierarchical_sales/D", "short"): 3400,
    ("restaurant", "short"): 4000,
    ("M_DENSE/H", "short"): 4000,
}
TOTAL = sum(CONFIG_QUOTAS.values())
assert TOTAL == 276400


def _pad(values: np.ndarray, width: int = 8192):
    values = np.asarray(values, dtype=np.float32).reshape(-1)
    values[~np.isfinite(values)] = np.nan
    if len(values) > width:
        values = values[-width:]
    target = np.full(width, np.nan, dtype=np.float32)
    mask = np.zeros(width, dtype=np.float32)
    if len(values):
        target[-len(values):] = values
        mask[-len(values):] = np.isfinite(values)
    return target, mask


class GIFTEvalTestContextTransductive105K(IterableDataset):
    """Finite 276,400-view test_data.input-only corpus; labels are never materialized."""

    def __init__(self, gift_eval_path, gift_eval_src, batch_size, sequence_length,
                 num_samples, seed, **_):
        if int(sequence_length) != 8192:
            raise ValueError("sequence_length must be 8192")
        if int(num_samples) != TOTAL:
            raise ValueError(f"num_samples must be {TOTAL}")
        self.gift_eval_path = str(gift_eval_path)
        self.gift_eval_src = str(gift_eval_src)
        self.batch_size = int(batch_size)
        self.seed = int(seed)

    def _contexts(self, name, term):
        os.environ["GIFT_EVAL"] = self.gift_eval_path
        os.environ["GIFT_EVAL_PATH"] = self.gift_eval_path
        if self.gift_eval_src not in sys.path:
            sys.path.insert(0, self.gift_eval_src)
        from gift_eval.data import Dataset

        # Deliberately access input only. Never iterate or materialize label.
        rows = Dataset(name=name, term=term, to_univariate=False).test_data.input
        seen, output = set(), []
        for row in rows:
            array = np.asarray(row["target"], dtype=np.float32)
            item_id = str(row.get("item_id", ""))
            channels = array if array.ndim > 1 else array.reshape(1, -1)
            for channel, values in enumerate(channels):
                # Crop immediately so long electricity histories do not consume
                # several GB per rank. Every retained value remains inside input.
                values = np.asarray(values[-8192:], dtype=np.float32).copy()
                digest = hashlib.sha1(values.tobytes()).digest()
                key = (item_id, channel, digest)
                if key not in seen:
                    seen.add(key)
                    output.append((f"{item_id}:v{channel}", values))
        if not output:
            raise RuntimeError(f"No test input contexts for {name}/{term}")
        return output

    def _build(self):
        specs = []
        for config_index, ((name, term), quota) in enumerate(CONFIG_QUOTAS.items()):
            contexts = self._contexts(name, term)
            rng = random.Random(self.seed + 1009 * config_index)
            rng.shuffle(contexts)
            for view_index in range(quota):
                item_id, values = contexts[view_index % len(contexts)]
                # Cycle the visible history length without reading beyond input.
                # Short series naturally fall back to their complete history.
                requested = (8192, 4096, 2048)[(view_index // len(contexts)) % 3]
                view = values[-min(len(values), requested):]
                specs.append((name, term, item_id, view_index, view))
        if len(specs) != TOTAL:
            raise RuntimeError(f"Expected {TOTAL} specs, got {len(specs)}")
        random.Random(self.seed).shuffle(specs)
        return specs

    def __iter__(self):
        rank = int(os.getenv("RANK", "0"))
        world = int(os.getenv("WORLD_SIZE", "1"))
        local = self._build()[rank::world]
        batch = []
        for name, term, item_id, view_index, values in local:
            target, mask = _pad(values)
            category = f"{name}|{term}|{item_id}|v{view_index}"
            batch.append({
                "target": target,
                "target_mask": mask,
                "sequence_length": min(len(values), 8192),
                "source_type": 3,
                "source_dataset": name,
                "source_term": term,
                "target_category": category[-32:],
            })
            if len(batch) == self.batch_size:
                yield self._collate(batch)
                batch = []
        if batch:
            yield self._collate(batch)

    @staticmethod
    def _collate(rows):
        return {
            "target": torch.as_tensor(np.stack([x["target"] for x in rows]), dtype=torch.float32),
            "target_mask": torch.as_tensor(np.stack([x["target_mask"] for x in rows]), dtype=torch.float32),
            "sequence_length": torch.as_tensor([x["sequence_length"] for x in rows]),
            "source_type": torch.as_tensor([x["source_type"] for x in rows], dtype=torch.uint8),
            "source_dataset": [x["source_dataset"] for x in rows],
            "source_term": [x["source_term"] for x in rows],
            "target_category": [x["target_category"] for x in rows],
        }


def create_tail_dataset(**kwargs):
    return GIFTEvalTestContextTransductive105K(**kwargs)


def create_toto2_cpm_pretraining_dataset(**kwargs):
    """Adapter for the unmodified 107 latest pipeline loader interface."""
    kwargs = dict(kwargs)
    kwargs["sequence_length"] = kwargs.pop("max_sequence_length")
    kwargs["num_samples"] = TOTAL
    return GIFTEvalTestContextTransductive105K(**kwargs)
