#!/usr/bin/env python3
"""Merge valid original rows plus the exact supplement into two validated Zarr blocks."""

from collections import Counter
from pathlib import Path
import json
import shutil
import sys

import numpy as np
import zarr
from numcodecs import Blosc

GEN_ROOT = Path("/home/toto2_stats_multimodal_generator_latest")
ORIGINAL = Path("/public_data/.toto2_multimodal_gifteval_test_context_transductive_105k_tmp")
SUPPLEMENT = Path("/public_data/.toto2_multimodal_gifteval_test_context_transductive_105k_supplement_tmp")
FINAL = Path("/public_data/toto2_multimodal_gifteval_test_context_transductive_105k")
STAGING = Path(str(FINAL) + ".merge_tmp")

sys.path.insert(0, str(GEN_ROOT))
from gifteval_test_context_transductive_105k_loader import CONFIG_QUOTAS


def valid_sources():
    paths = sorted(ORIGINAL.glob("*.zarr")) + sorted(SUPPLEMENT.glob("*.zarr"))
    if len(paths) != 18:
        raise RuntimeError(f"expected 12 original + 6 supplement stores, got {len(paths)}")
    for path in paths:
        group = zarr.open_group(str(path), mode="r")
        valid = np.flatnonzero(group["sequence_length"][:] > 0)
        yield path, group, valid


def main():
    sources = list(valid_sources())
    total = sum(len(valid) for _, _, valid in sources)
    if total != 105000:
        raise RuntimeError(f"expected 105000 valid rows before merge, got {total}")

    counts = Counter()
    for _, group, valid in sources:
        names = group["source_dataset"][valid]
        terms = group["source_term"][valid]
        counts.update(
            (name.decode().rstrip("\0"), term.decode().rstrip("\0"))
            for name, term in zip(names, terms)
        )
    if counts != Counter(CONFIG_QUOTAS):
        raise RuntimeError(f"quota mismatch before merge: actual={counts}, expected={CONFIG_QUOTAS}")

    if STAGING.exists():
        shutil.rmtree(STAGING)
    STAGING.mkdir(parents=True)
    first = sources[0][1]
    keys = list(first.array_keys())
    compressor = Blosc(cname="zstd", clevel=5, shuffle=Blosc.BITSHUFFLE)

    destinations = []
    for block_index, size in enumerate((100000, 5000)):
        out = zarr.open_group(str(STAGING / f"block-{block_index:06d}.zarr"), mode="w")
        for key in keys:
            src = first[key]
            shape = (size,) + src.shape[1:]
            chunks = (64,) + src.shape[1:] if src.shape[1:] else (64,)
            out.create_dataset(key, shape=shape, chunks=chunks, dtype=src.dtype, compressor=compressor)
        out.attrs.update(dict(first.attrs))
        out.attrs.update({
            "written_count": size,
            "image_renderer": "rgb_overlay_raw_independent_diff_shared_q01_q99_v1",
            "image_tokens_generated_directly_with": "rewrite_zarr_image_tokens_rgb.render_rgb_overlay",
            "image_tokens_posthoc_rewritten": False,
            "quota_manifest": json.dumps({f"{k[0]}|{k[1]}": v for k, v in CONFIG_QUOTAS.items()}, sort_keys=True),
        })
        destinations.append(out)

    global_offset = 0
    for path, group, valid in sources:
        for start in range(0, len(valid), 64):
            idx = valid[start:start + 64]
            src_left = 0
            while src_left < len(idx):
                block_index = 0 if global_offset < 100000 else 1
                block_offset = global_offset if block_index == 0 else global_offset - 100000
                room = destinations[block_index][keys[0]].shape[0] - block_offset
                take = min(room, len(idx) - src_left)
                chosen = idx[src_left:src_left + take]
                for key in keys:
                    destinations[block_index][key][block_offset:block_offset + take] = group[key][chosen]
                global_offset += take
                src_left += take
        print(f"COPIED {path.name} valid={len(valid)} total={global_offset}", flush=True)

    if global_offset != 105000:
        raise RuntimeError(f"copy ended at {global_offset}")
    (STAGING / "metadata.json").write_text(json.dumps({
        "total": 105000,
        "blocks": [100000, 5000],
        "quota": {f"{k[0]}|{k[1]}": v for k, v in CONFIG_QUOTAS.items()},
    }, indent=2))
    if FINAL.exists():
        shutil.rmtree(FINAL)
    STAGING.rename(FINAL)
    print(f"MERGE_VALID total=105000 output={FINAL}", flush=True)


if __name__ == "__main__":
    main()
