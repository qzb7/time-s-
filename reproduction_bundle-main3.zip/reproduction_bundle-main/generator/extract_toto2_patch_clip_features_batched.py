#!/usr/bin/env python3
"""Fast cross-sample Qwen + CLIP extraction for Toto-2 8192/32 patches."""

from __future__ import annotations

import argparse
from concurrent.futures import ProcessPoolExecutor, ThreadPoolExecutor
import json
import os
import shutil
import sys
import time
from pathlib import Path

import numpy as np
import requests
import torch
from PIL import Image
from tqdm import tqdm

sys.path.insert(0, str(Path(__file__).resolve().parent))
from extract_toto2_patch_clip_features import (  # noqa: E402
    compute_global_differences,
    make_patch_image,
    make_patch_channel_images,
    sample_id,
    value_text,
)


def _describe_sample_worker(item):
    from toto2_stats_template import describe_sample
    values, valid, patch_size = item
    return describe_sample(values, valid, patch_size)


def _render_channel_image(args):
    return make_patch_channel_images(*args)


def _safe_component(value: str) -> str:
    """Convert a dataset/config name into one safe directory component."""
    return "".join(
        char if char.isalnum() or char in "._-" else "__"
        for char in str(value)
    ).strip("._") or "unknown"


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser()
    p.add_argument("--data_dir", default="/data/GIFTEvalPretrain")
    p.add_argument("--gift_eval_path", default="/data/GIFTEval")
    p.add_argument("--gift_eval_src", default="/home/chronos-forecasting-main/gift-eval/src")
    p.add_argument("--output_dir", default="/data/toto2_multimodal_text_clip_1m")
    p.add_argument("--num_samples", type=int, default=1000000)
    p.add_argument("--batch_size", type=int, default=64)
    p.add_argument("--sample_group_size", type=int, default=8)
    p.add_argument("--patch_size", type=int, default=32)
    p.add_argument("--sequence_length", type=int, default=8192)
    p.add_argument("--clip_model", default="ViT-B/32")
    p.add_argument("--clip_checkpoint", default="", help="Local OpenAI CLIP checkpoint for offline execution.")
    p.add_argument("--qwen_model", default="/home/Qwen3-VL-8B-Instruct")
    p.add_argument("--text_backend", choices=("local", "api", "stats"), default="local")
    p.add_argument("--workers", type=int, default=0)
    p.add_argument("--api_url", default="")
    p.add_argument("--api_model", default="qwen3.7-plus")
    p.add_argument("--api_key_file", default="/home/toto-main/.qwen_api_key")
    p.add_argument("--api_concurrency", type=int, default=32)
    p.add_argument("--qwen_batch_size", type=int, default=16)
    p.add_argument("--clip_batch_size", type=int, default=64)
    p.add_argument("--qwen_max_new_tokens", type=int, default=160)
    p.add_argument("--low_valid_threshold", type=float, default=0.25)
    p.add_argument("--sample_pool_size", type=int, default=61440)
    p.add_argument("--samples_per_arrow", type=int, default=512)
    p.add_argument("--samples_per_dataset_block", type=int, default=256)
    p.add_argument("--arrow_row_chunk_size", type=int, default=4096)
    p.add_argument("--windows_per_series", type=int, default=16)
    p.add_argument("--prefetch_pools", type=int, default=16)
    p.add_argument("--arrow_cache_size", type=int, default=1024)
    p.add_argument("--log_interval", type=int, default=1)
    p.add_argument("--seed", type=int, default=5252)
    p.add_argument("--save_images", type=int, default=1)
    p.add_argument("--save_text", type=int, default=1)
    p.add_argument(
        "--asset_dataset_count",
        type=int,
        default=0,
        help="For gifteval_test, save images/text only for the first N configs in ascending sample-count order.",
    )
    p.add_argument(
        "--asset_sample_count",
        type=int,
        default=0,
        help="For streaming generation, save raw text/images only for the first N samples of each 100k block.",
    )
    p.add_argument("--dataset_source", choices=("streaming", "gifteval_test"), default="streaming")
    return p.parse_args()


def setup_paths() -> None:
    for path in ("/home/toto-main", "/home/chronos-forecasting-main"):
        if path not in sys.path:
            sys.path.insert(0, path)


def compact_prompt(patch_index: int, start: int, raw: np.ndarray, valid: np.ndarray, padding: np.ndarray) -> str:
    text = value_text(raw, valid | padding)
    text = text.replace("<MISSING>", "<MISSING>")
    for i in np.flatnonzero(padding):
        values = text[1:-1].split(", ")
        values[int(i)] = "<PAD>"
        text = "[" + ", ".join(values) + "]"
    missing_mask = [int((not ok) and (not pad)) for ok, pad in zip(valid, padding)]
    padding_mask = padding.astype(int).tolist()
    return (
        "You are a senior data analyst specializing in temporal data interpretation.\n"
        "Analyze the numerical progression in this local time-series patch.\n"
        "Your description must begin exactly with 'The time series shows...'.\n"
        "Write one clear, precise, objective paragraph of 50 to 120 words.\n"
        "Describe the temporal progression from start to finish, approximate level and range, "
        "trend or changes in direction, stability, local fluctuations, peaks, valleys, abrupt changes, "
        "and the location of missing or padded positions. Do not invent values, do not treat padding "
        "as a real observation, and do not mention periodicity unless clearly supported by the values.\n"
        "Return only the paragraph, with no JSON, headings, bullets, or meta-commentary.\n\n"
        f"Patch index: {patch_index}\n"
        f"Global interval: [{start}, {start + len(raw)})\n"
        f"Metric values: {text}\n"
        f"Missing mask: {json.dumps(missing_mask)}\n"
        f"Padding mask: {json.dumps(padding_mask)}"
    )


def fixed_description(valid: np.ndarray, padding: np.ndarray, threshold: float) -> str | None:
    fraction = float(valid.mean())
    if fraction < threshold:
        return "The time series shows too few valid observations in this patch to support a reliable temporal description."
    if padding.all():
        return "The time series shows only padding in this patch, with no observed temporal values available for interpretation."
    return None


def qwen_generate(model, processor, prompts: list[str], device: torch.device, max_new_tokens: int) -> list[str]:
    chats = [
        processor.apply_chat_template(
            [{"role": "user", "content": [{"type": "text", "text": prompt}]}],
            tokenize=False,
            add_generation_prompt=True,
        )
        for prompt in prompts
    ]
    inputs = processor(text=chats, padding=True, return_tensors="pt")
    inputs = {key: value.to(device) if torch.is_tensor(value) else value for key, value in inputs.items()}
    with torch.inference_mode():
        generated = model.generate(
            **inputs,
            max_new_tokens=max_new_tokens,
            do_sample=False,
            num_beams=1,
            use_cache=True,
        )
    prompt_length = inputs["input_ids"].shape[1]
    decoded = processor.batch_decode(generated[:, prompt_length:], skip_special_tokens=True)
    return [item.strip() for item in decoded]


def api_generate(
    prompts: list[str],
    api_url: str,
    api_key: str,
    model_name: str,
    max_new_tokens: int,
    concurrency: int,
) -> list[str]:
    endpoint = api_url.rstrip("/")
    if not endpoint.endswith("/chat/completions"):
        endpoint += "/v1/chat/completions"
    headers = {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}

    def request_one(prompt: str) -> str:
        last_error = None
        for attempt in range(4):
            try:
                response = requests.post(
                    endpoint,
                    headers=headers,
                    json={
                        "model": model_name,
                        "messages": [{"role": "user", "content": prompt}],
                        "temperature": 0.3,
                        "max_tokens": max_new_tokens,
                    },
                    timeout=180,
                )
                response.raise_for_status()
                payload = response.json()
                content = payload["choices"][0]["message"].get("content", "")
                if isinstance(content, list):
                    content = "".join(
                        part.get("text", "") for part in content if isinstance(part, dict)
                    )
                content = str(content).strip()
                if content:
                    return content
                raise RuntimeError("API returned empty content")
            except Exception as exc:  # retry transient API/network failures
                last_error = exc
                time.sleep(min(2 ** attempt, 8))
        return "The time series shows a local temporal pattern based on the observed values."

    with ThreadPoolExecutor(max_workers=max(1, concurrency)) as executor:
        return list(executor.map(request_one, prompts))


def main() -> None:
    args = parse_args()
    if args.sequence_length != 8192 or args.patch_size != 32:
        raise ValueError("This pipeline requires sequence_length=8192 and patch_size=32.")
    setup_paths()
    rank = int(os.environ.get("RANK", "0"))
    world = int(os.environ.get("WORLD_SIZE", "1"))
    local_rank = int(os.environ.get("LOCAL_RANK", "0"))
    device = torch.device("cuda", local_rank if torch.cuda.is_available() else "cpu")
    if device.type == "cuda":
        torch.cuda.set_device(device)

    import open_clip

    clip_name = args.clip_model.replace("/", "-")
    clip_model, _, clip_preprocess = open_clip.create_model_and_transforms(
        clip_name, pretrained=(args.clip_checkpoint or "openai"), device=device
    )
    clip_tokenizer = open_clip.get_tokenizer(clip_name)
    clip_model.eval()
    qwen = None
    processor = None
    api_key = ""
    if args.text_backend == "stats":
        from toto2_stats_template import describe_patch, describe_sample
    elif args.text_backend == "local":
        from transformers import AutoProcessor
        import transformers

        # Qwen3.5 and Qwen3-VL use different class names across
        # Transformers versions. Prefer Qwen3.5 when available.
        qwen_cls = getattr(transformers, "Qwen3_5ForConditionalGeneration", None)
        if qwen_cls is None:
            qwen_cls = getattr(transformers, "Qwen3VLForConditionalGeneration", None)
        if qwen_cls is None:
            raise ImportError(
                "The installed Transformers version exposes neither "
                "Qwen3_5ForConditionalGeneration nor Qwen3VLForConditionalGeneration."
            )

        qwen = qwen_cls.from_pretrained(
            args.qwen_model,
            torch_dtype=torch.float16,
            device_map={"": device},
        ).eval()
        processor = AutoProcessor.from_pretrained(args.qwen_model)
        if hasattr(processor, "tokenizer"):
            processor.tokenizer.padding_side = "left"
    else:
        if not args.api_url:
            raise ValueError("--api_url is required when --text_backend=api")
        api_key = Path(args.api_key_file).read_text(encoding="utf-8").strip()
        if not api_key:
            raise ValueError(f"API key file is empty: {args.api_key_file}")

    if args.dataset_source == "gifteval_test":
        from load_gifteval_toto2_test_samples import GIFTTESTMultimodalDataset

        dataset = GIFTTESTMultimodalDataset(
            gift_eval_path=args.gift_eval_path,
            gift_eval_src=args.gift_eval_src,
            seed=args.seed,
            rank=rank,
            world_size=world,
        )
        local_target = len(dataset)
        if rank == 0:
            print(
                f"gifteval-test multimodal samples={dataset.total_size} "
                f"local_rank0={local_target} ordered_by_config_size=ascending",
                flush=True,
            )
    else:
        from load_gifteval_toto2_cpm_pretrain import create_toto2_cpm_pretraining_dataset

        dataset = create_toto2_cpm_pretraining_dataset(
            data_dir=args.data_dir,
            gift_eval_path=args.gift_eval_path,
            gift_eval_src=args.gift_eval_src,
            batch_size=args.batch_size,
            patch_size=args.patch_size,
            max_sequence_length=args.sequence_length,
            gradient_accumulation_steps=1,
            start_optimizer_step=0,
            seed=args.seed + rank,
            sample_pool_size=args.sample_pool_size,
            samples_per_arrow=args.samples_per_arrow,
            samples_per_dataset_block=args.samples_per_dataset_block,
            arrow_row_chunk_size=args.arrow_row_chunk_size,
            windows_per_series=args.windows_per_series,
            prefetch_pools=args.prefetch_pools,
            arrow_cache_size=args.arrow_cache_size,
            log_interval=args.log_interval,
        )
        local_target = (args.num_samples + world - 1) // world
    asset_dataset_names = set(
        getattr(dataset, "ordered_dataset_names", [])[: max(0, args.asset_dataset_count)]
    )
    loader = iter(dataset)

    def fetch_rows():
        batch = next(loader)
        targets = batch["target"].detach().cpu().numpy()
        masks = batch["target_mask"].detach().cpu().numpy().astype(bool)
        lengths = batch["sequence_length"].detach().cpu().numpy().astype(int)
        if args.dataset_source == "gifteval_test":
            # The official test loader yields one record at a time, unlike
            # the streaming training loader which yields tensor batches.
            if targets.ndim == 1:
                return [(
                    targets,
                    masks,
                    int(lengths),
                    str(batch["dataset"]),
                    str(batch["term"]),
                    str(batch["frequency"]),
                    int(batch["window_index"]),
                    int(batch["variate_index"]),
                    int(batch["prediction_length"]),
                )]
            return list(zip(
                targets, masks, lengths,
                list(batch["dataset"]), list(batch["term"]), list(batch["frequency"]),
                batch["window_index"].detach().cpu().numpy().astype(int),
                batch["variate_index"].detach().cpu().numpy().astype(int),
                batch["prediction_length"].detach().cpu().numpy().astype(int),
            ))
        return list(zip(targets, masks, lengths))
    root = Path(args.output_dir)
    root.mkdir(parents=True, exist_ok=True)
    # Resume by skipping the same number of samples from the deterministic
    # streaming order. Only complete sample directories count as finished.
    existing = sorted(root.rglob("patch_clip_embeddings.npz"))
    done = min(len(existing), local_target)
    group_index = 0
    started = time.time()
    pending_rows = []
    progress = tqdm(
        total=local_target,
        initial=done,
        desc=f"multimodal rank-{rank:02d}",
        unit="sample",
        dynamic_ncols=True,
        disable=os.environ.get("TQDM_DISABLE", "0") == "1",
    )

    skipped = 0
    while skipped < done:
        if not pending_rows:
            pending_rows.extend(fetch_rows())
        drop = min(done - skipped, len(pending_rows))
        del pending_rows[:drop]
        skipped += drop

    if done:
        print(f"resume rank={rank} existing_samples={done}/{local_target}", flush=True)

    image_executor = ThreadPoolExecutor(max_workers=max(4, min(32, args.workers)))
    stats_executor = (
        ProcessPoolExecutor(max_workers=max(1, args.workers))
        if args.text_backend == "stats"
        else None
    )
    padding_text_feature_cache = {}
    padding_image_feature = None
    while done < local_target:
        rows = []
        while len(rows) < args.sample_group_size and done + len(rows) < local_target:
            if not pending_rows:
                pending_rows.extend(fetch_rows())
            item = pending_rows.pop(0)
            row, mask, length = item[:3]
            rows.append((row, mask, int(length), done + len(rows), item[3:]))

        records = []
        source_by_sid = {}
        global_stats_by_row = None
        if args.text_backend == "stats":
            global_stats_by_row = list(
                stats_executor.map(
                    _describe_sample_worker,
                    ((item[0], item[1], args.patch_size) for item in rows),
                    chunksize=1,
                )
            )
        for row_index, (row, mask, sequence_length, sample_index, sample_metadata) in enumerate(rows):
            sid = sample_id(row, rank, sample_index)
            global_stats = global_stats_by_row[row_index] if global_stats_by_row is not None else None
            source_by_sid[sid] = (
                row.astype(np.float32, copy=True),
                mask.astype(bool, copy=True),
                int(sequence_length),
                sample_metadata,
            )
            padding = np.arange(args.sequence_length) < args.sequence_length - sequence_length
            diff1_full, diff2_full = compute_global_differences(row, mask)
            for patch_index in range(args.sequence_length // args.patch_size):
                left = patch_index * args.patch_size
                right = left + args.patch_size
                raw = row[left:right].astype(np.float32, copy=True)
                valid = mask[left:right] & np.isfinite(raw) & ~padding[left:right]
                pad = padding[left:right]
                fixed = fixed_description(valid, pad, args.low_valid_threshold)
                statistical_description = (
                    describe_patch(raw, valid, pad, global_stats, start=left)
                    if args.text_backend == "stats" else fixed
                )
                records.append({
                    "sample_index": sample_index,
                    "sample_id": sid,
                    "patch_index": patch_index,
                    "start": left,
                    "raw": raw,
                    "valid": valid,
                    "padding": pad,
                    "description": statistical_description,
                    "prompt": None if fixed or args.text_backend == "stats" else compact_prompt(patch_index, left, raw, valid, pad),
                    "image_args": (
                        raw, valid, diff1_full[left:right], diff2_full[left:right]
                    ),
                })

        image_args = [item.pop("image_args") for item in records]
        for item, image in zip(records, image_executor.map(_render_channel_image, image_args)):
            item["channel_images"] = image

        qwen_records = [item for item in records if item["prompt"] is not None and args.text_backend != "stats"]
        for left in range(0, len(qwen_records), args.qwen_batch_size):
            chunk = qwen_records[left:left + args.qwen_batch_size]
            prompts = [item["prompt"] for item in chunk]
            if args.text_backend == "api":
                descriptions = api_generate(
                    prompts,
                    args.api_url,
                    api_key,
                    args.api_model,
                    args.qwen_max_new_tokens,
                    args.api_concurrency,
                )
            else:
                descriptions = qwen_generate(
                    qwen, processor, prompts, device, args.qwen_max_new_tokens
                )
            for item, description in zip(chunk, descriptions):
                item["description"] = description or "The patch shows a local temporal pattern based on the observed values."

        with torch.inference_mode():
            clip_mean = torch.tensor((0.48145466, 0.4578275, 0.40821073), device=device).view(1, 3, 1, 1)
            clip_std = torch.tensor((0.26862954, 0.26130258, 0.27577711), device=device).view(1, 3, 1, 1)

            image_rows = [None] * len(records)
            full_padding_indices = [index for index, item in enumerate(records) if bool(item["padding"].all())]
            image_encode_indices = [index for index, item in enumerate(records) if not bool(item["padding"].all())]
            if padding_image_feature is None and full_padding_indices:
                image_encode_indices.append(full_padding_indices[0])
            for left in range(0, len(image_encode_indices), args.clip_batch_size):
                indices = image_encode_indices[left:left + args.clip_batch_size]
                image_np = np.stack([records[index]["channel_images"] for index in indices], axis=0)
                images = torch.from_numpy(image_np).to(device, non_blocking=True).float().div_(255.0)
                images = (images - clip_mean) / clip_std
                encoded = clip_model.encode_image(images).float().cpu().numpy()
                for index, feature in zip(indices, encoded):
                    image_rows[index] = feature
                    if bool(records[index]["padding"].all()) and padding_image_feature is None:
                        padding_image_feature = feature
            if padding_image_feature is not None:
                for index in full_padding_indices:
                    if image_rows[index] is None:
                        image_rows[index] = padding_image_feature
            image_features = np.stack(image_rows)

            text_rows = [None] * len(records)
            text_encode_indices = []
            pending_padding = {}
            for index, item in enumerate(records):
                description = item["description"]
                has_padding = bool(item["padding"].any())
                cached = padding_text_feature_cache.get(description) if has_padding else None
                if cached is not None:
                    text_rows[index] = cached
                elif has_padding:
                    if description not in pending_padding:
                        pending_padding[description] = [index]
                        text_encode_indices.append(index)
                    else:
                        pending_padding[description].append(index)
                else:
                    text_encode_indices.append(index)
            for left in range(0, len(text_encode_indices), args.clip_batch_size):
                indices = text_encode_indices[left:left + args.clip_batch_size]
                texts = clip_tokenizer([records[index]["description"] for index in indices]).to(device, non_blocking=True)
                encoded = clip_model.encode_text(texts).float().cpu().numpy()
                for index, feature in zip(indices, encoded):
                    text_rows[index] = feature
                    item = records[index]
                    if bool(item["padding"].any()):
                        description = item["description"]
                        padding_text_feature_cache[description] = feature
                        for alias_index in pending_padding.get(description, []):
                            text_rows[alias_index] = feature
            text_features = np.stack(text_rows)

        by_sample = {}
        for index, item in enumerate(records):
            by_sample.setdefault(item["sample_id"], []).append((item, image_features[index], text_features[index]))
        for sid, sample_records in by_sample.items():
            sample_metadata = source_by_sid[sid][3]
            if args.dataset_source == "gifteval_test" and sample_metadata:
                dataset_key = f"{sample_metadata[0]}__{sample_metadata[1]}"
                dataset_dir = root / _safe_component(dataset_key)
            else:
                block_index = (int(sample_records[0][0]["sample_index"]) * world + rank) // 100000
                dataset_dir = root / f"block-{block_index:06d}" / f"rank-{rank:02d}"
            dataset_dir.mkdir(parents=True, exist_ok=True)
            sample_dir = dataset_dir / sid
            if sample_dir.exists():
                # A previous OOM may have left image/text files but no final
                # npz. Remove only that incomplete sample before rebuilding.
                if (sample_dir / "patch_clip_embeddings.npz").exists():
                    continue
                shutil.rmtree(sample_dir)
            sample_dir.mkdir(parents=True, exist_ok=False)
            sample_records.sort(key=lambda item: item[0]["patch_index"])
            source_values, source_mask, source_length, _ = source_by_sid[sid]
            source_padding = np.arange(args.sequence_length) < args.sequence_length - source_length
            image_array = np.stack([item[1] for item in sample_records])
            text_array = np.stack([item[2] for item in sample_records])
            channel_array = np.stack([item[0]["channel_images"] for item in sample_records])
            image_norm = image_array / np.maximum(np.linalg.norm(image_array, axis=-1, keepdims=True), 1e-8)
            text_norm = text_array / np.maximum(np.linalg.norm(text_array, axis=-1, keepdims=True), 1e-8)
            np.savez_compressed(
                sample_dir / "patch_clip_embeddings.npz",
                image_global=image_array,
                text_global=text_array,
                image_global_normalized=image_norm,
                text_global_normalized=text_norm,
                time_series_8192=source_values,
                target_mask_8192=source_mask,
                padding_mask_8192=source_padding,
                sequence_length=np.asarray(source_length, dtype=np.int64),
                image_channels=channel_array,
            )
            metadata = {
                "sample_id": sid,
                "sequence_length": args.sequence_length,
                "patch_size": args.patch_size,
                "num_patches": len(sample_records),
                "patch_order": "ascending_global_start",
                "time_series_file": "patch_clip_embeddings.npz:time_series_8192",
                "mask_files": [
                    "patch_clip_embeddings.npz:target_mask_8192",
                    "patch_clip_embeddings.npz:padding_mask_8192",
                ],
                "global_start": [item[0]["start"] for item in sample_records],
                "valid_fraction": [float(item[0]["valid"].mean()) for item in sample_records],
                "source_mix": "GIFT-Eval official test_data.input" if args.dataset_source == "gifteval_test" else "70% GIFTEvalPretrain / 30% GIFT-Eval training_dataset",
                "clip_model": args.clip_model,
                "text_backend": args.text_backend,
                "text_description": "deterministic_stl_statistics" if args.text_backend == "stats" else "qwen",
                "qwen_model": args.qwen_model if args.text_backend == "local" else args.api_model,
            }
            sample_dataset_name = (
                f"{sample_metadata[0]}::{sample_metadata[1]}"
                if sample_metadata
                else None
            )
            local_block_index = (int(sample_records[0][0]["sample_index"]) * world + rank) % 100000
            streaming_asset_limit = args.asset_sample_count or args.asset_dataset_count
            save_sample_assets = bool(args.save_images or args.save_text) and (
                (
                    args.dataset_source != "gifteval_test"
                    and streaming_asset_limit > 0
                    and local_block_index < streaming_asset_limit
                )
                or (
                    args.dataset_source == "gifteval_test"
                    and sample_dataset_name in asset_dataset_names
                )
            )
            if sample_metadata:
                dataset_name, term, frequency, window_index, variate_index, prediction_length = sample_metadata
                metadata.update({
                    "dataset": dataset_name,
                    "term": term,
                    "frequency": frequency,
                    "window_index": int(window_index),
                    "variate_index": int(variate_index),
                    "prediction_length": int(prediction_length),
                })
            (sample_dir / "metadata.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")
            if save_sample_assets and args.save_text:
                text_dir = sample_dir / "text"
                text_dir.mkdir()
                for item, _, _ in sample_records:
                    i = item["patch_index"]
                    (text_dir / f"patch-{i:04d}.prompt.txt").write_text(item["prompt"] or "SKIPPED_LOW_VALID", encoding="utf-8")
                    (text_dir / f"patch-{i:04d}.description.txt").write_text(item["description"], encoding="utf-8")
            if save_sample_assets and args.save_images:
                image_dir = sample_dir / "image"
                image_dir.mkdir()
                for item, _, _ in sample_records:
                    Image.fromarray(np.moveaxis(item["channel_images"], 0, -1), mode="RGB").save(image_dir / f"patch-{item['patch_index']:04d}.png")

        done += len(rows)
        progress.update(len(rows))
        group_index += 1
        elapsed = max(time.time() - started, 1e-6)
        print(
            f"batched-clip-extract rank={rank} group={group_index} samples={done}/{local_target} "
            f"global_est={min(args.num_samples, done * world)} qwen_patches={len(qwen_records)} "
            f"fixed_patches={len(records) - len(qwen_records)} rate={done / elapsed:.4f} samples/s "
            f"elapsed={elapsed:.1f}s",
            flush=True,
        )

    if stats_executor is not None:
        stats_executor.shutdown(wait=True)
    image_executor.shutdown(wait=True)
    elapsed = max(time.time() - started, 1e-6)
    progress.close()
    print(f"DONE rank={rank} samples={done} elapsed={elapsed:.1f}s rate={done / elapsed:.4f} samples/s", flush=True)


if __name__ == "__main__":
    main()
