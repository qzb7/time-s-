from __future__ import annotations

import numpy as np
from statsmodels.tsa.seasonal import STL


EPS = 1e-8


def _safe_corr(a, b):
    """Correlation without NumPy divide-by-zero warnings."""
    a = np.asarray(a, dtype=np.float64)
    b = np.asarray(b, dtype=np.float64)
    finite = np.isfinite(a) & np.isfinite(b)
    a = a[finite]
    b = b[finite]
    if len(a) < 2:
        return 0.0
    a = a - np.mean(a)
    b = b - np.mean(b)
    denom = float(np.sqrt(np.dot(a, a) * np.dot(b, b)))
    if not np.isfinite(denom) or denom <= EPS:
        return 0.0
    value = float(np.dot(a, b) / denom)
    return value if np.isfinite(value) else 0.0


def _bucket(value, cuts, labels):
    return labels[int(np.digitize([value], cuts)[0])]


def _theil_sen_slope(x, positions=None):
    x = np.asarray(x, dtype=np.float64)
    if positions is None:
        positions = np.arange(len(x), dtype=np.float64)
    else:
        positions = np.asarray(positions, dtype=np.float64)
    if len(x) < 2:
        return 0.0
    dx = positions[None, :] - positions[:, None]
    dy = x[None, :] - x[:, None]
    slopes = dy[dx > 0] / dx[dx > 0]
    return float(np.median(slopes)) if len(slopes) else 0.0


def _robust_scale(x):
    x = np.asarray(x, dtype=np.float64)
    if len(x) == 0:
        return 1.0
    q25, q75 = np.percentile(x, [25, 75])
    scale = float(q75 - q25)
    if scale < EPS:
        scale = float(1.4826 * np.median(np.abs(x - np.median(x))))
    if scale < EPS:
        scale = float(np.std(x))
    return max(scale, EPS)


def _period(y):
    candidates = [2, 4, 7, 12, 24, 48, 96, 168, 336, 720]
    candidates = [p for p in candidates if p * 3 <= len(y)]
    if not candidates:
        return 2
    window = min(31, len(y))
    smooth = np.convolve(y, np.ones(window) / window, mode="same")
    residual = y - smooth
    scores = []
    for period in candidates:
        a, b = residual[period:], residual[:-period]
        scores.append(_safe_corr(a, b))
    return candidates[int(np.argmax(np.abs(scores)))]


def describe_sample(values: np.ndarray, valid: np.ndarray, patch_size: int = 32):
    """Keep the sample-level API, but do not compute global statistics.

    Descriptions are deliberately local: all numerical features are computed
    independently inside each 32-point patch in ``describe_patch``.
    """
    return None


def _padding_desc(padding):
    ratio = float(np.mean(padding))
    if ratio <= 0:
        return "no padding"
    if ratio <= 0.25:
        return "light left padding"
    if ratio <= 0.50:
        return "moderate left padding"
    return "heavy left padding"


def _missing_desc(valid, padding):
    missing = (~valid) & (~padding)
    count = int(missing.sum())
    if count == 0:
        return "no missing observations"
    transitions = np.diff(np.r_[False, missing, False].astype(np.int8))
    blocks = int(np.sum(transitions == 1))
    if blocks == 1 and count >= 2:
        return "one contiguous block of missing observations"
    if blocks > 1 and count >= max(3, len(valid) // 8):
        return "multiple blocks of missing observations"
    if count <= 2:
        return "a few isolated missing observations"
    return "scattered missing observations"


def _coverage_desc(valid):
    ratio = float(np.mean(valid))
    return _bucket(ratio, [0.375, 0.625, 0.875], ["low", "moderate", "high", "full"])


def _confidence(valid, padding):
    count = int(valid.sum())
    missing = (~valid & ~padding).sum()
    if count >= 28 and missing <= 2:
        return "high"
    if count >= 20:
        return "moderate"
    if count >= 8:
        return "low"
    return "very low"


def _trend_desc(slope, scale, length):
    normalized = slope * max(length - 1, 1) / scale
    return _bucket(
        normalized,
        [-1.0, -0.30, -0.08, 0.08, 0.30, 1.0],
        [
            "a strong downward local trend",
            "a moderate downward local trend",
            "a weak downward local trend",
            "a nearly flat local trend",
            "a weak upward local trend",
            "a moderate upward local trend",
            "a strong upward local trend",
        ],
    )


def _shape_desc(x, scale):
    if len(x) < 8:
        return "an unassessable shape"
    smooth = np.convolve(x, np.ones(5) / 5, mode="same") if len(x) >= 5 else x
    smooth[:2] = x[:2]
    smooth[-2:] = x[-2:]
    slope = _theil_sen_slope(smooth)
    split = len(smooth) // 2
    left = _theil_sen_slope(smooth[:split])
    right = _theil_sen_slope(smooth[split:])
    total = max(scale, _robust_scale(x))
    if abs(left) * len(smooth) / total > 0.10 and abs(right) * len(smooth) / total > 0.10 and left * right < 0:
        return "a U-shaped pattern" if left < 0 < right else "an inverted U-shaped pattern"
    if abs(left - right) * len(smooth) / total > 0.25:
        return "a single-reversal pattern"
    if np.max(np.abs(np.diff(smooth, 2))) > 0.30 * total:
        return "a sudden level-shift pattern"
    signs = np.sign(np.diff(smooth))
    signs = signs[signs != 0]
    turns = int(np.sum(signs[1:] != signs[:-1])) if len(signs) > 1 else 0
    if turns >= 3:
        return "a multi-turn pattern"
    if np.std(np.diff(smooth, 2)) < 0.08 * total:
        return "an approximately linear shape"
    return "a smoothly curved shape"


def _variation_desc(residual, scale):
    ratio = _robust_scale(residual) / scale
    return _bucket(ratio, [0.03, 0.10, 0.30, 0.70], ["very low", "low", "moderate", "high", "very high"])


def _volatility_pattern(residual, scale):
    if len(residual) < 8:
        return "unassessable"
    half = len(residual) // 2
    first = _robust_scale(residual[:half])
    second = _robust_scale(residual[half:])
    ratio = second / max(first, EPS)
    if ratio > 1.8:
        return "gradually increasing"
    if ratio < 0.56:
        return "gradually decreasing"
    local = np.abs(residual - np.median(residual))
    if local.max() > 3.0 * max(_robust_scale(residual), EPS):
        return "abruptly changing"
    return "stable"


def _stationarity_desc(x, residual, scale):
    """Describe local stationarity heuristically within one patch.

    A 32-point patch is too short for a reliable formal stationarity test, so
    compare robust level, scale, trend strength, and short-range dependence
    between the two halves of the patch.
    """
    if len(x) < 8:
        return "not reliably assessable from the available observations"

    half = len(x) // 2
    left = np.asarray(x[:half], dtype=np.float64)
    right = np.asarray(x[-half:], dtype=np.float64)
    robust_scale = max(float(scale), EPS)
    level_shift = abs(float(np.median(right) - np.median(left))) / robust_scale
    left_scale = _robust_scale(left)
    right_scale = _robust_scale(right)
    scale_ratio = max(left_scale, right_scale) / max(min(left_scale, right_scale), EPS)
    slope_strength = abs(_theil_sen_slope(x)) * max(len(x) - 1, 1) / robust_scale

    acf_change = 0.0
    if len(left) >= 4 and len(right) >= 4:
        left_corr = _safe_corr(left[1:], left[:-1])
        right_corr = _safe_corr(right[1:], right[:-1])
        acf_change = abs(left_corr - right_corr)

    strong_change = (
        level_shift > 0.60
        or scale_ratio > 2.50
        or slope_strength > 0.80
        or acf_change > 0.60
    )
    mild_change = (
        level_shift > 0.25
        or scale_ratio > 1.60
        or slope_strength > 0.30
        or acf_change > 0.30
    )
    if strong_change:
        return "locally non-stationary, with a substantial change in level, trend, volatility, or dependence"
    if mild_change:
        return "approximately locally stationary, but with mild changes in level, volatility, or dependence"
    return "approximately locally stationary, with stable level, volatility, and short-range dependence"


def _roughness_desc(x, scale):
    if len(x) < 2:
        return "unassessable"
    ratio = float(np.median(np.abs(np.diff(x))) / max(_robust_scale(x), EPS))
    return _bucket(ratio, [0.10, 0.30, 0.70, 1.20], ["smooth", "moderately smooth", "mixed", "jagged", "highly jagged"])


def _oscillation_desc(residual):
    if len(residual) < 8 or np.std(residual) < EPS:
        return "local periodic behavior that cannot be reliably assessed"
    scores = []
    for lag in range(2, max(3, len(residual) // 3 + 1)):
        a, b = residual[lag:], residual[:-lag]
        scores.append(abs(_safe_corr(a, b)))
    best = max(scores) if scores else 0.0
    if best >= 0.70:
        return "strong and regular local periodic behavior"
    if best >= 0.45:
        return "moderately regular local periodic behavior"
    if best >= 0.25:
        return "weak local periodic behavior"
    return "no clear local periodic behavior"


def _dependence_desc(residual):
    if len(residual) < 8 or np.std(residual) < EPS:
        return "unassessable"
    corr = _safe_corr(residual[1:], residual[:-1])
    if corr >= 0.55:
        return "strong persistent"
    if corr >= 0.20:
        return "weak persistent"
    if corr <= -0.55:
        return "strong alternating"
    if corr <= -0.20:
        return "weak alternating"
    return "little"


def _event_desc(x, residual, scale):
    if len(x) < 8:
        return "events that cannot be reliably assessed"
    robust = _robust_scale(residual)
    high = int(np.sum(residual > 3.0 * robust))
    low = int(np.sum(residual < -3.0 * robust))
    if high or low:
        if high and low:
            return "multiple isolated outliers"
        return "one isolated upward spike" if high else "one isolated downward spike"
    smooth = np.convolve(x, np.ones(3) / 3, mode="same")
    signs = np.sign(np.diff(smooth))
    signs = signs[signs != 0]
    turns = int(np.sum(signs[1:] != signs[:-1])) if len(signs) > 1 else 0
    if turns >= 3:
        return "multiple local peaks and troughs"
    if turns == 2:
        return "mixed local events"
    if turns == 1:
        return "one broad local peak" if smooth[-1] < smooth[len(smooth) // 2] else "one broad local trough"
    if np.ptp(x) < 0.08 * max(scale, EPS):
        return "a long nearly constant segment"
    return "no prominent local events"


def _regime_desc(trend, variation, volatility, oscillation, event, scale, length):
    trend_strength = abs(trend) * max(length - 1, 1) / max(scale, EPS)
    if "level-shift" in event or "level-shift" in volatility:
        return "level-shifting"
    if volatility in {"gradually increasing", "gradually decreasing", "abruptly changing"}:
        return "variance-changing"
    if oscillation.startswith("strong") or oscillation.startswith("moderately"):
        return "oscillation-dominated"
    if "spike" in event or "outliers" in event or "burst" in event:
        return "event-dominated"
    if trend_strength >= 0.30:
        return "trend-dominated"
    if variation in {"very high", "high"}:
        return "irregular"
    return "locally stable"


def describe_patch(raw, valid, padding, global_info, start: int = 0):
    raw = np.asarray(raw, dtype=np.float64)
    valid = np.asarray(valid, dtype=bool) & np.isfinite(raw) & ~np.asarray(padding, dtype=bool)
    padding = np.asarray(padding, dtype=bool)
    valid_count = int(valid.sum())

    if padding.all():
        return (
            "This patch consists entirely of left padding and contains no valid observations. "
            "Missingness and local statistical characteristics are not applicable."
        )

    missing_desc = _missing_desc(valid, padding)
    padding_desc = _padding_desc(padding)
    coverage_desc = _coverage_desc(valid)
    confidence_desc = _confidence(valid, padding)
    if valid_count < 8:
        return (
            f"This patch contains {padding_desc} and {missing_desc}, leaving {coverage_desc} valid data coverage. "
            "The local trend, shape, variation, periodic behavior, residual dependence, and local events "
            f"cannot be reliably assessed. Overall, the local behavior is not reliably assessable, and these "
            f"characteristics are estimated with {confidence_desc} confidence."
        )

    positions = np.flatnonzero(valid)
    x = raw[positions]
    scale = _robust_scale(x)
    local_slope = _theil_sen_slope(x, positions)
    # Interpolation is only used to make local smoothing continuous. The
    # original masks still determine coverage and missingness in the text.
    filled = np.interp(np.arange(len(raw)), positions, x)
    local_trend = np.polyval(np.polyfit(positions, x, 1), positions)
    trend_on_patch = np.polyval(np.polyfit(positions, x, 1), np.arange(len(raw)))
    detrended = x - local_trend
    residual = filled - trend_on_patch

    trend_desc = _trend_desc(local_slope, scale, len(raw))
    shape_desc = _shape_desc(filled, scale)
    variation_desc = _variation_desc(detrended, scale)
    volatility_desc = _volatility_pattern(residual[valid], scale)
    roughness_desc = _roughness_desc(x, scale)
    oscillation_desc = _oscillation_desc(residual[valid])
    dependence_desc = _dependence_desc(residual[valid])
    stationarity_desc = _stationarity_desc(x, residual[valid], scale)
    event_desc = _event_desc(x, detrended, scale)
    regime_desc = _regime_desc(local_slope, variation_desc, volatility_desc, oscillation_desc, event_desc, scale, len(raw))

    return (
        f"This patch contains {padding_desc} and {missing_desc}, leaving {coverage_desc} valid data coverage. "
        f"Within the valid observations, the series shows {trend_desc} and follows {shape_desc}. "
        f"Its local variation is {variation_desc}, with {volatility_desc} volatility and {roughness_desc} "
        f"point-to-point movement. The patch exhibits {oscillation_desc}. After removing the local trend, "
        f"the remaining fluctuations show {dependence_desc} short-range dependence. The patch contains "
        f"{event_desc}. Local stationarity is {stationarity_desc}. Overall, its local behavior is best "
        f"characterized as {regime_desc}, and these "
        f"characteristics are estimated with {confidence_desc} confidence."
    )
