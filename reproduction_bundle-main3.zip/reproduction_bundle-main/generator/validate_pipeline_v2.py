import sys

import numpy as np
import torch
import zarr

sys.path.insert(0, "/home/toto2_stats_multimodal_generator_latest")
from extract_toto2_patch_clip_features import make_patch_channel_images
from extract_toto2_patch_clip_features_zarr_pipeline import render_patch_images_gpu


store = "/public_data/.toto2_pipeline_smoke_20260806_v2/smoke-v2.rank-00.zarr"
group = zarr.open_group(store, mode="r")
assert group.attrs["written_count"] == 4
assert group["time_series_8192"].shape == (4, 8192)
assert group["image_global_fp16"].shape == (4, 256, 512)
assert group["text_global_fp16"].shape == (4, 256, 512)

image = group["image_global_fp16"][:] .astype(np.float32) * group["image_scale"][:]
text = group["text_global_fp16"][:] .astype(np.float32) * group["text_scale"][:]
assert np.isfinite(image).all()
assert np.isfinite(text).all()
assert np.max(np.abs(image)) > 0
assert np.max(np.abs(text)) > 0

raw = np.linspace(-2.0, 3.0, 32, dtype=np.float32)
raw[10:13] = np.nan
valid = np.isfinite(raw)
diff1 = np.full(32, np.nan, dtype=np.float32)
diff2 = np.full(32, np.nan, dtype=np.float32)
ok1 = valid[1:] & valid[:-1]
ok2 = valid[2:] & valid[1:-1] & valid[:-2]
diff1[1:][ok1] = raw[1:][ok1] - raw[:-1][ok1]
diff2[2:][ok2] = raw[2:][ok2] - raw[:-2][ok2]
cpu = make_patch_channel_images(raw, valid, diff1, diff2)
gpu = render_patch_images_gpu(
    torch.from_numpy(raw[None]).cuda(),
    torch.from_numpy(valid[None]).cuda(),
    torch.from_numpy(diff1[None]).cuda(),
    torch.from_numpy(diff2[None]).cuda(),
)[0].cpu().numpy()

cpu_line = cpu < 255
gpu_line = gpu < 255
occupancy_ratio = float(gpu_line.sum() / max(cpu_line.sum(), 1))
assert 0.70 <= occupancy_ratio <= 1.30, occupancy_ratio
print({
    "written_count": 4,
    "image_finite": True,
    "text_finite": True,
    "gpu_cpu_line_occupancy_ratio": occupancy_ratio,
})
