import os
import queue
import random
import re
import threading
import time
import math
import sys
from collections import OrderedDict
from pathlib import Path

import numpy as np
import pyarrow as pa
import torch
from datasets import Dataset as HFDataset
from torch.utils.data import IterableDataset, get_worker_info


REPO_ROOT = Path(__file__).resolve().parent
LOCAL_GIFT_EVAL_SRC = REPO_ROOT / "foundTS-main" / "GIFT-Eval" / "src"
FALLBACK_GIFT_EVAL_SRC = Path("/home/gift-eval-scan/src")


def parse_bool_flag(value, default=False):
    if value is None:
        return bool(default)
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return bool(value)
    if isinstance(value, str):
        return value.strip().lower() in {"1", "true", "yes", "y", "on"}
    return bool(value)


PRETTY_NAMES = {
    "saugeenday": "saugeen",
    "temperature_rain_with_missing": "temperature_rain",
    "kdd_cup_2018_with_missing": "kdd_cup_2018",
    "car_parts_with_missing": "car_parts",
}

GIFT_EVAL_SHORT_DATASETS = [
    "m4_yearly",
    "m4_quarterly",
    "m4_monthly",
    "m4_weekly",
    "m4_daily",
    "m4_hourly",
    "electricity/15T",
    "electricity/H",
    "electricity/D",
    "electricity/W",
    "solar/10T",
    "solar/H",
    "solar/D",
    "solar/W",
    "hospital",
    "covid_deaths",
    "us_births/D",
    "us_births/M",
    "us_births/W",
    "saugeenday/D",
    "saugeenday/M",
    "saugeenday/W",
    "temperature_rain_with_missing",
    "kdd_cup_2018_with_missing/H",
    "kdd_cup_2018_with_missing/D",
    "car_parts_with_missing",
    "restaurant",
    "hierarchical_sales/D",
    "hierarchical_sales/W",
    "LOOP_SEATTLE/5T",
    "LOOP_SEATTLE/H",
    "LOOP_SEATTLE/D",
    "SZ_TAXI/15T",
    "SZ_TAXI/H",
    "M_DENSE/H",
    "M_DENSE/D",
    "ett1/15T",
    "ett1/H",
    "ett1/D",
    "ett1/W",
    "ett2/15T",
    "ett2/H",
    "ett2/D",
    "ett2/W",
    "jena_weather/10T",
    "jena_weather/H",
    "jena_weather/D",
    "bitbrains_fast_storage/5T",
    "bitbrains_fast_storage/H",
    "bitbrains_rnd/5T",
    "bitbrains_rnd/H",
    "bizitobs_application",
    "bizitobs_service",
    "bizitobs_l2c/5T",
    "bizitobs_l2c/H",
]

# GIFT-Eval configs whose Chronos public-corpus names overlap the downstream
# datasets listed in Chronos-2 Table 6.  Keep this list conservative: only
# configs already supported by the local GIFT-Eval Dataset API are included.
CHRONOS2_DOWNSTREAM_GIFTEVAL_TRAIN_DATASETS = [
    # Electricity: electricity_15min, monash_electricity_hourly,
    # monash_electricity_weekly
    "electricity/15T",
    "electricity/H",
    "electricity/W",
    # KDD Cup (2018): monash_kdd_cup_2018
    "kdd_cup_2018_with_missing/H",
    "kdd_cup_2018_with_missing/D",
    # M4 downstream splits
    "m4_yearly",
    "m4_quarterly",
    "m4_monthly",
    "m4_weekly",
    "m4_daily",
    "m4_hourly",
    # Solar: solar, solar_1h
    "solar/10T",
    "solar/H",
    "solar/D",
    "solar/W",
    # Taxi: taxi_1h, taxi_30min.  The local GIFT-Eval config exposes the same
    # source through SZ_TAXI at 15-minute and hourly granularities.
    "SZ_TAXI/15T",
    "SZ_TAXI/H",
    # Temperature-Rain: monash_temperature_rain
    "temperature_rain_with_missing",

    "ett1/15T",
    "ett1/H",
    "ett1/D",
    "ett1/W",
    "ett2/15T",
    "ett2/H",
    "ett2/D",
    "ett2/W",

    "jena_weather/10T",
    "jena_weather/H",
    "jena_weather/D",

    "hierarchical_sales/D",
    "hierarchical_sales/W",
    "LOOP_SEATTLE/5T",
    "LOOP_SEATTLE/H",
    "LOOP_SEATTLE/D",
]

# GIFT-Eval configs with real multivariate targets/covariates in the benchmark
# tables.  The local GIFT-Eval package may not expose every config name across
# versions; multivariate training skips unavailable entries at runtime.
GIFT_EVAL_REAL_MULTIVARIATE_DATASETS = [
    # Table 13: target variates > 1
    "jena_weather/10T",
    "jena_weather/H",
    "jena_weather/D",
    "bizitobs_application",
    "bizitobs_service",
    "bizitobs_l2c/5T",
    "bizitobs_l2c/H",
    "bitbrains_fast_storage/5T",
    "bitbrains_fast_storage/H",
    "bitbrains_rnd/5T",
    "bitbrains_rnd/H",
    "ett1/15T",
    "ett1/H",
    "ett1/D",
    "ett1/W",
    "ett2/15T",
    "ett2/H",
    "ett2/D",
    "ett2/W",
    # Larger GIFT-Eval table entries; kept here if supported by the local API.
    "era5/H",
    "era5/D",
    "azure_vm_traces_2017/5T",
    "azure_vm_traces_2017/H",
    "alibaba_cluster_trace_2018/5T",
    "alibaba_cluster_trace_2018/H",
    "pems04/5T",
    "pems08/5T",
    "pems_bay/5T",
    "q_traffic/H",
]

# Chronos-2 Table 14 pretraining datasets whose # Targets >= 2.  These names
# are matched against /data/GIFTEvalPretrain Arrow subdirectories after
# normalization, and also allow yearly/sharded suffixes such as era5_1993.
CHRONOS2_PRETRAIN_TARGET_MULTIVARIATE_DATASETS = [
    "cmip6",
    "era5",
    "borg_cluster_data_2011",
    "alibaba_cluster_trace_2018",
    "pems04",
    "pems08",
    "beijing_subway",
    "shmetro",
    "hzmetro",
    "subseasonal",
    "godaddy",
    "china_air_quality",
    "beijing_air_quality",
    "residential_load_power",
    "residential_pv_power",
    "cdc_fluview_ilinet",
    "cdc_fluview_who_nrevss",
]

GIFT_EVAL_DATASET_ALIASES = {
    "chronos2_downstream": CHRONOS2_DOWNSTREAM_GIFTEVAL_TRAIN_DATASETS,
    "chronos2_table6": CHRONOS2_DOWNSTREAM_GIFTEVAL_TRAIN_DATASETS,
    "chronos2_multivariate": GIFT_EVAL_REAL_MULTIVARIATE_DATASETS,
    "gift_eval_multivariate": GIFT_EVAL_REAL_MULTIVARIATE_DATASETS,
    "real_multivariate": GIFT_EVAL_REAL_MULTIVARIATE_DATASETS,
    "downstream": CHRONOS2_DOWNSTREAM_GIFTEVAL_TRAIN_DATASETS,
    "electricity_15min": ["electricity/15T"],
    "monash_electricity_hourly": ["electricity/H"],
    "monash_electricity_weekly": ["electricity/W"],
    "monash_kdd_cup_2018": ["kdd_cup_2018_with_missing/H"],
    "solar": ["solar/10T"],
    "solar_1h": ["solar/H"],
    "taxi_1h": ["SZ_TAXI/H"],
    "taxi_30min": ["SZ_TAXI/15T"],
    "monash_temperature_rain": ["temperature_rain_with_missing"],
}

PRETRAIN_DATASET_ALIASES = {
    "chronos2_pretrain_multivariate": CHRONOS2_PRETRAIN_TARGET_MULTIVARIATE_DATASETS,
    "chronos2_table14_multivariate": CHRONOS2_PRETRAIN_TARGET_MULTIVARIATE_DATASETS,
    "pretrain_multivariate": CHRONOS2_PRETRAIN_TARGET_MULTIVARIATE_DATASETS,
    "real_pretrain_multivariate": CHRONOS2_PRETRAIN_TARGET_MULTIVARIATE_DATASETS,
}

GIFT_EVAL_MED_LONG_DATASETS = [
    "electricity/15T",
    "electricity/H",
    "solar/10T",
    "solar/H",
    "kdd_cup_2018_with_missing/H",
    "LOOP_SEATTLE/5T",
    "LOOP_SEATTLE/H",
    "SZ_TAXI/15T",
    "M_DENSE/H",
    "ett1/15T",
    "ett1/H",
    "ett2/15T",
    "ett2/H",
    "jena_weather/10T",
    "jena_weather/H",
    "bitbrains_fast_storage/5T",
    "bitbrains_rnd/5T",
    "bizitobs_application",
    "bizitobs_service",
    "bizitobs_l2c/5T",
    "bizitobs_l2c/H",
]


def split_arg_list(value, default=None):
    if value is None:
        return default or []
    if isinstance(value, (list, tuple)):
        return [str(item) for item in value]
    return [item for item in str(value).replace(",", " ").split() if item]


def gifteval_requested_datasets(value):
    datasets = split_arg_list(value, default=["all"])
    if len(datasets) == 1 and datasets[0].lower() == "all":
        return GIFT_EVAL_SHORT_DATASETS
    selected = []
    for dataset in datasets:
        alias = GIFT_EVAL_DATASET_ALIASES.get(dataset.lower())
        if alias is None:
            selected.append(dataset)
        else:
            selected.extend(alias)
    return list(OrderedDict.fromkeys(selected))


def pretrain_requested_datasets(value):
    datasets = split_arg_list(value, default=["all"])
    if len(datasets) == 1 and datasets[0].lower() == "all":
        return None
    selected = []
    for dataset in datasets:
        alias = PRETRAIN_DATASET_ALIASES.get(dataset.lower())
        if alias is None:
            selected.append(dataset)
        else:
            selected.extend(alias)
    return list(OrderedDict.fromkeys(selected))


def normalize_pretrain_dataset_name(dataset_name):
    return re.sub(r"[^a-z0-9]+", "_", str(dataset_name).lower()).strip("_")


def pretrain_dataset_matches(name, requested_names):
    if requested_names is None:
        return True
    normalized_name = normalize_pretrain_dataset_name(name)
    for requested_name in requested_names:
        normalized_requested = normalize_pretrain_dataset_name(requested_name)
        if normalized_name == normalized_requested or normalized_name.startswith(f"{normalized_requested}_"):
            return True
    return False


def gifteval_requested_terms(value):
    terms = split_arg_list(value, default=["short"])
    if len(terms) == 1 and terms[0].lower() == "all":
        return ["short", "medium", "long"]
    return terms


def gifteval_should_run_dataset_term(dataset_name, term):
    if term == "short":
        return True
    return dataset_name in GIFT_EVAL_MED_LONG_DATASETS


def normalize_gifteval_name(dataset_name):
    if "/" in dataset_name:
        ds_key, ds_freq = dataset_name.split("/", 1)
        return PRETTY_NAMES.get(ds_key.lower(), ds_key.lower()), ds_freq
    return PRETTY_NAMES.get(dataset_name.lower(), dataset_name.lower()), None


def sample_prediction_length(
        available_steps,
        max_pred_len,
        min_pred_len,
        output_patch_size,
        prediction_patch_multiple,
        rng,
):
    available_steps = min(int(available_steps), int(max_pred_len))
    min_pred_len = int(min_pred_len)
    if available_steps < min_pred_len:
        return None
    if not prediction_patch_multiple:
        return available_steps

    output_patch_size = int(output_patch_size)
    min_pred_len = max(output_patch_size, math.ceil(min_pred_len / output_patch_size) * output_patch_size)
    max_pred_len = (available_steps // output_patch_size) * output_patch_size
    if max_pred_len < min_pred_len:
        return None
    min_patches = min_pred_len // output_patch_size
    max_patches = max_pred_len // output_patch_size
    return rng.randint(min_patches, max_patches) * output_patch_size


def interpolate_int(start, end, progress):
    progress = min(1.0, max(0.0, float(progress)))
    return int(round(float(start) + (float(end) - float(start)) * progress))


def curriculum_limits(
        batch_index,
        enabled,
        max_seq_len,
        max_pred_len,
        initial_max_history_len,
        mid_max_history_len,
        final_max_history_len,
        history_mid_batches,
        history_final_batches,
        initial_max_pred_len,
        mid_max_pred_len,
        final_max_pred_len,
        pred_mid_batches,
        pred_final_batches,
):
    if not enabled:
        return int(max_seq_len), int(max_pred_len)

    batch_index = max(0, int(batch_index or 0))
    max_seq_len = int(max_seq_len)
    max_pred_len = int(max_pred_len)
    initial_max_history_len = min(max_seq_len, int(initial_max_history_len or max_seq_len))
    mid_max_history_len = min(max_seq_len, int(mid_max_history_len or max_seq_len))
    final_max_history_len = min(max_seq_len, int(final_max_history_len or max_seq_len))
    initial_max_pred_len = min(max_pred_len, int(initial_max_pred_len or max_pred_len))
    final_max_pred_len = min(max_pred_len, int(final_max_pred_len or max_pred_len))
    pred_mid_batches = int(pred_mid_batches or 0)
    pred_final_batches = int(pred_final_batches or 0)
    if mid_max_pred_len is None:
        mid_max_pred_len = initial_max_pred_len if pred_mid_batches > 0 else final_max_pred_len
    mid_max_pred_len = min(max_pred_len, int(mid_max_pred_len or max_pred_len))

    if history_mid_batches <= 0 or batch_index <= history_mid_batches:
        denom = max(1, int(history_mid_batches or 1))
        history_limit = interpolate_int(initial_max_history_len, mid_max_history_len, batch_index / denom)
    elif history_final_batches <= history_mid_batches or batch_index <= history_final_batches:
        denom = max(1, int(history_final_batches - history_mid_batches))
        history_limit = interpolate_int(
            mid_max_history_len,
            final_max_history_len,
            (batch_index - history_mid_batches) / denom,
        )
    else:
        history_limit = final_max_history_len

    if pred_mid_batches <= 0:
        if pred_final_batches <= 0 or batch_index <= pred_final_batches:
            pred_limit = interpolate_int(
                initial_max_pred_len,
                final_max_pred_len,
                batch_index / max(1, pred_final_batches or 1),
            )
        else:
            pred_limit = final_max_pred_len
    elif batch_index <= pred_mid_batches:
        pred_limit = interpolate_int(initial_max_pred_len, mid_max_pred_len, batch_index / max(1, pred_mid_batches))
    elif pred_final_batches <= pred_mid_batches or batch_index <= pred_final_batches:
        denom = max(1, pred_final_batches - pred_mid_batches)
        pred_limit = interpolate_int(
            mid_max_pred_len,
            final_max_pred_len,
            (batch_index - pred_mid_batches) / denom,
        )
    else:
        pred_limit = final_max_pred_len

    return max(1, min(max_seq_len, history_limit)), max(1, min(max_pred_len, pred_limit))


def import_gifteval_dataset(gift_eval_path, gift_eval_src=None):
    os.environ["GIFT_EVAL"] = str(gift_eval_path)
    os.environ["GIFT_EVAL_PATH"] = str(gift_eval_path)
    if gift_eval_src:
        os.environ["GIFT_EVAL_SRC"] = str(gift_eval_src)

    src_candidates = [
        Path(gift_eval_src).expanduser() if gift_eval_src else None,
        Path(os.environ["GIFT_EVAL_SRC"]).expanduser() if os.environ.get("GIFT_EVAL_SRC") else None,
        Path(gift_eval_path).expanduser() / "src" if gift_eval_path else None,
        LOCAL_GIFT_EVAL_SRC,
        FALLBACK_GIFT_EVAL_SRC,
    ]
    for src_path in src_candidates:
        if src_path and (src_path / "gift_eval").exists() and str(src_path) not in sys.path:
            sys.path.append(str(src_path))

    try:
        from gift_eval.data import Dataset
    except ImportError as exc:
        raise ImportError(
            "Could not import gift_eval.data.Dataset. Install GIFT-Eval or set "
            "GIFT_EVAL_SRC=/path/to/GIFT-Eval/src. The data root should be /data/GIFTEval."
        ) from exc
    return Dataset


def generate_pretrain_dataset(
        data_dir,
        seq_len,
        pred_len,
        batch_size,
        dataset_mode="streaming",
        stream_shuffle_buffer=8192,
        stream_log_interval=1000,
        stream_window_stride=1,
        stream_file_shuffle=True,
        stream_refill_windows=2,
        stream_sample_pool_size=8192,
        stream_samples_per_arrow=512,
        stream_samples_per_dataset_block=512,
        stream_arrow_row_chunk_size=4096,
        stream_windows_per_series=16,
        stream_prefetch_pools=4,
        stream_arrow_cache_size=512,
        dynamic_min_history_len=48,
        dynamic_min_pred_len=1,
        dynamic_history_patch_multiple=True,
        dynamic_prediction_patch_multiple=True,
        dynamic_curriculum_enable=False,
        dynamic_curriculum_initial_max_history_len=2048,
        dynamic_curriculum_mid_max_history_len=4096,
        dynamic_curriculum_final_max_history_len=None,
        dynamic_curriculum_history_mid_batches=80000,
        dynamic_curriculum_history_final_batches=150000,
        dynamic_curriculum_initial_max_pred_len=256,
        dynamic_curriculum_mid_max_pred_len=None,
        dynamic_curriculum_final_max_pred_len=None,
        dynamic_curriculum_pred_mid_batches=0,
        dynamic_curriculum_pred_final_batches=80000,
        output_patch_size=None,
        seed=5252,
        **kwargs,
):
    final_curriculum_history = dynamic_curriculum_final_max_history_len or seq_len
    final_curriculum_pred = dynamic_curriculum_final_max_pred_len or pred_len
    common_dynamic_kwargs = dict(
        max_seq_len=seq_len,
        max_pred_len=pred_len,
        batch_size=batch_size,
        output_patch_size=output_patch_size or int(kwargs.get("patch_len", 48)),
        patch_len=int(kwargs.get("patch_len", 48)),
        log_interval=stream_log_interval,
        window_stride=stream_window_stride,
        file_shuffle=stream_file_shuffle,
        sample_pool_size=stream_sample_pool_size or stream_shuffle_buffer,
        samples_per_arrow=stream_samples_per_arrow or stream_refill_windows,
        samples_per_dataset_block=stream_samples_per_dataset_block,
        arrow_row_chunk_size=stream_arrow_row_chunk_size,
        windows_per_series=stream_windows_per_series,
        prefetch_pools=stream_prefetch_pools,
        arrow_cache_size=stream_arrow_cache_size,
        min_history_len=dynamic_min_history_len,
        min_pred_len=dynamic_min_pred_len,
        history_patch_multiple=dynamic_history_patch_multiple,
        prediction_patch_multiple=dynamic_prediction_patch_multiple,
        curriculum_enable=dynamic_curriculum_enable,
        curriculum_initial_max_history_len=dynamic_curriculum_initial_max_history_len,
        curriculum_mid_max_history_len=dynamic_curriculum_mid_max_history_len,
        curriculum_final_max_history_len=final_curriculum_history,
        curriculum_history_mid_batches=dynamic_curriculum_history_mid_batches,
        curriculum_history_final_batches=dynamic_curriculum_history_final_batches,
        curriculum_initial_max_pred_len=dynamic_curriculum_initial_max_pred_len,
        curriculum_mid_max_pred_len=dynamic_curriculum_mid_max_pred_len,
        curriculum_final_max_pred_len=final_curriculum_pred,
        curriculum_pred_mid_batches=dynamic_curriculum_pred_mid_batches,
        curriculum_pred_final_batches=dynamic_curriculum_pred_final_batches,
    )
    common_gifteval_kwargs = dict(
        gift_eval_path=kwargs.get("gift_eval_path", "/data/GIFTEval"),
        gift_eval_src=kwargs.get("gift_eval_src"),
        dataset_names=kwargs.get("gift_eval_datasets", "all"),
        terms=kwargs.get("gift_eval_terms", "short"),
        max_seq_len=seq_len,
        max_pred_len=pred_len,
        batch_size=batch_size,
        output_patch_size=output_patch_size or int(kwargs.get("patch_len", 48)),
        patch_len=int(kwargs.get("patch_len", 48)),
        log_interval=stream_log_interval,
        file_shuffle=stream_file_shuffle,
        sample_pool_size=stream_sample_pool_size or stream_shuffle_buffer,
        samples_per_dataset_block=stream_samples_per_dataset_block,
        windows_per_series=stream_windows_per_series,
        min_history_len=dynamic_min_history_len,
        min_pred_len=dynamic_min_pred_len,
        history_patch_multiple=dynamic_history_patch_multiple,
        prediction_patch_multiple=dynamic_prediction_patch_multiple,
        curriculum_enable=dynamic_curriculum_enable,
        curriculum_initial_max_history_len=dynamic_curriculum_initial_max_history_len,
        curriculum_mid_max_history_len=dynamic_curriculum_mid_max_history_len,
        curriculum_final_max_history_len=final_curriculum_history,
        curriculum_history_mid_batches=dynamic_curriculum_history_mid_batches,
        curriculum_history_final_batches=dynamic_curriculum_history_final_batches,
        curriculum_initial_max_pred_len=dynamic_curriculum_initial_max_pred_len,
        curriculum_mid_max_pred_len=dynamic_curriculum_mid_max_pred_len,
        curriculum_final_max_pred_len=final_curriculum_pred,
        curriculum_pred_mid_batches=dynamic_curriculum_pred_mid_batches,
        curriculum_pred_final_batches=dynamic_curriculum_pred_final_batches,
    )

    if dataset_mode in {"mixed_mv_univariate", "mixed_multivariate_univariate", "streaming_mv_univariate"}:
        synthetic_mv_data_dir = kwargs.get("synthetic_mv_data_dir") or kwargs.get("synthetic_data_dir")
        real_mv_data_dir = kwargs.get("real_mv_data_dir") or kwargs.get("pretrain_mv_data_dir") or data_dir
        if not synthetic_mv_data_dir:
            raise ValueError(
                "dataset_mode='mixed_mv_univariate' requires --synthetic_mv_data_dir "
                "for the artificial multivariate Arrow data."
            )
        mv_ratio = float(kwargs.get("mv_ratio", 0.7))
        synthetic_mv_ratio = float(kwargs.get("synthetic_mv_ratio", 0.5))
        real_mv_gifteval_train_ratio = float(kwargs.get("real_mv_gifteval_train_ratio", 0.5))
        pretrain_mv_datasets = kwargs.get("pretrain_mv_datasets", "chronos2_pretrain_multivariate")
        univariate_gifteval_train_ratio = kwargs.get("univariate_gifteval_train_ratio")
        if univariate_gifteval_train_ratio is None:
            univariate_gifteval_train_ratio = kwargs.get("gift_eval_train_ratio", 0.1)
        univariate_gifteval_train_ratio = float(univariate_gifteval_train_ratio)
        mv_min_variates = int(kwargs.get("mv_min_variates", 2))
        mv_max_variates = int(kwargs.get("mv_max_variates", 10))
        mv_shuffle_variates = parse_bool_flag(kwargs.get("mv_shuffle_variates", True), default=True)
        gifteval_mv_kwargs = dict(common_gifteval_kwargs)
        gifteval_mv_kwargs["dataset_names"] = kwargs.get("gift_eval_mv_datasets", "chronos2_multivariate")
        gifteval_mv_kwargs["terms"] = kwargs.get("gift_eval_mv_terms", kwargs.get("gift_eval_terms", "all"))

        synthetic_mv_dataset = GIFTEvalDynamicMultivariateStreamingDataset(
            data_dir=synthetic_mv_data_dir,
            min_variates=mv_min_variates,
            max_variates=mv_max_variates,
            shuffle_variates=mv_shuffle_variates,
            seed=seed + 101,
            **common_dynamic_kwargs,
        )
        real_pretrain_mv_dataset = GIFTEvalDynamicMultivariateStreamingDataset(
            data_dir=real_mv_data_dir,
            min_variates=mv_min_variates,
            max_variates=mv_max_variates,
            shuffle_variates=mv_shuffle_variates,
            dataset_names=pretrain_mv_datasets,
            seed=seed + 202,
            **common_dynamic_kwargs,
        )
        gifteval_train_mv_dataset = GIFTEvalTrainPartMultivariateStreamingDataset(
            min_variates=mv_min_variates,
            max_variates=mv_max_variates,
            shuffle_variates=mv_shuffle_variates,
            seed=seed + 303,
            **gifteval_mv_kwargs,
        )
        real_mv_dataset = GroupAwareMixedChronos2BatchDataset(
            primary_dataset=real_pretrain_mv_dataset,
            extra_dataset=gifteval_train_mv_dataset,
            extra_ratio=real_mv_gifteval_train_ratio,
            seed=seed + 404,
            name="real_mv_pretrain_plus_gifteval_train",
        )
        multivariate_dataset = GroupAwareMixedChronos2BatchDataset(
            primary_dataset=synthetic_mv_dataset,
            extra_dataset=real_mv_dataset,
            extra_ratio=1.0 - synthetic_mv_ratio,
            seed=seed + 505,
            name="synthetic_mv_plus_real_mv",
        )
        univariate_pretrain_dataset = GIFTEvalDynamicStreamingDataset(
            data_dir=real_mv_data_dir,
            seed=seed + 606,
            **common_dynamic_kwargs,
        )
        univariate_gifteval_dataset = GIFTEvalTrainPartStreamingDataset(
            seed=seed + 707,
            **common_gifteval_kwargs,
        )
        univariate_dataset = GroupAwareMixedChronos2BatchDataset(
            primary_dataset=univariate_pretrain_dataset,
            extra_dataset=univariate_gifteval_dataset,
            extra_ratio=univariate_gifteval_train_ratio,
            seed=seed + 808,
            name="univariate_pretrain_plus_gifteval_train",
        )
        return GroupAwareMixedChronos2BatchDataset(
            primary_dataset=univariate_dataset,
            extra_dataset=multivariate_dataset,
            extra_ratio=mv_ratio,
            seed=seed + 909,
            name="mv70_univariate30_synthetic50_real50",
        )

    if dataset_mode in {"streaming_plus_gifteval_train", "pretrain_plus_gifteval_train"}:
        pretrain_dataset = GIFTEvalDynamicStreamingDataset(
            data_dir=data_dir,
            max_seq_len=seq_len,
            max_pred_len=pred_len,
            batch_size=batch_size,
            output_patch_size=output_patch_size or int(kwargs.get("patch_len", 48)),
            patch_len=int(kwargs.get("patch_len", 48)),
            log_interval=stream_log_interval,
            window_stride=stream_window_stride,
            file_shuffle=stream_file_shuffle,
            sample_pool_size=stream_sample_pool_size or stream_shuffle_buffer,
            samples_per_arrow=stream_samples_per_arrow or stream_refill_windows,
            samples_per_dataset_block=stream_samples_per_dataset_block,
            arrow_row_chunk_size=stream_arrow_row_chunk_size,
            windows_per_series=stream_windows_per_series,
            prefetch_pools=stream_prefetch_pools,
            arrow_cache_size=stream_arrow_cache_size,
            min_history_len=dynamic_min_history_len,
            min_pred_len=dynamic_min_pred_len,
            history_patch_multiple=dynamic_history_patch_multiple,
            prediction_patch_multiple=dynamic_prediction_patch_multiple,
            curriculum_enable=dynamic_curriculum_enable,
            curriculum_initial_max_history_len=dynamic_curriculum_initial_max_history_len,
            curriculum_mid_max_history_len=dynamic_curriculum_mid_max_history_len,
            curriculum_final_max_history_len=final_curriculum_history,
            curriculum_history_mid_batches=dynamic_curriculum_history_mid_batches,
            curriculum_history_final_batches=dynamic_curriculum_history_final_batches,
            curriculum_initial_max_pred_len=dynamic_curriculum_initial_max_pred_len,
            curriculum_mid_max_pred_len=dynamic_curriculum_mid_max_pred_len,
            curriculum_final_max_pred_len=final_curriculum_pred,
            curriculum_pred_mid_batches=dynamic_curriculum_pred_mid_batches,
            curriculum_pred_final_batches=dynamic_curriculum_pred_final_batches,
            seed=seed,
        )
        gifteval_train_dataset = GIFTEvalTrainPartStreamingDataset(
            gift_eval_path=kwargs.get("gift_eval_path", "/data/GIFTEval"),
            gift_eval_src=kwargs.get("gift_eval_src"),
            dataset_names=kwargs.get("gift_eval_datasets", "all"),
            terms=kwargs.get("gift_eval_terms", "short"),
            max_seq_len=seq_len,
            max_pred_len=pred_len,
            batch_size=batch_size,
            output_patch_size=output_patch_size or int(kwargs.get("patch_len", 48)),
            patch_len=int(kwargs.get("patch_len", 48)),
            log_interval=stream_log_interval,
            file_shuffle=stream_file_shuffle,
            sample_pool_size=stream_sample_pool_size or stream_shuffle_buffer,
            samples_per_dataset_block=stream_samples_per_dataset_block,
            windows_per_series=stream_windows_per_series,
            min_history_len=dynamic_min_history_len,
            min_pred_len=dynamic_min_pred_len,
            history_patch_multiple=dynamic_history_patch_multiple,
            prediction_patch_multiple=dynamic_prediction_patch_multiple,
            curriculum_enable=dynamic_curriculum_enable,
            curriculum_initial_max_history_len=dynamic_curriculum_initial_max_history_len,
            curriculum_mid_max_history_len=dynamic_curriculum_mid_max_history_len,
            curriculum_final_max_history_len=final_curriculum_history,
            curriculum_history_mid_batches=dynamic_curriculum_history_mid_batches,
            curriculum_history_final_batches=dynamic_curriculum_history_final_batches,
            curriculum_initial_max_pred_len=dynamic_curriculum_initial_max_pred_len,
            curriculum_mid_max_pred_len=dynamic_curriculum_mid_max_pred_len,
            curriculum_final_max_pred_len=final_curriculum_pred,
            curriculum_pred_mid_batches=dynamic_curriculum_pred_mid_batches,
            curriculum_pred_final_batches=dynamic_curriculum_pred_final_batches,
            seed=seed + 777,
        )
        return MixedChronos2BatchDataset(
            primary_dataset=pretrain_dataset,
            extra_dataset=gifteval_train_dataset,
            extra_ratio=float(kwargs.get("gift_eval_train_ratio", 0.1)),
            extra_warmup_batches=int(kwargs.get("gift_eval_train_warmup_batches", 0)),
            extra_initial_ratio=(
                float(kwargs["gift_eval_train_initial_ratio"])
                if kwargs.get("gift_eval_train_initial_ratio") is not None
                else None
            ),
            extra_ratio_decay_batches=int(kwargs.get("gift_eval_train_ratio_decay_batches", 0)),
            seed=seed,
            name="streaming_plus_gifteval_train",
        )

    if dataset_mode in {"prepared_arrow_plus_gifteval_train", "prepared_plus_gifteval_train"}:
        pretrain_dataset = PreparedArrowChronos2Dataset(
            data_dir=data_dir,
            max_seq_len=seq_len,
            max_pred_len=pred_len,
            batch_size=batch_size,
            output_patch_size=output_patch_size or int(kwargs.get("patch_len", 48)),
            log_interval=stream_log_interval,
            file_shuffle=stream_file_shuffle,
            row_chunk_size=stream_arrow_row_chunk_size,
            arrow_cache_size=stream_arrow_cache_size,
            seed=seed,
        )
        gifteval_train_dataset = GIFTEvalTrainPartStreamingDataset(
            gift_eval_path=kwargs.get("gift_eval_path", "/data/GIFTEval"),
            gift_eval_src=kwargs.get("gift_eval_src"),
            dataset_names=kwargs.get("gift_eval_datasets", "all"),
            terms=kwargs.get("gift_eval_terms", "short"),
            max_seq_len=seq_len,
            max_pred_len=pred_len,
            batch_size=batch_size,
            output_patch_size=output_patch_size or int(kwargs.get("patch_len", 48)),
            patch_len=int(kwargs.get("patch_len", 48)),
            log_interval=stream_log_interval,
            file_shuffle=stream_file_shuffle,
            sample_pool_size=stream_sample_pool_size or stream_shuffle_buffer,
            samples_per_dataset_block=stream_samples_per_dataset_block,
            windows_per_series=stream_windows_per_series,
            min_history_len=dynamic_min_history_len,
            min_pred_len=dynamic_min_pred_len,
            history_patch_multiple=dynamic_history_patch_multiple,
            prediction_patch_multiple=dynamic_prediction_patch_multiple,
            curriculum_enable=dynamic_curriculum_enable,
            curriculum_initial_max_history_len=dynamic_curriculum_initial_max_history_len,
            curriculum_mid_max_history_len=dynamic_curriculum_mid_max_history_len,
            curriculum_final_max_history_len=final_curriculum_history,
            curriculum_history_mid_batches=dynamic_curriculum_history_mid_batches,
            curriculum_history_final_batches=dynamic_curriculum_history_final_batches,
            curriculum_initial_max_pred_len=dynamic_curriculum_initial_max_pred_len,
            curriculum_mid_max_pred_len=dynamic_curriculum_mid_max_pred_len,
            curriculum_final_max_pred_len=final_curriculum_pred,
            curriculum_pred_mid_batches=dynamic_curriculum_pred_mid_batches,
            curriculum_pred_final_batches=dynamic_curriculum_pred_final_batches,
            seed=seed + 777,
        )
        return MixedChronos2BatchDataset(
            primary_dataset=pretrain_dataset,
            extra_dataset=gifteval_train_dataset,
            extra_ratio=float(kwargs.get("gift_eval_train_ratio", 0.1)),
            extra_warmup_batches=int(kwargs.get("gift_eval_train_warmup_batches", 0)),
            extra_initial_ratio=(
                float(kwargs["gift_eval_train_initial_ratio"])
                if kwargs.get("gift_eval_train_initial_ratio") is not None
                else None
            ),
            extra_ratio_decay_batches=int(kwargs.get("gift_eval_train_ratio_decay_batches", 0)),
            seed=seed,
            name="prepared_arrow_plus_gifteval_train",
        )

    if dataset_mode in {"gifteval_train", "gifteval_test_input", "gifteval_eval_train"}:
        return GIFTEvalTrainPartStreamingDataset(
            gift_eval_path=data_dir,
            gift_eval_src=kwargs.get("gift_eval_src"),
            dataset_names=kwargs.get("gift_eval_datasets", "all"),
            terms=kwargs.get("gift_eval_terms", "short"),
            max_seq_len=seq_len,
            max_pred_len=pred_len,
            batch_size=batch_size,
            output_patch_size=output_patch_size or int(kwargs.get("patch_len", 48)),
            patch_len=int(kwargs.get("patch_len", 48)),
            log_interval=stream_log_interval,
            file_shuffle=stream_file_shuffle,
            sample_pool_size=stream_sample_pool_size or stream_shuffle_buffer,
            samples_per_dataset_block=stream_samples_per_dataset_block,
            windows_per_series=stream_windows_per_series,
            min_history_len=dynamic_min_history_len,
            min_pred_len=dynamic_min_pred_len,
            history_patch_multiple=dynamic_history_patch_multiple,
            prediction_patch_multiple=dynamic_prediction_patch_multiple,
            curriculum_enable=dynamic_curriculum_enable,
            curriculum_initial_max_history_len=dynamic_curriculum_initial_max_history_len,
            curriculum_mid_max_history_len=dynamic_curriculum_mid_max_history_len,
            curriculum_final_max_history_len=final_curriculum_history,
            curriculum_history_mid_batches=dynamic_curriculum_history_mid_batches,
            curriculum_history_final_batches=dynamic_curriculum_history_final_batches,
            curriculum_initial_max_pred_len=dynamic_curriculum_initial_max_pred_len,
            curriculum_mid_max_pred_len=dynamic_curriculum_mid_max_pred_len,
            curriculum_final_max_pred_len=final_curriculum_pred,
            curriculum_pred_mid_batches=dynamic_curriculum_pred_mid_batches,
            curriculum_pred_final_batches=dynamic_curriculum_pred_final_batches,
            seed=seed,
        )

    if dataset_mode in {"prepared_arrow", "prepared", "fixed_arrow"}:
        return PreparedArrowChronos2Dataset(
            data_dir=data_dir,
            max_seq_len=seq_len,
            max_pred_len=pred_len,
            batch_size=batch_size,
            output_patch_size=output_patch_size or int(kwargs.get("patch_len", 48)),
            log_interval=stream_log_interval,
            file_shuffle=stream_file_shuffle,
            row_chunk_size=stream_arrow_row_chunk_size,
            arrow_cache_size=stream_arrow_cache_size,
            seed=seed,
        )

    if dataset_mode in {"streaming_multivariate", "multivariate_streaming"}:
        return GIFTEvalDynamicMultivariateStreamingDataset(
            data_dir=data_dir,
            min_variates=int(kwargs.get("mv_min_variates", 2)),
            max_variates=int(kwargs.get("mv_max_variates", 10)),
            shuffle_variates=parse_bool_flag(kwargs.get("mv_shuffle_variates", True), default=True),
            max_seq_len=seq_len,
            max_pred_len=pred_len,
            batch_size=batch_size,
            output_patch_size=output_patch_size or int(kwargs.get("patch_len", 48)),
            patch_len=int(kwargs.get("patch_len", 48)),
            log_interval=stream_log_interval,
            window_stride=stream_window_stride,
            file_shuffle=stream_file_shuffle,
            sample_pool_size=stream_sample_pool_size or stream_shuffle_buffer,
            samples_per_arrow=stream_samples_per_arrow or stream_refill_windows,
            samples_per_dataset_block=stream_samples_per_dataset_block,
            arrow_row_chunk_size=stream_arrow_row_chunk_size,
            windows_per_series=stream_windows_per_series,
            prefetch_pools=stream_prefetch_pools,
            arrow_cache_size=stream_arrow_cache_size,
            min_history_len=dynamic_min_history_len,
            min_pred_len=dynamic_min_pred_len,
            history_patch_multiple=dynamic_history_patch_multiple,
            prediction_patch_multiple=dynamic_prediction_patch_multiple,
            curriculum_enable=dynamic_curriculum_enable,
            curriculum_initial_max_history_len=dynamic_curriculum_initial_max_history_len,
            curriculum_mid_max_history_len=dynamic_curriculum_mid_max_history_len,
            curriculum_final_max_history_len=final_curriculum_history,
            curriculum_history_mid_batches=dynamic_curriculum_history_mid_batches,
            curriculum_history_final_batches=dynamic_curriculum_history_final_batches,
            curriculum_initial_max_pred_len=dynamic_curriculum_initial_max_pred_len,
            curriculum_mid_max_pred_len=dynamic_curriculum_mid_max_pred_len,
            curriculum_final_max_pred_len=final_curriculum_pred,
            curriculum_pred_mid_batches=dynamic_curriculum_pred_mid_batches,
            curriculum_pred_final_batches=dynamic_curriculum_pred_final_batches,
            seed=seed,
        )

    if dataset_mode != "streaming":
        raise ValueError(
            "Supported dataset_mode values are 'streaming', 'prepared_arrow', 'gifteval_train', "
            "'streaming_multivariate', 'streaming_plus_gifteval_train', and 'prepared_arrow_plus_gifteval_train', "
            f"got {dataset_mode!r}."
        )
    return GIFTEvalDynamicStreamingDataset(
        data_dir=data_dir,
        max_seq_len=seq_len,
        max_pred_len=pred_len,
        batch_size=batch_size,
        output_patch_size=output_patch_size or int(kwargs.get("patch_len", 48)),
        patch_len=int(kwargs.get("patch_len", 48)),
        log_interval=stream_log_interval,
        window_stride=stream_window_stride,
        file_shuffle=stream_file_shuffle,
        sample_pool_size=stream_sample_pool_size or stream_shuffle_buffer,
        samples_per_arrow=stream_samples_per_arrow or stream_refill_windows,
        samples_per_dataset_block=stream_samples_per_dataset_block,
        arrow_row_chunk_size=stream_arrow_row_chunk_size,
        windows_per_series=stream_windows_per_series,
        prefetch_pools=stream_prefetch_pools,
        arrow_cache_size=stream_arrow_cache_size,
        min_history_len=dynamic_min_history_len,
        min_pred_len=dynamic_min_pred_len,
        history_patch_multiple=dynamic_history_patch_multiple,
        prediction_patch_multiple=dynamic_prediction_patch_multiple,
        curriculum_enable=dynamic_curriculum_enable,
        curriculum_initial_max_history_len=dynamic_curriculum_initial_max_history_len,
        curriculum_mid_max_history_len=dynamic_curriculum_mid_max_history_len,
        curriculum_final_max_history_len=final_curriculum_history,
        curriculum_history_mid_batches=dynamic_curriculum_history_mid_batches,
        curriculum_history_final_batches=dynamic_curriculum_history_final_batches,
        curriculum_initial_max_pred_len=dynamic_curriculum_initial_max_pred_len,
        curriculum_mid_max_pred_len=dynamic_curriculum_mid_max_pred_len,
        curriculum_final_max_pred_len=final_curriculum_pred,
        curriculum_pred_mid_batches=dynamic_curriculum_pred_mid_batches,
        curriculum_pred_final_batches=dynamic_curriculum_pred_final_batches,
        seed=seed,
    )


def load_irregular_dynamtic(
        data_dir,
        seq_len,
        pred_len,
        batch_size,
        output_patch_size,
        **kwargs,
):
    """
    Build the irregular dynamic streaming dataloader expected by Chronos-2 pretraining.

    The misspelled function name is intentionally kept because downstream experiments
    already refer to `load_irregular_dynamtic`.
    """
    return generate_pretrain_dataset(
        data_dir=data_dir,
        seq_len=seq_len,
        pred_len=pred_len,
        batch_size=batch_size,
        output_patch_size=output_patch_size,
        patch_len=kwargs.pop("patch_len", output_patch_size),
        **kwargs,
    )


def load_irregular_dynamic(*args, **kwargs):
    """Correctly-spelled alias for `load_irregular_dynamtic`."""
    return load_irregular_dynamtic(*args, **kwargs)


class MixedChronos2BatchDataset(IterableDataset):
    """Mix two Chronos-2 batch-yielding IterableDatasets at sample granularity."""

    def __init__(
            self,
            primary_dataset,
            extra_dataset,
            extra_ratio=0.1,
            extra_warmup_batches=0,
            extra_initial_ratio=None,
            extra_ratio_decay_batches=0,
            seed=5252,
            name="mixed",
    ):
        self.primary_dataset = primary_dataset
        self.extra_dataset = extra_dataset
        self.extra_ratio = min(1.0, max(0.0, float(extra_ratio)))
        self.extra_ratio_decay_batches = max(0, int(extra_ratio_decay_batches or 0))
        self.extra_warmup_batches = max(0, int(extra_warmup_batches or 0))
        if extra_initial_ratio is None:
            extra_initial_ratio = max(self.extra_ratio, 0.5) if self.extra_warmup_batches > 0 else self.extra_ratio
        self.extra_initial_ratio = min(1.0, max(0.0, float(extra_initial_ratio)))
        self.seed = int(seed)
        self.name = name
        self.batch_size = getattr(primary_dataset, "batch_size", None)
        if self.batch_size is None:
            self.batch_size = getattr(extra_dataset, "batch_size", None)

        print(
            f"Use mixed Chronos2 dataset: name={self.name}, extra_ratio={self.extra_ratio}, "
            f"extra_initial_ratio={self.extra_initial_ratio}, "
            f"extra_ratio_decay_batches={self.extra_ratio_decay_batches}, "
            f"extra_warmup_batches={self.extra_warmup_batches}, batch_size={self.batch_size}",
            flush=True,
        )

    def _extra_ratio_at(self, batch_index):
        if batch_index < self.extra_warmup_batches:
            return self.extra_initial_ratio
        if self.extra_ratio_decay_batches <= 0:
            return self.extra_ratio
        progress = (batch_index - self.extra_warmup_batches) / max(1, self.extra_ratio_decay_batches)
        return min(1.0, max(0.0, self.extra_initial_ratio + (self.extra_ratio - self.extra_initial_ratio) * min(1.0, max(0.0, progress))))

    @staticmethod
    def _infer_batch_size(batch):
        context = batch.get("context")
        if context is None:
            raise ValueError("MixedChronos2BatchDataset expects batches with a 'context' tensor.")
        return int(context.shape[0])

    @staticmethod
    def _slice_batch(batch, start, end):
        sliced = {}
        batch_size = MixedChronos2BatchDataset._infer_batch_size(batch)
        for key, value in batch.items():
            if torch.is_tensor(value) and value.ndim > 0 and value.shape[0] == batch_size:
                sliced[key] = value[start:end]
            else:
                sliced[key] = value
        return sliced

    @staticmethod
    def _concat_batches(primary_batch, extra_batch, primary_count, extra_count, rng):
        primary_part = MixedChronos2BatchDataset._slice_batch(primary_batch, 0, primary_count)
        extra_part = MixedChronos2BatchDataset._slice_batch(extra_batch, 0, extra_count)
        mixed = {}
        total = primary_count + extra_count
        for key in primary_part:
            primary_value = primary_part[key]
            extra_value = extra_part.get(key)
            if torch.is_tensor(primary_value) and torch.is_tensor(extra_value):
                if primary_value.ndim > 0 and primary_value.shape[0] == primary_count:
                    mixed[key] = torch.cat([primary_value, extra_value], dim=0)
                else:
                    mixed[key] = primary_value
            else:
                mixed[key] = primary_value if primary_value is not None else extra_value

        if total > 0:
            order = list(range(total))
            rng.shuffle(order)
            order_tensor = torch.as_tensor(order, dtype=torch.long)
            for key, value in list(mixed.items()):
                if torch.is_tensor(value) and value.ndim > 0 and value.shape[0] == total:
                    mixed[key] = value.index_select(0, order_tensor.to(value.device))
            mixed["group_ids"] = torch.arange(total, dtype=torch.long)
        return mixed

    def __iter__(self):
        worker_info = get_worker_info()
        worker_id = worker_info.id if worker_info is not None else 0
        rank = int(os.getenv("RANK", "0"))
        global_shard_id = rank * (worker_info.num_workers if worker_info is not None else 1) + worker_id
        rng = random.Random(self.seed + global_shard_id * 1237)
        primary_iter = iter(self.primary_dataset)
        extra_iter = iter(self.extra_dataset)
        primary_batches = 0
        extra_batches = 0
        total_batches = 0
        global_num_shards = max(1, int(os.getenv("WORLD_SIZE", "1")) * (worker_info.num_workers if worker_info is not None else 1))

        while True:
            global_batch_est = total_batches * global_num_shards
            extra_ratio = self._extra_ratio_at(global_batch_est)
            if extra_ratio <= 0.0:
                primary_batches += 1
                total_batches += 1
                yield next(primary_iter)
                continue

            try:
                primary_batch = next(primary_iter)
            except StopIteration:
                primary_iter = iter(self.primary_dataset)
                primary_batch = next(primary_iter)
            try:
                extra_batch = next(extra_iter)
            except StopIteration:
                extra_iter = iter(self.extra_dataset)
                extra_batch = next(extra_iter)

            primary_size = self._infer_batch_size(primary_batch)
            extra_size = self._infer_batch_size(extra_batch)
            target_size = int(self.batch_size or primary_size)
            target_size = min(target_size, primary_size + extra_size)
            if target_size <= 1:
                primary_batches += 1
                total_batches += 1
                yield primary_batch
                continue

            extra_count = int(round(target_size * extra_ratio))
            extra_count = min(extra_size, max(1, extra_count))
            primary_count = min(primary_size, target_size - extra_count)
            if primary_count <= 0:
                primary_count = min(primary_size, 1)
                extra_count = min(extra_size, target_size - primary_count)
            if extra_count <= 0:
                extra_count = min(extra_size, 1)
                primary_count = min(primary_size, target_size - extra_count)

            primary_batches += 1
            extra_batches += 1
            total_batches += 1
            yield self._concat_batches(primary_batch, extra_batch, primary_count, extra_count, rng)


class GroupAwareMixedChronos2BatchDataset(IterableDataset):
    """Mix two Chronos-2 datasets while preserving multivariate group_ids."""

    def __init__(
            self,
            primary_dataset,
            extra_dataset,
            extra_ratio=0.5,
            seed=5252,
            name="group_aware_mixed",
    ):
        self.primary_dataset = primary_dataset
        self.extra_dataset = extra_dataset
        self.extra_ratio = min(1.0, max(0.0, float(extra_ratio)))
        self.seed = int(seed)
        self.name = name
        self.batch_size = getattr(primary_dataset, "batch_size", None) or getattr(extra_dataset, "batch_size", None)
        print(
            f"Use group-aware mixed Chronos2 dataset: name={self.name}, "
            f"extra_ratio={self.extra_ratio}, batch_size={self.batch_size}",
            flush=True,
        )

    @staticmethod
    def _infer_batch_size(batch):
        context = batch.get("context")
        if context is None:
            raise ValueError("GroupAwareMixedChronos2BatchDataset expects a 'context' tensor.")
        return int(context.shape[0])

    @staticmethod
    def _ordered_groups(group_ids):
        seen = set()
        groups = []
        for group_id in group_ids.detach().cpu().tolist():
            group_id = int(group_id)
            if group_id not in seen:
                seen.add(group_id)
                groups.append(group_id)
        return groups

    @staticmethod
    def _slice_by_group_rows(batch, max_rows):
        batch_size = GroupAwareMixedChronos2BatchDataset._infer_batch_size(batch)
        max_rows = max(0, int(max_rows))
        if max_rows <= 0 or batch_size <= 0:
            return None
        group_ids = batch.get("group_ids")
        if not torch.is_tensor(group_ids) or group_ids.ndim == 0 or group_ids.shape[0] != batch_size:
            end = min(max_rows, batch_size)
            indices = torch.arange(end, dtype=torch.long)
        else:
            selected = []
            used_rows = 0
            for group_id in GroupAwareMixedChronos2BatchDataset._ordered_groups(group_ids):
                group_indices = (group_ids == group_id).nonzero(as_tuple=False).flatten().detach().cpu()
                group_size = int(group_indices.numel())
                if selected and used_rows + group_size > max_rows:
                    break
                selected.append(group_indices)
                used_rows += group_size
                if used_rows >= max_rows:
                    break
            if not selected:
                first_group = GroupAwareMixedChronos2BatchDataset._ordered_groups(group_ids)[0]
                selected = [(group_ids == first_group).nonzero(as_tuple=False).flatten().detach().cpu()]
            indices = torch.cat(selected, dim=0).to(dtype=torch.long)

        sliced = {}
        for key, value in batch.items():
            if torch.is_tensor(value) and value.ndim > 0 and value.shape[0] == batch_size:
                sliced[key] = value.index_select(0, indices.to(value.device))
            else:
                sliced[key] = value
        return sliced

    @staticmethod
    def _concat_and_shuffle_groups(parts, rng):
        parts = [part for part in parts if part is not None and GroupAwareMixedChronos2BatchDataset._infer_batch_size(part) > 0]
        if not parts:
            raise ValueError("Cannot concatenate empty batch parts.")

        mixed = {}
        keys = list(parts[0].keys())
        for key in keys:
            values = [part.get(key) for part in parts]
            if key == "group_ids" and all(torch.is_tensor(value) for value in values):
                remapped_values = []
                offset = 0
                for value in values:
                    remapped = torch.empty_like(value, dtype=torch.long)
                    for local_group_id, old_group_id in enumerate(GroupAwareMixedChronos2BatchDataset._ordered_groups(value)):
                        remapped[value == old_group_id] = offset + local_group_id
                    offset += len(GroupAwareMixedChronos2BatchDataset._ordered_groups(value))
                    remapped_values.append(remapped)
                mixed[key] = torch.cat(remapped_values, dim=0)
            elif all(torch.is_tensor(value) for value in values):
                first = values[0]
                if first.ndim > 0 and all(value.ndim > 0 for value in values):
                    mixed[key] = torch.cat(values, dim=0)
                else:
                    mixed[key] = first
            else:
                mixed[key] = next((value for value in values if value is not None), None)

        total = GroupAwareMixedChronos2BatchDataset._infer_batch_size(mixed)
        group_ids = mixed.get("group_ids")
        if not torch.is_tensor(group_ids) or group_ids.ndim == 0 or group_ids.shape[0] != total:
            group_ids = torch.arange(total, dtype=torch.long)
            mixed["group_ids"] = group_ids

        groups = []
        remapped = torch.empty_like(group_ids, dtype=torch.long)
        for new_group_id, old_group_id in enumerate(GroupAwareMixedChronos2BatchDataset._ordered_groups(group_ids)):
            indices = (group_ids == old_group_id).nonzero(as_tuple=False).flatten().detach().cpu()
            groups.append(indices)
            remapped[indices.to(remapped.device)] = new_group_id
        rng.shuffle(groups)
        row_order = torch.cat(groups, dim=0).to(dtype=torch.long)

        for key, value in list(mixed.items()):
            if torch.is_tensor(value) and value.ndim > 0 and value.shape[0] == total:
                mixed[key] = value.index_select(0, row_order.to(value.device))

        shuffled_group_ids = mixed["group_ids"]
        new_group_ids = torch.empty_like(shuffled_group_ids, dtype=torch.long)
        for new_group_id, old_group_id in enumerate(GroupAwareMixedChronos2BatchDataset._ordered_groups(shuffled_group_ids)):
            new_group_ids[shuffled_group_ids == old_group_id] = new_group_id
        mixed["group_ids"] = new_group_ids
        return mixed

    def __iter__(self):
        worker_info = get_worker_info()
        worker_id = worker_info.id if worker_info is not None else 0
        rank = int(os.getenv("RANK", "0"))
        global_shard_id = rank * (worker_info.num_workers if worker_info is not None else 1) + worker_id
        rng = random.Random(self.seed + global_shard_id * 3217)
        primary_iter = iter(self.primary_dataset)
        extra_iter = iter(self.extra_dataset)

        while True:
            if self.extra_ratio <= 0.0:
                try:
                    yield next(primary_iter)
                except StopIteration:
                    primary_iter = iter(self.primary_dataset)
                    yield next(primary_iter)
                continue

            if self.extra_ratio >= 1.0:
                try:
                    yield next(extra_iter)
                except StopIteration:
                    extra_iter = iter(self.extra_dataset)
                    yield next(extra_iter)
                continue

            try:
                primary_batch = next(primary_iter)
            except StopIteration:
                primary_iter = iter(self.primary_dataset)
                primary_batch = next(primary_iter)
            try:
                extra_batch = next(extra_iter)
            except StopIteration:
                extra_iter = iter(self.extra_dataset)
                extra_batch = next(extra_iter)

            target_size = int(self.batch_size or self._infer_batch_size(primary_batch))
            extra_rows = int(round(target_size * self.extra_ratio))
            primary_rows = target_size - extra_rows
            primary_part = self._slice_by_group_rows(primary_batch, primary_rows)
            extra_part = self._slice_by_group_rows(extra_batch, extra_rows)
            yield self._concat_and_shuffle_groups([primary_part, extra_part], rng)


class GIFTEvalTrainPartStreamingDataset(IterableDataset):
    """
    Use the train/history part of GIFT-Eval evaluation windows for Chronos-2 pretraining.

    For each requested GIFT-Eval dataset config, this reads Dataset(...).test_data.input
    and samples supervised windows from those historical target series only. The future
    labels from test_data.label are intentionally not used.
    """

    def __init__(
            self,
            gift_eval_path,
            gift_eval_src,
            dataset_names,
            terms,
            max_seq_len,
            max_pred_len,
            batch_size,
            output_patch_size,
            patch_len=48,
            log_interval=1000,
            file_shuffle=True,
            sample_pool_size=8192,
            samples_per_dataset_block=512,
            windows_per_series=16,
            min_history_len=48,
            min_pred_len=1,
            history_patch_multiple=True,
            prediction_patch_multiple=True,
            curriculum_enable=False,
            curriculum_initial_max_history_len=2048,
            curriculum_mid_max_history_len=4096,
            curriculum_final_max_history_len=None,
            curriculum_history_mid_batches=80000,
            curriculum_history_final_batches=150000,
            curriculum_initial_max_pred_len=256,
            curriculum_mid_max_pred_len=None,
            curriculum_final_max_pred_len=None,
            curriculum_pred_mid_batches=0,
            curriculum_pred_final_batches=80000,
            seed=5252,
    ):
        self.gift_eval_path = gift_eval_path
        self.gift_eval_src = gift_eval_src
        self.max_seq_len = int(max_seq_len)
        self.max_pred_len = int(max_pred_len)
        self.batch_size = int(batch_size)
        self.output_patch_size = int(output_patch_size)
        self.patch_len = int(patch_len)
        self.num_output_patches = math.ceil(self.max_pred_len / self.output_patch_size)
        self.log_interval = max(0, int(log_interval or 0))
        self.file_shuffle = bool(file_shuffle)
        self.sample_pool_size = max(1, int(sample_pool_size or 1))
        self.samples_per_dataset_block = max(1, int(samples_per_dataset_block or 1))
        self.windows_per_series = max(1, int(windows_per_series or 1))
        self.min_history_len = max(1, int(min_history_len or 1))
        self.min_pred_len = max(1, int(min_pred_len or 1))
        self.history_patch_multiple = bool(history_patch_multiple)
        self.prediction_patch_multiple = bool(prediction_patch_multiple)
        self.curriculum_enable = bool(curriculum_enable)
        self.curriculum_initial_max_history_len = int(curriculum_initial_max_history_len or self.max_seq_len)
        self.curriculum_mid_max_history_len = int(curriculum_mid_max_history_len or self.max_seq_len)
        self.curriculum_final_max_history_len = int(curriculum_final_max_history_len or self.max_seq_len)
        self.curriculum_history_mid_batches = int(curriculum_history_mid_batches or 0)
        self.curriculum_history_final_batches = int(curriculum_history_final_batches or 0)
        self.curriculum_initial_max_pred_len = int(curriculum_initial_max_pred_len or self.max_pred_len)
        self.curriculum_mid_max_pred_len = (
            int(curriculum_mid_max_pred_len) if curriculum_mid_max_pred_len is not None else None
        )
        self.curriculum_final_max_pred_len = int(curriculum_final_max_pred_len or self.max_pred_len)
        self.curriculum_pred_mid_batches = int(curriculum_pred_mid_batches or 0)
        self.curriculum_pred_final_batches = int(curriculum_pred_final_batches or 0)
        self.seed = int(seed)

        if self.history_patch_multiple and self.min_history_len < self.patch_len:
            self.min_history_len = self.patch_len
        if self.prediction_patch_multiple and self.min_pred_len < self.output_patch_size:
            self.min_pred_len = self.output_patch_size
        self.invalid_dataset_configs = set()

        self.dataset_configs = [
            (dataset_name, term)
            for dataset_name in gifteval_requested_datasets(dataset_names)
            for term in gifteval_requested_terms(terms)
            if gifteval_should_run_dataset_term(dataset_name, term)
        ]
        if not self.dataset_configs:
            raise ValueError("No GIFT-Eval dataset configs selected for gifteval_train mode.")

        print(
            "Use GIFT-Eval train-part streaming dataset: "
            f"gift_eval_path={self.gift_eval_path}, configs={len(self.dataset_configs)}, "
            f"max_seq_len={self.max_seq_len}, max_pred_len={self.max_pred_len}, "
            f"batch_size={self.batch_size}, output_patch_size={self.output_patch_size}, "
            f"patch_len={self.patch_len}, sample_pool_size={self.sample_pool_size}, "
            f"samples_per_dataset_block={self.samples_per_dataset_block}, "
            f"windows_per_series={self.windows_per_series}, "
            f"prediction_patch_multiple={self.prediction_patch_multiple}, "
            f"curriculum_enable={self.curriculum_enable}, "
            f"curriculum_history=({self.curriculum_initial_max_history_len}->{self.curriculum_mid_max_history_len}->{self.curriculum_final_max_history_len}), "
            f"curriculum_pred=({self.curriculum_initial_max_pred_len}->{self.curriculum_mid_max_pred_len}->{self.curriculum_final_max_pred_len}), "
            f"curriculum_pred_batches=({self.curriculum_pred_mid_batches}->{self.curriculum_pred_final_batches})",
            flush=True,
        )

    def _curriculum_limits(self, batch_index):
        return curriculum_limits(
            batch_index=batch_index,
            enabled=self.curriculum_enable,
            max_seq_len=self.max_seq_len,
            max_pred_len=self.max_pred_len,
            initial_max_history_len=self.curriculum_initial_max_history_len,
            mid_max_history_len=self.curriculum_mid_max_history_len,
            final_max_history_len=self.curriculum_final_max_history_len,
            history_mid_batches=self.curriculum_history_mid_batches,
            history_final_batches=self.curriculum_history_final_batches,
            initial_max_pred_len=self.curriculum_initial_max_pred_len,
            mid_max_pred_len=self.curriculum_mid_max_pred_len,
            final_max_pred_len=self.curriculum_final_max_pred_len,
            pred_mid_batches=self.curriculum_pred_mid_batches,
            pred_final_batches=self.curriculum_pred_final_batches,
        )

    def __iter__(self):
        worker_info = get_worker_info()
        worker_id = worker_info.id if worker_info is not None else 0
        num_workers = worker_info.num_workers if worker_info is not None else 1
        rank = int(os.getenv("RANK", "0"))
        world_size = int(os.getenv("WORLD_SIZE", "1"))
        global_shard_id = rank * num_workers + worker_id
        global_num_shards = max(1, world_size * num_workers)
        rng = random.Random(self.seed + global_shard_id * 1009)
        dataset_rng = random.Random(self.seed + global_shard_id * 9176)
        Dataset = import_gifteval_dataset(self.gift_eval_path, self.gift_eval_src)

        if rank == 0 and worker_id == 0:
            print(
                f"GIFT-Eval train-part shard: world_size={world_size}, workers={num_workers}, "
                f"global_shards={global_num_shards}, configs={len(self.dataset_configs)}",
                flush=True,
            )

        raw_iter = self._iter_pool_generator(
            Dataset=Dataset,
            rng=rng,
            dataset_rng=dataset_rng,
            shard_id=global_shard_id,
            num_shards=global_num_shards,
            global_num_shards=global_num_shards,
            rank=rank,
            worker_id=worker_id,
        )
        yield from self._iter_chronos2_batches(raw_iter)

    def _iter_chronos2_batches(self, raw_iter):
        batch = []
        for sample in raw_iter:
            batch.append(sample)
            if len(batch) >= self.batch_size:
                yield self._collate_chronos2_batch(batch)
                batch = []
        if batch:
            yield self._collate_chronos2_batch(batch)

    def _iter_pool_generator(self, Dataset, rng, dataset_rng, shard_id, num_shards, global_num_shards, rank, worker_id):
        emitted = 0
        skipped = 0
        pool_epoch = 0
        start_time = time.time()

        while True:
            pool = []
            config_order = list(self.dataset_configs)
            if self.file_shuffle:
                dataset_rng.shuffle(config_order)
            batch_index = (emitted * max(1, global_num_shards)) // max(1, self.batch_size)
            max_history_len, max_pred_len = self._curriculum_limits(batch_index)
            pool_rounds = 0

            while len(pool) < self.sample_pool_size:
                pool_rounds += 1
                if pool and getattr(self, "allow_partial_pool", False) and pool_rounds > getattr(self, "partial_pool_after_rounds", 1):
                    break
                if not pool and getattr(self, "allow_partial_pool", False) and pool_rounds > getattr(self, "empty_pool_error_rounds", 4):
                    raise RuntimeError(
                        "No multivariate GIFT-Eval train windows found after scanning multiple dataset rounds. "
                        "Check --gift_eval_mv_datasets/--gift_eval_mv_terms or lower --mv_min_variates."
                    )
                for dataset_name, term in config_order:
                    if len(pool) >= self.sample_pool_size:
                        break
                    target_windows = min(self.samples_per_dataset_block, self.sample_pool_size - len(pool))
                    block = self._sample_dataset_config(
                        Dataset=Dataset,
                        dataset_name=dataset_name,
                        term=term,
                        rng=rng,
                        shard_id=shard_id,
                        num_shards=num_shards,
                        target_windows=target_windows,
                        max_history_len=max_history_len,
                        max_pred_len=max_pred_len,
                    )
                    if block:
                        pool.extend(block)
                    else:
                        skipped += 1

            rng.shuffle(pool)
            pool_epoch += 1
            emitted += len(pool)
            if self.log_interval and rank == 0 and worker_id == 0 and emitted % self.log_interval < len(pool):
                elapsed = time.time() - start_time
                print(
                    f"[gifteval train rank={rank} worker={worker_id}] "
                    f"pool_epoch={pool_epoch} configs_in_pool={len(config_order)} "
                    f"pool_ready={len(pool)} worker_windows={emitted} "
                    f"batch_index={batch_index} max_history_len={max_history_len} max_pred_len={max_pred_len} "
                    f"global_windows_est={emitted * max(1, global_num_shards)} skipped={skipped} "
                    f"elapsed={elapsed:.1f}s",
                    flush=True,
                )
            while pool:
                yield pool.pop()

    def _sample_dataset_config(self, Dataset, dataset_name, term, rng, shard_id, num_shards, target_windows, max_history_len, max_pred_len):
        try:
            to_univariate = Dataset(name=dataset_name, term=term, to_univariate=False).target_dim != 1
            dataset = Dataset(name=dataset_name, term=term, to_univariate=to_univariate)
            input_iter = dataset.training_dataset
        except Exception as exc:
            raise RuntimeError(f"Failed to load GIFT-Eval train part: dataset={dataset_name}, term={term}") from exc

        windows = []
        for item_idx, entry in enumerate(input_iter):
            if item_idx % num_shards != shard_id:
                continue
            target = np.asarray(entry["target"], dtype=np.float32)
            windows.extend(self._sample_from_target(target, rng, target_windows - len(windows), max_history_len, max_pred_len))
            if len(windows) >= target_windows:
                break
        return windows

    def _sample_from_target(self, target, rng, max_windows, max_history_len, max_pred_len):
        if max_windows <= 0:
            return []
        if target.ndim == 1:
            target = target.reshape(1, -1)
        elif target.ndim != 2:
            return []

        windows = []
        channel_indices = list(range(target.shape[0]))
        rng.shuffle(channel_indices)
        for channel_idx in channel_indices:
            series = fill_missing_values(target[channel_idx].astype(np.float32))
            if series is None:
                continue
            windows.extend(self._sample_windows_from_series(series, rng, max_windows - len(windows), max_history_len, max_pred_len))
            if len(windows) >= max_windows:
                return windows
        return windows

    def _sample_windows_from_series(self, series, rng, max_windows, max_history_len=None, max_pred_len=None):
        windows = []
        series_len = int(len(series))
        min_total = self.min_history_len + self.min_pred_len
        if series_len < min_total:
            return windows
        max_history_len = int(max_history_len or self.max_seq_len)
        max_pred_len = int(max_pred_len or self.max_pred_len)

        for _ in range(min(self.windows_per_series, max_windows)):
            max_total = min(series_len, max_history_len + max_pred_len)
            if max_total < min_total:
                continue
            total_len = rng.randint(min_total, max_total)
            max_history = min(max_history_len, total_len - self.min_pred_len)
            min_history = min(self.min_history_len, max_history)
            if self.history_patch_multiple:
                max_history = (max_history // self.patch_len) * self.patch_len
                min_history = max(self.patch_len, ((min_history + self.patch_len - 1) // self.patch_len) * self.patch_len)
                if max_history < min_history:
                    continue
                history_steps = rng.randint(min_history // self.patch_len, max_history // self.patch_len) * self.patch_len
            else:
                history_steps = rng.randint(min_history, max_history)
            pred_steps = sample_prediction_length(
                available_steps=total_len - history_steps,
                max_pred_len=max_pred_len,
                min_pred_len=self.min_pred_len,
                output_patch_size=self.output_patch_size,
                prediction_patch_multiple=self.prediction_patch_multiple,
                rng=rng,
            )
            if pred_steps is None:
                continue

            valid_offsets = series_len - history_steps - pred_steps + 1
            if valid_offsets <= 0:
                continue
            offset = rng.randrange(valid_offsets)
            history = np.nan_to_num(series[offset:offset + history_steps], nan=0.0, posinf=0.0, neginf=0.0)
            future = np.nan_to_num(
                series[offset + history_steps:offset + history_steps + pred_steps],
                nan=0.0,
                posinf=0.0,
                neginf=0.0,
            )

            context = np.zeros(self.max_seq_len, dtype=np.float32)
            context_mask = np.zeros(self.max_seq_len, dtype=np.float32)
            future_target = np.zeros(self.max_pred_len, dtype=np.float32)
            future_target_mask = np.zeros(self.max_pred_len, dtype=np.float32)
            context[-history_steps:] = history
            context_mask[-history_steps:] = 1.0
            future_target[:pred_steps] = future
            future_target_mask[:pred_steps] = 1.0
            windows.append({
                "context": context,
                "context_mask": context_mask,
                "future_target": future_target,
                "future_target_mask": future_target_mask,
            })
        return windows

    def _collate_chronos2_batch(self, samples):
        context = torch.as_tensor(np.stack([x["context"] for x in samples]), dtype=torch.float32)
        context_mask = torch.as_tensor(np.stack([x["context_mask"] for x in samples]), dtype=torch.float32)
        future_target = torch.as_tensor(np.stack([x["future_target"] for x in samples]), dtype=torch.float32)
        future_target_mask = torch.as_tensor(
            np.stack([x["future_target_mask"] for x in samples]), dtype=torch.float32
        )
        return {
            "context": context,
            "context_mask": context_mask,
            "future_target": future_target,
            "future_target_mask": future_target_mask,
            "group_ids": torch.arange(len(samples), dtype=torch.long),
            "future_covariates": None,
            "future_covariates_mask": None,
            "num_output_patches": self.num_output_patches,
        }


class GIFTEvalTrainPartMultivariateStreamingDataset(GIFTEvalTrainPartStreamingDataset):
    """Use multivariate GIFT-Eval train/history windows with shared group IDs."""

    def __init__(
            self,
            *args,
            min_variates=2,
            max_variates=10,
            max_grouped_sample_pool_size=None,
            shuffle_variates=True,
            **kwargs,
    ):
        super().__init__(*args, **kwargs)
        self.min_variates = max(1, int(min_variates or 1))
        self.max_variates = max(self.min_variates, int(max_variates or self.min_variates))
        self.shuffle_variates = bool(shuffle_variates)
        self.allow_partial_pool = True
        self.partial_pool_after_rounds = 1
        self.empty_pool_error_rounds = 4
        if max_grouped_sample_pool_size is not None:
            max_grouped_sample_pool_size = max(1, int(max_grouped_sample_pool_size))
            if self.sample_pool_size > max_grouped_sample_pool_size:
                self.sample_pool_size = max_grouped_sample_pool_size
        print(
            f"Use GIFT-Eval train-part multivariate grouping: "
            f"min_variates={self.min_variates}, max_variates={self.max_variates}, "
            f"shuffle_variates={self.shuffle_variates}, "
            f"sample_pool_size={self.sample_pool_size}",
            flush=True,
        )

    def _sample_dataset_config(self, Dataset, dataset_name, term, rng, shard_id, num_shards, target_windows, max_history_len, max_pred_len):
        config_key = (dataset_name, term)
        if config_key in self.invalid_dataset_configs:
            return []
        try:
            dataset = Dataset(name=dataset_name, term=term, to_univariate=False)
            if int(getattr(dataset, "target_dim", 1) or 1) < self.min_variates:
                self.invalid_dataset_configs.add(config_key)
                return []
            input_iter = dataset.test_data.input
        except Exception as exc:
            self.invalid_dataset_configs.add(config_key)
            return []

        windows = []
        for item_idx, entry in enumerate(input_iter):
            if item_idx % num_shards != shard_id:
                continue
            target = np.asarray(entry["target"], dtype=np.float32)
            windows.extend(self._sample_from_target(target, rng, target_windows - len(windows), max_history_len, max_pred_len))
            if len(windows) >= target_windows:
                break
        return windows

    def _iter_chronos2_batches(self, raw_iter):
        batch = []
        row_count = 0
        for sample in raw_iter:
            sample_rows = int(sample["context"].shape[0])
            if batch and row_count + sample_rows > self.batch_size:
                yield self._collate_chronos2_batch(batch)
                batch = []
                row_count = 0
            batch.append(sample)
            row_count += sample_rows
            if row_count >= self.batch_size:
                yield self._collate_chronos2_batch(batch)
                batch = []
                row_count = 0
        if batch:
            yield self._collate_chronos2_batch(batch)

    def _sample_from_target(self, target, rng, max_windows, max_history_len, max_pred_len):
        if max_windows <= 0:
            return []
        if target.ndim == 1:
            return []
        if target.ndim != 2:
            return []

        valid_series = []
        for channel_idx in range(target.shape[0]):
            series = fill_missing_values(target[channel_idx].astype(np.float32))
            if series is not None:
                valid_series.append(series)
        if len(valid_series) < self.min_variates:
            return []
        if len(valid_series) > self.max_variates:
            selected = list(range(len(valid_series)))
            rng.shuffle(selected)
            selected = selected[: rng.randint(self.min_variates, self.max_variates)]
            valid_series = [valid_series[idx] for idx in selected]
        if self.shuffle_variates and len(valid_series) > 1:
            rng.shuffle(valid_series)

        target = np.stack(valid_series, axis=0).astype(np.float32, copy=False)
        windows = []
        series_len = int(target.shape[1])
        min_total = self.min_history_len + self.min_pred_len
        if series_len < min_total:
            return windows
        max_history_len = int(max_history_len or self.max_seq_len)
        max_pred_len = int(max_pred_len or self.max_pred_len)

        for _ in range(min(self.windows_per_series, max_windows)):
            max_total = min(series_len, max_history_len + max_pred_len)
            if max_total < min_total:
                continue
            total_len = rng.randint(min_total, max_total)
            max_history = min(max_history_len, total_len - self.min_pred_len)
            min_history = min(self.min_history_len, max_history)
            if self.history_patch_multiple:
                max_history = (max_history // self.patch_len) * self.patch_len
                min_history = max(self.patch_len, ((min_history + self.patch_len - 1) // self.patch_len) * self.patch_len)
                if max_history < min_history:
                    continue
                history_steps = rng.randint(min_history // self.patch_len, max_history // self.patch_len) * self.patch_len
            else:
                history_steps = rng.randint(min_history, max_history)
            pred_steps = sample_prediction_length(
                available_steps=total_len - history_steps,
                max_pred_len=max_pred_len,
                min_pred_len=self.min_pred_len,
                output_patch_size=self.output_patch_size,
                prediction_patch_multiple=self.prediction_patch_multiple,
                rng=rng,
            )
            if pred_steps is None:
                continue

            valid_offsets = series_len - history_steps - pred_steps + 1
            if valid_offsets <= 0:
                continue
            offset = rng.randrange(valid_offsets)
            history = np.nan_to_num(
                target[:, offset:offset + history_steps],
                nan=0.0,
                posinf=0.0,
                neginf=0.0,
            ).astype(np.float32, copy=False)
            future = np.nan_to_num(
                target[:, offset + history_steps:offset + history_steps + pred_steps],
                nan=0.0,
                posinf=0.0,
                neginf=0.0,
            ).astype(np.float32, copy=False)

            context = np.zeros((target.shape[0], self.max_seq_len), dtype=np.float32)
            context_mask = np.zeros((target.shape[0], self.max_seq_len), dtype=np.float32)
            future_target = np.zeros((target.shape[0], self.max_pred_len), dtype=np.float32)
            future_target_mask = np.zeros((target.shape[0], self.max_pred_len), dtype=np.float32)
            context[:, -history_steps:] = history
            context_mask[:, -history_steps:] = 1.0
            future_target[:, :pred_steps] = future
            future_target_mask[:, :pred_steps] = 1.0
            windows.append({
                "context": context,
                "context_mask": context_mask,
                "future_target": future_target,
                "future_target_mask": future_target_mask,
                "history_length": history_steps,
                "prediction_length": pred_steps,
                "num_variates": target.shape[0],
            })
        return windows

    def _collate_chronos2_batch(self, samples):
        context = torch.as_tensor(np.concatenate([x["context"] for x in samples], axis=0), dtype=torch.float32)
        context_mask = torch.as_tensor(
            np.concatenate([x["context_mask"] for x in samples], axis=0),
            dtype=torch.float32,
        )
        future_target = torch.as_tensor(
            np.concatenate([x["future_target"] for x in samples], axis=0),
            dtype=torch.float32,
        )
        future_target_mask = torch.as_tensor(
            np.concatenate([x["future_target_mask"] for x in samples], axis=0),
            dtype=torch.float32,
        )
        group_ids = []
        for group_idx, sample in enumerate(samples):
            group_ids.append(torch.full((int(sample["context"].shape[0]),), fill_value=group_idx, dtype=torch.long))
        return {
            "context": context,
            "context_mask": context_mask,
            "future_target": future_target,
            "future_target_mask": future_target_mask,
            "group_ids": torch.cat(group_ids, dim=0),
            "future_covariates": None,
            "future_covariates_mask": None,
            "num_output_patches": self.num_output_patches,
        }


class PreparedArrowChronos2Dataset(IterableDataset):
    """
    Streaming reader for arrow files that already contain pre-split history and prediction lengths.

    Supported row layouts:
      - context/history/past + future_target/future/label
      - target + history_len + pred_len, where target stores history followed by future

    Iteration yields the same Chronos-2 batch dictionary as GIFTEvalDynamicStreamingDataset.
    """

    HISTORY_KEYS = ("context", "history", "past", "past_target", "input", "inputs")
    FUTURE_KEYS = ("future_target", "future", "label", "labels", "prediction", "target_future")
    TARGET_KEYS = ("target", "values", "series")
    HISTORY_LEN_KEYS = ("history_len", "history_length", "context_len", "context_length", "past_len")
    PRED_LEN_KEYS = ("pred_len", "prediction_length", "future_len", "future_length", "horizon")

    def __init__(
            self,
            data_dir,
            max_seq_len,
            max_pred_len,
            batch_size,
            output_patch_size,
            log_interval=1000,
            file_shuffle=True,
            row_chunk_size=4096,
            arrow_cache_size=512,
            seed=5252,
    ):
        self.data_dir = data_dir
        self.max_seq_len = int(max_seq_len)
        self.max_pred_len = int(max_pred_len)
        self.batch_size = int(batch_size)
        self.output_patch_size = int(output_patch_size)
        self.num_output_patches = math.ceil(self.max_pred_len / self.output_patch_size)
        self.log_interval = max(0, int(log_interval or 0))
        self.file_shuffle = bool(file_shuffle)
        self.row_chunk_size = max(1, int(row_chunk_size or 1))
        self.arrow_cache_size = max(1, int(arrow_cache_size or 1))
        self.seed = int(seed)

        if self.batch_size <= 0:
            raise ValueError("batch_size must be positive")
        if self.output_patch_size <= 0:
            raise ValueError("output_patch_size must be positive")

        self.arrow_files = self._collect_arrow_files(data_dir)
        if not self.arrow_files:
            raise ValueError(f"No .arrow files found in {data_dir}")

        print(
            "Use prepared-arrow Chronos2 dataset: "
            f"files={len(self.arrow_files)}, max_seq_len={self.max_seq_len}, "
            f"max_pred_len={self.max_pred_len}, batch_size={self.batch_size}, "
            f"output_patch_size={self.output_patch_size}, row_chunk_size={self.row_chunk_size}, "
            f"arrow_cache_size={self.arrow_cache_size}",
            flush=True,
        )

    @staticmethod
    def _collect_arrow_files(data_dir):
        files = []
        for root, _, filenames in os.walk(data_dir):
            for filename in sorted(filenames):
                if filename.endswith(".arrow") and not filename.startswith("."):
                    files.append(os.path.join(root, filename))
        return sorted(files)

    @staticmethod
    def _first_present(sample, keys):
        for key in keys:
            if key in sample and sample[key] is not None:
                return sample[key]
        return None

    @staticmethod
    def _scalar_int(value, default=None):
        if value is None:
            return default
        array = np.asarray(value)
        if array.size == 0:
            return default
        return int(array.reshape(-1)[0])

    @staticmethod
    def _to_1d(value):
        array = np.asarray(value, dtype=np.float32)
        if array.ndim == 0:
            array = array.reshape(1)
        if array.ndim == 1:
            return array
        if array.ndim == 2:
            if array.shape[0] == 1:
                return array[0]
            if array.shape[1] == 1:
                return array[:, 0]
        return array.reshape(-1)

    def __iter__(self):
        worker_info = get_worker_info()
        worker_id = worker_info.id if worker_info is not None else 0
        num_workers = worker_info.num_workers if worker_info is not None else 1
        rank = int(os.getenv("RANK", "0"))
        world_size = int(os.getenv("WORLD_SIZE", "1"))
        global_shard_id = rank * num_workers + worker_id
        global_num_shards = max(1, world_size * num_workers)
        rng = random.Random(self.seed + global_shard_id * 1009)
        arrow_cache = OrderedDict()

        if rank == 0 and worker_id == 0:
            print(
                f"Prepared-arrow shard: world_size={world_size}, workers={num_workers}, "
                f"global_shards={global_num_shards}, files={len(self.arrow_files)}",
                flush=True,
            )

        emitted = 0
        start_time = time.time()
        batch = []
        arrow_epoch = 0
        while True:
            arrow_epoch += 1
            file_order = list(self.arrow_files)
            if self.file_shuffle:
                rng.shuffle(file_order)
            if rank == 0 and worker_id == 0:
                print(
                    f"[prepared arrow rank={rank} worker={worker_id}] "
                    f"arrow_epoch={arrow_epoch} start files={len(file_order)}",
                    flush=True,
                )
            for arrow_path in file_order:
                dataset = self._get_arrow_dataset(arrow_path, arrow_cache)
                for sample in self._iter_arrow_samples(dataset, global_shard_id, global_num_shards, rng):
                    parsed = self._parse_record(sample)
                    if parsed is None:
                        continue
                    batch.append(parsed)
                    if len(batch) >= self.batch_size:
                        emitted += len(batch)
                        if self.log_interval and rank == 0 and worker_id == 0 and emitted % self.log_interval < len(batch):
                            elapsed = time.time() - start_time
                            print(
                                f"[prepared arrow rank={rank} worker={worker_id}] "
                                f"worker_windows={emitted} global_windows_est={emitted * global_num_shards} "
                                f"last_file={arrow_path} elapsed={elapsed:.1f}s",
                                flush=True,
                        )
                        yield self._collate_chronos2_batch(batch)
                        batch = []
            if batch:
                emitted += len(batch)
                if rank == 0 and worker_id == 0:
                    elapsed = time.time() - start_time
                    print(
                        f"[prepared arrow rank={rank} worker={worker_id}] "
                        f"arrow_epoch={arrow_epoch} complete files={len(file_order)} "
                        f"flushing_partial_batch={len(batch)} worker_windows={emitted} "
                        f"global_windows_est={emitted * global_num_shards} elapsed={elapsed:.1f}s",
                        flush=True,
                    )
                yield self._collate_chronos2_batch(batch)
                batch = []
            elif rank == 0 and worker_id == 0:
                elapsed = time.time() - start_time
                print(
                    f"[prepared arrow rank={rank} worker={worker_id}] "
                    f"arrow_epoch={arrow_epoch} complete files={len(file_order)} "
                    f"worker_windows={emitted} global_windows_est={emitted * global_num_shards} "
                    f"elapsed={elapsed:.1f}s",
                    flush=True,
                )

    def _get_arrow_dataset(self, arrow_path, arrow_cache):
        dataset = arrow_cache.get(arrow_path)
        if dataset is not None:
            arrow_cache.move_to_end(arrow_path)
            return dataset
        try:
            dataset = HFDataset.from_file(arrow_path, in_memory=False)
        except Exception as exc:
            try:
                with pa.memory_map(arrow_path, "r") as source:
                    table = pa.ipc.open_file(source).read_all()
                dataset = HFDataset(table)
            except Exception as fallback_exc:
                raise RuntimeError(f"Failed to read arrow file: {arrow_path}") from fallback_exc
        arrow_cache[arrow_path] = dataset
        if len(arrow_cache) > self.arrow_cache_size:
            arrow_cache.popitem(last=False)
        return dataset

    def _iter_arrow_samples(self, dataset, shard_id, num_shards, rng):
        total = len(dataset)
        if total <= shard_id:
            return
        starts = list(range(shard_id, total, num_shards * self.row_chunk_size))
        if self.file_shuffle:
            rng.shuffle(starts)
        for start in starts:
            stop = min(total, start + num_shards * self.row_chunk_size)
            indices = list(range(start, stop, num_shards))
            if self.file_shuffle:
                rng.shuffle(indices)
            for index in indices:
                yield dataset[int(index)]

    def _parse_record(self, sample):
        history = self._first_present(sample, self.HISTORY_KEYS)
        future = self._first_present(sample, self.FUTURE_KEYS)

        if history is not None and future is not None:
            history = fill_missing_values(self._to_1d(history))
            future = fill_missing_values(self._to_1d(future))
        else:
            target = self._first_present(sample, self.TARGET_KEYS)
            if target is None:
                return None
            target = fill_missing_values(self._to_1d(target))
            history_len = self._scalar_int(self._first_present(sample, self.HISTORY_LEN_KEYS))
            pred_len = self._scalar_int(self._first_present(sample, self.PRED_LEN_KEYS))
            if history_len is None or pred_len is None:
                return None
            if len(target) < history_len + pred_len:
                return None
            history = target[:history_len]
            future = target[history_len:history_len + pred_len]

        if history is None or future is None or len(history) == 0 or len(future) == 0:
            return None
        history = np.nan_to_num(history[-self.max_seq_len:], nan=0.0, posinf=0.0, neginf=0.0).astype(np.float32)
        future = np.nan_to_num(future[:self.max_pred_len], nan=0.0, posinf=0.0, neginf=0.0).astype(np.float32)
        if len(future) == 0:
            return None

        context = np.zeros(self.max_seq_len, dtype=np.float32)
        context_mask = np.zeros(self.max_seq_len, dtype=np.float32)
        future_target = np.zeros(self.max_pred_len, dtype=np.float32)
        future_target_mask = np.zeros(self.max_pred_len, dtype=np.float32)
        context[-len(history):] = history
        context_mask[-len(history):] = 1.0
        future_target[:len(future)] = future
        future_target_mask[:len(future)] = 1.0
        return {
            "context": context,
            "context_mask": context_mask,
            "future_target": future_target,
            "future_target_mask": future_target_mask,
        }

    def _collate_chronos2_batch(self, samples):
        context = torch.as_tensor(np.stack([x["context"] for x in samples]), dtype=torch.float32)
        context_mask = torch.as_tensor(np.stack([x["context_mask"] for x in samples]), dtype=torch.float32)
        future_target = torch.as_tensor(np.stack([x["future_target"] for x in samples]), dtype=torch.float32)
        future_target_mask = torch.as_tensor(
            np.stack([x["future_target_mask"] for x in samples]), dtype=torch.float32
        )
        return {
            "context": context,
            "context_mask": context_mask,
            "future_target": future_target,
            "future_target_mask": future_target_mask,
            "group_ids": torch.arange(len(samples), dtype=torch.long),
            "future_covariates": None,
            "future_covariates_mask": None,
            "num_output_patches": self.num_output_patches,
        }


class GIFTEvalDynamicStreamingDataset(IterableDataset):
    """
    Falcon-X style streaming sampler.

    Iteration yields Chronos-2 batches:
      context             [batch_size, max_seq_len], left padded
      context_mask        [batch_size, max_seq_len], 1 for real history points
      future_target       [batch_size, max_pred_len], right padded
      future_target_mask  [batch_size, max_pred_len], 1 for real future targets
      group_ids           [batch_size], unique group per series
      num_output_patches  scalar int

    The actual history length and prediction length are sampled dynamically per
    window. Pools are composed from small dataset blocks and shuffled, so a large
    micro-batch can see multiple datasets without forcing one Arrow read per
    sample.
    """

    def __init__(
            self,
            data_dir,
            max_seq_len,
            max_pred_len,
            batch_size,
            output_patch_size,
            patch_len=48,
            log_interval=1000,
            window_stride=1,
            file_shuffle=True,
            sample_pool_size=8192,
            samples_per_arrow=512,
            samples_per_dataset_block=512,
            arrow_row_chunk_size=4096,
            windows_per_series=16,
            prefetch_pools=4,
            arrow_cache_size=512,
            min_history_len=48,
            min_pred_len=1,
            history_patch_multiple=True,
            prediction_patch_multiple=True,
            curriculum_enable=False,
            curriculum_initial_max_history_len=2048,
            curriculum_mid_max_history_len=4096,
            curriculum_final_max_history_len=None,
            curriculum_history_mid_batches=80000,
            curriculum_history_final_batches=150000,
            curriculum_initial_max_pred_len=256,
            curriculum_mid_max_pred_len=None,
            curriculum_final_max_pred_len=None,
            curriculum_pred_mid_batches=0,
            curriculum_pred_final_batches=80000,
            dataset_names=None,
            seed=5252,
    ):
        self.data_dir = data_dir
        self.max_seq_len = int(max_seq_len)
        self.max_pred_len = int(max_pred_len)
        self.batch_size = int(batch_size)
        self.output_patch_size = int(output_patch_size)
        self.patch_len = int(patch_len)
        self.num_output_patches = math.ceil(self.max_pred_len / self.output_patch_size)
        self.log_interval = max(0, int(log_interval or 0))
        self.window_stride = max(1, int(window_stride or 1))
        self.file_shuffle = bool(file_shuffle)
        self.sample_pool_size = max(1, int(sample_pool_size or 1))
        self.samples_per_arrow = max(1, int(samples_per_arrow or 1))
        self.samples_per_dataset_block = max(1, int(samples_per_dataset_block or self.sample_pool_size))
        self.arrow_row_chunk_size = max(1, int(arrow_row_chunk_size or 1))
        self.windows_per_series = max(1, int(windows_per_series or 1))
        self.prefetch_pools = max(0, int(prefetch_pools or 0))
        self.arrow_cache_size = max(1, int(arrow_cache_size or 1))
        self.min_history_len = max(1, int(min_history_len or 1))
        self.min_pred_len = max(1, int(min_pred_len or 1))
        self.history_patch_multiple = bool(history_patch_multiple)
        self.prediction_patch_multiple = bool(prediction_patch_multiple)
        self.curriculum_enable = bool(curriculum_enable)
        self.curriculum_initial_max_history_len = int(curriculum_initial_max_history_len or self.max_seq_len)
        self.curriculum_mid_max_history_len = int(curriculum_mid_max_history_len or self.max_seq_len)
        self.curriculum_final_max_history_len = int(curriculum_final_max_history_len or self.max_seq_len)
        self.curriculum_history_mid_batches = int(curriculum_history_mid_batches or 0)
        self.curriculum_history_final_batches = int(curriculum_history_final_batches or 0)
        self.curriculum_initial_max_pred_len = int(curriculum_initial_max_pred_len or self.max_pred_len)
        self.curriculum_mid_max_pred_len = (
            int(curriculum_mid_max_pred_len) if curriculum_mid_max_pred_len is not None else None
        )
        self.curriculum_final_max_pred_len = int(curriculum_final_max_pred_len or self.max_pred_len)
        self.curriculum_pred_mid_batches = int(curriculum_pred_mid_batches or 0)
        self.curriculum_pred_final_batches = int(curriculum_pred_final_batches or 0)
        self.requested_dataset_names = pretrain_requested_datasets(dataset_names)
        self.seed = int(seed)

        if self.batch_size <= 0:
            raise ValueError("batch_size must be positive")
        if self.output_patch_size <= 0:
            raise ValueError("output_patch_size must be positive")
        if self.max_seq_len < self.patch_len:
            raise ValueError("max_seq_len must be at least patch_len")
        if self.history_patch_multiple and self.min_history_len < self.patch_len:
            self.min_history_len = self.patch_len
        if self.prediction_patch_multiple and self.min_pred_len < self.output_patch_size:
            self.min_pred_len = self.output_patch_size
        self.dataset_to_arrow_files = self._collect_arrow_files(data_dir, self.requested_dataset_names)
        self.dataset_names = sorted(self.dataset_to_arrow_files)
        self.total_arrow_files = sum(len(paths) for paths in self.dataset_to_arrow_files.values())
        if not self.dataset_names:
            raise ValueError(f"No data-*.arrow files found in {data_dir}")

        print(
            "Use dynamic streaming GIFTEval dataset: "
            f"datasets={len(self.dataset_names)}, files={self.total_arrow_files}, "
            f"dataset_filter={len(self.requested_dataset_names) if self.requested_dataset_names is not None else 'all'}, "
            f"max_seq_len={self.max_seq_len}, max_pred_len={self.max_pred_len}, "
            f"batch_size={self.batch_size}, output_patch_size={self.output_patch_size}, "
            f"patch_len={self.patch_len}, min_history_len={self.min_history_len}, "
            f"min_pred_len={self.min_pred_len}, sample_pool_size={self.sample_pool_size}, "
            f"samples_per_dataset_block={self.samples_per_dataset_block}, "
            f"samples_per_arrow={self.samples_per_arrow}, arrow_row_chunk_size={self.arrow_row_chunk_size}, "
            f"windows_per_series={self.windows_per_series}, prefetch_pools={self.prefetch_pools}, "
            f"arrow_cache_size={self.arrow_cache_size}, "
            f"prediction_patch_multiple={self.prediction_patch_multiple}, "
            f"curriculum_enable={self.curriculum_enable}, "
            f"curriculum_history=({self.curriculum_initial_max_history_len}->{self.curriculum_mid_max_history_len}->{self.curriculum_final_max_history_len}), "
            f"curriculum_pred=({self.curriculum_initial_max_pred_len}->{self.curriculum_mid_max_pred_len}->{self.curriculum_final_max_pred_len}), "
            f"curriculum_pred_batches=({self.curriculum_pred_mid_batches}->{self.curriculum_pred_final_batches})",
            flush=True,
        )

    def _curriculum_limits(self, batch_index):
        return curriculum_limits(
            batch_index=batch_index,
            enabled=self.curriculum_enable,
            max_seq_len=self.max_seq_len,
            max_pred_len=self.max_pred_len,
            initial_max_history_len=self.curriculum_initial_max_history_len,
            mid_max_history_len=self.curriculum_mid_max_history_len,
            final_max_history_len=self.curriculum_final_max_history_len,
            history_mid_batches=self.curriculum_history_mid_batches,
            history_final_batches=self.curriculum_history_final_batches,
            initial_max_pred_len=self.curriculum_initial_max_pred_len,
            mid_max_pred_len=self.curriculum_mid_max_pred_len,
            final_max_pred_len=self.curriculum_final_max_pred_len,
            pred_mid_batches=self.curriculum_pred_mid_batches,
            pred_final_batches=self.curriculum_pred_final_batches,
        )

    @staticmethod
    def _collect_arrow_files(data_dir, requested_dataset_names=None):
        dataset_to_arrow_files = {}
        for name in sorted(os.listdir(data_dir)):
            subdir = os.path.join(data_dir, name)
            if not os.path.isdir(subdir) or name.startswith("."):
                continue
            if not pretrain_dataset_matches(name, requested_dataset_names):
                continue
            files = [
                os.path.join(subdir, filename)
                for filename in sorted(os.listdir(subdir))
                if filename.startswith("data-") and filename.endswith(".arrow")
            ]
            if files:
                dataset_to_arrow_files[name] = files
        return dataset_to_arrow_files

    def __iter__(self):
        worker_info = get_worker_info()
        worker_id = worker_info.id if worker_info is not None else 0
        num_workers = worker_info.num_workers if worker_info is not None else 1
        rank = int(os.getenv("RANK", "0"))
        world_size = int(os.getenv("WORLD_SIZE", "1"))
        global_shard_id = rank * num_workers + worker_id
        global_num_shards = max(1, world_size * num_workers)

        rng = random.Random(self.seed + global_shard_id * 1009)
        dataset_rng = random.Random(self.seed + global_shard_id * 9176)
        arrow_orders = {name: self._new_arrow_order(name, rng) for name in self.dataset_names}
        arrow_positions = {name: 0 for name in self.dataset_names}

        if rank == 0 and worker_id == 0:
            print(
                f"Dynamic streaming shard: world_size={world_size}, workers={num_workers}, "
                f"global_shards={global_num_shards}, datasets={len(self.dataset_names)}",
                flush=True,
            )

        generator_kwargs = dict(
            arrow_orders=arrow_orders,
            arrow_positions=arrow_positions,
            rng=rng,
            dataset_rng=dataset_rng,
            shard_id=0,
            num_shards=1,
            global_num_shards=global_num_shards,
            rank=rank,
            worker_id=worker_id,
        )
        if self.prefetch_pools <= 0:
            raw_iter = self._iter_pool_generator(**generator_kwargs)
        else:
            raw_iter = self._iter_prefetch(**generator_kwargs)
        yield from self._iter_chronos2_batches(raw_iter)

    def _iter_chronos2_batches(self, raw_iter):
        batch = []
        for sample in raw_iter:
            batch.append(sample)
            if len(batch) >= self.batch_size:
                yield self._collate_chronos2_batch(batch)
                batch = []
        if batch:
            yield self._collate_chronos2_batch(batch)

    def _collate_chronos2_batch(self, samples):
        context = torch.as_tensor(np.stack([x["context"] for x in samples]), dtype=torch.float32)
        context_mask = torch.as_tensor(np.stack([x["context_mask"] for x in samples]), dtype=torch.float32)
        future_target = torch.as_tensor(np.stack([x["future_target"] for x in samples]), dtype=torch.float32)
        future_target_mask = torch.as_tensor(
            np.stack([x["future_target_mask"] for x in samples]), dtype=torch.float32
        )
        group_ids = torch.arange(len(samples), dtype=torch.long)

        return {
            "context": context,
            "context_mask": context_mask,
            "future_target": future_target,
            "future_target_mask": future_target_mask,
            "group_ids": group_ids,
            "future_covariates": None,
            "future_covariates_mask": None,
            "num_output_patches": self.num_output_patches,
        }

    def _iter_prefetch(self, **kwargs):
        pool_queue = queue.Queue(maxsize=self.prefetch_pools)
        stop_event = threading.Event()

        def producer():
            try:
                for pool in self._iter_pool_generator(**kwargs):
                    if stop_event.is_set():
                        break
                    while not stop_event.is_set():
                        try:
                            pool_queue.put(pool, timeout=0.5)
                            break
                        except queue.Full:
                            continue
            except BaseException as exc:
                pool_queue.put(exc)

        thread = threading.Thread(target=producer, daemon=True)
        thread.start()
        try:
            while True:
                item = pool_queue.get()
                if isinstance(item, BaseException):
                    raise item
                yield item
        finally:
            stop_event.set()

    def _iter_pool_generator(
            self,
            arrow_orders,
            arrow_positions,
            rng,
            dataset_rng,
            shard_id,
            num_shards,
            global_num_shards,
            rank,
            worker_id,
    ):
        arrow_cache = OrderedDict()
        invalid_arrow_paths = set()
        dataset_order = []
        dataset_position = 0
        dataset_round = 0
        datasets_seen = set()
        emitted = 0
        skipped = 0
        pool_epoch = 0
        start_time = time.time()

        while True:
            pool = []
            pool_datasets = []
            batch_index = (emitted * max(1, global_num_shards)) // max(1, self.batch_size)
            max_history_len, max_pred_len = self._curriculum_limits(batch_index)
            pool_round_start = dataset_round
            while len(pool) < self.sample_pool_size:
                if dataset_position >= len(dataset_order):
                    scanned_rounds = dataset_round - pool_round_start
                    if pool and getattr(self, "allow_partial_pool", False) and scanned_rounds >= getattr(self, "partial_pool_after_rounds", 1):
                        break
                    if not pool and getattr(self, "allow_partial_pool", False) and scanned_rounds >= getattr(self, "empty_pool_error_rounds", 4):
                        raise RuntimeError(
                            "No multivariate Arrow windows found after scanning multiple dataset rounds. "
                            "Check --real_mv_data_dir or lower --mv_min_variates."
                        )
                    dataset_order = list(self.dataset_names)
                    if self.file_shuffle:
                        dataset_rng.shuffle(dataset_order)
                    dataset_position = 0
                    dataset_round += 1
                    datasets_seen = set()
                dataset_name = dataset_order[dataset_position]
                dataset_position += 1
                datasets_seen.add(dataset_name)
                pool_datasets.append(dataset_name)

                target = min(
                    self.samples_per_dataset_block,
                    self.sample_pool_size - len(pool),
                )
                block = []
                skipped += self._fill_dataset_block(
                    block=block,
                    dataset_name=dataset_name,
                    arrow_orders=arrow_orders,
                    arrow_positions=arrow_positions,
                    rng=rng,
                    shard_id=shard_id,
                    num_shards=num_shards,
                    arrow_cache=arrow_cache,
                    invalid_arrow_paths=invalid_arrow_paths,
                    target_windows=target,
                    max_history_len=max_history_len,
                    max_pred_len=max_pred_len,
                )
                pool.extend(block)

            rng.shuffle(pool)
            pool_epoch += 1
            emitted += len(pool)
            if self.log_interval and rank == 0 and worker_id == 0 and emitted % self.log_interval < len(pool):
                elapsed = time.time() - start_time
                print(
                    f"[dynamic stream rank={rank} worker={worker_id}] "
                    f"pool_epoch={pool_epoch} datasets_in_pool={len(set(pool_datasets))} "
                    f"dataset_round={dataset_round} datasets_seen={len(datasets_seen)}/{len(self.dataset_names)} "
                    f"pool_ready={len(pool)} worker_windows={emitted} "
                    f"batch_index={batch_index} max_history_len={max_history_len} max_pred_len={max_pred_len} "
                    f"global_windows_est={emitted * max(1, global_num_shards)} skipped={skipped} "
                    f"dataset_head={pool_datasets[:6]} elapsed={elapsed:.1f}s",
                    flush=True,
                )
            while pool:
                yield pool.pop()

    def _fill_dataset_block(
            self,
            block,
            dataset_name,
            arrow_orders,
            arrow_positions,
            rng,
            shard_id,
            num_shards,
            arrow_cache,
            invalid_arrow_paths,
            target_windows,
            max_history_len,
            max_pred_len,
    ):
        skipped = 0
        draws = 0
        max_draws = max(8, (target_windows // self.samples_per_arrow + 1) * 8)
        while len(block) < target_windows and draws < max_draws:
            draws += 1
            arrow_path = self._next_arrow_path(dataset_name, arrow_orders, arrow_positions, rng)
            windows = self._sample_from_arrow(
                arrow_path=arrow_path,
                shard_id=shard_id,
                num_shards=num_shards,
                rng=rng,
                arrow_cache=arrow_cache,
                invalid_arrow_paths=invalid_arrow_paths,
                max_windows=min(self.samples_per_arrow, target_windows - len(block)),
                max_history_len=max_history_len,
                max_pred_len=max_pred_len,
            )
            if windows:
                block.extend(windows)
            else:
                skipped += 1
        return skipped

    def _new_arrow_order(self, dataset_name, rng):
        files = list(self.dataset_to_arrow_files[dataset_name])
        if self.file_shuffle:
            rng.shuffle(files)
        return files

    def _next_arrow_path(self, dataset_name, arrow_orders, arrow_positions, rng):
        if arrow_positions[dataset_name] >= len(arrow_orders[dataset_name]):
            arrow_orders[dataset_name] = self._new_arrow_order(dataset_name, rng)
            arrow_positions[dataset_name] = 0
        path = arrow_orders[dataset_name][arrow_positions[dataset_name]]
        arrow_positions[dataset_name] += 1
        return path

    def _get_arrow_dataset(self, arrow_path, arrow_cache):
        dataset = arrow_cache.get(arrow_path)
        if dataset is not None:
            arrow_cache.move_to_end(arrow_path)
            return dataset
        try:
            dataset = HFDataset.from_file(arrow_path, in_memory=False)
        except Exception as exc:
            try:
                with pa.memory_map(arrow_path, "r") as source:
                    table = pa.ipc.open_file(source).read_all()
                dataset = HFDataset(table)
            except Exception as fallback_exc:
                raise RuntimeError(f"Failed to read arrow file: {arrow_path}") from fallback_exc
        arrow_cache[arrow_path] = dataset
        if len(arrow_cache) > self.arrow_cache_size:
            arrow_cache.popitem(last=False)
        return dataset

    def _sample_from_arrow(
            self,
            arrow_path,
            shard_id,
            num_shards,
            rng,
            arrow_cache,
            invalid_arrow_paths,
            max_windows,
            max_history_len,
            max_pred_len,
    ):
        if arrow_path in invalid_arrow_paths:
            return []
        dataset = self._get_arrow_dataset(arrow_path, arrow_cache)
        if len(dataset) <= shard_id:
            invalid_arrow_paths.add(arrow_path)
            return []
        candidate_count = (len(dataset) - 1 - shard_id) // num_shards + 1
        chunk_count = min(candidate_count, self.arrow_row_chunk_size)
        chunk_start = rng.randrange(candidate_count - chunk_count + 1)
        indices = list(range(chunk_start, chunk_start + chunk_count))
        rng.shuffle(indices)

        windows = []
        for local_idx in indices:
            sample_idx = shard_id + local_idx * num_shards
            windows.extend(
                self._sample_from_record(
                    dataset[int(sample_idx)],
                    rng=rng,
                    max_windows=max_windows - len(windows),
                    max_history_len=max_history_len,
                    max_pred_len=max_pred_len,
                )
            )
            if len(windows) >= max_windows:
                break
        return windows

    def _sample_from_record(self, sample, rng, max_windows, max_history_len=None, max_pred_len=None):
        target = np.asarray(sample["target"], dtype=np.float32)
        if target.ndim == 1:
            target = target.reshape(1, -1)
        elif target.ndim != 2:
            return []

        windows = []
        max_history_len = int(max_history_len or self.max_seq_len)
        max_pred_len = int(max_pred_len or self.max_pred_len)
        channel_indices = list(range(target.shape[0]))
        rng.shuffle(channel_indices)
        for channel_idx in channel_indices:
            series = fill_missing_values(target[channel_idx].astype(np.float32))
            if series is None:
                continue
            series_len = int(len(series))
            min_total = self.min_history_len + self.min_pred_len
            if series_len < min_total:
                continue

            for _ in range(min(self.windows_per_series, max_windows - len(windows))):
                max_total = min(series_len, max_history_len + max_pred_len)
                if max_total < min_total:
                    continue
                total_len = rng.randint(min_total, max_total)
                max_history = min(max_history_len, total_len - self.min_pred_len)
                min_history = min(self.min_history_len, max_history)
                if self.history_patch_multiple:
                    max_history = (max_history // self.patch_len) * self.patch_len
                    min_history = max(self.patch_len, ((min_history + self.patch_len - 1) // self.patch_len) * self.patch_len)
                    if max_history < min_history:
                        continue
                    history_steps = rng.randint(min_history // self.patch_len, max_history // self.patch_len) * self.patch_len
                else:
                    history_steps = rng.randint(min_history, max_history)
                pred_steps = sample_prediction_length(
                    available_steps=total_len - history_steps,
                    max_pred_len=max_pred_len,
                    min_pred_len=self.min_pred_len,
                    output_patch_size=self.output_patch_size,
                    prediction_patch_multiple=self.prediction_patch_multiple,
                    rng=rng,
                )
                if pred_steps is None:
                    continue

                valid_offsets = series_len - history_steps - pred_steps + 1
                if valid_offsets <= 0:
                    continue
                if self.window_stride <= 1:
                    offset = rng.randrange(valid_offsets)
                else:
                    offset = rng.randrange((valid_offsets - 1) // self.window_stride + 1) * self.window_stride

                history = np.nan_to_num(
                    series[offset:offset + history_steps],
                    nan=0.0,
                    posinf=0.0,
                    neginf=0.0,
                ).astype(np.float32, copy=False)
                future = np.nan_to_num(
                    series[offset + history_steps:offset + history_steps + pred_steps],
                    nan=0.0,
                    posinf=0.0,
                    neginf=0.0,
                ).astype(np.float32, copy=False)

                context = np.zeros(self.max_seq_len, dtype=np.float32)
                context_mask = np.zeros(self.max_seq_len, dtype=np.float32)
                future_target = np.zeros(self.max_pred_len, dtype=np.float32)
                future_target_mask = np.zeros(self.max_pred_len, dtype=np.float32)
                context[-history_steps:] = history
                context_mask[-history_steps:] = 1.0
                future_target[:pred_steps] = future
                future_target_mask[:pred_steps] = 1.0
                windows.append({
                    "context": context,
                    "context_mask": context_mask,
                    "future_target": future_target,
                    "future_target_mask": future_target_mask,
                    "history_length": history_steps,
                    "prediction_length": pred_steps,
                })
                if len(windows) >= max_windows:
                    return windows
        return windows


class GIFTEvalDynamicMultivariateStreamingDataset(GIFTEvalDynamicStreamingDataset):
    """Stream multivariate Arrow records without splitting variates into independent groups."""

    def __init__(
            self,
            *args,
            min_variates=2,
            max_variates=10,
            max_grouped_sample_pool_size=None,
            shuffle_variates=True,
            **kwargs,
    ):
        super().__init__(*args, **kwargs)
        self.min_variates = max(1, int(min_variates or 1))
        self.max_variates = max(self.min_variates, int(max_variates or self.min_variates))
        self.shuffle_variates = bool(shuffle_variates)
        self.allow_partial_pool = True
        self.partial_pool_after_rounds = 1
        self.empty_pool_error_rounds = 4
        if max_grouped_sample_pool_size is not None:
            max_grouped_sample_pool_size = max(1, int(max_grouped_sample_pool_size))
            if self.sample_pool_size > max_grouped_sample_pool_size:
                self.sample_pool_size = max_grouped_sample_pool_size
        print(
            f"Use multivariate grouping: min_variates={self.min_variates}, "
            f"max_variates={self.max_variates}, shuffle_variates={self.shuffle_variates}, "
            f"sample_pool_size={self.sample_pool_size}",
            flush=True,
        )

    def _iter_chronos2_batches(self, raw_iter):
        batch = []
        row_count = 0
        for sample in raw_iter:
            sample_rows = int(sample["context"].shape[0])
            if batch and row_count + sample_rows > self.batch_size:
                yield self._collate_chronos2_batch(batch)
                batch = []
                row_count = 0
            batch.append(sample)
            row_count += sample_rows
            if row_count >= self.batch_size:
                yield self._collate_chronos2_batch(batch)
                batch = []
                row_count = 0
        if batch:
            yield self._collate_chronos2_batch(batch)

    def _sample_from_record(self, sample, rng, max_windows, max_history_len=None, max_pred_len=None):
        target = np.asarray(sample["target"], dtype=np.float32)
        if target.ndim == 1:
            target = target.reshape(1, -1)
        elif target.ndim != 2:
            return []

        valid_series = []
        for channel_idx in range(target.shape[0]):
            series = fill_missing_values(target[channel_idx].astype(np.float32))
            if series is not None:
                valid_series.append(series)
        if len(valid_series) < self.min_variates:
            return []
        if len(valid_series) > self.max_variates:
            selected = list(range(len(valid_series)))
            rng.shuffle(selected)
            selected = selected[: rng.randint(self.min_variates, self.max_variates)]
            valid_series = [valid_series[idx] for idx in selected]
        if self.shuffle_variates and len(valid_series) > 1:
            rng.shuffle(valid_series)
        target = np.stack(valid_series, axis=0).astype(np.float32, copy=False)

        windows = []
        series_len = int(target.shape[1])
        min_total = self.min_history_len + self.min_pred_len
        if series_len < min_total:
            return windows

        max_history_len = int(max_history_len or self.max_seq_len)
        max_pred_len = int(max_pred_len or self.max_pred_len)

        for _ in range(min(self.windows_per_series, max_windows)):
            max_total = min(series_len, max_history_len + max_pred_len)
            if max_total < min_total:
                continue
            total_len = rng.randint(min_total, max_total)
            max_history = min(max_history_len, total_len - self.min_pred_len)
            min_history = min(self.min_history_len, max_history)
            if self.history_patch_multiple:
                max_history = (max_history // self.patch_len) * self.patch_len
                min_history = max(self.patch_len, ((min_history + self.patch_len - 1) // self.patch_len) * self.patch_len)
                if max_history < min_history:
                    continue
                history_steps = rng.randint(min_history // self.patch_len, max_history // self.patch_len) * self.patch_len
            else:
                history_steps = rng.randint(min_history, max_history)

            pred_steps = sample_prediction_length(
                available_steps=total_len - history_steps,
                max_pred_len=max_pred_len,
                min_pred_len=self.min_pred_len,
                output_patch_size=self.output_patch_size,
                prediction_patch_multiple=self.prediction_patch_multiple,
                rng=rng,
            )
            if pred_steps is None:
                continue

            valid_offsets = series_len - history_steps - pred_steps + 1
            if valid_offsets <= 0:
                continue
            if self.window_stride <= 1:
                offset = rng.randrange(valid_offsets)
            else:
                offset = rng.randrange((valid_offsets - 1) // self.window_stride + 1) * self.window_stride

            history = np.nan_to_num(
                target[:, offset:offset + history_steps],
                nan=0.0,
                posinf=0.0,
                neginf=0.0,
            ).astype(np.float32, copy=False)
            future = np.nan_to_num(
                target[:, offset + history_steps:offset + history_steps + pred_steps],
                nan=0.0,
                posinf=0.0,
                neginf=0.0,
            ).astype(np.float32, copy=False)

            context = np.zeros((target.shape[0], self.max_seq_len), dtype=np.float32)
            context_mask = np.zeros((target.shape[0], self.max_seq_len), dtype=np.float32)
            future_target = np.zeros((target.shape[0], self.max_pred_len), dtype=np.float32)
            future_target_mask = np.zeros((target.shape[0], self.max_pred_len), dtype=np.float32)
            context[:, -history_steps:] = history
            context_mask[:, -history_steps:] = 1.0
            future_target[:, :pred_steps] = future
            future_target_mask[:, :pred_steps] = 1.0
            windows.append({
                "context": context,
                "context_mask": context_mask,
                "future_target": future_target,
                "future_target_mask": future_target_mask,
                "history_length": history_steps,
                "prediction_length": pred_steps,
                "num_variates": target.shape[0],
            })
        return windows

    def _collate_chronos2_batch(self, samples):
        context = torch.as_tensor(np.concatenate([x["context"] for x in samples], axis=0), dtype=torch.float32)
        context_mask = torch.as_tensor(
            np.concatenate([x["context_mask"] for x in samples], axis=0),
            dtype=torch.float32,
        )
        future_target = torch.as_tensor(
            np.concatenate([x["future_target"] for x in samples], axis=0),
            dtype=torch.float32,
        )
        future_target_mask = torch.as_tensor(
            np.concatenate([x["future_target_mask"] for x in samples], axis=0),
            dtype=torch.float32,
        )
        group_ids = []
        for group_idx, sample in enumerate(samples):
            group_ids.append(torch.full((int(sample["context"].shape[0]),), fill_value=group_idx, dtype=torch.long))

        return {
            "context": context,
            "context_mask": context_mask,
            "future_target": future_target,
            "future_target_mask": future_target_mask,
            "group_ids": torch.cat(group_ids, dim=0),
            "future_covariates": None,
            "future_covariates_mask": None,
            "num_output_patches": self.num_output_patches,
        }


def fill_missing_values(series):
    finite_mask = np.isfinite(series)
    if finite_mask.all():
        return series
    if not finite_mask.any():
        return None
    indices = np.arange(len(series), dtype=np.float32)
    filled = np.interp(
        indices,
        indices[finite_mask],
        series[finite_mask],
    ).astype(np.float32)
    return filled
