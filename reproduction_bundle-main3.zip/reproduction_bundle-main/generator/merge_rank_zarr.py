#!/usr/bin/env python3
import json
import shutil
import sys
from pathlib import Path
import numpy as np
import zarr
from numcodecs import Blosc

block = sys.argv[1]
src_root = Path(sys.argv[2])
out_root = Path(sys.argv[3])
chunk = 64
stores = sorted(src_root.glob(f"{block}.rank-*.zarr"))
if not stores:
    raise SystemExit(f"no rank stores for {block}")
groups = [zarr.open_group(str(p), mode="r") for p in stores]
keys = list(groups[0].array_keys())
total = min(100000, sum(int(g[keys[0]].shape[0]) for g in groups))
out_root.mkdir(parents=True, exist_ok=True)
out = out_root / f"{block}.zarr"
tmp = out_root / f"{block}.zarr.tmp"
if tmp.exists():
    shutil.rmtree(tmp)
if out.exists():
    raise FileExistsError(out)
compressor = Blosc(cname="zstd", clevel=5, shuffle=Blosc.BITSHUFFLE)
dst = zarr.open_group(str(tmp), mode="w")
for key in keys:
    src = groups[0][key]
    shape = (total,) + src.shape[1:]
    chunks = (chunk,) + src.shape[1:] if src.shape[1:] else (chunk,)
    dst.create_dataset(key, shape=shape, chunks=chunks, dtype=src.dtype, compressor=compressor)
dst.attrs.update(dict(groups[0].attrs))
dst.attrs["written_count"] = total
dst.attrs["source_rank_stores"] = len(stores)
offset = 0
for group in groups:
    take = min(int(group[keys[0]].shape[0]), total - offset)
    for left in range(0, take, chunk):
        right = min(left + chunk, take)
        for key in keys:
            dst[key][offset + left:offset + right] = group[key][left:right]
    offset += take
    if offset >= total:
        break
(out_root / f"{block}.metadata.json").write_text(json.dumps({"block": block, "written_count": total, "chunk_size": chunk}, indent=2))
tmp.rename(out)
for p in stores:
    shutil.rmtree(p)
    meta = p.parent / f"{p.name}.metadata.jsonl"
    if meta.exists():
        meta.unlink()
print(f"merged {block}: {total} samples -> {out}", flush=True)
