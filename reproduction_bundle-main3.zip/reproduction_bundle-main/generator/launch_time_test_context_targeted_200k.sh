#!/usr/bin/env bash
set -euo pipefail

GEN_ROOT=/home/toto2_stats_multimodal_generator_latest
TMP_ROOT=/public_data/.toto2_multimodal_time_test_context_targeted_200k_tmp
OUT_ROOT=/public_data/toto2_multimodal_time_test_context_targeted_200k
LOG_ROOT=${GEN_ROOT}/logs
LOG_FILE=${LOG_ROOT}/generate_time_test_context_targeted_200k_$(date +%Y%m%d_%H%M%S).log
PY=/opt/conda/envs/toto2mm/bin/python

mkdir -p "${TMP_ROOT}" "${OUT_ROOT}" "${LOG_ROOT}"
ln -sfn "${LOG_FILE}" "${LOG_ROOT}/generate_time_test_context_targeted_200k.latest.log"

echo "START $(date -Is) host=$(hostname) output=${OUT_ROOT}" | tee -a "${LOG_FILE}"
echo "TRANSDUCTIVE_TIME_TEST_INPUT_ONLY=true labels_accessed=false total=200000 targeted=200000 replay=0 weak_configs_only=true image_renderer=rgb_overlay_raw_independent_diff_shared_q01_q99_v1 clip_batch_size=16384 block_size=99996" | tee -a "${LOG_FILE}"

CUDA_VISIBLE_DEVICES=0,1,2,3,4,5 \
OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 \
ZARR_RANK_ROOT="${TMP_ROOT}" \
"${PY}" -m torch.distributed.run \
  --nproc_per_node=6 --master_port=29873 \
  "${GEN_ROOT}/extract_gifteval_test_context_transductive_105k_latest107.py" \
  --gift_eval_path /public_data/GIFTEval \
  --gift_eval_src /home/chronos-forecasting-main/gift-eval/src \
  --output_dir "${TMP_ROOT}" \
  --loader_module time_test_context_targeted_200k_loader \
  --num_samples 200000 --start_block 0 --block_size 99996 \
  --batch_size 64 --sample_group_size 64 --workers 16 --prefetch_groups 6 \
  --zarr_write_batch_size 64 --clip_model ViT-B/32 \
  --clip_checkpoint "${GEN_ROOT}/ViT-B-32.pt" \
  --clip_batch_size 16384 --seed 20260901 --log_interval 1024 \
  2>&1 | tee -a "${LOG_FILE}"

for block in block-000000 block-000001 block-000002; do
  "${PY}" "${GEN_ROOT}/merge_rank_zarr.py" \
    "${block}" "${TMP_ROOT}" "${OUT_ROOT}" 2>&1 | tee -a "${LOG_FILE}"
done

"${PY}" - "${OUT_ROOT}" "${GEN_ROOT}" <<'PY' | tee -a "${LOG_FILE}"
import collections
import glob
import json
import sys

import zarr

out_root, gen_root = sys.argv[1:]
sys.path.insert(0, gen_root)
from time_test_context_targeted_200k_loader import CONFIG_QUOTAS

paths = sorted(glob.glob(out_root + "/block-*.zarr"))
if len(paths) != 3:
    raise RuntimeError(f"expected three merged blocks, got {paths}")
counts = collections.Counter()
total = 0
sizes = []
for path in paths:
    group = zarr.open_group(path, mode="a")
    n = int(group["time_series_8192"].shape[0])
    sizes.append(n)
    total += n
    names = [value.decode().rstrip("\x00") for value in group["source_dataset"][:]]
    terms = [value.decode().rstrip("\x00") for value in group["source_term"][:]]
    counts.update(zip(names, terms))
    group.attrs.update(
        {
            "transductive_time_test_input_only": True,
            "labels_accessed": False,
            "intended_use": "transductive_adaptation_test_only_not_zero_shot",
            "image_renderer": "rgb_overlay_raw_independent_diff_shared_q01_q99_v1",
            "image_tokens_generated_directly_with": "rewrite_zarr_image_tokens_rgb.render_rgb_overlay",
            "image_tokens_posthoc_rewritten": False,
            "targeted_views": 200000,
            "all_config_replay_views": 0,
            "weak_configs_only": True,
            "quota_manifest": json.dumps(
                {f"{key[0]}|{key[1]}": value for key, value in CONFIG_QUOTAS.items()},
                sort_keys=True,
            ),
        }
    )
if sizes != [99996, 99996, 8]:
    raise RuntimeError(f"unexpected block sizes: {sizes}")
if total != 200000:
    raise RuntimeError(f"expected 200000 rows, got {total}")
if counts != collections.Counter(CONFIG_QUOTAS):
    raise RuntimeError(f"bad quota: actual={counts}, expected={CONFIG_QUOTAS}")
print("VALID", total, "blocks", sizes, "configs", len(counts))
PY

echo "DONE $(date -Is)" | tee -a "${LOG_FILE}"
touch "${OUT_ROOT}/.complete"
