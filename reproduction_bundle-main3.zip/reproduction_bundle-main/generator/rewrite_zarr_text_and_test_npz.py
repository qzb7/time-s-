#!/usr/bin/env python3
"""Rewrite old Zarr text tokens and grouped test NPZ image/text tokens."""

from __future__ import annotations

import argparse
from concurrent.futures import ProcessPoolExecutor
import json
import multiprocessing as mp
import os
from pathlib import Path
import time

import numpy as np
import torch
import torch.distributed as dist
import zarr
from numcodecs import Blosc
from tqdm import tqdm

from rewrite_zarr_image_tokens_rgb import (
    CLIP_MEAN,
    CLIP_STD,
    compute_differences,
    render_rgb_overlay,
    scaled_fp16,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--text_zarr_root", default="")
    parser.add_argument("--test_npz_root", required=True)
    parser.add_argument("--clip_checkpoint", required=True)
    parser.add_argument("--clip_model", default="ViT-B/32")
    parser.add_argument("--sample_group_size", type=int, default=128)
    parser.add_argument("--clip_batch_size", type=int, default=16384)
    parser.add_argument("--zarr_chunk_size", type=int, default=64)
    parser.add_argument("--text_workers", type=int, default=16)
    parser.add_argument("--manifest_dir", required=True)
    return parser.parse_args()


def describe_one_row(payload) -> list[str]:
    row, target_mask, padding_mask = payload
    from toto2_stats_template import describe_patch

    row = np.asarray(row, dtype=np.float32)
    target_mask = np.asarray(target_mask, dtype=bool)
    padding_mask = np.asarray(padding_mask, dtype=bool)
    descriptions = []
    for start in range(0, 8192, 32):
        stop = start + 32
        raw = row[start:stop]
        pad = padding_mask[start:stop]
        valid = target_mask[start:stop] & np.isfinite(raw) & ~pad
        descriptions.append(describe_patch(raw, valid, pad, None, start=start))
    return descriptions


def load_completed(path: Path) -> set[str]:
    if not path.exists():
        return set()
    completed = set()
    for line in path.read_text(encoding="utf-8").splitlines():
        try:
            record = json.loads(line)
            if record.get("status") == "completed":
                completed.add(record["path"])
        except Exception:
            continue
    return completed


def append_manifest(path: Path, record: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(record, ensure_ascii=True) + "\n")


class MultimodalEncoder:
    def __init__(self, model, tokenizer, device, clip_batch_size: int, executor):
        self.model = model
        self.tokenizer = tokenizer
        self.device = device
        self.clip_batch_size = clip_batch_size
        self.executor = executor
        self.mean = torch.tensor(CLIP_MEAN, device=device).view(1, 3, 1, 1)
        self.std = torch.tensor(CLIP_STD, device=device).view(1, 3, 1, 1)
        self.padding_image_feature = None

    def descriptions(self, rows, target_mask, padding_mask) -> list[str]:
        payloads = zip(rows, target_mask, padding_mask)
        nested = list(self.executor.map(describe_one_row, payloads, chunksize=1))
        return [description for row_descriptions in nested for description in row_descriptions]

    def encode_text(self, descriptions: list[str]) -> np.ndarray:
        unique, inverse = np.unique(np.asarray(descriptions, dtype=object), return_inverse=True)
        unique_features = np.empty((len(unique), 512), dtype=np.float32)
        with torch.inference_mode():
            for left in range(0, len(unique), self.clip_batch_size):
                right = min(len(unique), left + self.clip_batch_size)
                tokens = self.tokenizer([str(value) for value in unique[left:right]]).to(
                    self.device, non_blocking=True
                )
                unique_features[left:right] = self.model.encode_text(tokens).float().cpu().numpy()
        return unique_features[inverse]

    def encode_images(self, rows, target_mask, padding_mask) -> np.ndarray:
        valid = target_mask & ~padding_mask & np.isfinite(rows)
        diff1, diff2 = compute_differences(rows, valid)
        patches = rows.reshape(-1, 32)
        valid_patches = valid.reshape(-1, 32)
        d1_patches = diff1.reshape(-1, 32)
        d2_patches = diff2.reshape(-1, 32)
        full_padding = padding_mask.reshape(-1, 32).all(axis=-1)
        features = np.empty((len(patches), 512), dtype=np.float32)

        indices_to_encode = np.flatnonzero(~full_padding)
        if self.padding_image_feature is None and full_padding.any():
            indices_to_encode = np.concatenate(
                (indices_to_encode, np.flatnonzero(full_padding)[:1])
            )
        with torch.inference_mode():
            for left in range(0, len(indices_to_encode), self.clip_batch_size):
                indices = indices_to_encode[left:left + self.clip_batch_size]
                raw = torch.from_numpy(patches[indices]).to(self.device, non_blocking=True)
                raw_valid = torch.from_numpy(valid_patches[indices]).to(self.device, non_blocking=True)
                d1 = torch.from_numpy(d1_patches[indices]).to(self.device, non_blocking=True)
                d2 = torch.from_numpy(d2_patches[indices]).to(self.device, non_blocking=True)
                images = render_rgb_overlay(raw, raw_valid, d1, d2)
                images = images.float().div_(255.0)
                images = (images - self.mean) / self.std
                encoded = self.model.encode_image(images).float().cpu().numpy()
                features[indices] = encoded
                if self.padding_image_feature is None:
                    locations = np.flatnonzero(full_padding[indices])
                    if len(locations):
                        self.padding_image_feature = encoded[locations[0]].copy()
        if self.padding_image_feature is not None:
            features[full_padding] = self.padding_image_feature
        return features


def rewrite_zarr_text(store: Path, encoder: MultimodalEncoder, args, rank: int) -> None:
    started = time.time()
    group = zarr.open_group(str(store), mode="a")
    count = int(group["time_series_8192"].shape[0])
    for name in ("text_global_fp16", "text_scale"):
        if name in group:
            del group[name]
    compressor = Blosc(cname="zstd", clevel=5, shuffle=Blosc.BITSHUFFLE)
    text_array = group.create_dataset(
        "text_global_fp16",
        shape=(count, 256, 512),
        chunks=(args.zarr_chunk_size, 256, 512),
        dtype="f2",
        compressor=compressor,
        overwrite=True,
    )
    scale_array = group.create_dataset(
        "text_scale",
        shape=(count, 256, 1),
        chunks=(args.zarr_chunk_size, 256, 1),
        dtype="f4",
        compressor=compressor,
        overwrite=True,
    )
    progress = tqdm(total=count, desc=f"text rank{rank} {store.name}", unit="sample")
    for left in range(0, count, args.sample_group_size):
        right = min(count, left + args.sample_group_size)
        rows = np.asarray(group["time_series_8192"][left:right], dtype=np.float32)
        target = np.asarray(group["target_mask_8192"][left:right], dtype=bool)
        padding = np.asarray(group["padding_mask_8192"][left:right], dtype=bool)
        descriptions = encoder.descriptions(rows, target, padding)
        features = encoder.encode_text(descriptions).reshape(right - left, 256, 512)
        fp16, scales = scaled_fp16(features)
        text_array[left:right] = fp16
        scale_array[left:right] = scales
        progress.update(right - left)
    progress.close()
    checks = sorted(set((0, count // 2, count - 1)))
    restored = np.asarray(text_array[checks], np.float32) * np.asarray(scale_array[checks], np.float32)
    if restored.shape != (len(checks), 256, 512) or not np.isfinite(restored).all():
        raise RuntimeError(f"text validation failed: {store}")
    print(f"TEXT COMPLETE rank={rank} store={store} elapsed={time.time()-started:.1f}s", flush=True)


def rewrite_test_npz(path: Path, encoder: MultimodalEncoder, args, rank: int) -> None:
    started = time.time()
    with np.load(path, allow_pickle=False) as source:
        values = {name: source[name] for name in source.files}
    rows = np.asarray(values["time_series_8192"], dtype=np.float32)
    target = np.asarray(values["target_mask_8192"], dtype=bool)
    padding = np.asarray(values["padding_mask_8192"], dtype=bool)
    count = len(rows)
    image_output = np.empty((count, 256, 512), dtype=np.float32)
    text_output = np.empty((count, 256, 512), dtype=np.float32)
    for left in range(0, count, args.sample_group_size):
        right = min(count, left + args.sample_group_size)
        image_output[left:right] = encoder.encode_images(
            rows[left:right], target[left:right], padding[left:right]
        ).reshape(right - left, 256, 512)
        descriptions = encoder.descriptions(rows[left:right], target[left:right], padding[left:right])
        text_output[left:right] = encoder.encode_text(descriptions).reshape(right - left, 256, 512)
    if not np.isfinite(image_output).all() or not np.isfinite(text_output).all():
        raise RuntimeError(f"non-finite test tokens: {path}")
    values["image_global"] = image_output
    values["text_global"] = text_output
    temporary = path.with_name(path.name + ".rewrite_tmp")
    with temporary.open("wb") as handle:
        np.savez_compressed(handle, **values)
    os.replace(temporary, path)
    print(f"NPZ COMPLETE rank={rank} path={path} samples={count} elapsed={time.time()-started:.1f}s", flush=True)


def main() -> None:
    args = parse_args()
    dist.init_process_group("nccl")
    rank = dist.get_rank()
    world = dist.get_world_size()
    local_rank = int(os.environ.get("LOCAL_RANK", rank))
    device = torch.device("cuda", local_rank)
    torch.cuda.set_device(device)

    # Spawn avoids forking a process after CUDA initialization.
    executor = ProcessPoolExecutor(
        max_workers=args.text_workers,
        mp_context=mp.get_context("spawn"),
    )
    import open_clip

    clip_name = args.clip_model.replace("/", "-")
    clip_model, _, _ = open_clip.create_model_and_transforms(
        clip_name, pretrained=args.clip_checkpoint, device=device
    )
    clip_model.eval()
    tokenizer = open_clip.get_tokenizer(clip_name)
    encoder = MultimodalEncoder(
        clip_model, tokenizer, device, args.clip_batch_size, executor
    )

    manifest_dir = Path(args.manifest_dir)
    zarr_manifest = manifest_dir / f"rewrite_text_zarr.rank-{rank:02d}.jsonl"
    npz_manifest = manifest_dir / f"rewrite_test_npz.rank-{rank:02d}.jsonl"
    completed_zarr = set()
    for manifest_path in manifest_dir.glob("rewrite_text_zarr.rank-*.jsonl"):
        completed_zarr.update(load_completed(manifest_path))
    completed_npz = set()
    for manifest_path in manifest_dir.glob("rewrite_test_npz.rank-*.jsonl"):
        completed_npz.update(load_completed(manifest_path))

    stores = sorted(Path(args.text_zarr_root).glob("block-*.zarr")) if args.text_zarr_root else []
    pending_stores = [path for path in stores if str(path.resolve()) not in completed_zarr]
    assigned_stores = pending_stores[rank::world]
    for store in assigned_stores:
        key = str(store.resolve())
        if key in completed_zarr:
            print(f"TEXT SKIP completed {store}", flush=True)
            continue
        try:
            rewrite_zarr_text(store, encoder, args, rank)
            append_manifest(zarr_manifest, {"status": "completed", "path": key, "time": time.time()})
        except Exception as exc:
            append_manifest(zarr_manifest, {"status": "failed", "path": key, "error": repr(exc), "time": time.time()})
            raise

    npz_files = sorted(Path(args.test_npz_root).rglob("*.npz"))
    pending_npz = [path for path in npz_files if str(path.resolve()) not in completed_npz]
    assigned_npz = pending_npz[rank::world]
    print(
        f"START rank={rank}/{world} zarr_total={len(stores)} zarr_pending={len(pending_stores)} "
        f"npz_total={len(npz_files)} npz_pending={len(pending_npz)}",
        flush=True,
    )
    for path in assigned_npz:
        key = str(path.resolve())
        if key in completed_npz:
            print(f"NPZ SKIP completed {path}", flush=True)
            continue
        try:
            rewrite_test_npz(path, encoder, args, rank)
            append_manifest(npz_manifest, {"status": "completed", "path": key, "time": time.time()})
        except Exception as exc:
            append_manifest(npz_manifest, {"status": "failed", "path": key, "error": repr(exc), "time": time.time()})
            raise

    executor.shutdown(wait=True)
    if rank == 0:
        print("TEXT ZARR AND TEST NPZ REWRITE COMPLETE", flush=True)
    dist.destroy_process_group()


if __name__ == "__main__":
    main()
