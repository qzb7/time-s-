#!/usr/bin/env python3
from __future__ import annotations

import json
import os
import runpy
import shutil
from pathlib import Path

import numpy as np
import zarr
from numcodecs import Blosc

ORIGINAL = "/home/toto2_stats_multimodal_generator_latest/extract_toto2_patch_clip_features_batched.py"
RANK = int(os.environ.get("RANK", os.environ.get("LOCAL_RANK", "0")))
BLOCK_NAME = os.environ.get("BLOCK_NAME", "block-000000")
ROOT = Path(os.environ.get("ZARR_RANK_ROOT", "/public_data/toto2_multimodal_zarr_tmp"))
STORE = ROOT / f"{BLOCK_NAME}.rank-{RANK:02d}.zarr"
CHUNK = 64
COMPRESSOR = Blosc(cname="zstd", clevel=5, shuffle=Blosc.BITSHUFFLE)

def scaled_fp16(x):
    x = np.asarray(x, dtype=np.float32)
    scale = np.max(np.abs(x), axis=-1, keepdims=True)
    scale = np.where(np.isfinite(scale) & (scale > 1e-12), scale, 1.0).astype(np.float32)
    return np.nan_to_num(x / scale, nan=0.0, posinf=0.0, neginf=0.0).astype(np.float16), scale

class RankWriter:
    def __init__(self):
        ROOT.mkdir(parents=True, exist_ok=True)
        if STORE.exists():
            shutil.rmtree(STORE)
        self.group = None
        self.arrays = {}
        self.count = 0
        self.metadata = []

    def _init(self, values):
        image = np.asarray(values["image_global"])
        text = np.asarray(values["text_global"])
        time = np.asarray(values["time_series_8192"])
        self.group = zarr.open_group(str(STORE), mode="w")
        specs = {
            "time_series_8192": (time.shape, "f4"),
            "target_mask_8192": (np.asarray(values["target_mask_8192"]).shape, "u1"),
            "padding_mask_8192": (np.asarray(values["padding_mask_8192"]).shape, "u1"),
            "image_global_fp16": (image.shape, "f2"),
            "image_scale": ((image.shape[0], 1), "f4"),
            "text_global_fp16": (text.shape, "f2"),
            "text_scale": ((text.shape[0], 1), "f4"),
            "sequence_length": ((), "i8"),
        }
        for name, (shape, dtype) in specs.items():
            initial = (0,) + shape
            chunks = (CHUNK,) + shape if shape else (CHUNK,)
            self.arrays[name] = self.group.create_dataset(
                name, shape=initial, chunks=chunks, dtype=dtype,
                compressor=COMPRESSOR, overwrite=True,
            )
        self.group.attrs.update({
            "format": "toto2_multimodal_zarr_fp16_scaled",
            "token_dtype": "float16",
            "token_scale_dtype": "float32",
            "time_series_dtype": "float32",
            "mask_dtype": "uint8",
            "token_scale_axis": "per_patch_max_abs",
            "chunk_size": CHUNK,
            "block_name": BLOCK_NAME,
        })

    def append(self, filename, values):
        if self.group is None:
            self._init(values)
        image, image_scale = scaled_fp16(values["image_global"])
        text, text_scale = scaled_fp16(values["text_global"])
        row = self.count
        for arr in self.arrays.values():
            arr.resize((row + 1,) + arr.shape[1:])
        self.arrays["time_series_8192"][row] = np.asarray(values["time_series_8192"], dtype=np.float32)
        self.arrays["target_mask_8192"][row] = np.asarray(values["target_mask_8192"], dtype=np.uint8)
        self.arrays["padding_mask_8192"][row] = np.asarray(values["padding_mask_8192"], dtype=np.uint8)
        self.arrays["image_global_fp16"][row] = image
        self.arrays["image_scale"][row] = image_scale
        self.arrays["text_global_fp16"][row] = text
        self.arrays["text_scale"][row] = text_scale
        self.arrays["sequence_length"][row] = int(np.asarray(values.get("sequence_length", 8192)).reshape(-1)[0])
        self.metadata.append({"row": row, "source": str(filename)})
        self.count += 1

    def close(self):
        if self.group is not None:
            self.group.attrs["written_count"] = self.count
            (STORE.parent / f"{STORE.name}.metadata.jsonl").write_text(
                "\n".join(json.dumps(x) for x in self.metadata) + "\n",
                encoding="utf-8",
            )

writer = RankWriter()
def direct_zarr_save(filename, *args, **kwargs):
    if args:
        raise ValueError("positional npz fields are not supported")
    writer.append(filename, kwargs)

np.savez_compressed = direct_zarr_save
try:
    runpy.run_path(ORIGINAL, run_name="__main__")
finally:
    writer.close()
