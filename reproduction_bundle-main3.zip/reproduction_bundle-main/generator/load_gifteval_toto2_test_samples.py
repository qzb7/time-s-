from __future__ import annotations

import os
import sys
from pathlib import Path

import numpy as np
import torch
from torch.utils.data import IterableDataset


class GIFTTESTMultimodalDataset(IterableDataset):
    """Official GIFT-Eval test windows, right-padded/aligned to 8192 points.

    One yielded item is exactly one ``test_data.input`` window. Multivariate
    configurations are expanded to univariate entries, matching the existing
    evaluation path when KEEP_MULTIVARIATE=0.
    """

    def __init__(self, gift_eval_path, gift_eval_src, seed=5252, rank=0, world_size=1):
        super().__init__()
        self.gift_eval_path = str(gift_eval_path)
        self.gift_eval_src = str(gift_eval_src)
        self.seed = int(seed)
        self.rank = int(rank)
        self.world_size = int(world_size)
        self.sequence_length = 8192
        self.ordered_dataset_names = []
        self.records = self._build_records()
        self.local_records = self.records[self.rank :: self.world_size]

    def _build_records(self):
        os.environ["GIFT_EVAL"] = self.gift_eval_path
        os.environ["GIFT_EVAL_PATH"] = self.gift_eval_path
        if self.gift_eval_src not in sys.path:
            sys.path.insert(0, self.gift_eval_src)
        # Keep this loader independent of Chronos. Only GIFT-Eval's Dataset
        # implementation and the official configuration list are required.
        from gift_eval.data import Dataset

        short_datasets = [
            "m4_yearly", "m4_quarterly", "m4_monthly", "m4_weekly", "m4_daily", "m4_hourly",
            "electricity/15T", "electricity/H", "electricity/D", "electricity/W",
            "solar/10T", "solar/H", "solar/D", "solar/W", "hospital", "covid_deaths",
            "us_births/D", "us_births/M", "us_births/W", "saugeenday/D", "saugeenday/M",
            "saugeenday/W", "temperature_rain_with_missing", "kdd_cup_2018_with_missing/H",
            "kdd_cup_2018_with_missing/D", "car_parts_with_missing", "restaurant",
            "hierarchical_sales/D", "hierarchical_sales/W", "LOOP_SEATTLE/5T", "LOOP_SEATTLE/H",
            "LOOP_SEATTLE/D", "SZ_TAXI/15T", "SZ_TAXI/H", "M_DENSE/H", "M_DENSE/D",
            "ett1/15T", "ett1/H", "ett1/D", "ett1/W", "ett2/15T", "ett2/H", "ett2/D",
            "ett2/W", "jena_weather/10T", "jena_weather/H", "jena_weather/D",
            "bitbrains_fast_storage/5T", "bitbrains_fast_storage/H", "bitbrains_rnd/5T",
            "bitbrains_rnd/H", "bizitobs_application", "bizitobs_service", "bizitobs_l2c/5T",
            "bizitobs_l2c/H",
        ]
        medium_long_datasets = {
            "electricity/15T", "electricity/H", "solar/10T", "solar/H",
            "kdd_cup_2018_with_missing/H", "LOOP_SEATTLE/5T", "LOOP_SEATTLE/H",
            "SZ_TAXI/15T", "M_DENSE/H", "ett1/15T", "ett1/H", "ett2/15T", "ett2/H",
            "jena_weather/10T", "jena_weather/H", "bitbrains_fast_storage/5T",
            "bitbrains_rnd/5T", "bizitobs_application", "bizitobs_service", "bizitobs_l2c/5T",
            "bizitobs_l2c/H",
        }
        requested = [
            (name, term)
            for name in short_datasets
            for term in ("short", "medium", "long")
            if term == "short" or name in medium_long_datasets
        ]

        grouped = []
        for dataset_name, term in requested:
            to_univariate = Dataset(name=dataset_name, term=term, to_univariate=False).target_dim != 1
            dataset = Dataset(name=dataset_name, term=term, to_univariate=to_univariate)
            inputs = list(dataset.test_data.input)
            rows = []
            for window_index, entry in enumerate(inputs):
                target = np.asarray(entry["target"], dtype=np.float32)
                if target.ndim == 1:
                    target = target[None, :]
                for variate_index, series in enumerate(target):
                    finite = np.isfinite(series)
                    values = np.full((self.sequence_length,), np.nan, dtype=np.float32)
                    mask = np.zeros((self.sequence_length,), dtype=bool)
                    take = min(series.shape[-1], self.sequence_length)
                    values[-take:] = series[-take:]
                    mask[-take:] = finite[-take:]
                    rows.append({
                        "dataset": dataset_name,
                        "term": str(term),
                        "frequency": str(dataset.freq),
                        "window_index": int(window_index),
                        "variate_index": int(variate_index),
                        "prediction_length": int(dataset.prediction_length),
                        "target": values,
                        "target_mask": mask,
                        "sequence_length": int(take),
                    })
            grouped.append((len(rows), dataset_name, str(term), rows))

        # Stable small-to-large ordering by configuration sample count.
        grouped.sort(key=lambda item: (item[0], item[1], item[2]))
        records = []
        self.ordered_dataset_names = []
        for _, _, _, rows in grouped:
            dataset_name = rows[0]["dataset"] if rows else None
            term = rows[0]["term"] if rows else None
            config_key = f"{dataset_name}::{term}" if dataset_name is not None else None
            if config_key is not None and config_key not in self.ordered_dataset_names:
                self.ordered_dataset_names.append(config_key)
            records.extend(rows)
        return records

    def __len__(self):
        return len(self.local_records)

    @property
    def total_size(self):
        return len(self.records)

    def __iter__(self):
        worker = torch.utils.data.get_worker_info()
        records = self.local_records
        if worker is not None:
            records = records[worker.id :: worker.num_workers]
        for record in records:
            yield {
                "target": torch.from_numpy(record["target"]),
                "target_mask": torch.from_numpy(record["target_mask"]),
                "sequence_length": torch.tensor(record["sequence_length"], dtype=torch.long),
                "dataset": record["dataset"],
                "term": record["term"],
                "frequency": record["frequency"],
                "window_index": torch.tensor(record["window_index"], dtype=torch.long),
                "variate_index": torch.tensor(record["variate_index"], dtype=torch.long),
                "prediction_length": torch.tensor(record["prediction_length"], dtype=torch.long),
            }
