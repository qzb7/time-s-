from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import random
import sys

import numpy as np
import torch
from torch.utils.data import IterableDataset


TIME_ROOT = os.environ.get("REPRO_TIME_ROOT", "/home/TIME")
TIME_DATA = os.environ.get("REPRO_TIME_DATA", "/public_data/TIME")
TIME_CONFIG = Path(TIME_ROOT) / "src/timebench/config/datasets.yaml"

# The seed allocation identifies only the weak configurations with the largest
# measured MASE/CRPS gaps at checkpoint-73000. It is proportionally expanded
# from 165k to 200k below; no all-configuration replay is generated.
TARGET_QUOTAS = {
    # Finance / health short: 45k
    ("ECDC_COVID/D", "short"): 9_000,
    ("ECDC_COVID/W", "short"): 7_000,
    ("Crypto/D", "short"): 8_000,
    ("Oil_Price/B", "short"): 6_000,
    ("Job_Claims/W", "short"): 5_000,
    ("US_Term_Structure/B", "short"): 6_000,
    ("Global_Price/Q", "short"): 4_000,
    # CPHL: 40k
    ("CPHL/15T", "short"): 2_000,
    ("CPHL/15T", "medium"): 4_000,
    ("CPHL/15T", "long"): 4_000,
    ("CPHL/30T", "short"): 3_000,
    ("CPHL/30T", "medium"): 6_000,
    ("CPHL/30T", "long"): 6_000,
    ("CPHL/H", "short"): 3_000,
    ("CPHL/H", "medium"): 6_000,
    ("CPHL/H", "long"): 6_000,
    # Current velocity: 35k
    ("current_velocity/10T", "short"): 1_000,
    ("current_velocity/10T", "medium"): 2_000,
    ("current_velocity/10T", "long"): 2_000,
    ("current_velocity/15T", "short"): 1_000,
    ("current_velocity/15T", "medium"): 3_000,
    ("current_velocity/15T", "long"): 4_000,
    ("current_velocity/20T", "short"): 2_000,
    ("current_velocity/20T", "medium"): 5_000,
    ("current_velocity/20T", "long"): 6_000,
    ("current_velocity/5T", "short"): 1_000,
    ("current_velocity/5T", "medium"): 2_000,
    ("current_velocity/5T", "long"): 2_000,
    ("current_velocity/H", "short"): 1_000,
    ("current_velocity/H", "medium"): 2_000,
    ("current_velocity/H", "long"): 1_000,
    # Coastal temperature/salinity: 25k
    ("Coastal_T_S/5T", "short"): 2_000,
    ("Coastal_T_S/5T", "medium"): 3_000,
    ("Coastal_T_S/5T", "long"): 3_000,
    ("Coastal_T_S/15T", "short"): 2_000,
    ("Coastal_T_S/15T", "medium"): 3_000,
    ("Coastal_T_S/15T", "long"): 4_000,
    ("Coastal_T_S/20T", "short"): 1_000,
    ("Coastal_T_S/20T", "medium"): 2_000,
    ("Coastal_T_S/20T", "long"): 2_000,
    ("Coastal_T_S/H", "short"): 1_000,
    ("Coastal_T_S/H", "medium"): 1_000,
    ("Coastal_T_S/H", "long"): 1_000,
    # Singapore weather/air quality: 15k
    ("SG_PM25/H", "short"): 2_000,
    ("SG_PM25/H", "medium"): 4_000,
    ("SG_PM25/H", "long"): 2_000,
    ("SG_Weather/D", "short"): 4_000,
    ("SG_Weather/D", "medium"): 2_000,
    ("SG_Weather/D", "long"): 1_000,
    # Solar protection: 5k
    ("Australia_Solar/H", "short"): 2_000,
    ("Australia_Solar/H", "medium"): 1_000,
    ("Australia_Solar/H", "long"): 2_000,
}

assert sum(TARGET_QUOTAS.values()) == 165_000


def _time_api():
    os.environ["TIME_DATASET"] = TIME_DATA
    src = str(Path(TIME_ROOT) / "src")
    if src not in sys.path:
        sys.path.insert(0, src)
    from timebench.evaluation.data import (
        Dataset,
        get_dataset_settings,
        load_dataset_config,
    )
    from timebench.evaluation.utils import get_available_terms

    return Dataset, get_dataset_settings, load_dataset_config, get_available_terms


def _all_configs():
    _, _, load_dataset_config, get_available_terms = _time_api()
    config = load_dataset_config(TIME_CONFIG)
    configs = []
    for name in config.get("datasets", {}):
        for term in get_available_terms(name, config):
            configs.append((str(name), str(term)))
    if len(configs) != 98:
        raise RuntimeError(f"Expected 98 TIME configurations, got {len(configs)}")
    return config, configs


TIME_CONFIG_OBJECT, ALL_CONFIGS = _all_configs()
_target_total = 200_000
_seed_total = sum(TARGET_QUOTAS.values())
CONFIG_QUOTAS = {
    key: value * _target_total // _seed_total
    for key, value in TARGET_QUOTAS.items()
}
_remainder = _target_total - sum(CONFIG_QUOTAS.values())
_fraction_order = sorted(
    TARGET_QUOTAS,
    key=lambda key: (TARGET_QUOTAS[key] * _target_total) % _seed_total,
    reverse=True,
)
for key in _fraction_order[:_remainder]:
    CONFIG_QUOTAS[key] += 1
TOTAL = sum(CONFIG_QUOTAS.values())
assert TOTAL == 200_000
assert set(CONFIG_QUOTAS) == set(TARGET_QUOTAS)

# Optional explicit counts, e.g. [{"dataset":"CPHL/H","term":"short","count":1000}].
# Preserve the historical ordering and allocations when no override is supplied.
if os.environ.get("REPRO_QUOTAS"):
    with open(os.environ["REPRO_QUOTAS"]) as f:
        entries = json.load(f)
    custom = {}
    for entry in entries:
        key = (entry["dataset"], entry["term"])
        count = entry["count"]
        if key not in ALL_CONFIGS or key in custom or type(count) is not int or count <= 0:
            raise ValueError(f"Invalid or duplicate quota: {entry}")
        custom[key] = count
    if not custom:
        raise ValueError("Empty quota list")
    CONFIG_QUOTAS = custom
    TOTAL = sum(custom.values())


def _pad(values: np.ndarray, valid: np.ndarray, width: int = 8192):
    values = np.asarray(values, dtype=np.float32).reshape(-1)
    valid = np.asarray(valid, dtype=bool).reshape(-1) & np.isfinite(values)
    if len(values) > width:
        values = values[-width:]
        valid = valid[-width:]
    target = np.full(width, np.nan, dtype=np.float32)
    mask = np.zeros(width, dtype=np.float32)
    if len(values):
        target[-len(values):] = values
        mask[-len(values):] = valid
    return target, mask


class TIMETestContextTargeted200K(IterableDataset):
    """Finite TIME test-input-only views; labels/future values are never read."""

    def __init__(
        self,
        batch_size,
        sequence_length,
        num_samples,
        seed,
        **_,
    ):
        if int(sequence_length) != 8192:
            raise ValueError("sequence_length must be 8192")
        if int(num_samples) != TOTAL:
            raise ValueError(f"num_samples must be {TOTAL}")
        self.batch_size = int(batch_size)
        self.seed = int(seed)

    def _contexts(self, name, term):
        Dataset, get_dataset_settings, _, _ = _time_api()
        settings = get_dataset_settings(name, term, TIME_CONFIG_OBJECT)
        metadata = Dataset(
            name=name,
            term=term,
            to_univariate=False,
            prediction_length=settings["prediction_length"],
            test_length=settings["test_length"],
            val_length=settings["val_length"],
            storage_path=TIME_DATA,
        )
        dataset = Dataset(
            name=name,
            term=term,
            to_univariate=metadata.target_dim != 1,
            prediction_length=settings["prediction_length"],
            test_length=settings["test_length"],
            val_length=settings["val_length"],
            storage_path=TIME_DATA,
        )
        # Deliberately access input only. Do not zip with or materialize label.
        rows = dataset.test_data.input
        output = []
        for row_index, row in enumerate(rows):
            array = np.asarray(row["target"], dtype=np.float32)
            item_id = str(row.get("item_id", row_index))
            channels = array if array.ndim > 1 else array.reshape(1, -1)
            for channel, channel_values in enumerate(channels):
                values = np.asarray(channel_values[-8192:], dtype=np.float32).copy()
                valid = np.isfinite(values)
                output.append((f"{item_id}:v{channel}", values, valid))
        if not output:
            raise RuntimeError(f"No TIME test input contexts for {name}/{term}")
        return output

    def _build_local(self, rank, world):
        local = []
        global_position = 0
        crop_lengths = (8192, 6144, 4096, 3072, 2048)
        for config_index, ((name, term), quota) in enumerate(CONFIG_QUOTAS.items()):
            contexts = self._contexts(name, term)
            rng = random.Random(self.seed + 1009 * config_index)
            rng.shuffle(contexts)
            for view_index in range(quota):
                if global_position % world == rank:
                    item_id, values, valid = contexts[view_index % len(contexts)]
                    requested = crop_lengths[(view_index // len(contexts)) % len(crop_lengths)]
                    width = min(len(values), requested)
                    local.append(
                        (name, term, item_id, view_index, values[-width:], valid[-width:])
                    )
                global_position += 1
        random.Random(self.seed + 7919 * rank).shuffle(local)
        return local

    def __iter__(self):
        rank = int(os.getenv("RANK", "0"))
        world = int(os.getenv("WORLD_SIZE", "1"))
        batch = []
        for name, term, item_id, view_index, values, valid in self._build_local(rank, world):
            target, mask = _pad(values, valid)
            digest = hashlib.sha1(
                f"{name}|{term}|{item_id}|{view_index}".encode()
            ).hexdigest()[:24]
            batch.append(
                {
                    "target": target,
                    "target_mask": mask,
                    "sequence_length": min(len(values), 8192),
                    "source_type": 4,
                    "source_dataset": name,
                    "source_term": term,
                    "target_category": f"time_transductive_{digest}",
                }
            )
            if len(batch) == self.batch_size:
                yield self._collate(batch)
                batch = []
        if batch:
            yield self._collate(batch)

    @staticmethod
    def _collate(rows):
        return {
            "target": torch.as_tensor(
                np.stack([row["target"] for row in rows]), dtype=torch.float32
            ),
            "target_mask": torch.as_tensor(
                np.stack([row["target_mask"] for row in rows]), dtype=torch.float32
            ),
            "sequence_length": torch.as_tensor(
                [row["sequence_length"] for row in rows]
            ),
            "source_type": torch.as_tensor(
                [row["source_type"] for row in rows], dtype=torch.uint8
            ),
            "source_dataset": [row["source_dataset"] for row in rows],
            "source_term": [row["source_term"] for row in rows],
            "target_category": [row["target_category"] for row in rows],
        }


def create_tail_dataset(**kwargs):
    return TIMETestContextTargeted200K(**kwargs)


def create_toto2_cpm_pretraining_dataset(**kwargs):
    kwargs = dict(kwargs)
    kwargs["sequence_length"] = kwargs.pop("max_sequence_length")
    kwargs["num_samples"] = TOTAL
    return TIMETestContextTargeted200K(**kwargs)
