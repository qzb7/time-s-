#!/usr/bin/env python3
"""Generate aligned Toto-2 patch assets and CLIP embeddings.

One loader row is one 8192-point Toto-2 sample.  Each row is split into
exactly 256 non-overlapping 32-point patches.  For every patch this script
saves the raw text description, the RGB chart (raw/diff-1/diff-2), and the
CLIP text/image embeddings in patch order.

The loader is imported from the remote Toto-2 repository at runtime so that
the 70/30 pretrain/GIFT-Eval mix and padding behavior remain unchanged.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
import time
from pathlib import Path

import numpy as np
import torch
from PIL import Image, ImageDraw


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser()
    p.add_argument("--data_dir", default="/data/GIFTEvalPretrain")
    p.add_argument("--gift_eval_path", default="/data/GIFTEval")
    p.add_argument("--gift_eval_src", default="/home/chronos-forecasting-main/gift-eval/src")
    p.add_argument("--output_dir", default="/home/toto-main/data/toto2_clip_patch_10k")
    p.add_argument("--num_samples", type=int, default=10000)
    p.add_argument("--batch_size", type=int, default=64)
    p.add_argument("--patch_size", type=int, default=32)
    p.add_argument("--sequence_length", type=int, default=8192)
    p.add_argument("--clip_model", default="ViT-B/32")
    p.add_argument("--qwen_model", default="/home/Qwen3-VL-8B-Instruct")
    p.add_argument("--qwen_batch_size", type=int, default=4)
    p.add_argument("--qwen_max_new_tokens", type=int, default=128)
    p.add_argument("--sample_pool_size", type=int, default=61440)
    p.add_argument("--samples_per_arrow", type=int, default=512)
    p.add_argument("--samples_per_dataset_block", type=int, default=256)
    p.add_argument("--arrow_row_chunk_size", type=int, default=4096)
    p.add_argument("--windows_per_series", type=int, default=16)
    p.add_argument("--prefetch_pools", type=int, default=16)
    p.add_argument("--arrow_cache_size", type=int, default=1024)
    p.add_argument("--log_interval", type=int, default=100)
    p.add_argument("--seed", type=int, default=5252)
    p.add_argument("--save_images", type=int, default=1)
    p.add_argument("--save_text", type=int, default=1)
    return p.parse_args()


def setup_paths() -> None:
    for path in ("/home/toto-main", "/home/chronos-forecasting-main"):
        if path not in sys.path:
            sys.path.insert(0, path)


def finite_mask(values: np.ndarray) -> np.ndarray:
    return np.isfinite(values)


def robust_uint8(values: np.ndarray, valid: np.ndarray) -> np.ndarray:
    out = np.zeros(values.shape, dtype=np.uint8)
    good = valid & np.isfinite(values)
    if not good.any():
        return out
    finite = values[good].astype(np.float32)
    lo, hi = np.percentile(finite, [1.0, 99.0])
    if hi <= lo:
        lo, hi = float(finite.min()), float(finite.max())
    span = max(hi - lo, 1e-6)
    scaled = np.clip((values - lo) / span, 0.0, 1.0) * 255.0
    out[good] = scaled[good].astype(np.uint8)
    return out


def compute_global_differences(values: np.ndarray, valid: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """Compute differences on the complete 8192-point sequence before slicing."""
    values = values.astype(np.float32, copy=False)
    valid = valid & np.isfinite(values)
    diff1 = np.full_like(values, np.nan)
    diff2 = np.full_like(values, np.nan)
    if len(values) > 1:
        ok = valid[1:] & valid[:-1]
        diff1[1:][ok] = values[1:][ok] - values[:-1][ok]
    if len(values) > 2:
        ok = valid[2:] & valid[1:-1] & valid[:-2]
        diff2[2:][ok] = values[2:][ok] - values[:-2][ok]
    return diff1, diff2


def make_patch_image(
    raw: np.ndarray,
    valid: np.ndarray,
    diff1: np.ndarray,
    diff2: np.ndarray,
) -> Image.Image:
    """Render raw/diff-1/diff-2 as red/green/blue curves on white."""
    raw = raw.astype(np.float32, copy=False)
    raw_valid = valid & np.isfinite(raw)
    values = (raw, diff1, diff2)
    masks = (raw_valid, np.isfinite(diff1), np.isfinite(diff2))
    width, height = 224, 224
    canvas = Image.new("RGB", (width, height), "white")
    draw = ImageDraw.Draw(canvas)
    colors = ((220, 40, 40), (35, 150, 70), (40, 90, 210))
    for channel_values, channel_valid, color in zip(values, masks, colors):
        scaled = robust_uint8(channel_values, channel_valid)
        last = None
        for i, value in enumerate(scaled):
            ok = bool(channel_valid[i])
            if not ok:
                last = None
                continue
            x = int(i * (width - 1) / max(len(raw) - 1, 1))
            y = int((height - 1) - int(value) * (height - 1) / 255)
            point = (x, y)
            if last is not None:
                draw.line((last, point), fill=color, width=2)
            draw.point(point, fill=color)
            last = point
    return canvas


def make_patch_channel_images(raw, valid, diff1, diff2):
    """Vectorized 224x224 CHW uint8 rasterization with independent RGB channels."""
    values = (np.asarray(raw, dtype=np.float32), np.asarray(diff1, dtype=np.float32), np.asarray(diff2, dtype=np.float32))
    masks = (np.asarray(valid, dtype=bool) & np.isfinite(values[0]), np.isfinite(values[1]), np.isfinite(values[2]))
    colors = np.asarray(((220, 40, 40), (35, 150, 70), (40, 90, 210)), dtype=np.uint8)
    h = w = 224
    canvas = np.full((3, h, w), 255, dtype=np.uint8)
    for c, (v, ok) in enumerate(zip(values, masks)):
        idx = np.flatnonzero(ok)
        if idx.size == 0:
            continue
        scaled = robust_uint8(v, ok).astype(np.float32)
        xp = idx.astype(np.float32) * (w - 1) / max(len(v) - 1, 1)
        yp = (h - 1) - scaled[idx] * (h - 1) / 255.0
        breaks = np.flatnonzero(np.diff(idx) > 1) + 1
        for run in np.split(np.arange(idx.size), breaks):
            if run.size == 0:
                continue
            x0 = int(np.ceil(xp[run[0]]))
            x1 = int(np.floor(xp[run[-1]]))
            if x1 >= x0:
                xx = np.arange(max(0, x0), min(w - 1, x1) + 1, dtype=np.float32)
                yy = np.clip(np.rint(np.interp(xx, xp[run], yp[run])).astype(np.int32), 0, h - 1)
                xx = xx.astype(np.int32)
                canvas[c, yy, xx] = colors[c, c]
                canvas[c, np.clip(yy - 1, 0, h - 1), xx] = colors[c, c]
                canvas[c, np.clip(yy + 1, 0, h - 1), xx] = colors[c, c]
            points = np.clip(np.rint(xp[run]).astype(np.int32), 0, w - 1)
            py = np.clip(np.rint(yp[run]).astype(np.int32), 0, h - 1)
            canvas[c, py, points] = colors[c, c]
    return canvas

def value_text(values: np.ndarray, valid: np.ndarray) -> str:
    result = []
    for value, ok in zip(values, valid):
        if not ok or not np.isfinite(value):
            result.append("<MISSING>")
        else:
            result.append(f"{float(value):.6g}")
    return "[" + ", ".join(result) + "]"


def build_text_prompt(patch_index: int, start: int, raw: np.ndarray, valid: np.ndarray) -> str:
    missing = [int(not ok) for ok in valid]
    padding = [0] * len(valid)
    return f"""You are given one local patch from a long time series.

The complete time series contains 8192 observations and is divided into
non-overlapping patches of length 32.

Current patch information:
- Patch index: {patch_index}
- Global interval: [{start}, {start + len(raw)})
- Patch length: {len(raw)}

The raw values of the current patch are:
{value_text(raw, valid)}

Each value has one of the following meanings:
- A numeric value: an observed value
- <MISSING>: an internal observation is missing
- <PAD>: the position is outside the original series and was added only for padding

Validity mask:
{json.dumps(valid.astype(int).tolist())}

Missing mask:
{json.dumps(missing)}

Padding mask:
{json.dumps(padding)}

Question:
Based only on the raw values in this patch, describe its local temporal behavior.

Focus on:
1. The approximate level and value range.
2. Whether the values are increasing, decreasing, stable, or changing direction.
3. Local fluctuations, peaks, valleys, and abrupt changes.
4. Whether the patch contains a smooth or irregular pattern.
5. The location and extent of missing observations.
6. Whether padding affects the reliability of the description.

Do not use image information.
Do not use first-order or second-order differences.
Do not invent values for <MISSING> or <PAD>.
Do not interpret <PAD> as a real zero or constant value.
Do not make claims about periodicity unless clearly supported by the 32 values.

Return only a JSON object with exactly these fields:
{{
  "local_description": "...",
  "level_pattern": "...",
  "trend_pattern": "...",
  "fluctuation_pattern": "...",
  "missingness_pattern": "...",
  "valid_fraction": 0.0,
  "confidence": "high/medium/low"
}}"""


def sample_id(values: np.ndarray, rank: int, index: int) -> str:
    h = hashlib.sha1(values.astype(np.float32, copy=False).tobytes()).hexdigest()[:16]
    return f"sample-r{rank:02d}-{index:08d}-{h}"


def qwen_descriptions(model, processor, prompts: list[str], device: torch.device, max_new_tokens: int) -> list[str]:
    chat_prompts = []
    for prompt in prompts:
        messages = [{"role": "user", "content": [{"type": "text", "text": prompt}]}]
        chat_prompts.append(
            processor.apply_chat_template(
                messages,
                tokenize=False,
                add_generation_prompt=True,
            )
        )
    inputs = processor(text=chat_prompts, padding=True, return_tensors="pt")
    inputs = {k: v.to(device) if torch.is_tensor(v) else v for k, v in inputs.items()}
    with torch.inference_mode():
        generated = model.generate(**inputs, max_new_tokens=max_new_tokens, do_sample=False)
    prompt_len = inputs["input_ids"].shape[1]
    outputs = generated[:, prompt_len:]
    return processor.batch_decode(outputs, skip_special_tokens=True)


def main() -> None:
    args = parse_args()
    if args.sequence_length != 8192 or args.patch_size != 32:
        raise ValueError("This pipeline requires sequence_length=8192 and patch_size=32.")
    setup_paths()
    rank = int(os.environ.get("RANK", "0"))
    world = int(os.environ.get("WORLD_SIZE", "1"))
    local_rank = int(os.environ.get("LOCAL_RANK", "0"))
    device = torch.device("cuda", local_rank if torch.cuda.is_available() else "cpu")
    if device.type == "cuda":
        torch.cuda.set_device(device)

    from load_gifteval_toto2_cpm_pretrain import create_toto2_cpm_pretraining_dataset
    import clip
    from transformers import AutoProcessor, Qwen3VLForConditionalGeneration

    clip_model, clip_preprocess = clip.load(args.clip_model, device=device, jit=False)
    clip_model.eval()
    qwen = Qwen3VLForConditionalGeneration.from_pretrained(
        args.qwen_model, torch_dtype=torch.float16, device_map={"": device}
    ).eval()
    processor = AutoProcessor.from_pretrained(args.qwen_model)
    # Qwen is decoder-only; left padding is required for batched generation.
    if hasattr(processor, "tokenizer"):
        processor.tokenizer.padding_side = "left"
    dataset = create_toto2_cpm_pretraining_dataset(
        data_dir=args.data_dir,
        gift_eval_path=args.gift_eval_path,
        gift_eval_src=args.gift_eval_src,
        batch_size=args.batch_size,
        patch_size=args.patch_size,
        max_sequence_length=args.sequence_length,
        gradient_accumulation_steps=1,
        start_optimizer_step=0,
        seed=args.seed + rank,
        sample_pool_size=args.sample_pool_size,
        samples_per_arrow=args.samples_per_arrow,
        samples_per_dataset_block=args.samples_per_dataset_block,
        arrow_row_chunk_size=args.arrow_row_chunk_size,
        windows_per_series=args.windows_per_series,
        prefetch_pools=args.prefetch_pools,
        arrow_cache_size=args.arrow_cache_size,
        log_interval=args.log_interval,
    )
    loader = iter(dataset)
    local_target = (args.num_samples + world - 1) // world
    root = Path(args.output_dir) / f"rank-{rank:02d}"
    root.mkdir(parents=True, exist_ok=True)
    done = 0
    start_time = time.time()
    while done < local_target:
        batch = next(loader)
        targets = batch["target"].detach().cpu().numpy()
        masks = batch["target_mask"].detach().cpu().numpy().astype(bool)
        for row, mask in zip(targets, masks):
            if done >= local_target:
                break
            sid = sample_id(row, rank, done)
            sample_dir = root / sid
            sample_dir.mkdir(parents=True, exist_ok=False)
            diff1_full, diff2_full = compute_global_differences(row, mask)
            patch_texts = []
            patch_images = []
            for patch_index in range(args.sequence_length // args.patch_size):
                left = patch_index * args.patch_size
                right = left + args.patch_size
                raw = row[left:right].astype(np.float32, copy=True)
                valid = mask[left:right] & np.isfinite(raw)
                patch_texts.append(build_text_prompt(patch_index, left, raw, valid))
                patch_images.append(make_patch_image(raw, valid, diff1_full[left:right], diff2_full[left:right]))

            descriptions = []
            for left in range(0, len(patch_texts), args.qwen_batch_size):
                descriptions.extend(qwen_descriptions(qwen, processor, patch_texts[left:left + args.qwen_batch_size], device, args.qwen_max_new_tokens))

            image_features = []
            text_features = []
            with torch.inference_mode():
                for left in range(0, len(patch_images), args.qwen_batch_size):
                    ims = torch.stack([clip_preprocess(im) for im in patch_images[left:left + args.qwen_batch_size]]).to(device)
                    image_features.append(clip_model.encode_image(ims).float().cpu())
                    toks = clip.tokenize(descriptions[left:left + args.qwen_batch_size], truncate=True).to(device)
                    text_features.append(clip_model.encode_text(toks).float().cpu())
            image_features = torch.cat(image_features).numpy()
            text_features = torch.cat(text_features).numpy()

            image_norm = image_features / np.maximum(np.linalg.norm(image_features, axis=-1, keepdims=True), 1e-8)
            text_norm = text_features / np.maximum(np.linalg.norm(text_features, axis=-1, keepdims=True), 1e-8)
            np.savez_compressed(
                sample_dir / "patch_clip_embeddings.npz",
                image_global=image_features,
                text_global=text_features,
                image_global_normalized=image_norm,
                text_global_normalized=text_norm,
            )
            metadata = {
                "sample_id": sid,
                "sequence_length": args.sequence_length,
                "patch_size": args.patch_size,
                "num_patches": args.sequence_length // args.patch_size,
                "patch_order": "ascending_global_start",
                "global_start": list(range(0, args.sequence_length, args.patch_size)),
                "valid_fraction": [float(mask[left:left + args.patch_size].mean()) for left in range(0, args.sequence_length, args.patch_size)],
                "source_mix": "70% GIFTEvalPretrain / 30% GIFT-Eval training_dataset",
                "clip_model": args.clip_model,
                "qwen_model": args.qwen_model,
            }
            (sample_dir / "metadata.json").write_text(json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8")
            if args.save_text:
                text_dir = sample_dir / "text"
                text_dir.mkdir()
                for i, (prompt, description) in enumerate(zip(patch_texts, descriptions)):
                    (text_dir / f"patch-{i:04d}.prompt.txt").write_text(prompt, encoding="utf-8")
                    (text_dir / f"patch-{i:04d}.description.txt").write_text(description, encoding="utf-8")
            if args.save_images:
                image_dir = sample_dir / "image"
                image_dir.mkdir()
                for i, image in enumerate(patch_images):
                    image.save(image_dir / f"patch-{i:04d}.png")
            done += 1
            if done % args.log_interval == 0 or done == 1:
                elapsed = max(time.time() - start_time, 1e-6)
                print(f"clip-extract rank={rank} samples={done}/{local_target} global_est={min(args.num_samples, done * world)} rate={done / elapsed:.3f} samples/s patches={done * 256}", flush=True)

    elapsed = max(time.time() - start_time, 1e-6)
    print(f"DONE rank={rank} samples={done} elapsed={elapsed:.1f}s rate={done / elapsed:.3f} samples/s", flush=True)


if __name__ == "__main__":
    main()
