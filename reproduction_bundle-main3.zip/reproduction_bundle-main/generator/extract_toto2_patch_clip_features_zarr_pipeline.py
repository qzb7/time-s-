#!/usr/bin/env python3
"""Pipelined Toto-2 multimodal feature extraction directly into rank Zarr stores."""

from __future__ import annotations

import argparse
from collections import deque
from concurrent.futures import ProcessPoolExecutor, ThreadPoolExecutor
import json
import multiprocessing as mp
import os
from pathlib import Path
import shutil
import sys
import time

import numpy as np
import torch
import zarr
from numcodecs import Blosc
from tqdm import tqdm


SCRIPT_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPT_DIR))


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--data_dir", default="/public_data/GIFTEvalPretrain")
    parser.add_argument("--gift_eval_path", default="/public_data/GIFTEval")
    parser.add_argument("--gift_eval_src", default="/home/chronos-forecasting-main/gift-eval/src")
    parser.add_argument("--output_dir", required=True)
    parser.add_argument("--num_samples", type=int, required=True)
    parser.add_argument("--start_block", type=int, default=0)
    parser.add_argument("--block_size", type=int, default=100000)
    parser.add_argument("--batch_size", type=int, default=64)
    parser.add_argument("--sample_group_size", type=int, default=64)
    parser.add_argument("--patch_size", type=int, default=32)
    parser.add_argument("--sequence_length", type=int, default=8192)
    parser.add_argument("--clip_model", default="ViT-B/32")
    parser.add_argument("--clip_checkpoint", required=True)
    parser.add_argument("--clip_batch_size", type=int, default=8192)
    parser.add_argument("--workers", type=int, default=16)
    parser.add_argument("--prefetch_groups", type=int, default=2)
    parser.add_argument("--zarr_write_batch_size", type=int, default=64)
    parser.add_argument("--sample_pool_size", type=int, default=61440)
    parser.add_argument("--samples_per_arrow", type=int, default=512)
    parser.add_argument("--samples_per_dataset_block", type=int, default=128)
    parser.add_argument("--arrow_row_chunk_size", type=int, default=4096)
    parser.add_argument("--windows_per_series", type=int, default=16)
    parser.add_argument("--prefetch_pools", type=int, default=32)
    parser.add_argument("--arrow_cache_size", type=int, default=512)
    parser.add_argument("--log_interval", type=int, default=1)
    parser.add_argument("--seed", type=int, default=20260806)
    return parser.parse_args()


def _warm_worker(value: int) -> int:
    return value


def _describe_row_worker(payload):
    """Generate all 256 local descriptions for one sample in one worker."""
    from toto2_stats_template import describe_patch

    row, mask, sequence_length, patch_size = payload
    row = np.asarray(row, dtype=np.float32)
    mask = np.asarray(mask, dtype=bool)
    padding = np.arange(len(row)) < len(row) - int(sequence_length)
    descriptions = []
    padding_flags = []
    for start in range(0, len(row), patch_size):
        stop = start + patch_size
        raw = row[start:stop]
        pad = padding[start:stop]
        valid = mask[start:stop] & np.isfinite(raw) & ~pad
        descriptions.append(describe_patch(raw, valid, pad, None, start=start))
        padding_flags.append(bool(pad.any()))
    return descriptions, np.asarray(padding_flags, dtype=bool)


def _compute_differences(rows: np.ndarray, masks: np.ndarray):
    finite = masks & np.isfinite(rows)
    diff1 = np.full_like(rows, np.nan, dtype=np.float32)
    diff2 = np.full_like(rows, np.nan, dtype=np.float32)
    ok1 = finite[:, 1:] & finite[:, :-1]
    ok2 = finite[:, 2:] & finite[:, 1:-1] & finite[:, :-2]
    delta1 = rows[:, 1:] - rows[:, :-1]
    delta2 = rows[:, 2:] - rows[:, :-2]
    diff1[:, 1:][ok1] = delta1[ok1]
    diff2[:, 2:][ok2] = delta2[ok2]
    return diff1, diff2


def _masked_quantile(sorted_values: torch.Tensor, counts: torch.Tensor, q: float):
    position = (counts.clamp_min(1).to(torch.float32) - 1.0) * q
    lower = position.floor().to(torch.long)
    upper = position.ceil().to(torch.long)
    weight = position - lower.to(position.dtype)
    lo = sorted_values.gather(-1, lower.unsqueeze(-1)).squeeze(-1)
    hi = sorted_values.gather(-1, upper.unsqueeze(-1)).squeeze(-1)
    return lo + (hi - lo) * weight


def render_patch_images_gpu(
    raw: torch.Tensor,
    raw_valid: torch.Tensor,
    diff1: torch.Tensor,
    diff2: torch.Tensor,
):
    """Rasterize raw/diff1/diff2 curves in parallel on the GPU."""
    values = torch.stack((raw, diff1, diff2), dim=1)
    valid = torch.stack((raw_valid, torch.isfinite(diff1), torch.isfinite(diff2)), dim=1)
    safe_values = torch.where(valid, values, torch.full_like(values, float("inf")))
    sorted_values = torch.sort(safe_values, dim=-1).values
    counts = valid.sum(dim=-1)
    q01 = _masked_quantile(sorted_values, counts, 0.01)
    q99 = _masked_quantile(sorted_values, counts, 0.99)
    minimum = sorted_values[..., 0]
    maximum_index = (counts.clamp_min(1) - 1).unsqueeze(-1)
    maximum = sorted_values.gather(-1, maximum_index).squeeze(-1)
    use_range = q99 <= q01
    lower = torch.where(use_range, minimum, q01)
    upper = torch.where(use_range, maximum, q99)
    lower = torch.where(counts > 0, lower, torch.zeros_like(lower))
    upper = torch.where(counts > 0, upper, torch.ones_like(upper))
    span = (upper - lower).clamp_min(1e-6)
    scaled = ((values - lower.unsqueeze(-1)) / span.unsqueeze(-1)).clamp_(0.0, 1.0)
    scaled = torch.where(valid, scaled, torch.zeros_like(scaled))

    batch, channels, length = values.shape
    height = width = 224
    canvas = torch.full(
        (batch, channels, height, width), 255, dtype=torch.uint8, device=values.device
    )
    x_float = torch.arange(width, device=values.device, dtype=torch.float32)
    x_float = x_float * (length - 1) / (width - 1)
    left = x_float.floor().to(torch.long)
    right = x_float.ceil().to(torch.long).clamp_max(length - 1)
    alpha = (x_float - left.to(torch.float32)).view(1, 1, width)
    y_value = scaled[..., left] * (1.0 - alpha) + scaled[..., right] * alpha
    y_index = torch.round((height - 1) * (1.0 - y_value)).to(torch.long)
    line_valid = valid[..., left] & valid[..., right]
    colors = torch.tensor((220, 150, 210), dtype=torch.uint8, device=values.device)

    b_idx, c_idx, x_idx = line_valid.nonzero(as_tuple=True)
    if b_idx.numel():
        y_idx = y_index[b_idx, c_idx, x_idx]
        for offset in (-1, 0, 1):
            canvas[b_idx, c_idx, (y_idx + offset).clamp(0, height - 1), x_idx] = colors[c_idx]

    point_x = torch.round(
        torch.arange(length, device=values.device, dtype=torch.float32)
        * (width - 1)
        / max(length - 1, 1)
    ).to(torch.long)
    point_y = torch.round((height - 1) * (1.0 - scaled)).to(torch.long)
    b_idx, c_idx, p_idx = valid.nonzero(as_tuple=True)
    if b_idx.numel():
        canvas[b_idx, c_idx, point_y[b_idx, c_idx, p_idx], point_x[p_idx]] = colors[c_idx]
    return canvas


def _scaled_fp16(values: np.ndarray):
    values = np.asarray(values, dtype=np.float32)
    scale = np.max(np.abs(values), axis=-1, keepdims=True)
    scale = np.where(np.isfinite(scale) & (scale > 1e-12), scale, 1.0).astype(np.float32)
    normalized = np.nan_to_num(values / scale, nan=0.0, posinf=0.0, neginf=0.0)
    return normalized.astype(np.float16), scale


class BatchedRankWriter:
    def __init__(self, store: Path, chunk_size: int):
        self.store = store
        self.chunk_size = chunk_size
        self.group = None
        self.arrays = {}
        self.count = 0

    def _initialize(self, batch):
        if self.store.exists():
            shutil.rmtree(self.store)
        self.store.parent.mkdir(parents=True, exist_ok=True)
        self.group = zarr.open_group(str(self.store), mode="w")
        image = batch["image_global"]
        text = batch["text_global"]
        time_values = batch["time_series_8192"]
        specs = {
            "time_series_8192": (time_values.shape[1:], "f4"),
            "target_mask_8192": (batch["target_mask_8192"].shape[1:], "u1"),
            "padding_mask_8192": (batch["padding_mask_8192"].shape[1:], "u1"),
            "image_global_fp16": (image.shape[1:], "f2"),
            "image_scale": (image.shape[1:-1] + (1,), "f4"),
            "text_global_fp16": (text.shape[1:], "f2"),
            "text_scale": (text.shape[1:-1] + (1,), "f4"),
            "sequence_length": ((), "i8"),
            "source_type": ((), "u1"),
            "source_dataset": ((), "S128"),
            "source_term": ((), "S16"),
        }
        compressor = Blosc(cname="zstd", clevel=5, shuffle=Blosc.BITSHUFFLE)
        for name, (shape, dtype) in specs.items():
            self.arrays[name] = self.group.create_dataset(
                name,
                shape=(0,) + shape,
                chunks=(self.chunk_size,) + shape if shape else (self.chunk_size,),
                dtype=dtype,
                compressor=compressor,
                overwrite=True,
            )
        self.group.attrs.update({
            "format": "toto2_multimodal_zarr_fp16_scaled_pipeline_v2",
            "token_dtype": "float16",
            "token_scale_dtype": "float32",
            "time_series_dtype": "float32",
            "mask_dtype": "uint8",
            "token_scale_axis": "per_patch_max_abs",
            "chunk_size": self.chunk_size,
            "source_type_encoding": "0=GIFTEvalPretrain,1=GIFT-Eval training_dataset,255=unknown",
            "source_string_encoding": "utf-8 fixed-width bytes",
        })

    def append_batch(self, batch):
        if self.group is None:
            self._initialize(batch)
        image, image_scale = _scaled_fp16(batch["image_global"])
        text, text_scale = _scaled_fp16(batch["text_global"])
        values = {
            "time_series_8192": np.asarray(batch["time_series_8192"], dtype=np.float32),
            "target_mask_8192": np.asarray(batch["target_mask_8192"], dtype=np.uint8),
            "padding_mask_8192": np.asarray(batch["padding_mask_8192"], dtype=np.uint8),
            "image_global_fp16": image,
            "image_scale": image_scale,
            "text_global_fp16": text,
            "text_scale": text_scale,
            "sequence_length": np.asarray(batch["sequence_length"], dtype=np.int64),
            "source_type": np.asarray(batch["source_type"], dtype=np.uint8),
            "source_dataset": np.asarray(batch["source_dataset"], dtype="S128"),
            "source_term": np.asarray(batch["source_term"], dtype="S16"),
        }
        batch_size = len(values["sequence_length"])
        start, stop = self.count, self.count + batch_size
        for array in self.arrays.values():
            array.resize((stop,) + array.shape[1:])
        for name, value in values.items():
            self.arrays[name][start:stop] = value
        self.count = stop

    def close(self):
        if self.group is not None:
            self.group.attrs["written_count"] = self.count
            metadata_path = self.store.parent / f"{self.store.name}.metadata.jsonl"
            metadata_path.write_text(
                json.dumps({"written_count": self.count, "pipeline": "v2"}) + "\n",
                encoding="utf-8",
            )


class RotatingRankWriter:
    """Rotate only the output store; keep the loader, workers and CLIP process alive."""

    def __init__(self, rank_root: Path, rank: int, start_block: int, block_size: int, world: int, chunk_size: int):
        self.rank_root = rank_root
        self.rank = rank
        self.block_index = start_block
        self.block_size = block_size
        self.local_block_size = (block_size + world - 1) // world
        self.chunk_size = chunk_size
        self.writer = None
        self.count_in_block = 0

    def _open(self):
        store = self.rank_root / f"block-{self.block_index:06d}.rank-{self.rank:02d}.zarr"
        self.writer = BatchedRankWriter(store, self.chunk_size)
        self.count_in_block = 0
        print(f"OPEN rank={self.rank} block={self.block_index:06d}", flush=True)

    @staticmethod
    def _slice(batch, left, right):
        return {key: value[left:right] for key, value in batch.items()}

    def append_batch(self, batch):
        left = 0
        batch_size = len(batch["sequence_length"])
        while left < batch_size:
            if self.writer is None:
                self._open()
            room = self.local_block_size - self.count_in_block
            take = min(room, batch_size - left)
            self.writer.append_batch(self._slice(batch, left, left + take))
            self.count_in_block += take
            left += take
            if self.count_in_block >= self.local_block_size:
                self.writer.close()
                print(
                    f"CLOSE rank={self.rank} block={self.block_index:06d} samples={self.count_in_block}",
                    flush=True,
                )
                self.writer = None
                self.block_index += 1
                self.count_in_block = 0

    def close(self):
        if self.writer is not None:
            self.writer.close()
            self.writer = None


def _setup_paths():
    for path in ("/home/toto-main", "/home/chronos-forecasting-main"):
        if path not in sys.path:
            sys.path.insert(0, path)


def main():
    args = parse_args()
    if args.sequence_length != 8192 or args.patch_size != 32:
        raise ValueError("pipeline_v2 currently requires sequence_length=8192 and patch_size=32")
    _setup_paths()
    rank = int(os.environ.get("RANK", "0"))
    world = int(os.environ.get("WORLD_SIZE", "1"))
    local_rank = int(os.environ.get("LOCAL_RANK", "0"))
    local_target = (args.num_samples + world - 1) // world

    context = mp.get_context("fork")
    stats_executor = ProcessPoolExecutor(max_workers=args.workers, mp_context=context)
    list(stats_executor.map(_warm_worker, range(args.workers), chunksize=1))

    device = torch.device("cuda", local_rank)
    torch.cuda.set_device(device)
    import open_clip

    clip_name = args.clip_model.replace("/", "-")
    clip_model, _, _ = open_clip.create_model_and_transforms(
        clip_name, pretrained=args.clip_checkpoint, device=device
    )
    clip_model.eval()
    clip_tokenizer = open_clip.get_tokenizer(clip_name)
    clip_mean = torch.tensor(
        (0.48145466, 0.4578275, 0.40821073), device=device
    ).view(1, 3, 1, 1)
    clip_std = torch.tensor(
        (0.26862954, 0.26130258, 0.27577711), device=device
    ).view(1, 3, 1, 1)

    from load_gifteval_toto2_cpm_pretrain import create_toto2_cpm_pretraining_dataset

    dataset = create_toto2_cpm_pretraining_dataset(
        data_dir=args.data_dir,
        gift_eval_path=args.gift_eval_path,
        gift_eval_src=args.gift_eval_src,
        batch_size=args.batch_size,
        patch_size=args.patch_size,
        max_sequence_length=args.sequence_length,
        gradient_accumulation_steps=1,
        start_optimizer_step=0,
        seed=args.seed + rank,
        sample_pool_size=args.sample_pool_size,
        samples_per_arrow=args.samples_per_arrow,
        samples_per_dataset_block=args.samples_per_dataset_block,
        arrow_row_chunk_size=args.arrow_row_chunk_size,
        windows_per_series=args.windows_per_series,
        prefetch_pools=args.prefetch_pools,
        arrow_cache_size=args.arrow_cache_size,
        log_interval=args.log_interval,
    )
    loader = iter(dataset)
    pending_rows = deque()

    def fetch_group():
        rows = []
        while len(rows) < args.sample_group_size and len(rows) < local_target:
            if not pending_rows:
                batch = next(loader)
                targets = batch["target"].detach().cpu().numpy().astype(np.float32, copy=False)
                masks = batch["target_mask"].detach().cpu().numpy().astype(bool, copy=False)
                lengths = batch["sequence_length"].detach().cpu().numpy().astype(np.int64, copy=False)
                source_types = batch["source_type"].detach().cpu().numpy().astype(np.uint8, copy=False)
                source_datasets = list(batch["source_dataset"])
                source_terms = list(batch["source_term"])
                pending_rows.extend(
                    zip(targets, masks, lengths, source_types, source_datasets, source_terms)
                )
            rows.append(pending_rows.popleft())
        return rows

    rank_root = Path(os.environ.get("ZARR_RANK_ROOT", args.output_dir))
    writer = RotatingRankWriter(
        rank_root=rank_root,
        rank=rank,
        start_block=args.start_block,
        block_size=args.block_size,
        world=world,
        chunk_size=args.zarr_write_batch_size,
    )
    writer_executor = ThreadPoolExecutor(max_workers=1)
    pending_write = None
    padding_text_cache = {}
    padding_image_feature = None
    prepared = deque()

    def submit_group(rows):
        futures = [
            stats_executor.submit(
                _describe_row_worker,
                (row, mask, int(length), args.patch_size),
            )
            for row, mask, length, _source_type, _source_dataset, _source_term in rows
        ]
        return rows, futures

    for _ in range(max(1, args.prefetch_groups)):
        prepared.append(submit_group(fetch_group()))

    done = 0
    started = time.time()
    progress = tqdm(total=local_target, desc=f"pipeline-v2 rank-{rank:02d}", unit="sample")
    try:
        while done < local_target:
            rows, description_futures = prepared.popleft()
            if done + len(rows) > local_target:
                rows = rows[: local_target - done]
                description_futures = description_futures[: len(rows)]
            while len(prepared) < max(1, args.prefetch_groups) and done + sum(len(x[0]) for x in prepared) + len(rows) < local_target:
                prepared.append(submit_group(fetch_group()))

            description_results = [future.result() for future in description_futures]
            descriptions = [text for result in description_results for text in result[0]]
            padding_text_flags = np.concatenate([result[1] for result in description_results])
            row_values = np.stack([item[0] for item in rows]).astype(np.float32, copy=False)
            row_masks = np.stack([item[1] for item in rows]).astype(bool, copy=False)
            lengths = np.asarray([item[2] for item in rows], dtype=np.int64)
            source_types = np.asarray([item[3] for item in rows], dtype=np.uint8)
            source_datasets = np.asarray([item[4] for item in rows], dtype="S128")
            source_terms = np.asarray([item[5] for item in rows], dtype="S16")
            padding = np.arange(args.sequence_length)[None, :] < (args.sequence_length - lengths)[:, None]
            diff1, diff2 = _compute_differences(row_values, row_masks)
            patches = row_values.reshape(-1, args.patch_size)
            valid_patches = (row_masks & ~padding & np.isfinite(row_values)).reshape(-1, args.patch_size)
            diff1_patches = diff1.reshape(-1, args.patch_size)
            diff2_patches = diff2.reshape(-1, args.patch_size)
            full_padding = padding.reshape(-1, args.patch_size).all(axis=-1)
            patch_count = len(patches)
            image_features = np.empty((patch_count, 512), dtype=np.float32)

            with torch.inference_mode():
                encode_indices = np.flatnonzero(~full_padding)
                if padding_image_feature is None and full_padding.any():
                    encode_indices = np.concatenate((encode_indices, np.flatnonzero(full_padding)[:1]))
                for left in range(0, len(encode_indices), args.clip_batch_size):
                    indices = encode_indices[left:left + args.clip_batch_size]
                    raw = torch.from_numpy(patches[indices]).to(device, non_blocking=True)
                    raw_valid = torch.from_numpy(valid_patches[indices]).to(device, non_blocking=True)
                    d1 = torch.from_numpy(diff1_patches[indices]).to(device, non_blocking=True)
                    d2 = torch.from_numpy(diff2_patches[indices]).to(device, non_blocking=True)
                    images = render_patch_images_gpu(raw, raw_valid, d1, d2)
                    images = images.to(torch.float32).div_(255.0)
                    images = (images - clip_mean) / clip_std
                    encoded = clip_model.encode_image(images).float().cpu().numpy()
                    image_features[indices] = encoded
                    for index, feature in zip(indices, encoded):
                        if full_padding[index] and padding_image_feature is None:
                            padding_image_feature = feature.copy()
                if padding_image_feature is not None:
                    image_features[full_padding] = padding_image_feature

                unique_descriptions, inverse = np.unique(np.asarray(descriptions, dtype=object), return_inverse=True)
                unique_features = np.empty((len(unique_descriptions), 512), dtype=np.float32)
                to_encode = []
                for index, description in enumerate(unique_descriptions):
                    is_padding = bool(np.any(padding_text_flags[inverse == index]))
                    cached = padding_text_cache.get(str(description)) if is_padding else None
                    if cached is None:
                        to_encode.append(index)
                    else:
                        unique_features[index] = cached
                for left in range(0, len(to_encode), args.clip_batch_size):
                    indices = to_encode[left:left + args.clip_batch_size]
                    tokens = clip_tokenizer([str(unique_descriptions[index]) for index in indices]).to(
                        device, non_blocking=True
                    )
                    encoded = clip_model.encode_text(tokens).float().cpu().numpy()
                    unique_features[indices] = encoded
                    for index, feature in zip(indices, encoded):
                        if bool(np.any(padding_text_flags[inverse == index])):
                            padding_text_cache[str(unique_descriptions[index])] = feature.copy()
                text_features = unique_features[inverse]

            samples = len(rows)
            image_features = image_features.reshape(samples, -1, 512)
            text_features = text_features.reshape(samples, -1, 512)
            write_batch = {
                "time_series_8192": row_values,
                "target_mask_8192": row_masks,
                "padding_mask_8192": padding,
                "image_global": image_features,
                "text_global": text_features,
                "sequence_length": lengths,
                "source_type": source_types,
                "source_dataset": source_datasets,
                "source_term": source_terms,
            }
            if pending_write is not None:
                pending_write.result()
            pending_write = writer_executor.submit(writer.append_batch, write_batch)
            done += samples
            progress.update(samples)
            elapsed = max(time.time() - started, 1e-6)
            print(
                f"pipeline-v2 rank={rank} samples={done}/{local_target} "
                f"global_est={min(args.num_samples, args.start_block * args.block_size + done * world)} "
                f"unique_text={len(unique_descriptions)}/{len(descriptions)} "
                f"rate={done / elapsed:.4f} samples/s elapsed={elapsed:.1f}s",
                flush=True,
            )
    finally:
        if pending_write is not None:
            pending_write.result()
        writer_executor.shutdown(wait=True)
        writer.close()
        stats_executor.shutdown(wait=True)
        progress.close()
    elapsed = max(time.time() - started, 1e-6)
    print(f"DONE pipeline-v2 rank={rank} samples={done} rate={done / elapsed:.4f}", flush=True)


if __name__ == "__main__":
    main()
