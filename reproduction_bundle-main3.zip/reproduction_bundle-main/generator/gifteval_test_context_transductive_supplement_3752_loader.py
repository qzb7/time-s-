from __future__ import annotations

import hashlib
import os
import random
import sys

import numpy as np
import torch
from torch.utils.data import IterableDataset


# Exact requested quota. Keys are (GIFTEval dataset name, horizon term).
CONFIG_QUOTAS = {
    ("LOOP_SEATTLE/H", "short"): 84,
    ("LOOP_SEATTLE/H", "medium"): 160,
    ("LOOP_SEATTLE/H", "long"): 194,
    ("LOOP_SEATTLE/5T", "short"): 115,
    ("LOOP_SEATTLE/5T", "medium"): 92,
    ("LOOP_SEATTLE/5T", "long"): 47,
    ("LOOP_SEATTLE/D", "short"): 24,
    ("electricity/15T", "short"): 68,
    ("electricity/H", "short"): 109,
    ("electricity/D", "short"): 122,
    ("electricity/W", "short"): 74,
    ("electricity/15T", "medium"): 35,
    ("electricity/15T", "long"): 70,
    ("electricity/H", "medium"): 29,
    ("electricity/H", "long"): 64,
    ("bizitobs_application", "short"): 359,
    ("bizitobs_application", "medium"): 201,
    ("bizitobs_application", "long"): 21,
    ("jena_weather/D", "short"): 312,
    ("jena_weather/10T", "long"): 42,
    ("jena_weather/10T", "short"): 83,
    ("jena_weather/10T", "medium"): 43,
    ("jena_weather/H", "short"): 10,
    ("jena_weather/H", "medium"): 0,
    ("jena_weather/H", "long"): 53,
    ("m4_hourly", "short"): 622,
    ("solar/10T", "short"): 60,
    ("solar/10T", "medium"): 25,
    ("solar/10T", "long"): 159,
    ("us_births/D", "short"): 193,
    ("us_births/M", "short"): 23,
    ("us_births/W", "short"): 107,
    ("solar/H", "short"): 72,
    ("solar/H", "medium"): 31,
    ("solar/H", "long"): 49,
}
TOTAL = sum(CONFIG_QUOTAS.values())
assert TOTAL == 3752


def _pad(values: np.ndarray, width: int = 8192):
    values = np.asarray(values, dtype=np.float32).reshape(-1)
    values[~np.isfinite(values)] = np.nan
    if len(values) > width:
        values = values[-width:]
    target = np.full(width, np.nan, dtype=np.float32)
    mask = np.zeros(width, dtype=np.float32)
    if len(values):
        target[-len(values):] = values
        mask[-len(values):] = np.isfinite(values)
    return target, mask


class GIFTEvalTestContextTransductive105K(IterableDataset):
    """Finite test_data.input-only corpus; future labels are never materialized."""

    def __init__(self, gift_eval_path, gift_eval_src, batch_size, sequence_length,
                 num_samples, seed, **_):
        if int(sequence_length) != 8192:
            raise ValueError("sequence_length must be 8192")
        if int(num_samples) != TOTAL:
            raise ValueError(f"num_samples must be {TOTAL}")
        self.gift_eval_path = str(gift_eval_path)
        self.gift_eval_src = str(gift_eval_src)
        self.batch_size = int(batch_size)
        self.seed = int(seed)

    def _contexts(self, name, term):
        os.environ["GIFT_EVAL"] = self.gift_eval_path
        os.environ["GIFT_EVAL_PATH"] = self.gift_eval_path
        if self.gift_eval_src not in sys.path:
            sys.path.insert(0, self.gift_eval_src)
        from gift_eval.data import Dataset

        # Deliberately access input only. Never iterate or materialize label.
        rows = Dataset(name=name, term=term, to_univariate=False).test_data.input
        seen, output = set(), []
        for row in rows:
            array = np.asarray(row["target"], dtype=np.float32)
            item_id = str(row.get("item_id", ""))
            channels = array if array.ndim > 1 else array.reshape(1, -1)
            for channel, values in enumerate(channels):
                # Crop immediately so long electricity histories do not consume
                # several GB per rank. Every retained value remains inside input.
                values = np.asarray(values[-8192:], dtype=np.float32).copy()
                digest = hashlib.sha1(values.tobytes()).digest()
                key = (item_id, channel, digest)
                if key not in seen:
                    seen.add(key)
                    output.append((f"{item_id}:v{channel}", values))
        if not output:
            raise RuntimeError(f"No test input contexts for {name}/{term}")
        return output

    def _build(self):
        specs = []
        for config_index, ((name, term), quota) in enumerate(CONFIG_QUOTAS.items()):
            contexts = self._contexts(name, term)
            rng = random.Random(self.seed + 1009 * config_index)
            rng.shuffle(contexts)
            for view_index in range(quota):
                item_id, values = contexts[view_index % len(contexts)]
                # Cycle the visible history length without reading beyond input.
                # Short series naturally fall back to their complete history.
                requested = (8192, 4096, 2048)[(view_index // len(contexts)) % 3]
                view = values[-min(len(values), requested):]
                specs.append((name, term, item_id, view_index, view))
        if len(specs) != TOTAL:
            raise RuntimeError(f"Expected {TOTAL} specs, got {len(specs)}")
        random.Random(self.seed).shuffle(specs)
        return specs

    def __iter__(self):
        rank = int(os.getenv("RANK", "0"))
        world = int(os.getenv("WORLD_SIZE", "1"))
        local = self._build()[rank::world]
        batch = []
        for name, term, item_id, view_index, values in local:
            target, mask = _pad(values)
            category = f"{name}|{term}|{item_id}|v{view_index}"
            batch.append({
                "target": target,
                "target_mask": mask,
                "sequence_length": min(len(values), 8192),
                "source_type": 3,
                "source_dataset": name,
                "source_term": term,
                "target_category": category[-32:],
            })
            if len(batch) == self.batch_size:
                yield self._collate(batch)
                batch = []
        if batch:
            yield self._collate(batch)

    @staticmethod
    def _collate(rows):
        return {
            "target": torch.as_tensor(np.stack([x["target"] for x in rows]), dtype=torch.float32),
            "target_mask": torch.as_tensor(np.stack([x["target_mask"] for x in rows]), dtype=torch.float32),
            "sequence_length": torch.as_tensor([x["sequence_length"] for x in rows]),
            "source_type": torch.as_tensor([x["source_type"] for x in rows], dtype=torch.uint8),
            "source_dataset": [x["source_dataset"] for x in rows],
            "source_term": [x["source_term"] for x in rows],
            "target_category": [x["target_category"] for x in rows],
        }


def create_tail_dataset(**kwargs):
    return GIFTEvalTestContextTransductive105K(**kwargs)


def create_toto2_cpm_pretraining_dataset(**kwargs):
    """Adapter for the unmodified 107 latest pipeline loader interface."""
    kwargs = dict(kwargs)
    kwargs["sequence_length"] = kwargs.pop("max_sequence_length")
    kwargs["num_samples"] = TOTAL
    return GIFTEvalTestContextTransductive105K(**kwargs)
