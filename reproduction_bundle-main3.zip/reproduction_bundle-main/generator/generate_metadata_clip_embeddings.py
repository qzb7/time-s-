#!/usr/bin/env python3
"""Build deduplicated CLIP metadata embeddings and aligned Zarr sidecars.

Only stores that already contain source_dataset/source_term/source_type are
included. Missing provenance is never guessed. The saved CLIP vectors are
float16; each source sample receives only an int32 metadata_id sidecar.
"""

from __future__ import annotations

import argparse
import collections
import hashlib
import json
import os
import re
import sys
from pathlib import Path

import numpy as np
import torch
import torch.distributed as dist
import zarr


DEFAULT_ROOTS = [
    "/public_data/.toto2_multimodal_zarr_pipeline_v2_tmp",
    "/public_data/toto2_multimodal_chronos_tail_four_50k",
    "/public_data/toto2_multimodal_gifteval_test_context_29106",
    "/public_data/toto2_multimodal_gifteval_test_context_nonsolar_targeted_400k",
    "/public_data/toto2_multimodal_gifteval_test_context_targeted_276400",
    "/public_data/toto2_multimodal_gifteval_test_context_transductive_105k",
    "/public_data/toto2_multimodal_quota_1m_blocks100k",
    "/public_data/toto2_multimodal_time_eval_history_111177",
    "/public_data/toto2_multimodal_time_test_context_targeted_200k",
]

HORIZON_TERMS = {"short", "medium", "long"}


def atomic_json(path: Path, value) -> None:
    tmp = path.with_suffix(path.suffix + ".partial")
    tmp.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    os.replace(tmp, path)


def decode_bytes(values: np.ndarray) -> np.ndarray:
    return np.char.decode(values, "utf-8") if values.dtype.kind == "S" else values.astype(str)


def discover_stores(root: Path) -> list[Path]:
    stores = list(root.glob("*.zarr"))
    generation = root / "generation"
    if generation.is_dir():
        stores.extend(generation.glob("*.zarr"))
    return sorted(set(p.resolve() for p in stores))


def clean_dataset_name(raw: str) -> str:
    name = raw.strip().replace("\\", "/")
    base = name.rsplit("/", 1)[0] if "/" in name else name
    base = re.sub(r"(?i)_(1h|hourly|daily|weekly|monthly|quarterly|yearly|15min|30min)$", "", base)
    special = {
        "bizitobs": "BizITObs",
        "m4": "M4",
        "ett1": "ETT1",
        "ett2": "ETT2",
        "kdd": "KDD",
        "pm25": "PM2.5",
        "ecdc": "ECDC",
        "cphl": "CPHL",
        "m_dense": "M-Dense",
    }
    words = re.split(r"[_\-]+", base)
    pretty = []
    for word in words:
        low = word.lower()
        pretty.append(special.get(low, word if any(c.isupper() for c in word) else word.capitalize()))
    return " ".join(x for x in pretty if x).strip() or raw.strip()


def infer_domain(raw: str) -> str:
    s = raw.lower()
    rules = [
        ("cloud and system monitoring", ["azure", "bitbrains", "bizitobs", "bdg-2", "cluster", "server", "kdd2022", "metropt"]),
        ("health and medical", ["covid", "flu", "ilinet", "hospital", "birth", "ecdc", "tycho", "health"]),
        ("transport and mobility", ["traffic", "taxi", "uber", "loop_seattle", "subway", "carpark", "pedestrian", "metro", "port_activity", "trajectory"]),
        ("energy and electricity", ["solar", "electric", "energy", "power", "load", "smart_meter", "lcl", "eweld"]),
        ("environment and weather", ["weather", "temperature", "rain", "air_quality", "pm25", "wind", "subseasonal", "oikolab", "water_quality", "coastal", "precip"]),
        ("economy and finance", ["bitcoin", "crypto", "exchange", "finance", "stock", "oil_price", "term_structure", "job_claim", "sales", "restaurant", "favorita", "retail", "price"]),
        ("sensor, activity, and industrial", ["sensor", "activity", "manufact", "machine", "current_velocity", "cockatoo", "pdb", "smart"]),
    ]
    for domain, keywords in rules:
        if any(k in s for k in keywords):
            return domain
    if s.startswith("m4_"):
        return "economy and business"
    return "general time series"


def pretty_frequency(code: str | None) -> str | None:
    if not code:
        return None
    value = code.strip()
    upper = value.upper()
    direct = {
        "H": "hourly",
        "D": "daily",
        "W": "weekly",
        "M": "monthly",
        "Q": "quarterly",
        "Y": "yearly",
        "A": "yearly",
        "B": "business-daily",
        "T": "minutely",
        "MIN": "minutely",
        "S": "every second",
    }
    if upper in direct:
        return direct[upper]
    match = re.fullmatch(r"(\d+)([A-Za-z]+)", value)
    if match:
        amount, unit = int(match.group(1)), match.group(2).upper()
        names = {
            "T": "minutes", "MIN": "minutes", "S": "seconds", "H": "hours",
            "D": "days", "W": "weeks", "M": "months", "Q": "quarters", "Y": "years",
        }
        if unit in names:
            return f"every {amount} {names[unit]}"
    return value


def infer_frequency(raw: str) -> str | None:
    if "/" in raw:
        suffix = raw.rsplit("/", 1)[-1]
        if re.fullmatch(r"\d*(?:T|MIN|S|H|D|W|M|Q|Y|A|B)", suffix, flags=re.I):
            return pretty_frequency(suffix)
    patterns = [
        (r"(?i)(?:_|-)(\d+)min$", lambda m: f"every {int(m.group(1))} minutes"),
        (r"(?i)(?:_|-)(\d+)h$", lambda m: f"every {int(m.group(1))} hours"),
        (r"(?i)_hourly$", lambda m: "hourly"),
        (r"(?i)_daily$", lambda m: "daily"),
        (r"(?i)_weekly$", lambda m: "weekly"),
        (r"(?i)_monthly$", lambda m: "monthly"),
        (r"(?i)_quarterly$", lambda m: "quarterly"),
        (r"(?i)_yearly$", lambda m: "yearly"),
    ]
    for pattern, formatter in patterns:
        match = re.search(pattern, raw)
        if match:
            return formatter(match)
    return None


class GiftResolver:
    def __init__(self, gift_eval_path: str, gift_eval_src: str):
        self.cache: dict[tuple[str, str], tuple[str | None, int | None]] = {}
        os.environ.setdefault("GIFT_EVAL", gift_eval_path)
        sys.path.insert(0, gift_eval_src)
        try:
            from gift_eval.data import Dataset
            self.Dataset = Dataset
        except Exception:
            self.Dataset = None

    def resolve(self, dataset: str, term: str) -> tuple[str | None, int | None]:
        key = (dataset, term)
        if key in self.cache:
            return self.cache[key]
        answer: tuple[str | None, int | None] = (None, None)
        if self.Dataset is not None and term in HORIZON_TERMS:
            try:
                item = self.Dataset(name=dataset, term=term, to_univariate=False)
                answer = (pretty_frequency(str(item.freq)), int(item.prediction_length))
            except Exception:
                pass
        self.cache[key] = answer
        return answer


def build_metadata(dataset: str, term: str, resolver: GiftResolver) -> dict:
    resolved_freq, prediction_length = resolver.resolve(dataset, term)
    metadata = {
        "dataset_name": clean_dataset_name(dataset),
        "domain": infer_domain(dataset),
        "series_type": "univariate time series",
    }
    frequency = resolved_freq or infer_frequency(dataset)
    if frequency:
        metadata["frequency"] = frequency
    if term in HORIZON_TERMS:
        metadata["horizon_type"] = term
        if prediction_length is not None:
            metadata["prediction_length"] = prediction_length
    return metadata


def metadata_text(meta: dict) -> str:
    parts = [
        f"Dataset: {meta['dataset_name']}.",
        f"Domain: {meta['domain']}.",
    ]
    if "frequency" in meta:
        parts.append(f"Sampling frequency: {meta['frequency']}.")
    parts.append(f"Series type: {meta['series_type']}.")
    if "horizon_type" in meta:
        if "prediction_length" in meta:
            parts.append(
                f"Forecast horizon: {meta['horizon_type']}, {meta['prediction_length']} time steps."
            )
        else:
            parts.append(f"Forecast horizon: {meta['horizon_type']}.")
    return " ".join(parts)


def canonical(meta: dict) -> str:
    return json.dumps(meta, sort_keys=True, ensure_ascii=False, separators=(",", ":"))


def scan_plan(roots: list[Path], output: Path, resolver: GiftResolver) -> dict:
    stores = []
    raw_counts: collections.Counter[tuple[str, str, int]] = collections.Counter()
    skipped = []
    for root in roots:
        if not root.is_dir():
            skipped.append({"root": str(root), "reason": "missing_root"})
            continue
        for store in discover_stores(root):
            group = zarr.open_group(str(store), mode="r")
            required = {"source_dataset", "source_term", "source_type"}
            if not required.issubset(group.array_keys()):
                skipped.append({"store": str(store), "reason": "missing_source_fields"})
                continue
            size = len(group["source_dataset"])
            if len(group["source_term"]) != size or len(group["source_type"]) != size:
                raise RuntimeError(f"Misaligned provenance arrays: {store}")
            stores.append({"root": str(root), "store": str(store), "samples": size})
            chunk = 131072
            for left in range(0, size, chunk):
                right = min(size, left + chunk)
                datasets = decode_bytes(np.asarray(group["source_dataset"][left:right]))
                terms = decode_bytes(np.asarray(group["source_term"][left:right]))
                types = np.asarray(group["source_type"][left:right], dtype=np.uint8)
                raw_counts.update((str(d), str(t), int(s)) for d, t, s in zip(datasets, terms, types))

    raw_to_canonical = {}
    canonical_to_meta = {}
    for dataset, term, source_type in sorted(raw_counts):
        meta = build_metadata(dataset, term, resolver)
        key = canonical(meta)
        raw_key = json.dumps([dataset, term, source_type], ensure_ascii=False, separators=(",", ":"))
        raw_to_canonical[raw_key] = key
        canonical_to_meta.setdefault(key, meta)

    sorted_keys = sorted(canonical_to_meta)
    canonical_to_id = {key: index for index, key in enumerate(sorted_keys)}
    registry = []
    for index, key in enumerate(sorted_keys):
        meta = canonical_to_meta[key]
        text = metadata_text(meta)
        registry.append({
            "metadata_id": index,
            "metadata_hash": hashlib.sha256(key.encode("utf-8")).hexdigest(),
            **meta,
            "template_text": text,
            "embedding_row": index,
        })
    raw_to_id = {raw: canonical_to_id[key] for raw, key in raw_to_canonical.items()}
    plan = {
        "version": "metadata_clip_v1",
        "roots": [str(x) for x in roots],
        "stores": stores,
        "skipped": skipped,
        "total_samples": sum(x["samples"] for x in stores),
        "unique_raw_metadata": len(raw_counts),
        "unique_canonical_metadata": len(registry),
        "registry": registry,
        "raw_to_id": raw_to_id,
        "raw_counts": [
            {"source_dataset": d, "source_term": t, "source_type": s, "count": count}
            for (d, t, s), count in sorted(raw_counts.items())
        ],
    }
    atomic_json(output / "generation_plan.json", plan)
    atomic_json(output / "metadata_registry.json", {
        "version": plan["version"],
        "storage_dtype": "float16",
        "embedding_dim": 512,
        "entries": registry,
    })
    return plan


def encode_rank(plan: dict, args, rank: int, world: int, device: torch.device, output: Path) -> None:
    import open_clip

    clip_name = args.clip_model.replace("/", "-")
    model, _, _ = open_clip.create_model_and_transforms(
        clip_name, pretrained=args.clip_checkpoint, device=device
    )
    model.eval()
    tokenizer = open_clip.get_tokenizer(clip_name)
    ids = np.arange(rank, len(plan["registry"]), world, dtype=np.int32)
    result = np.empty((len(ids), 512), dtype=np.float16)
    with torch.inference_mode():
        for left in range(0, len(ids), args.clip_batch_size):
            batch_ids = ids[left:left + args.clip_batch_size]
            texts = [plan["registry"][int(i)]["template_text"] for i in batch_ids]
            tokens = tokenizer(texts).to(device, non_blocking=True)
            encoded = model.encode_text(tokens).float().cpu().numpy()
            result[left:left + len(batch_ids)] = encoded.astype(np.float16)
    rank_path = output / "parts" / f"embeddings-rank-{rank:02d}.npz"
    rank_path.parent.mkdir(parents=True, exist_ok=True)
    np.savez(rank_path, metadata_id=ids, embeddings=result)


def merge_embeddings(plan: dict, output: Path, world: int) -> None:
    final_path = output / "metadata_embeddings.fp16.npy"
    partial = output / "metadata_embeddings.fp16.npy.partial"
    table = np.lib.format.open_memmap(
        partial, mode="w+", dtype=np.float16, shape=(len(plan["registry"]), 512)
    )
    seen = np.zeros(len(plan["registry"]), dtype=bool)
    for rank in range(world):
        part = np.load(output / "parts" / f"embeddings-rank-{rank:02d}.npz")
        ids = part["metadata_id"].astype(np.int64)
        table[ids] = part["embeddings"]
        seen[ids] = True
    table.flush()
    del table
    if not bool(seen.all()):
        raise RuntimeError(f"Missing {int((~seen).sum())} metadata embeddings")
    os.replace(partial, final_path)


def sidecar_path(output: Path, root: str, store: str) -> Path:
    root_path, store_path = Path(root), Path(store)
    relative = store_path.relative_to(root_path)
    alias = root_path.name.lstrip(".")
    return output / "sidecars" / alias / relative.parent / f"{relative.name}.metadata_id.npy"


def write_sidecars(plan: dict, output: Path, rank: int, world: int) -> dict:
    raw_to_id = plan["raw_to_id"]
    completed = []
    for store_index, item in enumerate(plan["stores"]):
        if store_index % world != rank:
            continue
        store = item["store"]
        size = int(item["samples"])
        destination = sidecar_path(output, item["root"], store)
        destination.parent.mkdir(parents=True, exist_ok=True)
        if destination.is_file():
            try:
                existing = np.load(destination, mmap_mode="r")
                if existing.shape == (size,) and existing.dtype == np.int32:
                    completed.append({"store": store, "sidecar": str(destination), "samples": size, "resumed": True})
                    continue
            except Exception:
                pass
        partial = destination.with_suffix(destination.suffix + ".partial")
        ids_out = np.lib.format.open_memmap(partial, mode="w+", dtype=np.int32, shape=(size,))
        group = zarr.open_group(store, mode="r")
        chunk = 131072
        for left in range(0, size, chunk):
            right = min(size, left + chunk)
            datasets = decode_bytes(np.asarray(group["source_dataset"][left:right]))
            terms = decode_bytes(np.asarray(group["source_term"][left:right]))
            types = np.asarray(group["source_type"][left:right], dtype=np.uint8)
            values = np.empty(right - left, dtype=np.int32)
            for i, (dataset, term, source_type) in enumerate(zip(datasets, terms, types)):
                key = json.dumps([str(dataset), str(term), int(source_type)], ensure_ascii=False, separators=(",", ":"))
                values[i] = raw_to_id[key]
            ids_out[left:right] = values
        ids_out.flush()
        del ids_out
        os.replace(partial, destination)
        completed.append({"store": store, "sidecar": str(destination), "samples": size, "resumed": False})
    atomic_json(output / "parts" / f"sidecars-rank-{rank:02d}.json", completed)
    return {"stores": len(completed), "samples": sum(x["samples"] for x in completed)}


def finalize_report(plan: dict, output: Path, world: int, args) -> None:
    completed = []
    for rank in range(world):
        completed.extend(json.loads((output / "parts" / f"sidecars-rank-{rank:02d}.json").read_text()))
    table = np.load(output / "metadata_embeddings.fp16.npy", mmap_mode="r")
    finite = bool(np.isfinite(table).all())
    report = {
        "status": "complete",
        "total_samples": plan["total_samples"],
        "stores": len(plan["stores"]),
        "unique_raw_metadata": plan["unique_raw_metadata"],
        "unique_canonical_metadata": plan["unique_canonical_metadata"],
        "deduplicated_references": plan["total_samples"] - plan["unique_canonical_metadata"],
        "embedding_shape": list(table.shape),
        "embedding_dtype": str(table.dtype),
        "embeddings_all_finite": finite,
        "sidecar_stores": len(completed),
        "sidecar_samples": sum(x["samples"] for x in completed),
        "clip_model": args.clip_model,
        "clip_checkpoint": args.clip_checkpoint,
        "excluded_missing_provenance": plan["skipped"],
    }
    if report["sidecar_samples"] != plan["total_samples"] or not finite:
        report["status"] = "failed_validation"
    atomic_json(output / "validation_report.json", report)
    if report["status"] != "complete":
        raise RuntimeError(json.dumps(report, ensure_ascii=False))
    (output / ".complete").write_text("complete\n", encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", default="/public_data/toto2_metadata_embedding_source_provenance_v2")
    parser.add_argument("--roots", nargs="*", default=DEFAULT_ROOTS)
    parser.add_argument("--clip_model", default="ViT-B/32")
    parser.add_argument("--clip_checkpoint", default="/home/toto2_stats_multimodal_generator_latest/ViT-B-32.pt")
    parser.add_argument("--clip_batch_size", type=int, default=512)
    parser.add_argument("--gift_eval_path", default="/public_data/GIFTEval")
    parser.add_argument("--gift_eval_src", default="/home/chronos-forecasting-main/gift-eval/src")
    args = parser.parse_args()

    rank = int(os.environ.get("RANK", "0"))
    world = int(os.environ.get("WORLD_SIZE", "1"))
    local_rank = int(os.environ.get("LOCAL_RANK", "0"))
    torch.cuda.set_device(local_rank)
    # Ranks only need lightweight barriers; CLIP encoding itself is independent.
    # Gloo avoids allocating large NCCL /dev/shm segments on containerized hosts.
    dist.init_process_group("gloo")
    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)

    if rank == 0:
        resolver = GiftResolver(args.gift_eval_path, args.gift_eval_src)
        plan = scan_plan([Path(x) for x in args.roots], output, resolver)
        print(
            f"SCAN total_samples={plan['total_samples']} stores={len(plan['stores'])} "
            f"raw={plan['unique_raw_metadata']} canonical={plan['unique_canonical_metadata']}",
            flush=True,
        )
    dist.barrier()
    plan = json.loads((output / "generation_plan.json").read_text(encoding="utf-8"))
    device = torch.device("cuda", local_rank)
    encode_rank(plan, args, rank, world, device, output)
    dist.barrier()
    if rank == 0:
        merge_embeddings(plan, output, world)
    dist.barrier()
    stats = write_sidecars(plan, output, rank, world)
    print(f"RANK {rank} sidecars={stats['stores']} samples={stats['samples']}", flush=True)
    dist.barrier()
    if rank == 0:
        finalize_report(plan, output, world, args)
        print(f"COMPLETE output={output}", flush=True)
    dist.barrier()
    dist.destroy_process_group()


if __name__ == "__main__":
    main()
