from __future__ import annotations

import random

from gifteval_test_context_targeted_276400_loader import (
    GIFTEvalTestContextTransductive105K as _BaseDataset,
)


# Non-Solar/H targeted bank chosen from the measured checkpoint-44000 gaps.
CONFIG_QUOTAS = {
    # LOOP Seattle: 90,000
    ("LOOP_SEATTLE/H", "short"): 30_000,
    ("LOOP_SEATTLE/H", "medium"): 35_000,
    ("LOOP_SEATTLE/H", "long"): 25_000,
    # Electricity: 75,000
    ("electricity/W", "short"): 23_000,
    ("electricity/H", "short"): 20_000,
    ("electricity/15T", "short"): 15_000,
    ("electricity/D", "short"): 10_000,
    ("electricity/15T", "medium"): 2_500,
    ("electricity/15T", "long"): 2_500,
    ("electricity/H", "medium"): 2_000,
    # Jena Weather: 50,000
    ("jena_weather/D", "short"): 30_000,
    ("jena_weather/10T", "long"): 10_000,
    ("jena_weather/H", "short"): 4_000,
    ("jena_weather/H", "medium"): 3_000,
    ("jena_weather/H", "long"): 3_000,
    # BizITObs Application: 40,000
    ("bizitobs_application", "short"): 30_000,
    ("bizitobs_application", "medium"): 5_000,
    ("bizitobs_application", "long"): 5_000,
    # ETT: 45,000
    ("ett1/H", "long"): 20_000,
    ("ett1/H", "medium"): 10_000,
    ("ett1/15T", "long"): 5_000,
    ("ett2/W", "short"): 10_000,
    # M4: 30,000
    ("m4_hourly", "short"): 18_000,
    ("m4_yearly", "short"): 6_000,
    ("m4_weekly", "short"): 3_000,
    ("m4_daily", "short"): 1_000,
    ("m4_monthly", "short"): 1_000,
    ("m4_quarterly", "short"): 1_000,
    # BizITObs Service/L2C: 25,000
    ("bizitobs_service", "long"): 12_000,
    ("bizitobs_service", "short"): 4_000,
    ("bizitobs_l2c/5T", "medium"): 3_000,
    ("bizitobs_l2c/5T", "long"): 3_000,
    ("bizitobs_l2c/5T", "short"): 2_000,
    ("bizitobs_l2c/H", "long"): 1_000,
    # Bitbrains: 20,000
    ("bitbrains_fast_storage/5T", "medium"): 8_000,
    ("bitbrains_fast_storage/5T", "long"): 4_000,
    ("bitbrains_fast_storage/5T", "short"): 4_000,
    ("bitbrains_fast_storage/H", "short"): 2_000,
    ("bitbrains_rnd/5T", "medium"): 1_000,
    ("bitbrains_rnd/5T", "long"): 1_000,
    # US Births: 15,000
    ("us_births/M", "short"): 7_000,
    ("us_births/D", "short"): 5_000,
    ("us_births/W", "short"): 3_000,
    # Other protection configs: 10,000
    ("kdd_cup_2018_with_missing/H", "short"): 2_000,
    ("kdd_cup_2018_with_missing/H", "medium"): 2_000,
    ("kdd_cup_2018_with_missing/H", "long"): 2_000,
    ("hierarchical_sales/W", "short"): 2_000,
    ("restaurant", "short"): 1_000,
    ("M_DENSE/H", "short"): 1_000,
}
TOTAL = sum(CONFIG_QUOTAS.values())
assert TOTAL == 400_000


class GIFTEvalNonSolarTargeted400K(_BaseDataset):
    def __init__(
        self,
        gift_eval_path,
        gift_eval_src,
        batch_size,
        sequence_length,
        num_samples,
        seed,
        **_,
    ):
        if int(sequence_length) != 8192:
            raise ValueError("sequence_length must be 8192")
        if int(num_samples) != TOTAL:
            raise ValueError(f"num_samples must be {TOTAL}")
        self.gift_eval_path = str(gift_eval_path)
        self.gift_eval_src = str(gift_eval_src)
        self.batch_size = int(batch_size)
        self.seed = int(seed)

    def _build(self):
        specs = []
        crop_lengths = (8192, 6144, 4096, 3072, 2048)
        for config_index, ((name, term), quota) in enumerate(CONFIG_QUOTAS.items()):
            contexts = self._contexts(name, term)
            rng = random.Random(self.seed + 1009 * config_index)
            rng.shuffle(contexts)
            for view_index in range(quota):
                item_id, values = contexts[view_index % len(contexts)]
                requested = crop_lengths[(view_index // len(contexts)) % len(crop_lengths)]
                view = values[-min(len(values), requested) :]
                specs.append((name, term, item_id, view_index, view))
        if len(specs) != TOTAL:
            raise RuntimeError(f"Expected {TOTAL} specs, got {len(specs)}")
        random.Random(self.seed).shuffle(specs)
        return specs


def create_tail_dataset(**kwargs):
    return GIFTEvalNonSolarTargeted400K(**kwargs)


def create_toto2_cpm_pretraining_dataset(**kwargs):
    kwargs = dict(kwargs)
    kwargs["sequence_length"] = kwargs.pop("max_sequence_length")
    kwargs["num_samples"] = TOTAL
    return GIFTEvalNonSolarTargeted400K(**kwargs)
