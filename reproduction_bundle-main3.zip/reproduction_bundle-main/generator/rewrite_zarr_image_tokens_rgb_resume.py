#!/usr/bin/env python3
"""Resume one partially rewritten Zarr store across multiple GPUs."""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import time

import numpy as np
import torch
import torch.distributed as dist
import zarr
from tqdm import tqdm

from rewrite_zarr_image_tokens_rgb import (
    CLIP_MEAN,
    CLIP_STD,
    compute_differences,
    render_rgb_overlay,
    scaled_fp16,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--store", required=True)
    parser.add_argument("--resume_start", type=int, required=True)
    parser.add_argument("--sample_group_size", type=int, default=128)
    parser.add_argument("--clip_batch_size", type=int, default=16384)
    parser.add_argument("--clip_checkpoint", required=True)
    parser.add_argument("--clip_model", default="ViT-B/32")
    parser.add_argument("--manifest", required=True)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    dist.init_process_group("nccl")
    rank = dist.get_rank()
    world = dist.get_world_size()
    local_rank = int(os.environ.get("LOCAL_RANK", rank))
    device = torch.device("cuda", local_rank)
    torch.cuda.set_device(device)

    if args.resume_start < 0 or args.resume_start % args.sample_group_size:
        raise ValueError("--resume_start must be non-negative and aligned to sample_group_size")

    import open_clip

    clip_name = args.clip_model.replace("/", "-")
    clip_model, _, _ = open_clip.create_model_and_transforms(
        clip_name, pretrained=args.clip_checkpoint, device=device
    )
    clip_model.eval()
    clip_mean = torch.tensor(CLIP_MEAN, device=device).view(1, 3, 1, 1)
    clip_std = torch.tensor(CLIP_STD, device=device).view(1, 3, 1, 1)

    # All arrays already exist. Ranks only write disjoint, chunk-aligned ranges.
    group = zarr.open_group(args.store, mode="r+")
    sample_count = int(group["time_series_8192"].shape[0])
    image_array = group["image_global_fp16"]
    scale_array = group["image_scale"]
    for name in ("target_mask_8192", "padding_mask_8192", "image_global_fp16", "image_scale"):
        if int(group[name].shape[0]) != sample_count:
            raise ValueError(f"sample mismatch: {name}")

    starts = list(range(args.resume_start, sample_count, args.sample_group_size))
    assigned = starts[rank::world]
    assigned_samples = sum(min(sample_count, left + args.sample_group_size) - left for left in assigned)
    progress = tqdm(total=assigned_samples, desc=f"rank{rank} resume {Path(args.store).name}", unit="sample")
    padding_feature = None
    started = time.time()

    for sample_left in assigned:
        sample_right = min(sample_count, sample_left + args.sample_group_size)
        rows = np.asarray(group["time_series_8192"][sample_left:sample_right], dtype=np.float32)
        target_mask = np.asarray(group["target_mask_8192"][sample_left:sample_right], dtype=bool)
        padding_mask = np.asarray(group["padding_mask_8192"][sample_left:sample_right], dtype=bool)
        valid = target_mask & ~padding_mask & np.isfinite(rows)
        diff1, diff2 = compute_differences(rows, valid)

        patches = rows.reshape(-1, 32)
        valid_patches = valid.reshape(-1, 32)
        d1_patches = diff1.reshape(-1, 32)
        d2_patches = diff2.reshape(-1, 32)
        full_padding = padding_mask.reshape(-1, 32).all(axis=-1)
        features = np.empty((len(patches), 512), dtype=np.float32)

        encode_indices = np.flatnonzero(~full_padding)
        if padding_feature is None and full_padding.any():
            encode_indices = np.concatenate((encode_indices, np.flatnonzero(full_padding)[:1]))
        with torch.inference_mode():
            for patch_left in range(0, len(encode_indices), args.clip_batch_size):
                indices = encode_indices[patch_left:patch_left + args.clip_batch_size]
                raw = torch.from_numpy(patches[indices]).to(device, non_blocking=True)
                raw_valid = torch.from_numpy(valid_patches[indices]).to(device, non_blocking=True)
                d1 = torch.from_numpy(d1_patches[indices]).to(device, non_blocking=True)
                d2 = torch.from_numpy(d2_patches[indices]).to(device, non_blocking=True)
                images = render_rgb_overlay(raw, raw_valid, d1, d2)
                images = images.float().div_(255.0)
                images = (images - clip_mean) / clip_std
                encoded = clip_model.encode_image(images).float().cpu().numpy()
                features[indices] = encoded
                if padding_feature is None:
                    padding_positions = np.flatnonzero(full_padding[indices])
                    if len(padding_positions):
                        padding_feature = encoded[padding_positions[0]].copy()
        if padding_feature is not None:
            features[full_padding] = padding_feature

        features = features.reshape(sample_right - sample_left, 256, 512)
        fp16, scales = scaled_fp16(features)
        image_array[sample_left:sample_right] = fp16
        scale_array[sample_left:sample_right] = scales
        progress.update(sample_right - sample_left)

    progress.close()
    dist.barrier()
    if rank == 0:
        checks = sorted(set((args.resume_start, (args.resume_start + sample_count - 1) // 2, sample_count - 1)))
        restored = (
            np.asarray(image_array[checks], dtype=np.float32)
            * np.asarray(scale_array[checks], dtype=np.float32)
        )
        if restored.shape != (len(checks), 256, 512) or not np.isfinite(restored).all():
            raise RuntimeError("resumed image-token validation failed")
        record = {
            "status": "completed",
            "store": str(Path(args.store).resolve()),
            "renderer": "rgb_overlay_raw_independent_diff_shared_q01_q99_v1",
            "resume_start": args.resume_start,
            "world_size": world,
            "elapsed": time.time() - started,
            "time": time.time(),
        }
        manifest = Path(args.manifest)
        manifest.parent.mkdir(parents=True, exist_ok=True)
        with manifest.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(record) + "\n")
        print(f"RESUME COMPLETE store={args.store} start={args.resume_start} samples={sample_count}", flush=True)
    dist.destroy_process_group()


if __name__ == "__main__":
    main()
