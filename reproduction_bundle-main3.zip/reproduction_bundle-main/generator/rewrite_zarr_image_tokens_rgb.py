#!/usr/bin/env python3
"""Rewrite only Zarr image-token arrays with canonical RGB chart rendering."""

from __future__ import annotations

import argparse
from concurrent.futures import ProcessPoolExecutor
import json
import multiprocessing as mp
import os
from pathlib import Path
import time

import numpy as np
import torch
import torch.distributed as dist
import zarr
from numcodecs import Blosc
from tqdm import tqdm


CLIP_MEAN = (0.48145466, 0.4578275, 0.40821073)
CLIP_STD = (0.26862954, 0.26130258, 0.27577711)
CURVE_COLORS = ((220, 40, 40), (35, 150, 70), (40, 90, 210))


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--roots", nargs="+", required=True)
    parser.add_argument("--clip_checkpoint", required=True)
    parser.add_argument("--clip_model", default="ViT-B/32")
    parser.add_argument("--sample_group_size", type=int, default=128)
    parser.add_argument("--clip_batch_size", type=int, default=16384)
    parser.add_argument("--zarr_chunk_size", type=int, default=64)
    parser.add_argument("--manifest_dir", required=True)
    parser.add_argument("--rewrite_text_root", default="")
    parser.add_argument("--text_workers", type=int, default=16)
    return parser.parse_args()


def describe_one_row(payload) -> list[str]:
    row, target_mask, padding_mask = payload
    from toto2_stats_template import describe_patch

    row = np.asarray(row, dtype=np.float32)
    target_mask = np.asarray(target_mask, dtype=bool)
    padding_mask = np.asarray(padding_mask, dtype=bool)
    descriptions = []
    for start in range(0, 8192, 32):
        stop = start + 32
        raw = row[start:stop]
        pad = padding_mask[start:stop]
        valid = target_mask[start:stop] & np.isfinite(raw) & ~pad
        descriptions.append(describe_patch(raw, valid, pad, None, start=start))
    return descriptions


def discover_stores(roots: list[str]) -> list[Path]:
    required = {"time_series_8192", "target_mask_8192", "padding_mask_8192"}
    stores: list[Path] = []
    for root_value in roots:
        root = Path(root_value)
        if not root.exists():
            print(f"WARN missing root: {root}", flush=True)
            continue
        candidates = [root] + sorted(p for p in root.rglob("*.zarr") if p.is_dir())
        for path in candidates:
            if not ((path / ".zgroup").exists() or (path / "zarr.json").exists()):
                continue
            try:
                group = zarr.open_group(str(path), mode="r")
                if required.issubset(set(group.array_keys())):
                    stores.append(path)
            except Exception as exc:
                print(f"WARN unreadable store {path}: {exc!r}", flush=True)
    return sorted(set(stores), key=lambda value: str(value))


def compute_differences(values: np.ndarray, valid: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    diff1 = np.full_like(values, np.nan, dtype=np.float32)
    diff2 = np.full_like(values, np.nan, dtype=np.float32)
    ok1 = valid[:, 1:] & valid[:, :-1]
    ok2 = valid[:, 2:] & valid[:, 1:-1] & valid[:, :-2]
    delta1 = values[:, 1:] - values[:, :-1]
    delta2 = values[:, 2:] - values[:, :-2]
    diff1[:, 1:][ok1] = delta1[ok1]
    diff2[:, 2:][ok2] = delta2[ok2]
    return diff1, diff2


def masked_quantile(values: torch.Tensor, valid: torch.Tensor, q: float) -> torch.Tensor:
    safe = torch.where(valid, values, torch.full_like(values, float("inf")))
    ordered = torch.sort(safe, dim=-1).values
    counts = valid.sum(dim=-1)
    position = (counts.clamp_min(1).float() - 1.0) * q
    lower = position.floor().long()
    upper = position.ceil().long()
    weight = position - lower.float()
    lo = ordered.gather(-1, lower.unsqueeze(-1)).squeeze(-1)
    hi = ordered.gather(-1, upper.unsqueeze(-1)).squeeze(-1)
    result = lo + (hi - lo) * weight
    return torch.where(counts > 0, result, torch.zeros_like(result))


def scale_curves(
    raw: torch.Tensor,
    raw_valid: torch.Tensor,
    diff1: torch.Tensor,
    diff2: torch.Tensor,
) -> tuple[torch.Tensor, torch.Tensor]:
    """Scale raw independently and both differences with one shared robust scale."""
    d1_valid = torch.isfinite(diff1)
    d2_valid = torch.isfinite(diff2)

    raw_lo = masked_quantile(raw, raw_valid, 0.01)
    raw_hi = masked_quantile(raw, raw_valid, 0.99)
    raw_min = masked_quantile(raw, raw_valid, 0.0)
    raw_max = masked_quantile(raw, raw_valid, 1.0)
    degenerate = raw_hi <= raw_lo
    raw_lo = torch.where(degenerate, raw_min, raw_lo)
    raw_hi = torch.where(degenerate, raw_max, raw_hi)
    raw_span = (raw_hi - raw_lo).clamp_min(1e-6)
    raw_scaled = ((raw - raw_lo[:, None]) / raw_span[:, None]).clamp(0.0, 1.0)
    raw_scaled = torch.where(raw_valid, raw_scaled, torch.zeros_like(raw_scaled))

    d1_abs_q = masked_quantile(diff1.abs(), d1_valid, 0.99)
    d2_abs_q = masked_quantile(diff2.abs(), d2_valid, 0.99)
    shared_scale = torch.maximum(d1_abs_q, d2_abs_q).clamp_min(1e-6)
    d1_scaled = (0.5 + 0.45 * (diff1 / shared_scale[:, None]).clamp(-1.0, 1.0))
    d2_scaled = (0.5 + 0.45 * (diff2 / shared_scale[:, None]).clamp(-1.0, 1.0))
    d1_scaled = torch.where(d1_valid, d1_scaled, torch.zeros_like(d1_scaled))
    d2_scaled = torch.where(d2_valid, d2_scaled, torch.zeros_like(d2_scaled))

    scaled = torch.stack((raw_scaled, d1_scaled, d2_scaled), dim=1)
    valid = torch.stack((raw_valid, d1_valid, d2_valid), dim=1)
    return scaled, valid


def render_rgb_overlay(
    raw: torch.Tensor,
    raw_valid: torch.Tensor,
    diff1: torch.Tensor,
    diff2: torch.Tensor,
) -> torch.Tensor:
    """Render three true RGB curves on one white 224x224 canvas per patch."""
    scaled, valid = scale_curves(raw, raw_valid, diff1, diff2)
    batch, _, length = scaled.shape
    height = width = 224
    canvas = torch.full((batch, 3, height, width), 255, dtype=torch.uint8, device=raw.device)
    colors = torch.tensor(CURVE_COLORS, dtype=torch.uint8, device=raw.device)

    x_float = torch.arange(width, device=raw.device, dtype=torch.float32)
    x_float.mul_((length - 1) / (width - 1))
    left = x_float.floor().long()
    right = x_float.ceil().long().clamp_max(length - 1)
    alpha = (x_float - left.float()).view(1, width)

    point_x = torch.round(
        torch.arange(length, device=raw.device, dtype=torch.float32)
        * (width - 1) / max(length - 1, 1)
    ).long()

    for curve in range(3):
        curve_values = scaled[:, curve]
        curve_valid = valid[:, curve]
        interpolated = curve_values[:, left] * (1.0 - alpha) + curve_values[:, right] * alpha
        y_index = torch.round((height - 1) * (1.0 - interpolated)).long()
        line_valid = curve_valid[:, left] & curve_valid[:, right]
        b_idx, x_idx = line_valid.nonzero(as_tuple=True)
        if b_idx.numel():
            y_idx = y_index[b_idx, x_idx]
            color = colors[curve].view(1, 3)
            for offset in (-1, 0, 1):
                canvas[b_idx, :, (y_idx + offset).clamp(0, height - 1), x_idx] = color

        point_y = torch.round((height - 1) * (1.0 - curve_values)).long()
        b_idx, p_idx = curve_valid.nonzero(as_tuple=True)
        if b_idx.numel():
            canvas[b_idx, :, point_y[b_idx, p_idx], point_x[p_idx]] = colors[curve].view(1, 3)
    return canvas


def scaled_fp16(values: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    values = np.asarray(values, dtype=np.float32)
    scale = np.max(np.abs(values), axis=-1, keepdims=True)
    scale = np.where(np.isfinite(scale) & (scale > 1e-12), scale, 1.0).astype(np.float32)
    normalized = np.nan_to_num(values / scale, nan=0.0, posinf=0.0, neginf=0.0)
    return normalized.astype(np.float16), scale


def load_completed(path: Path) -> set[str]:
    if not path.exists():
        return set()
    completed = set()
    for line in path.read_text(encoding="utf-8").splitlines():
        try:
            record = json.loads(line)
            if record.get("status") == "completed":
                completed.add(record["store"])
        except Exception:
            continue
    return completed


def append_manifest(path: Path, record: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(record, ensure_ascii=True) + "\n")


def rewrite_store(
    store: Path,
    clip_model,
    device: torch.device,
    clip_mean: torch.Tensor,
    clip_std: torch.Tensor,
    args: argparse.Namespace,
    rank: int,
    rewrite_text: bool = False,
    tokenizer=None,
    text_executor=None,
) -> None:
    started = time.time()
    group = zarr.open_group(str(store), mode="a")
    sample_count = int(group["time_series_8192"].shape[0])
    for name in ("target_mask_8192", "padding_mask_8192"):
        if int(group[name].shape[0]) != sample_count:
            raise ValueError(f"sample mismatch in {store}: {name}")

    # The job has exclusive access: remove old or interrupted image arrays directly.
    for name in ("image_global_fp16", "image_scale"):
        if name in group:
            del group[name]

    compressor = Blosc(cname="zstd", clevel=5, shuffle=Blosc.BITSHUFFLE)
    image_array = group.create_dataset(
        "image_global_fp16",
        shape=(sample_count, 256, 512),
        chunks=(args.zarr_chunk_size, 256, 512),
        dtype="f2",
        compressor=compressor,
        overwrite=True,
    )
    scale_array = group.create_dataset(
        "image_scale",
        shape=(sample_count, 256, 1),
        chunks=(args.zarr_chunk_size, 256, 1),
        dtype="f4",
        compressor=compressor,
        overwrite=True,
    )
    text_array = None
    text_scale_array = None
    if rewrite_text:
        for name in ("text_global_fp16", "text_scale"):
            if name in group:
                del group[name]
        text_array = group.create_dataset(
            "text_global_fp16",
            shape=(sample_count, 256, 512),
            chunks=(args.zarr_chunk_size, 256, 512),
            dtype="f2",
            compressor=compressor,
            overwrite=True,
        )
        text_scale_array = group.create_dataset(
            "text_scale",
            shape=(sample_count, 256, 1),
            chunks=(args.zarr_chunk_size, 256, 1),
            dtype="f4",
            compressor=compressor,
            overwrite=True,
        )

    padding_feature = None
    progress = tqdm(total=sample_count, desc=f"rank{rank} {store.name}", unit="sample")
    for sample_left in range(0, sample_count, args.sample_group_size):
        sample_right = min(sample_count, sample_left + args.sample_group_size)
        rows = np.asarray(group["time_series_8192"][sample_left:sample_right], dtype=np.float32)
        target_mask = np.asarray(group["target_mask_8192"][sample_left:sample_right], dtype=bool)
        padding_mask = np.asarray(group["padding_mask_8192"][sample_left:sample_right], dtype=bool)
        valid = target_mask & ~padding_mask & np.isfinite(rows)
        diff1, diff2 = compute_differences(rows, valid)

        patches = rows.reshape(-1, 32)
        valid_patches = valid.reshape(-1, 32)
        d1_patches = diff1.reshape(-1, 32)
        d2_patches = diff2.reshape(-1, 32)
        full_padding = padding_mask.reshape(-1, 32).all(axis=-1)
        features = np.empty((len(patches), 512), dtype=np.float32)

        encode_indices = np.flatnonzero(~full_padding)
        if padding_feature is None and full_padding.any():
            encode_indices = np.concatenate((encode_indices, np.flatnonzero(full_padding)[:1]))
        with torch.inference_mode():
            for patch_left in range(0, len(encode_indices), args.clip_batch_size):
                indices = encode_indices[patch_left:patch_left + args.clip_batch_size]
                raw = torch.from_numpy(patches[indices]).to(device, non_blocking=True)
                raw_valid = torch.from_numpy(valid_patches[indices]).to(device, non_blocking=True)
                d1 = torch.from_numpy(d1_patches[indices]).to(device, non_blocking=True)
                d2 = torch.from_numpy(d2_patches[indices]).to(device, non_blocking=True)
                images = render_rgb_overlay(raw, raw_valid, d1, d2)
                images = images.float().div_(255.0)
                images = (images - clip_mean) / clip_std
                encoded = clip_model.encode_image(images).float().cpu().numpy()
                features[indices] = encoded
                if padding_feature is None:
                    padding_positions = np.flatnonzero(full_padding[indices])
                    if len(padding_positions):
                        padding_feature = encoded[padding_positions[0]].copy()
        if padding_feature is not None:
            features[full_padding] = padding_feature

        features = features.reshape(sample_right - sample_left, 256, 512)
        fp16, scales = scaled_fp16(features)
        image_array[sample_left:sample_right] = fp16
        scale_array[sample_left:sample_right] = scales

        if rewrite_text:
            nested = list(text_executor.map(
                describe_one_row,
                zip(rows, target_mask, padding_mask),
                chunksize=1,
            ))
            descriptions = [value for row_values in nested for value in row_values]
            unique, inverse = np.unique(np.asarray(descriptions, dtype=object), return_inverse=True)
            unique_features = np.empty((len(unique), 512), dtype=np.float32)
            with torch.inference_mode():
                for text_left in range(0, len(unique), args.clip_batch_size):
                    text_right = min(len(unique), text_left + args.clip_batch_size)
                    tokens = tokenizer([str(value) for value in unique[text_left:text_right]]).to(
                        device, non_blocking=True
                    )
                    unique_features[text_left:text_right] = (
                        clip_model.encode_text(tokens).float().cpu().numpy()
                    )
            text_features = unique_features[inverse].reshape(sample_right - sample_left, 256, 512)
            text_fp16, text_scales = scaled_fp16(text_features)
            text_array[sample_left:sample_right] = text_fp16
            text_scale_array[sample_left:sample_right] = text_scales
        progress.update(sample_right - sample_left)
    progress.close()

    # Small end-to-end validation before declaring this block complete.
    checks = sorted(set((0, sample_count // 2, sample_count - 1)))
    restored = (
        np.asarray(image_array[checks], dtype=np.float32)
        * np.asarray(scale_array[checks], dtype=np.float32)
    )
    if restored.shape != (len(checks), 256, 512) or not np.isfinite(restored).all():
        raise RuntimeError(f"image-token validation failed for {store}")
    if rewrite_text:
        restored_text = (
            np.asarray(text_array[checks], dtype=np.float32)
            * np.asarray(text_scale_array[checks], dtype=np.float32)
        )
        if restored_text.shape != (len(checks), 256, 512) or not np.isfinite(restored_text).all():
            raise RuntimeError(f"text-token validation failed for {store}")
    elapsed = time.time() - started
    print(f"COMPLETE rank={rank} store={store} samples={sample_count} elapsed={elapsed:.1f}s", flush=True)


def main() -> None:
    args = parse_args()
    dist.init_process_group("nccl")
    rank = dist.get_rank()
    world = dist.get_world_size()
    local_rank = int(os.environ.get("LOCAL_RANK", rank))
    device = torch.device("cuda", local_rank)
    torch.cuda.set_device(device)

    import open_clip

    clip_name = args.clip_model.replace("/", "-")
    clip_model, _, _ = open_clip.create_model_and_transforms(
        clip_name, pretrained=args.clip_checkpoint, device=device
    )
    clip_model.eval()
    clip_tokenizer = open_clip.get_tokenizer(clip_name)
    clip_mean = torch.tensor(CLIP_MEAN, device=device).view(1, 3, 1, 1)
    clip_std = torch.tensor(CLIP_STD, device=device).view(1, 3, 1, 1)

    stores = discover_stores(args.roots)
    manifest_dir = Path(args.manifest_dir)
    manifest = manifest_dir / f"rewrite_rgb_image_tokens.rank-{rank:02d}.jsonl"
    completed = set()
    for manifest_path in manifest_dir.glob("rewrite_rgb_image_tokens.rank-*.jsonl"):
        completed.update(load_completed(manifest_path))
    pending = [path for path in stores if str(path.resolve()) not in completed]
    assigned = pending[rank::world]
    rewrite_text_root = Path(args.rewrite_text_root).resolve() if args.rewrite_text_root else None
    text_executor = None
    print(
        f"START rank={rank}/{world} stores_total={len(stores)} pending_total={len(pending)} "
        f"assigned={len(assigned)} completed_global={len(completed)}",
        flush=True,
    )
    for store in assigned:
        store_key = str(store.resolve())
        if store_key in completed:
            print(f"SKIP completed {store}", flush=True)
            continue
        try:
            rewrite_text = (
                rewrite_text_root is not None
                and store.resolve().is_relative_to(rewrite_text_root)
            )
            if rewrite_text and text_executor is None:
                text_executor = ProcessPoolExecutor(
                    max_workers=args.text_workers,
                    mp_context=mp.get_context("spawn"),
                )
            rewrite_store(
                store,
                clip_model,
                device,
                clip_mean,
                clip_std,
                args,
                rank,
                rewrite_text=rewrite_text,
                tokenizer=clip_tokenizer,
                text_executor=text_executor,
            )
            append_manifest(manifest, {
                "status": "completed",
                "store": store_key,
                "renderer": "rgb_overlay_raw_independent_diff_shared_q01_q99_v1",
                "text_rewritten": rewrite_text,
                "time": time.time(),
            })
        except Exception as exc:
            append_manifest(manifest, {
                "status": "failed",
                "store": store_key,
                "error": repr(exc),
                "time": time.time(),
            })
            print(f"FAILED rank={rank} store={store}: {exc!r}", flush=True)
            raise
    if text_executor is not None:
        text_executor.shutdown(wait=True)
    if rank == 0:
        print("ALL RANKS COMPLETE", flush=True)
    dist.destroy_process_group()


if __name__ == "__main__":
    main()
