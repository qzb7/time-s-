#!/usr/bin/env python3
"""Append one GIFTEval metadata embedding without renumbering existing rows."""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import os
import shutil
import time
from pathlib import Path

import numpy as np
import torch


def atomic_json(path: Path, value) -> None:
    partial = path.with_suffix(path.suffix + ".partial")
    partial.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n")
    os.replace(partial, path)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", required=True)
    parser.add_argument("--dataset", required=True)
    parser.add_argument("--term", required=True)
    parser.add_argument("--generator", required=True)
    parser.add_argument("--gift-eval-path", required=True)
    parser.add_argument("--gift-eval-src", required=True)
    parser.add_argument("--clip-checkpoint", required=True)
    parser.add_argument("--device", default="cuda:0")
    args = parser.parse_args()

    root = Path(args.root)
    plan_path = root / "generation_plan.json"
    registry_path = root / "metadata_registry.json"
    table_path = root / "metadata_embeddings.fp16.npy"
    plan = json.loads(plan_path.read_text())
    registry_file = json.loads(registry_path.read_text())

    existing_ids = {
        int(mid)
        for raw, mid in plan["raw_to_id"].items()
        if tuple(str(x).casefold() for x in json.loads(raw)[:2])
        == (args.dataset.casefold(), args.term.casefold())
    }
    if existing_ids:
        print(f"already present: {args.dataset}/{args.term} -> {sorted(existing_ids)}")
        return

    spec = importlib.util.spec_from_file_location("metadata_generator", args.generator)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    resolver = module.GiftResolver(args.gift_eval_path, args.gift_eval_src)
    metadata = module.build_metadata(args.dataset, args.term, resolver)
    template_text = module.metadata_text(metadata)

    import open_clip

    model, _, _ = open_clip.create_model_and_transforms(
        "ViT-B-32", pretrained=args.clip_checkpoint, device=args.device
    )
    model.eval()
    tokenizer = open_clip.get_tokenizer("ViT-B-32")
    with torch.inference_mode():
        tokens = tokenizer([template_text]).to(args.device)
        embedding = model.encode_text(tokens).float().cpu().numpy().astype(np.float16)
    if embedding.shape != (1, 512) or not np.isfinite(embedding).all():
        raise RuntimeError(f"invalid embedding: shape={embedding.shape}")

    old_table = np.load(table_path)
    new_id = int(old_table.shape[0])
    if old_table.ndim != 2 or old_table.shape[1] != 512:
        raise RuntimeError(f"unexpected existing table shape: {old_table.shape}")
    new_table = np.concatenate([old_table, embedding], axis=0)

    stamp = time.strftime("%Y%m%d-%H%M%S")
    backup = root / f"backup-before-append-{stamp}"
    backup.mkdir()
    for path in (plan_path, registry_path, table_path, root / "validation_report.json"):
        if path.exists():
            shutil.copy2(path, backup / path.name)

    canonical = module.canonical(metadata)
    entry = {
        "metadata_id": new_id,
        "metadata_hash": hashlib.sha256(canonical.encode("utf-8")).hexdigest(),
        **metadata,
        "template_text": template_text,
        "embedding_row": new_id,
    }
    raw_key = json.dumps([args.dataset, args.term, 0], ensure_ascii=False, separators=(",", ":"))
    plan["raw_to_id"][raw_key] = new_id
    plan["registry"].append(entry)
    plan["raw_counts"].append({
        "source_dataset": args.dataset,
        "source_term": args.term,
        "source_type": 0,
        "count": 0,
    })
    plan["unique_raw_metadata"] = int(plan["unique_raw_metadata"]) + 1
    plan["unique_canonical_metadata"] = int(plan["unique_canonical_metadata"]) + 1
    registry_file["entries"].append(entry)

    table_partial = table_path.with_suffix(table_path.suffix + ".partial")
    np.save(table_partial, new_table)
    generated_partial = Path(str(table_partial) + ".npy")
    if generated_partial.exists():
        os.replace(generated_partial, table_path)
    else:
        os.replace(table_partial, table_path)
    atomic_json(plan_path, plan)
    atomic_json(registry_path, registry_file)

    report_path = root / "validation_report.json"
    if report_path.exists():
        report = json.loads(report_path.read_text())
        report["embedding_shape"] = list(new_table.shape)
        report["unique_raw_metadata"] = plan["unique_raw_metadata"]
        report["unique_canonical_metadata"] = plan["unique_canonical_metadata"]
        report["supplemental_eval_embeddings"] = int(report.get("supplemental_eval_embeddings", 0)) + 1
        atomic_json(report_path, report)

    print(json.dumps({
        "dataset": args.dataset,
        "term": args.term,
        "metadata_id": new_id,
        "metadata": metadata,
        "template_text": template_text,
        "embedding_shape": list(new_table.shape),
        "backup": str(backup),
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
