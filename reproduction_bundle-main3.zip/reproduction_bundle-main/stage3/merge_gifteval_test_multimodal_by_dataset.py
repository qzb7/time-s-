from __future__ import annotations

import argparse
import json
import math
import os
import time
from collections import defaultdict
from pathlib import Path

import numpy as np


REQUIRED_FIELDS = (
    "time_series_8192",
    "target_mask_8192",
    "padding_mask_8192",
    "image_global",
    "text_global",
)


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input_dir", required=True)
    parser.add_argument("--output_dir", required=True)
    parser.add_argument("--samples_per_shard", type=int, default=512)
    parser.add_argument("--scan_log_interval", type=int, default=10_000)
    return parser.parse_args()


def log(event: str, **values):
    print(json.dumps({"event": event, **values}, sort_keys=True), flush=True)


def valid_output(path: Path, expected: int) -> bool:
    if not path.is_file():
        return False
    try:
        with np.load(path, allow_pickle=False) as data:
            return (
                all(key in data for key in REQUIRED_FIELDS)
                and data["time_series_8192"].shape == (expected, 8192)
                and data["image_global"].shape == (expected, 256, 512)
                and data["text_global"].shape == (expected, 256, 512)
                and data["window_index"].shape == (expected,)
                and data["variate_index"].shape == (expected,)
            )
    except Exception:
        return False


def load_record(npz_path: Path):
    with np.load(npz_path, allow_pickle=False) as data:
        missing = [key for key in REQUIRED_FIELDS if key not in data]
        if missing:
            raise KeyError(f"missing fields: {missing}")
        time_series = np.asarray(data["time_series_8192"], dtype=np.float32)
        target_mask = np.asarray(data["target_mask_8192"], dtype=np.bool_)
        padding_mask = np.asarray(data["padding_mask_8192"], dtype=np.bool_)
        image = np.asarray(data["image_global"], dtype=np.float32)
        text = np.asarray(data["text_global"], dtype=np.float32)
        sequence_length = int(np.asarray(data.get("sequence_length", 8192)).item())
    if time_series.shape != (8192,):
        raise ValueError(f"invalid time_series shape: {time_series.shape}")
    if target_mask.shape != (8192,) or padding_mask.shape != (8192,):
        raise ValueError(f"invalid mask shapes: {target_mask.shape}, {padding_mask.shape}")
    if image.shape != (256, 512) or text.shape != (256, 512):
        raise ValueError(f"invalid token shapes: {image.shape}, {text.shape}")
    return time_series, target_mask, padding_mask, image, text, sequence_length


def write_shard(output_path: Path, records: list[dict], input_root: Path):
    capacity = len(records)
    time_series = np.empty((capacity, 8192), dtype=np.float32)
    target_mask = np.empty((capacity, 8192), dtype=np.bool_)
    padding_mask = np.empty((capacity, 8192), dtype=np.bool_)
    image = np.empty((capacity, 256, 512), dtype=np.float32)
    text = np.empty((capacity, 256, 512), dtype=np.float32)
    sequence_length = np.empty(capacity, dtype=np.int32)
    window_index = np.empty(capacity, dtype=np.int64)
    variate_index = np.empty(capacity, dtype=np.int32)
    sample_ids = np.empty(capacity, dtype="U80")
    written = 0
    skipped = []

    for record in records:
        try:
            values = load_record(record["npz"])
        except Exception as exc:
            skipped.append({"path": str(record["npz"].relative_to(input_root)), "error": repr(exc)})
            continue
        time_series[written] = values[0]
        target_mask[written] = values[1]
        padding_mask[written] = values[2]
        image[written] = values[3]
        text[written] = values[4]
        sequence_length[written] = values[5]
        window_index[written] = record["window_index"]
        variate_index[written] = record["variate_index"]
        sample_ids[written] = record["sample_id"]
        written += 1

    if written == 0:
        return 0, skipped

    temp_path = output_path.with_suffix(output_path.suffix + ".tmp")
    with temp_path.open("wb") as handle:
        np.savez(
            handle,
            time_series_8192=time_series[:written],
            target_mask_8192=target_mask[:written],
            padding_mask_8192=padding_mask[:written],
            image_global=image[:written],
            text_global=text[:written],
            sequence_length=sequence_length[:written],
            window_index=window_index[:written],
            variate_index=variate_index[:written],
            sample_id=sample_ids[:written],
        )
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(temp_path, output_path)
    return written, skipped


def main():
    args = parse_args()
    input_root = Path(args.input_dir).resolve()
    output_root = Path(args.output_dir).resolve()
    output_root.mkdir(parents=True, exist_ok=True)
    started = time.time()

    groups = defaultdict(list)
    scanned = 0
    metadata_errors = 0
    for metadata_path in input_root.glob("rank-*/*/sample-*/metadata.json"):
        scanned += 1
        try:
            metadata = json.loads(metadata_path.read_text())
            npz_path = metadata_path.with_name("patch_clip_embeddings.npz")
            if not npz_path.is_file():
                raise FileNotFoundError(npz_path)
            config = metadata_path.parents[1].name
            groups[config].append(
                {
                    "npz": npz_path,
                    "sample_id": str(metadata.get("sample_id", metadata_path.parent.name)),
                    "window_index": int(metadata["window_index"]),
                    "variate_index": int(metadata.get("variate_index", 0)),
                    "dataset": str(metadata.get("dataset", "")),
                    "term": str(metadata.get("term", "")),
                }
            )
        except Exception as exc:
            metadata_errors += 1
            log("metadata_skip", path=str(metadata_path), error=repr(exc))
        if scanned % args.scan_log_interval == 0:
            log("scan_progress", scanned=scanned, configs=len(groups), metadata_errors=metadata_errors)

    total_records = sum(len(records) for records in groups.values())
    log("scan_complete", configs=len(groups), samples=total_records, metadata_errors=metadata_errors)

    total_written = 0
    total_skipped = metadata_errors
    for config_index, config in enumerate(sorted(groups), start=1):
        records = groups[config]
        records.sort(key=lambda record: (record["window_index"], record["variate_index"], record["sample_id"]))
        config_dir = output_root / config
        config_dir.mkdir(parents=True, exist_ok=True)
        shard_entries = []
        config_written = 0
        config_skipped = []
        shard_count = math.ceil(len(records) / args.samples_per_shard)

        for shard_index, left in enumerate(range(0, len(records), args.samples_per_shard)):
            chunk = records[left : left + args.samples_per_shard]
            output_path = config_dir / f"samples-{shard_index:05d}.npz"
            if valid_output(output_path, len(chunk)):
                written = len(chunk)
                skipped = []
                status = "existing"
            else:
                written, skipped = write_shard(output_path, chunk, input_root)
                status = "written"
            config_written += written
            config_skipped.extend(skipped)
            shard_entries.append({"file": output_path.name, "samples": written})
            elapsed = max(time.time() - started, 1e-9)
            log(
                "shard_complete",
                config=config,
                config_index=config_index,
                configs_total=len(groups),
                shard=shard_index + 1,
                shards_total=shard_count,
                samples=written,
                status=status,
                total_rate=round((total_written + config_written) / elapsed, 3),
            )

        manifest = {
            "config": config,
            "dataset": records[0]["dataset"] if records else "",
            "term": records[0]["term"] if records else "",
            "sort_order": ["window_index", "variate_index", "sample_id"],
            "source_samples": len(records),
            "written_samples": config_written,
            "skipped_samples": len(config_skipped),
            "samples_per_shard": args.samples_per_shard,
            "fields": list(REQUIRED_FIELDS) + ["sequence_length", "window_index", "variate_index", "sample_id"],
            "shards": shard_entries,
        }
        temp_manifest = config_dir / "manifest.json.tmp"
        temp_manifest.write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n")
        os.replace(temp_manifest, config_dir / "manifest.json")
        if config_skipped:
            (config_dir / "skipped.jsonl").write_text(
                "".join(json.dumps(item, sort_keys=True) + "\n" for item in config_skipped)
            )
        total_written += config_written
        total_skipped += len(config_skipped)
        log(
            "config_complete",
            config=config,
            samples=config_written,
            skipped=len(config_skipped),
            shards=shard_count,
            configs_done=config_index,
            configs_total=len(groups),
        )

    summary = {
        "input_dir": str(input_root),
        "output_dir": str(output_root),
        "configs": len(groups),
        "source_samples": total_records,
        "written_samples": total_written,
        "skipped_samples": total_skipped,
        "samples_per_shard": args.samples_per_shard,
        "elapsed_seconds": time.time() - started,
    }
    (output_root / "summary.json").write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n")
    log("complete", **summary)


if __name__ == "__main__":
    main()
