#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import gmean

MASE = "eval_metrics/MASE[0.5]"
CRPS = "eval_metrics/mean_weighted_sum_quantile_loss"


def canonical_key(value: object) -> str:
    parts = [part.strip().lower() for part in str(value).strip().split("/") if part.strip()]
    def canonical_freq(freq: str) -> str:
        aliases = {"min": "t", "me": "m", "qe": "q", "ye-dec": "a", "h": "h"}
        freq = aliases.get(freq, freq)
        if freq.startswith("w-"):
            return "w"
        if freq.startswith("q-"):
            return "q"
        if freq.startswith("a-") or freq.startswith("ye-"):
            return "a"
        return freq

    if len(parts) >= 4 and canonical_freq(parts[-3]) == canonical_freq(parts[-2]):
        del parts[-2]
    dataset_aliases = {
        "car_parts_with_missing": "car_parts",
        "kdd_cup_2018_with_missing": "kdd_cup_2018",
        "saugeenday": "saugeen",
        "temperature_rain_with_missing": "temperature_rain",
    }
    if parts:
        parts[0] = dataset_aliases.get(parts[0], parts[0])
    if len(parts) >= 2:
        parts[-2] = canonical_freq(parts[-2])
    return "/".join(parts)


def load_csv(path: Path, model_name: str) -> pd.DataFrame:
    df = pd.read_csv(path)
    required = {"dataset", MASE, CRPS}
    if not required.issubset(df.columns):
        return pd.DataFrame()
    out = df[["dataset", MASE, CRPS]].copy()
    out["key"] = out["dataset"].map(canonical_key)
    out["term"] = out["key"].str.rsplit("/", n=1).str[-1]
    out["model"] = model_name
    out[MASE] = pd.to_numeric(out[MASE], errors="coerce")
    out[CRPS] = pd.to_numeric(out[CRPS], errors="coerce")
    out = out.replace([np.inf, -np.inf], np.nan).dropna(subset=[MASE, CRPS])
    return out.drop_duplicates("key", keep="last")


def aggregate(frame: pd.DataFrame, target_name: str, baseline: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    base = baseline.set_index("key")[[MASE, CRPS]].rename(
        columns={MASE: "base_mase", CRPS: "base_crps"}
    )
    target = frame[frame["model"] == target_name].merge(base, left_on="key", right_index=True)
    if len(target) != 97:
        missing = sorted(set(base.index) - set(target["key"]))
        raise RuntimeError(f"Target alignment is {len(target)}/97; missing={missing}")
    target["MASE_normalized"] = target[MASE] / target["base_mase"]
    target["CRPS_normalized"] = target[CRPS] / target["base_crps"]

    frame = frame.copy()
    frame["MASE_rank"] = frame.groupby("key")[MASE].rank(method="average", ascending=True)
    frame["CRPS_rank"] = frame.groupby("key")[CRPS].rank(method="average", ascending=True)
    target_rank = frame[frame["model"] == target_name][["key", "MASE_rank", "CRPS_rank"]]
    target = target.merge(target_rank, on="key", validate="one_to_one")

    rows = []
    for term in ["short", "medium", "long", "overall"]:
        part = target if term == "overall" else target[target["term"] == term]
        rows.append(
            {
                "horizon": term,
                "num_configs": len(part),
                "MASE_geomean": float(gmean(part["MASE_normalized"])),
                "MASE_average_dataset_rank": float(part["MASE_rank"].mean()),
                "CRPS_geomean": float(gmean(part["CRPS_normalized"])),
                "CRPS_average_dataset_rank": float(part["CRPS_rank"].mean()),
            }
        )
    return target, pd.DataFrame(rows)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--target-csv", type=Path, required=True)
    parser.add_argument("--target-name", required=True)
    parser.add_argument("--official-results", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()

    baseline_path = args.official_results / "seasonal_naive" / "all_results.csv"
    baseline = load_csv(baseline_path, "seasonal_naive")
    if len(baseline) != 97:
        raise RuntimeError(f"Seasonal naive has {len(baseline)} canonical configurations")

    frames = []
    for csv_path in sorted(args.official_results.glob("*/all_results.csv")):
        model_name = csv_path.parent.name
        if model_name.lower() == "seasonal_naive":
            continue
        loaded = load_csv(csv_path, model_name)
        if not loaded.empty:
            frames.append(loaded)
    target = load_csv(args.target_csv, args.target_name)
    frames.append(target)
    pool = pd.concat(frames, ignore_index=True)

    target_detail, summary = aggregate(pool, args.target_name, baseline)

    # Build one official-style row for every model using the same ranking pool.
    pool["MASE_rank"] = pool.groupby("key")[MASE].rank(method="average", ascending=True)
    pool["CRPS_rank"] = pool.groupby("key")[CRPS].rank(method="average", ascending=True)
    base = baseline.set_index("key")[[MASE, CRPS]].rename(columns={MASE: "base_mase", CRPS: "base_crps"})
    normalized = pool.merge(base, left_on="key", right_index=True)
    normalized["MASE_norm"] = normalized[MASE] / normalized["base_mase"]
    normalized["CRPS_norm"] = normalized[CRPS] / normalized["base_crps"]
    leaderboard_rows = []
    for name, part in normalized.groupby("model"):
        leaderboard_rows.append(
            {
                "T": "",
                "model": name,
                "Organization": "local-toto2-multimodal" if name == args.target_name else "",
                "Test Leak.": "No",
                "Replication Code": "Yes" if name == args.target_name else "No",
                "MASE": float(gmean(part["MASE_norm"])),
                "MASE_Rank": float(part["MASE_rank"].mean()),
                "CRPS": float(gmean(part["CRPS_norm"])),
                "CRPS_Rank": float(part["CRPS_rank"].mean()),
            }
        )
    leaderboard = pd.DataFrame(leaderboard_rows).sort_values("MASE_Rank")

    args.output_dir.mkdir(parents=True, exist_ok=True)
    target_detail.to_csv(args.output_dir / "per_config_relative_to_seasonal_naive.csv", index=False)
    summary.to_csv(args.output_dir / "relative_to_seasonal_naive.csv", index=False)
    leaderboard.to_csv(args.output_dir / "leaderboard_official_style.csv", index=False)
    print(summary.to_string(index=False))
    print("\nTARGET LEADERBOARD ROW")
    print(leaderboard[leaderboard["model"] == args.target_name].to_string(index=False))
    print(f"\nofficial_models={len(frames) - 1} target_configs={len(target)}")


if __name__ == "__main__":
    main()
