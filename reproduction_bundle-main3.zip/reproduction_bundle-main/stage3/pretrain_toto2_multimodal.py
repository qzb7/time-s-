from __future__ import annotations

import argparse
import contextlib
import json
import math
import os
import random
import sys
import time
from pathlib import Path

import numpy as np
import torch
import torch.distributed as dist
from torch.nn.parallel import DistributedDataParallel
from torch.utils.data import DataLoader


def parse_bool(value: str | bool) -> bool:
    if isinstance(value, bool):
        return value
    return value.lower() in {"1", "true", "yes", "y", "on"}


def args_parser():
    p = argparse.ArgumentParser(description="Continue Toto-2 CPM with aligned image/text patch tokens.")
    p.add_argument("--model_name_or_path", required=True)
    p.add_argument("--multimodal_data_dir", required=True)
    p.add_argument("--output_dir", required=True)
    p.add_argument("--toto2_src", default="/home/toto-main/toto2")
    p.add_argument("--max_steps", type=int, default=20000)
    p.add_argument("--save_steps", type=int, default=500)
    p.add_argument("--logging_steps", type=int, default=1)
    p.add_argument("--per_device_train_batch_size", type=int, default=16)
    p.add_argument("--gradient_accumulation_steps", type=int, default=1)
    p.add_argument("--learning_rate", type=float, default=6e-5)
    p.add_argument("--min_learning_rate", type=float, default=6e-6)
    p.add_argument("--warmup_steps", type=int, default=0)
    p.add_argument("--weight_decay", type=float, default=0.01)
    p.add_argument("--max_grad_norm", type=float, default=1.0)
    p.add_argument("--cpm_max_span_patches", type=int, default=6)
    p.add_argument("--cpm_max_mask_probability", type=float, default=0.4)
    p.add_argument("--image_dim", type=int, default=512)
    p.add_argument("--text_dim", type=int, default=512)
    p.add_argument("--seed", type=int, default=5252)
    p.add_argument("--num_workers", type=int, default=0)
    p.add_argument("--bf16", type=parse_bool, default=True)
    return p.parse_args()


def setup(args):
    sys.path.insert(0, args.toto2_src)
    world = int(os.environ.get("WORLD_SIZE", "1"))
    rank = int(os.environ.get("RANK", "0"))
    local_rank = int(os.environ.get("LOCAL_RANK", "0"))
    if not torch.cuda.is_available():
        raise RuntimeError("This training entrypoint requires CUDA.")
    torch.cuda.set_device(local_rank)
    if world > 1:
        dist.init_process_group("nccl")
    return rank, local_rank, world, torch.device("cuda", local_rank)


def cosine_factor(step, max_steps, min_lr, lr, warmup_steps=0):
    current = step + 1
    if warmup_steps > 0 and current <= warmup_steps:
        return current / warmup_steps
    decay_steps = max(1, max_steps - warmup_steps)
    progress = min(1.0, max(0.0, (current - warmup_steps) / decay_steps))
    return (min_lr / lr) + (1.0 - min_lr / lr) * 0.5 * (1.0 + math.cos(math.pi * progress))


def distributed_mean(value: torch.Tensor, world: int) -> torch.Tensor:
    if world > 1:
        dist.all_reduce(value, op=dist.ReduceOp.SUM)
        value /= world
    return value


def modal_reconstruction_loss(pred, target, masked_patches, world):
    # Transformer position i predicts patch i+1, matching Toto-2 CPM loss.
    pred = pred[..., :-1, :]
    target = target[..., 1:, :]
    mask = masked_patches[..., 1:].unsqueeze(-1).to(pred.dtype)
    per_patch = torch.nn.functional.smooth_l1_loss(pred, target, reduction="none").mean(dim=-1)
    local_sum = (per_patch * mask.squeeze(-1)).sum(dtype=torch.float32)
    local_count = mask.squeeze(-1).sum(dtype=torch.float32)
    if world > 1:
        global_sum = local_sum.detach().clone()
        global_count = local_count.detach().clone()
        dist.all_reduce(global_sum, op=dist.ReduceOp.SUM)
        dist.all_reduce(global_count, op=dist.ReduceOp.SUM)
    else:
        global_sum, global_count = local_sum.detach(), local_count.detach()
    loss = local_sum * world / global_count.clamp_min(1.0)
    return loss, global_sum / global_count.clamp_min(1.0), global_count


def save_checkpoint(model, output_dir, step, optimizer, scheduler, args):
    path = Path(output_dir) / f"checkpoint-{step}"
    path.mkdir(parents=True, exist_ok=True)
    model.save_pretrained(path)
    torch.save({"global_step": step, "optimizer": optimizer.state_dict(), "scheduler": scheduler.state_dict()}, path / "training_state.pt")
    (path / "training_args.json").write_text(json.dumps(vars(args), indent=2, sort_keys=True) + "\n")


def main():
    args = args_parser()
    rank, local_rank, world, device = setup(args)
    random.seed(args.seed + rank)
    np.random.seed(args.seed + rank)
    torch.manual_seed(args.seed + rank)
    torch.cuda.manual_seed_all(args.seed + rank)

    from load_toto2_multimodal_npz import Toto2MultimodalNPZDataset
    from pretrain_toto2_short_balanced import prepare_toto_batch, sample_contiguous_patch_mask, toto_pinball_loss
    from toto2_multimodal_model import Toto2MultimodalModel

    model = Toto2MultimodalModel.from_pretrained(args.model_name_or_path, map_location="cpu")
    if model.patch_size != 32:
        raise ValueError(f"Expected patch_size=32 for the multimodal NPZ bank, got {model.patch_size}")
    model.to(device)
    if world > 1:
        model = DistributedDataParallel(model, device_ids=[local_rank], output_device=local_rank, find_unused_parameters=False)
    raw_model = model.module if isinstance(model, DistributedDataParallel) else model

    optimizer = torch.optim.AdamW(raw_model.parameters(), lr=args.learning_rate, weight_decay=args.weight_decay)
    scheduler = torch.optim.lr_scheduler.LambdaLR(
        optimizer,
        lambda step: cosine_factor(
            step,
            args.max_steps,
            args.min_learning_rate,
            args.learning_rate,
            args.warmup_steps,
        ),
    )
    dataset = Toto2MultimodalNPZDataset(args.multimodal_data_dir, seed=args.seed)
    loader = DataLoader(
        dataset,
        batch_size=args.per_device_train_batch_size,
        num_workers=args.num_workers,
        pin_memory=True,
        drop_last=True,
    )
    iterator = iter(loader)

    if rank == 0:
        total = sum(p.numel() for p in raw_model.parameters())
        print(json.dumps({"total_parameters": total, "world_size": world, "effective_batch": args.per_device_train_batch_size * world * args.gradient_accumulation_steps, "image_loss_weight": 1.0, "text_loss_weight": 1.0, "task_loss_weight": 1.0}, sort_keys=True), flush=True)

    optimizer.zero_grad(set_to_none=True)
    model.train()
    for step in range(args.max_steps):
        metrics = []
        for micro in range(args.gradient_accumulation_steps):
            batch = next(iterator)
            prepared = prepare_toto_batch(
                batch,
                device,
                patch_size=raw_model.patch_size,
                cpm_max_span_patches=args.cpm_max_span_patches,
                cpm_max_mask_probability=args.cpm_max_mask_probability,
            )
            image = batch["image_tokens"].to(device, non_blocking=True).unsqueeze(1)
            text = batch["text_tokens"].to(device, non_blocking=True).unsqueeze(1)
            sync = micro == args.gradient_accumulation_steps - 1
            ctx = contextlib.nullcontext() if sync or not isinstance(model, DistributedDataParallel) else model.no_sync()
            with ctx:
                with torch.autocast(device_type="cuda", dtype=torch.bfloat16, enabled=args.bf16):
                    outputs, hidden = model(
                        target=prepared["target"],
                        target_mask=prepared["target_mask"],
                        cpm_mask=prepared["cpm_mask"],
                        series_ids=prepared["series_ids"],
                        image_tokens=image,
                        text_tokens=text,
                    )
                    task_loss, task_metrics = toto_pinball_loss(outputs, prepared, patch_size=raw_model.patch_size, world_size=world)
                    image_pred = raw_model.image_decoder(hidden)
                    text_pred = raw_model.text_decoder(hidden)
                    image_loss, image_global, image_count = modal_reconstruction_loss(image_pred, image, prepared["masked_patches"], world)
                    text_loss, text_global, text_count = modal_reconstruction_loss(text_pred, text, prepared["masked_patches"], world)
                    loss = (task_loss + image_loss + text_loss) / args.gradient_accumulation_steps
                loss.backward()
            metrics.append((task_metrics["loss"].detach(), image_global.detach(), text_global.detach(), image_count.detach()))

        grad_norm = torch.nn.utils.clip_grad_norm_(raw_model.parameters(), args.max_grad_norm)
        optimizer.step()
        scheduler.step()
        optimizer.zero_grad(set_to_none=True)

        if rank == 0 and (step + 1) % args.logging_steps == 0:
            task = torch.stack([m[0] for m in metrics]).mean().item()
            image_loss = torch.stack([m[1] for m in metrics]).mean().item()
            text_loss = torch.stack([m[2] for m in metrics]).mean().item()
            print(json.dumps({"step": step + 1, "loss": task + image_loss + text_loss, "loss_task": task, "loss_image": image_loss, "loss_text": text_loss, "masked_patches": torch.stack([m[3] for m in metrics]).mean().item(), "grad_norm": float(grad_norm), "learning_rate": optimizer.param_groups[0]["lr"]}, sort_keys=True), flush=True)
        if (step + 1) % args.save_steps == 0 or step + 1 == args.max_steps:
            if world > 1:
                dist.barrier()
            if rank == 0:
                save_checkpoint(raw_model, args.output_dir, step + 1, optimizer, scheduler, args)
            if world > 1:
                dist.barrier()
    if world > 1:
        dist.destroy_process_group()


if __name__ == "__main__":
    main()
