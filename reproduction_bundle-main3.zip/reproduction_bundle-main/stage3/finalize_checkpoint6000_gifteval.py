from __future__ import annotations

import csv
import os
from pathlib import Path
import shutil
import subprocess
import time


pid = 117326
result_dir = Path("/home/toto-main/results/toto2-313m-multimodal-latefusion-zarr-from-27000-gifteval/checkpoint-6000")
shard = result_dir / "all_results.shard-0.csv"
combined = result_dir / "all_results.csv"
ranking = result_dir / "ranking"

while Path(f"/proc/{pid}").exists():
    time.sleep(30)

if not shard.is_file():
    raise RuntimeError(f"Evaluation exited without {shard}")
with shard.open(newline="") as handle:
    rows = list(csv.DictReader(handle))
if len(rows) != 97:
    raise RuntimeError(f"Evaluation produced {len(rows)}/97 configurations")

shutil.copyfile(shard, combined)
subprocess.run(
    [
        "/opt/conda/envs/toto2mm/bin/python",
        "/home/toto-main/build_generic_gifteval_leaderboard.py",
        "--result_csv", str(combined),
        "--output_dir", str(ranking),
        "--model_name", "toto2-313m-multimodal-latefusion-zarr-step-6000",
        "--gift_results", "/home/chronos-forecasting-main/gift-eval/results",
    ],
    check=True,
)
print("checkpoint-6000 evaluation and leaderboard complete", flush=True)
