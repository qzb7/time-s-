from __future__ import annotations
import argparse, csv, importlib.util, json, math, os, sys, traceback
from pathlib import Path
import numpy as np
import torch
from gluonts.ev.metrics import MAE, MAPE, MASE, MSE, MSIS, ND, NRMSE, RMSE, SMAPE, MeanWeightedSumQuantileLoss
from gluonts.model import evaluate_model
from gluonts.model.forecast import QuantileForecast
from gluonts.time_feature import get_seasonality

QUANTILES=[0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9]
CSV_HEADER=["dataset","checkpoint","model","eval_metrics/MSE[mean]","eval_metrics/MSE[0.5]","eval_metrics/MAE[0.5]","eval_metrics/MASE[0.5]","eval_metrics/MAPE[0.5]","eval_metrics/sMAPE[0.5]","eval_metrics/MSIS","eval_metrics/RMSE[mean]","eval_metrics/NRMSE[mean]","eval_metrics/ND[0.5]","eval_metrics/mean_weighted_sum_quantile_loss","domain","num_variates","term"]

def args():
 p=argparse.ArgumentParser()
 p.add_argument("--checkpoint",required=True); p.add_argument("--data_dir",required=True)
 p.add_argument("--output_dir",required=True); p.add_argument("--model_name",required=True)
 p.add_argument("--gift_eval_path",default="/data/GIFTEval"); p.add_argument("--gift_eval_src",default="/home/chronos-forecasting-main/gift-eval/src")
 p.add_argument("--toto2_src",default="/home/toto-main/toto2"); p.add_argument("--batch_size",type=int,default=32)
 p.add_argument("--dd_unit_scaling_src",default="/home/toto-main/dd_unit_scaling")
 p.add_argument("--device",default="cuda:0"); p.add_argument("--shard_id",type=int,default=0); p.add_argument("--num_shards",type=int,default=2)
 return p.parse_args()

def load_common():
 path=Path("/home/chronos-forecasting-main/evaluate_chronos2_gifteval_chy_aligned.py")
 spec=importlib.util.spec_from_file_location("common",path); mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod

class FixedPredictor:
 def __init__(self, forecasts): self.forecasts=forecasts
 def predict(self, dataset, **kwargs):
  yield from self.forecasts

def impute_for_model(target: np.ndarray, valid: np.ndarray) -> np.ndarray:
    """Match the pure Toto2 evaluator's forward-fill input handling."""
    target = np.asarray(target, dtype=np.float32)
    valid = np.asarray(valid, dtype=bool) & np.isfinite(target)
    if not valid.any():
        return np.zeros_like(target, dtype=np.float32)
    first = int(np.flatnonzero(valid)[0])
    out = target.copy()
    out[~valid] = np.nan
    out[:first] = out[first]
    last = out[first]
    for i in range(first, len(out)):
        if valid[i]:
            last = out[i]
        else:
            out[i] = last
    return np.nan_to_num(out, nan=0.0, posinf=0.0, neginf=0.0).astype(np.float32)


def forecast_batch(model, target, target_mask, image, text, horizon, device):
    q = model.forecast_parallel(
        target, target_mask, image, text, int(horizon),
        has_missing_values=True, scaler_fallback_min_obs=8,
    )
    if q.is_sparse:
        q = q.to_dense()
    if q.ndim == 5:
        q = q.flatten(-2, -1)
    return q.permute(1, 2, 0, 3)

def metric_value(result,name):
 v=result[name]
 return float(v.iloc[0]) if hasattr(v,"iloc") else float(v[0])

def main():
 a=args(); os.environ["GIFT_EVAL"]=a.gift_eval_path; os.environ["GIFT_EVAL_PATH"]=a.gift_eval_path
 sys.path[:0]=[a.toto2_src,a.dd_unit_scaling_src,"/home/toto-main","/home/chronos-forecasting-main/src",a.gift_eval_src]
 from gift_eval.data import Dataset
 from toto2_latefusion_model import Toto2LateFusionMultimodalModel
 root=Path(a.data_dir); groups={}
 for mp in root.glob("rank-*/*/sample-*/metadata.json"):
  try:
   d=json.loads(mp.read_text()); key=(d["dataset"],d["term"]); npz=mp.with_name("patch_clip_embeddings.npz")
   groups.setdefault(key,[]).append((int(d["window_index"]),int(d.get("variate_index",0)),npz))
  except Exception as e: print("metadata skip",mp,repr(e),flush=True)
 configs=sorted(groups)[a.shard_id::a.num_shards]
 device=torch.device(a.device)
 model=Toto2LateFusionMultimodalModel.from_pretrained(a.checkpoint,map_location="cpu").to(device=device,dtype=torch.float32).eval()
 outdir=Path(a.output_dir); outdir.mkdir(parents=True,exist_ok=True)
 csvpath=outdir/f"all_results.shard-{a.shard_id}.csv"
 with csvpath.open("w",newline="") as f:
  csv.writer(f).writerow(CSV_HEADER)
 for dataset_name,term in configs:
  try:
   meta=Dataset(name=dataset_name,term=term,to_univariate=False)
   uni=Dataset(name=dataset_name,term=term,to_univariate=meta.target_dim!=1)
   pairs=list(zip(uni.test_data.input,uni.test_data.label))
   rows=sorted(groups[(dataset_name,term)],key=lambda x:(x[0],x[1]))
   inputs=[]; labels=[]; eval_inputs=[]; eval_labels=[]; forecasts=[]
   for wi,vi,npz in rows:
    if wi>=len(pairs):
     print("skip out-of-range",dataset_name,term,wi,len(pairs),flush=True); continue
    inp,lab=pairs[wi]
    inputs.append(inp); labels.append(lab)
   for start in range(0,len(rows),a.batch_size):
    batchrows=rows[start:start+a.batch_size]; batch_inputs=[]; batch_labels=[]; valid_rows=[]
    for wi,vi,npz in batchrows:
     if wi>=len(pairs): continue
     try:
      with np.load(npz,allow_pickle=False) as z:
       target=np.asarray(z["time_series_8192"],np.float32); tm=np.asarray(z["target_mask_8192"],np.bool_); pm=np.asarray(z["padding_mask_8192"],np.bool_); tm=tm & ~pm & np.isfinite(target); target=impute_for_model(target,tm)
       image=np.nan_to_num(np.asarray(z["image_global"],np.float32),nan=0.0,posinf=0.0,neginf=0.0); text=np.nan_to_num(np.asarray(z["text_global"],np.float32),nan=0.0,posinf=0.0,neginf=0.0)
      if target.shape!=(8192,) or tm.shape!=(8192,) or image.shape!=(256,512) or text.shape!=(256,512): raise ValueError("shape")
      batch_inputs.append((target,tm,image,text)); batch_labels.append(pairs[wi][1]); valid_rows.append((wi,vi,npz))
     except Exception as e: print(f"sample skip {npz}: {type(e).__name__}: {e}",flush=True)
    if not batch_inputs: continue
    t=torch.from_numpy(np.stack([x[0] for x in batch_inputs])).to(device).unsqueeze(1)
    m=torch.from_numpy(np.stack([x[1] for x in batch_inputs])).to(device).unsqueeze(1)
    im=torch.from_numpy(np.stack([x[2] for x in batch_inputs])).to(device).unsqueeze(1)
    tx=torch.from_numpy(np.stack([x[3] for x in batch_inputs])).to(device).unsqueeze(1)
    horizon=int(uni.prediction_length)
    with torch.no_grad(): pred=forecast_batch(model,t,m,im,tx,horizon,device).cpu().numpy()
    for j,lab in enumerate(batch_labels):
     if not np.isfinite(pred[j]).all():
      print(f"sample skip nonfinite forecast {valid_rows[j][2]}",flush=True)
      continue
     forecasts.append(QuantileForecast(pred[j,0,:,:],lab["start"],[str(q) for q in QUANTILES],item_id=lab.get("item_id")))
     eval_inputs.append(pairs[valid_rows[j][0]][0]); eval_labels.append(lab)
   if not forecasts: continue
   class TD: pass
   td=TD(); td.input=eval_inputs; td.label=eval_labels
   result=evaluate_model(FixedPredictor(forecasts),test_data=td,metrics=[MSE(forecast_type="mean"),MSE(forecast_type=0.5),MAE(),MASE(),MAPE(),SMAPE(),MSIS(),RMSE(),NRMSE(),ND(),MeanWeightedSumQuantileLoss(quantile_levels=QUANTILES)],batch_size=a.batch_size,axis=None,mask_invalid_label=True,allow_nan_forecast=False,seasonality=get_seasonality(uni.freq))
   row=[f"{dataset_name}/{uni.freq}/{term}",a.checkpoint,a.model_name,metric_value(result,"MSE[mean]"),metric_value(result,"MSE[0.5]"),metric_value(result,"MAE[0.5]"),metric_value(result,"MASE[0.5]"),metric_value(result,"MAPE[0.5]"),metric_value(result,"sMAPE[0.5]"),metric_value(result,"MSIS"),metric_value(result,"RMSE[mean]"),metric_value(result,"NRMSE[mean]"),metric_value(result,"ND[0.5]"),metric_value(result,"mean_weighted_sum_quantile_loss"),"Unknown",meta.target_dim,term]
   with csvpath.open("a",newline="") as f: csv.writer(f).writerow(row)
   print(f"Wrote {dataset_name}/{term}: {len(forecasts)} samples",flush=True)
  except Exception:
   traceback.print_exc(); raise

if __name__=="__main__": main()
