#!/usr/bin/env python3
"""Resume only unfinished GIFTEval shard-0 configs, merge, then restart monitor."""

from __future__ import annotations

import argparse
import csv
import json
import os
import shutil
import signal
import subprocess
import time
from pathlib import Path


def process_alive(pid: int) -> bool:
    try:
        os.kill(pid, 0)
        return True
    except ProcessLookupError:
        return False


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--other-pid", type=int, required=True)
    p.add_argument("--checkpoint", required=True)
    p.add_argument("--data-dir", required=True)
    p.add_argument("--result-dir", required=True)
    p.add_argument("--log-root", required=True)
    p.add_argument("--metadata-root", required=True)
    p.add_argument("--model-name", required=True)
    p.add_argument("--monitor-script", required=True)
    p.add_argument("--monitor-nohup-log", required=True)
    args = p.parse_args()

    result = Path(args.result_dir)
    source_csv = result / "all_results.shard-0.csv"
    if not source_csv.is_file():
        raise FileNotFoundError(source_csv)
    old_rows = list(csv.DictReader(source_csv.open()))

    configs = []
    for manifest_path in sorted(Path(args.data_dir).glob("*/manifest.json")):
        manifest = json.loads(manifest_path.read_text())
        configs.append((manifest["dataset"], manifest["term"], int(manifest.get("written_samples", 0))))
    bins, loads = [[], []], [0, 0]
    for config in sorted(configs, key=lambda x: x[2], reverse=True):
        worker = min(range(2), key=lambda i: (loads[i], i))
        bins[worker].append(config)
        loads[worker] += config[2]
    assigned = sorted(bins[0])
    completed = {
        (dataset, term)
        for dataset, term, _ in assigned
        if any(row["dataset"].startswith(dataset + "/") and row["term"] == term for row in old_rows)
    }
    remaining = [(dataset, term) for dataset, term, _ in assigned if (dataset, term) not in completed]
    print(f"shard0 assigned={len(assigned)} completed={len(completed)} remaining={len(remaining)}", flush=True)

    resume_dir = result / "resume-shard0"
    if resume_dir.exists():
        shutil.rmtree(resume_dir)
    resume_dir.mkdir()
    command = [
        "/opt/conda/envs/toto2mm/bin/python",
        "/home/toto-main/evaluate_toto2_layer16_metadata_grouped_gifteval_fast.py",
        "--checkpoint", args.checkpoint,
        "--data_dir", args.data_dir,
        "--output_dir", str(resume_dir),
        "--model_name", args.model_name,
        "--gift_eval_path", "/public_data/GIFTEval",
        "--gift_eval_src", "/home/chronos-forecasting-main/gift-eval/src",
        "--toto2_src", "/home/toto-main/toto2",
        "--batch_size", "128",
        "--device", "cuda:0",
        "--metadata_root", args.metadata_root,
        "--shard_id", "0",
        "--num_shards", "1",
    ]
    for dataset, term in remaining:
        command.extend(["--include_config", f"{dataset}/{term}"])
    resume_log = Path(args.log_root) / "checkpoint-1000-shard0-gpu6-resume.log"
    with resume_log.open("w") as log:
        subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, check=True)

    resumed_csv = resume_dir / "all_results.shard-0.csv"
    resumed_rows = list(csv.DictReader(resumed_csv.open()))
    if len(resumed_rows) != len(remaining):
        raise RuntimeError(f"resume produced {len(resumed_rows)} rows, expected {len(remaining)}")
    backup = result / "all_results.shard-0.before-resume.csv"
    shutil.copy2(source_csv, backup)
    header = list(old_rows[0].keys()) if old_rows else list(resumed_rows[0].keys())
    combined = old_rows + resumed_rows
    with source_csv.with_suffix(".csv.partial").open("w", newline="") as out:
        writer = csv.DictWriter(out, fieldnames=header)
        writer.writeheader()
        writer.writerows(combined)
    os.replace(source_csv.with_suffix(".csv.partial"), source_csv)
    if len(combined) != len(assigned):
        raise RuntimeError(f"combined shard0 has {len(combined)} rows, expected {len(assigned)}")
    print(f"shard0 resumed and combined: {len(combined)} rows", flush=True)

    while process_alive(args.other_pid):
        print(f"waiting for GPU7 pid={args.other_pid}", flush=True)
        time.sleep(30)
    shard1 = result / "all_results.shard-1.csv"
    shard1_rows = list(csv.DictReader(shard1.open()))
    if len(shard1_rows) != len(bins[1]):
        raise RuntimeError(f"shard1 has {len(shard1_rows)} rows, expected {len(bins[1])}")

    subprocess.run([
        "/opt/conda/envs/toto2mm/bin/python", "/home/toto-main/merge_multimodal_gifteval_shards.py",
        "--result-dir", str(result), "--num-shards", "2", "--expected-configs", "97",
    ], check=True)
    leaderboard_log = Path(args.log_root) / "checkpoint-1000-leaderboard.log"
    with leaderboard_log.open("w") as log:
        subprocess.run([
            "/opt/conda/envs/toto2mm/bin/python", "/home/toto-main/build_generic_gifteval_leaderboard.py",
            "--result_csv", str(result / "all_results.csv"),
            "--output_dir", str(result / "ranking_official97"),
            "--model_name", args.model_name,
        ], stdout=log, stderr=subprocess.STDOUT, check=True)
    subprocess.run([
        "/opt/conda/envs/toto2mm/bin/python", "/home/toto-main/mark_leaderboard_transductive.py",
        str(result / "ranking_official97/leaderboard_official_style.csv"), args.model_name,
    ], check=True)
    (result / ".complete97").touch()
    print("checkpoint-1000 GIFTEval complete97", flush=True)

    monitor_log = open(args.monitor_nohup_log, "a")
    subprocess.Popen(
        ["bash", args.monitor_script],
        stdin=subprocess.DEVNULL,
        stdout=monitor_log,
        stderr=subprocess.STDOUT,
        start_new_session=True,
    )
    print("automatic joint monitor restarted", flush=True)


if __name__ == "__main__":
    main()
