from __future__ import annotations
import argparse, csv, os, sys, traceback
from pathlib import Path
import numpy as np
import torch
from gluonts.ev.metrics import MAE, MAPE, MASE, MSE, MSIS, ND, NRMSE, RMSE, SMAPE, MeanWeightedSumQuantileLoss
from gluonts.model import evaluate_model
from gluonts.model.forecast import QuantileForecast
from gluonts.time_feature import get_seasonality

QUANTILES = [0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9]
HEADER = ["dataset","checkpoint","model","eval_metrics/MSE[mean]","eval_metrics/MSE[0.5]","eval_metrics/MAE[0.5]","eval_metrics/MASE[0.5]","eval_metrics/MAPE[0.5]","eval_metrics/sMAPE[0.5]","eval_metrics/MSIS","eval_metrics/RMSE[mean]","eval_metrics/NRMSE[mean]","eval_metrics/ND[0.5]","eval_metrics/mean_weighted_sum_quantile_loss","domain","num_variates","term"]

def metric_value(result, name):
    v = result[name]
    return float(v.iloc[0]) if hasattr(v, "iloc") else float(v[0])

class FixedPredictor:
    def __init__(self, forecasts): self.forecasts = forecasts
    def predict(self, dataset, **kwargs): yield from self.forecasts

def pad_history(values, length=8192):
    values = np.asarray(values, dtype=np.float32).reshape(-1)
    values = values[-length:]
    valid = np.isfinite(values)
    out = np.zeros(length, dtype=np.float32)
    mask = np.zeros(length, dtype=bool)
    out[-len(values):] = np.nan_to_num(values, nan=0.0, posinf=0.0, neginf=0.0)
    mask[-len(values):] = valid
    return out, mask

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--checkpoint", required=True); ap.add_argument("--output_dir", required=True)
    ap.add_argument("--batch_size", type=int, default=64); ap.add_argument("--device", default="cuda:0")
    args = ap.parse_args()
    os.environ["GIFT_EVAL"] = "/public_data/GIFTEval"; os.environ["GIFT_EVAL_PATH"] = "/public_data/GIFTEval"
    sys.path[:0] = ["/home/toto-main/toto2", "/home/toto-main", "/home/chronos-forecasting-main/gift-eval/src"]
    from gift_eval.data import Dataset
    from toto2_multimodal_model_timeonly import Toto2MultimodalModel
    specs = [("kdd_cup_2018_with_missing/D", "short"), ("kdd_cup_2018_with_missing/H", "short"), ("kdd_cup_2018_with_missing/H", "medium"), ("restaurant", "short"), ("temperature_rain_with_missing", "short")]
    device = torch.device(args.device)
    model = Toto2MultimodalModel.from_pretrained(args.checkpoint, map_location="cpu").to(device=device, dtype=torch.float32).eval()
    outdir = Path(args.output_dir); outdir.mkdir(parents=True, exist_ok=True); csvpath = outdir / "all_results.csv"
    with csvpath.open("w", newline="") as f: csv.writer(f).writerow(HEADER)
    for dataset_name, term in specs:
        try:
            meta = Dataset(name=dataset_name, term=term, to_univariate=False)
            uni = Dataset(name=dataset_name, term=term, to_univariate=meta.target_dim != 1)
            pairs = list(zip(uni.test_data.input, uni.test_data.label))
            forecasts=[]; eval_inputs=[]; eval_labels=[]
            for start in range(0, len(pairs), args.batch_size):
                batch = pairs[start:start + args.batch_size]; ts=[]; masks=[]; labels=[]
                for inp, lab in batch:
                    x,m = pad_history(inp["target"]); ts.append(x); masks.append(m); labels.append(lab)
                t=torch.from_numpy(np.stack(ts)).to(device).unsqueeze(1); m=torch.from_numpy(np.stack(masks)).to(device).unsqueeze(1)
                image=torch.zeros((len(batch),1,256,512),device=device,dtype=torch.float32); text=torch.zeros_like(image)
                with torch.no_grad():
                    q=model.forecast_parallel(t,m,image,text,int(uni.prediction_length),has_missing_values=True,scaler_fallback_min_obs=8)
                    if q.is_sparse: q=q.to_dense()
                    if q.ndim==5: q=q.flatten(-2,-1)
                    pred=q.permute(1,2,0,3).cpu().numpy()
                for j,lab in enumerate(labels):
                    if not np.isfinite(pred[j]).all(): raise RuntimeError(f"nonfinite forecast at sample {start+j}")
                    forecasts.append(QuantileForecast(pred[j,0,:,:],lab["start"],[str(q) for q in QUANTILES],item_id=lab.get("item_id")))
                    eval_inputs.append(batch[j][0]); eval_labels.append(lab)
                print(f"{dataset_name}/{term}: {len(forecasts)}/{len(pairs)}",flush=True)
            class TD: pass
            td=TD(); td.input=eval_inputs; td.label=eval_labels
            result=evaluate_model(FixedPredictor(forecasts),test_data=td,metrics=[MSE(forecast_type="mean"),MSE(forecast_type=0.5),MAE(),MASE(),MAPE(),SMAPE(),MSIS(),RMSE(),NRMSE(),ND(),MeanWeightedSumQuantileLoss(quantile_levels=QUANTILES)],batch_size=args.batch_size,axis=None,mask_invalid_label=True,allow_nan_forecast=False,seasonality=get_seasonality(uni.freq))
            row=[f"{dataset_name}/{uni.freq}/{term}",args.checkpoint,"toto2-313m-timeonly-from-multimodal-6000",metric_value(result,"MSE[mean]"),metric_value(result,"MSE[0.5]"),metric_value(result,"MAE[0.5]"),metric_value(result,"MASE[0.5]"),metric_value(result,"MAPE[0.5]"),metric_value(result,"sMAPE[0.5]"),metric_value(result,"MSIS"),metric_value(result,"RMSE[mean]"),metric_value(result,"NRMSE[mean]"),metric_value(result,"ND[0.5]"),metric_value(result,"mean_weighted_sum_quantile_loss"),"Unknown",meta.target_dim,term]
            with csvpath.open("a",newline="") as f: csv.writer(f).writerow(row)
            print("WROTE",row[0],"samples",len(forecasts),flush=True)
        except Exception:
            traceback.print_exc(); raise
if __name__ == "__main__": main()
