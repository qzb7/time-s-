from __future__ import annotations

import os
from pathlib import Path

import numpy as np
import torch
from torch.utils.data import IterableDataset


class Toto2MultimodalNPZDataset(IterableDataset):
    """Stream patch-aligned NPZ samples with distributed/workers sharding."""

    def __init__(self, data_dir: str, seed: int = 5252):
        super().__init__()
        self.data_dir = Path(data_dir)
        self.seed = int(seed)

    def _files(self) -> list[Path]:
        # Multimodal pretraining data is stored in 100k-sample blocks:
        # block-*/rank-*/sample-*/patch_clip_embeddings.npz.
        files = sorted(self.data_dir.glob("block-*/rank-*/sample-*/patch_clip_embeddings.npz"))
        if not files:
            raise FileNotFoundError(f"No multimodal NPZ files found under {self.data_dir}")
        return files

    def __iter__(self):
        rank = int(os.environ.get("RANK", "0"))
        world = int(os.environ.get("WORLD_SIZE", "1"))
        worker = torch.utils.data.get_worker_info()
        worker_id = worker.id if worker else 0
        workers = worker.num_workers if worker else 1
        files = self._files()
        shard_id = rank * workers + worker_id
        num_shards = world * workers
        files = files[shard_id::num_shards]

        # Repeat the finite bank indefinitely; each pass has a deterministic
        # rank-local shuffle so CPM masks still provide stochasticity.
        rng = np.random.default_rng(self.seed + shard_id)
        reported_bad = set()
        while True:
            order = np.arange(len(files))
            rng.shuffle(order)
            for index in order:
                path = files[int(index)]
                try:
                    with np.load(path, allow_pickle=False) as data:
                        target = np.asarray(data["time_series_8192"], dtype=np.float32)
                        target_mask = np.asarray(data["target_mask_8192"], dtype=np.bool_)
                        # Use original CLIP features before L2 normalization.
                        image = np.asarray(data["image_global"], dtype=np.float32)
                        text = np.asarray(data["text_global"], dtype=np.float32)
                    if target.shape != (8192,) or target_mask.shape != (8192,):
                        raise ValueError("invalid time-series or target-mask shape")
                    if image.shape != (256, 512) or text.shape != (256, 512):
                        raise ValueError("expected unnormalized image/text shape (256, 512)")
                except Exception as exc:
                    path_str = str(path)
                    if path_str not in reported_bad:
                        print(
                            f"[rank={rank} worker={worker_id}] skip invalid NPZ: "
                            f"{path_str} ({type(exc).__name__}: {exc})",
                            flush=True,
                        )
                        reported_bad.add(path_str)
                    continue
                yield {
                    "target": torch.from_numpy(np.nan_to_num(target, nan=0.0)),
                    "target_mask": torch.from_numpy(target_mask),
                    "image_tokens": torch.from_numpy(image),
                    "text_tokens": torch.from_numpy(text),
                }
