from __future__ import annotations

import json
from pathlib import Path

import torch
from einops import rearrange, reduce, repeat
from torch import nn

from toto2 import Toto2Model
from toto2.model import (
    OutputResidualMLP,
    Toto2ModelOutputs,
    backfill_short_patches,
)


from toto2_layer16_concat_additive_model import Toto2Layer16ConcatAdditiveMultimodalModel


class MetadataResidualMLP(nn.Module):
    """Project one pooled CLIP vector into the Toto hidden space."""

    def __init__(self, in_dim: int, d_model: int, dropout_p: float):
        super().__init__()
        self.norm = nn.LayerNorm(in_dim)
        self.skip_proj = nn.Linear(in_dim, d_model, bias=True)
        self.linear1 = nn.Linear(in_dim, 4 * d_model, bias=True)
        self.linear2 = nn.Linear(4 * d_model, d_model, bias=True)
        self.dropout = nn.Dropout(dropout_p)
        self.activation = nn.GELU()

    def forward(self, value):
        value = self.norm(value)
        residual = self.skip_proj(value)
        branch = self.linear2(self.dropout(self.activation(self.linear1(value))))
        return residual + branch


class Toto2Layer16MetadataTokenModel(Toto2Layer16ConcatAdditiveMultimodalModel):
    """Layer-16 image/text fusion plus one non-temporal metadata token."""

    def __init__(self, base_model: Toto2Model, image_dim: int = 512, text_dim: int = 512,
                 metadata_dim: int = 512):
        super().__init__(base_model, image_dim=image_dim, text_dim=text_dim)
        self.metadata_dim = int(metadata_dim)
        d_model = int(base_model.config.d_model)
        self.metadata_projector = MetadataResidualMLP(
            self.metadata_dim, d_model, base_model.config.dropout_p
        )
        self.metadata_type_embedding = nn.Parameter(torch.zeros(1, 1, 1, d_model))
        self.metadata_position_embedding = nn.Parameter(torch.zeros(1, 1, 1, d_model))
        nn.init.normal_(self.metadata_type_embedding, std=0.02)
        nn.init.normal_(self.metadata_position_embedding, std=0.02)

    @property
    def config(self):
        return self.base_model.config

    @property
    def patch_size(self) -> int:
        return int(self.base_model.config.patch_size)

    @property
    def d_model(self) -> int:
        return int(self.base_model.config.d_model)

    def _transformer_range(self, state, time_ids, group_ids, start, end, has_missing_values=True):
        """Run an exact subset of the original Transformer decoder layers."""
        tr = self.base_model.transformer
        time_kwargs, var_kwargs = tr._sdpa_kwargs(
            state, time_ids, group_ids, has_missing_values=has_missing_values
        )
        num_series, seq_len = state.shape[-3], state.shape[-2]
        if time_ids is not None and time_ids.dim() > 1:
            flat_time_ids = time_ids.expand(*state.shape[:-1]).flatten(0, -2)
        else:
            flat_time_ids = time_ids
        leading = state.shape[:-2]
        state = rearrange(state, "... seq_len dim -> (...) seq_len dim")
        for idx in range(start, end):
            layer = tr.layers[idx]
            if tr._if_variate_layer(idx):
                state = rearrange(state, "(b n) s d -> (b s) n d", n=num_series)
                state = layer(state, **var_kwargs)
                state = rearrange(state, "(b s) n d -> (b n) s d", s=seq_len)
            else:
                state = layer(state, seq_ids=flat_time_ids, **time_kwargs)
        return state.unflatten(0, leading)

    def _fuse(self, hidden, image_tokens, text_tokens, visible_patch):
        image_tokens = image_tokens.to(dtype=hidden.dtype)
        text_tokens = text_tokens.to(dtype=hidden.dtype)
        visible_patch = visible_patch.unsqueeze(-1)
        image_tokens = torch.where(
            visible_patch,
            image_tokens,
            self.image_mask_token.to(dtype=hidden.dtype),
        )
        text_tokens = torch.where(
            visible_patch,
            text_tokens,
            self.text_mask_token.to(dtype=hidden.dtype),
        )
        image_input = torch.cat([hidden, image_tokens], dim=-1)
        text_input = torch.cat([hidden, text_tokens], dim=-1)
        image_feature = self.image_projector(image_input)
        text_feature = self.text_projector(text_input)
        return hidden + image_feature + text_feature

    def _metadata_token(self, metadata_embedding, hidden):
        metadata_embedding = metadata_embedding.to(dtype=hidden.dtype)
        token = self.metadata_projector(metadata_embedding)
        while token.dim() < hidden.dim():
            token = token.unsqueeze(-2)
        token = token.expand(*hidden.shape[:-2], 1, hidden.shape[-1])
        return token + self.metadata_type_embedding.to(hidden.dtype) + self.metadata_position_embedding.to(hidden.dtype)

    def _encode(self, time_x, group_ids, image_tokens, text_tokens, visible_patch,
                metadata_embedding, has_missing_values=True):
        time_ids = torch.arange(time_x.shape[-2], device=time_x.device, dtype=torch.int32)
        split = self.fusion_after_layer
        hidden = self._transformer_range(time_x, time_ids, group_ids, 0, split, has_missing_values)
        if image_tokens.shape[-2] != hidden.shape[-2] or text_tokens.shape[-2] != hidden.shape[-2]:
            raise ValueError("Modal patch count does not match time patches")
        fused = self._fuse(hidden, image_tokens, text_tokens, visible_patch)
        metadata_token = self._metadata_token(metadata_embedding, fused)
        fused = torch.cat([metadata_token, fused], dim=-2)
        # The metadata token receives identity RoPE (position 0), while the
        # original first temporal token remains at temporal position 0.
        time_ids = torch.cat([
            torch.zeros(1, device=time_x.device, dtype=torch.int32), time_ids
        ])
        meta_group = torch.zeros_like(group_ids[..., :1])
        group_ids = torch.cat([meta_group, group_ids], dim=-1)
        hidden = self._transformer_range(
            fused,
            time_ids,
            group_ids,
            split,
            len(self.base_model.transformer.layers),
            has_missing_values,
        )
        hidden = hidden[..., 1:, :]
        return self.base_model.transformer.out_norm(hidden)

    def _time_embed(self, target, target_mask, cpm_mask):
        base = self.base_model
        scaled, loc, scale = base.scaler(target, target_mask & cpm_mask)
        scaled = scaled.asinh()
        time_x = base.patch_proj(torch.cat([
            rearrange(scaled, "... (seq patch) -> ... seq patch", patch=self.patch_size),
            rearrange((~(target_mask & cpm_mask)).to(target.dtype), "... (seq patch) -> ... seq patch", patch=self.patch_size),
        ], dim=-1))
        return time_x, loc, scale

    def _group_ids(self, target_mask, cpm_mask, series_ids, n_patches):
        group_ids = repeat(series_ids, "... n_var -> ... n_var seq", seq=n_patches).clone()
        empty = reduce(target_mask, "... (seq patch) -> ... seq", "sum", patch=self.patch_size) == 0
        cpm_full = reduce(cpm_mask, "... (seq patch) -> ... seq", "prod", patch=self.patch_size) == 1
        group_ids[empty & cpm_full] = -1
        return group_ids

    def forward(self, target, target_mask, cpm_mask, series_ids, image_tokens, text_tokens,
                metadata_embedding, modal_patch_mask=None):
        time_x, loc, scale = self._time_embed(target, target_mask, cpm_mask)
        n_patches = time_x.shape[-2]
        if modal_patch_mask is None:
            visible = cpm_mask.unflatten(-1, (n_patches, self.patch_size)).any(dim=-1)
        else:
            visible = modal_patch_mask.bool()
        group_ids = self._group_ids(target_mask, cpm_mask, series_ids, n_patches)
        hidden = self._encode(
            time_x, group_ids, image_tokens, text_tokens, visible, metadata_embedding
        )
        quantiles = self.base_model.output_head(hidden, q=None)
        return Toto2ModelOutputs(quantiles, loc, scale), hidden

    @torch.inference_mode()
    def forecast_parallel(self, target, target_mask, image_tokens, text_tokens,
                          metadata_embedding, horizon,
                          has_missing_values=True, scaler_fallback_min_obs=8):
        """Parallel multi-horizon forecast using layer-16 concat-additive fusion."""
        base = self.base_model
        patch = self.patch_size
        initial_len = target.shape[-1]
        num_patches = (int(horizon) + patch - 1) // patch
        future_len = num_patches * patch
        full_target = torch.cat([
            target,
            torch.zeros(*target.shape[:-1], future_len, device=target.device, dtype=target.dtype),
        ], dim=-1)
        full_mask = torch.cat([
            target_mask,
            torch.zeros(*target_mask.shape[:-1], future_len, device=target_mask.device, dtype=torch.bool),
        ], dim=-1)
        _, loc, scale = base.scaler(full_target, full_mask)
        if scaler_fallback_min_obs:
            loc, scale = backfill_short_patches(
                full_target, loc, scale, full_mask, patch, int(scaler_fallback_min_obs)
            )
        scaled = ((full_target - loc) / scale).asinh()
        scaled = torch.where(full_mask, scaled, torch.zeros_like(scaled))
        time_x = base._embed_patches(scaled, full_mask, patch)
        n_total = time_x.shape[-2]
        context_patches = initial_len // patch
        if image_tokens.shape[-2] != context_patches or text_tokens.shape[-2] != context_patches:
            raise ValueError("Multimodal context patch count does not match time-series context")
        zeros_image = torch.zeros(
            *image_tokens.shape[:-2], num_patches, image_tokens.shape[-1],
            device=image_tokens.device, dtype=image_tokens.dtype,
        )
        zeros_text = torch.zeros(
            *text_tokens.shape[:-2], num_patches, text_tokens.shape[-1],
            device=text_tokens.device, dtype=text_tokens.dtype,
        )
        all_image = torch.cat([image_tokens, zeros_image], dim=-2)
        all_text = torch.cat([text_tokens, zeros_text], dim=-2)
        visible = target_mask.reshape(*target_mask.shape[:-1], -1, patch).any(-1)
        visible = torch.cat([
            visible,
            torch.zeros(*visible.shape[:-1], num_patches, device=visible.device, dtype=torch.bool),
        ], dim=-1)
        series_ids = torch.zeros(*target.shape[:-1], device=target.device, dtype=torch.long)
        group_ids = self._group_ids(full_mask, full_mask, series_ids, n_total)
        hidden = self._encode(
            time_x, group_ids, all_image, all_text, visible,
            metadata_embedding, has_missing_values,
        )
        pred_hidden = hidden[..., -(num_patches + 1):-1, :]
        nop = base.config.num_output_patches
        q = base.output_head(pred_hidden, q=None)[..., ::nop, :]
        future_loc = rearrange(loc[..., initial_len:initial_len + future_len], "... (s p) -> ... s p", p=patch)
        future_scale = rearrange(scale[..., initial_len:initial_len + future_len], "... (s p) -> ... s p", p=patch)
        q = q.sinh() * future_scale + future_loc
        q = base._clamp_nonfinite(q).sort(dim=0).values
        return rearrange(q, "... seq patch -> ... (seq patch)")[..., :int(horizon)]

    def save_pretrained(self, output_dir: str | Path):
        super().save_pretrained(output_dir)
        output_dir = Path(output_dir)
        torch.save({
            "metadata_projector": self.metadata_projector.state_dict(),
            "metadata_type_embedding": self.metadata_type_embedding.detach().cpu(),
            "metadata_position_embedding": self.metadata_position_embedding.detach().cpu(),
            "metadata_dim": self.metadata_dim,
        }, output_dir / "layer16_metadata_token_state.pt")
        (output_dir / "layer16_metadata_token_config.json").write_text(
            json.dumps(
                {
                    "metadata_dim": self.metadata_dim,
                    "fusion_after_layer": self.fusion_after_layer,
                    "metadata_tokens": 1,
                    "metadata_time_position": "identity_rope_without_shifting_temporal_positions",
                    "drop_metadata_before_output_head": True,
                },
                indent=2,
            )
            + "\n"
        )

    @classmethod
    def from_pretrained(cls, model_dir: str | Path, map_location="cpu"):
        model_dir = Path(model_dir)
        old = Toto2Layer16ConcatAdditiveMultimodalModel.from_pretrained(
            model_dir, map_location=map_location
        )
        metadata_path = model_dir / "layer16_metadata_token_state.pt"
        metadata_state = torch.load(metadata_path, map_location=map_location) if metadata_path.exists() else None
        metadata_dim = int(metadata_state.get("metadata_dim", 512)) if metadata_state else 512
        model = cls(
            old.base_model, image_dim=old.image_dim, text_dim=old.text_dim,
            metadata_dim=metadata_dim,
        )
        model.image_projector.load_state_dict(old.image_projector.state_dict())
        model.text_projector.load_state_dict(old.text_projector.state_dict())
        model.image_decoder.load_state_dict(old.image_decoder.state_dict())
        model.text_decoder.load_state_dict(old.text_decoder.state_dict())
        model.image_mask_token.data.copy_(old.image_mask_token.data)
        model.text_mask_token.data.copy_(old.text_mask_token.data)
        if metadata_state is not None:
            model.metadata_projector.load_state_dict(metadata_state["metadata_projector"])
            model.metadata_type_embedding.data.copy_(metadata_state["metadata_type_embedding"])
            model.metadata_position_embedding.data.copy_(metadata_state["metadata_position_embedding"])
        return model
