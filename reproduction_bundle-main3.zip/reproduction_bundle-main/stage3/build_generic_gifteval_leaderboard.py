from __future__ import annotations

import argparse
import csv
import math
from pathlib import Path


MASE = "eval_metrics/MASE[0.5]"
CRPS = "eval_metrics/mean_weighted_sum_quantile_loss"


def canonical(name: str) -> str:
    parts = str(name).strip().lower().split("/")
    if len(parts) >= 4 and parts[1] == parts[2]:
        parts.pop(1)
    if len(parts) == 4 and parts[-2] in {"w-fri", "w-thu", "w-wed", "w-tue", "w-sun"}:
        parts.pop(-2)
    aliases = {
        "car_parts_with_missing": "car_parts",
        "kdd_cup_2018_with_missing": "kdd_cup_2018",
        "saugeenday": "saugeen",
        "temperature_rain_with_missing": "temperature_rain",
    }
    if parts:
        parts[0] = aliases.get(parts[0], parts[0])
    if len(parts) >= 2:
        parts[1] = {
            "a-dec": "a", "q-dec": "q", "me": "m", "qe": "q", "ye": "a",
            "w-sun": "w", "w-fri": "w", "w-thu": "w", "w-wed": "w",
            "w-tue": "w",
        }.get(parts[1], parts[1])
    return "/".join(parts)


def read_results(path: Path):
    with path.open(newline="") as handle:
        rows = list(csv.DictReader(handle))
    return {canonical(row["dataset"]): row for row in rows}


def geomean(values):
    values = [max(float(value), 1e-12) for value in values]
    return math.exp(sum(math.log(value) for value in values) / len(values))


def average_tie_ranks(entries):
    entries = sorted(entries)
    result = {}
    left = 0
    while left < len(entries):
        right = left + 1
        while right < len(entries) and entries[right][0] == entries[left][0]:
            right += 1
        rank = ((left + 1) + right) / 2.0
        for _, model in entries[left:right]:
            result[model] = rank
        left = right
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--result_csv", required=True)
    parser.add_argument("--output_dir", required=True)
    parser.add_argument("--model_name", required=True)
    parser.add_argument("--gift_results", default="/home/chronos-forecasting-main/gift-eval/results")
    args = parser.parse_args()

    gift_root = Path(args.gift_results)
    baseline_path = gift_root / "seasonal_naive" / "all_results.csv"
    baseline = read_results(baseline_path)
    if len(baseline) != 97:
        raise RuntimeError(f"seasonal-naive canonical rows={len(baseline)}, expected 97")

    models = {}
    for path in sorted(gift_root.glob("*/all_results.csv")):
        if path == baseline_path:
            continue
        rows = read_results(path)
        if set(rows) != set(baseline):
            continue
        models[path.parent.name] = {
            metric: {key: float(rows[key][metric]) / float(baseline[key][metric]) for key in baseline}
            for metric in (MASE, CRPS)
        }

    target_rows = read_results(Path(args.result_csv))
    missing = sorted(set(baseline) - set(target_rows))
    extra = sorted(set(target_rows) - set(baseline))
    if missing or extra:
        raise RuntimeError(
            f"target canonical rows={len(target_rows)} missing={missing} extra={extra}"
        )
    models[args.model_name] = {
        metric: {key: float(target_rows[key][metric]) / float(baseline[key][metric]) for key in baseline}
        for metric in (MASE, CRPS)
    }

    ranks = {}
    for metric in (MASE, CRPS):
        for key in baseline:
            ranked = average_tie_ranks([(values[metric][key], model) for model, values in models.items()])
            for model, rank in ranked.items():
                ranks[metric, model, key] = rank

    leaderboard = []
    for model, values in models.items():
        leaderboard.append({
            "T": "",
            "model": model,
            "Organization": "local-toto2-multimodal" if model == args.model_name else "",
            "Test Leak.": "No",
            "Replication Code": "Yes" if model == args.model_name else "No",
            "MASE": f"{geomean(values[MASE].values()):.15f}",
            "MASE_Rank": f"{sum(ranks[MASE, model, key] for key in baseline) / len(baseline):.15f}",
            "CRPS": f"{geomean(values[CRPS].values()):.15f}",
            "CRPS_Rank": f"{sum(ranks[CRPS, model, key] for key in baseline) / len(baseline):.15f}",
        })
    leaderboard.sort(key=lambda row: (float(row["MASE_Rank"]) + float(row["CRPS_Rank"]), row["model"]))

    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    fields = ["T", "model", "Organization", "Test Leak.", "Replication Code", "MASE", "MASE_Rank", "CRPS", "CRPS_Rank"]
    with (output_dir / "leaderboard_official_style.csv").open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(leaderboard)

    target = models[args.model_name]
    horizon_rows = []
    for horizon in ("short", "medium", "long", "overall"):
        keys = list(baseline) if horizon == "overall" else [key for key in baseline if key.endswith("/" + horizon)]
        horizon_rows.append({
            "horizon": horizon,
            "num_configs": len(keys),
            "MASE_geomean": geomean(target[MASE][key] for key in keys),
            "MASE_average_dataset_rank": sum(ranks[MASE, args.model_name, key] for key in keys) / len(keys),
            "CRPS_geomean": geomean(target[CRPS][key] for key in keys),
            "CRPS_average_dataset_rank": sum(ranks[CRPS, args.model_name, key] for key in keys) / len(keys),
        })
    with (output_dir / "relative_to_seasonal_naive.csv").open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(horizon_rows[0]))
        writer.writeheader()
        writer.writerows(horizon_rows)

    target_row = next(row for row in leaderboard if row["model"] == args.model_name)
    print(f"aligned=97 official_models={len(models)-1} target={target_row}")
    for row in horizon_rows:
        print(row)


if __name__ == "__main__":
    main()
