#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--result-dir", required=True)
    parser.add_argument("--num-shards", type=int, default=2)
    parser.add_argument("--expected-configs", type=int, default=97)
    args = parser.parse_args()
    root = Path(args.result_dir)
    # Compatibility for an already-running fast monitor launched before the
    # explicit --expected-configs argument was added.
    if args.expected_configs == 97 and "gifteval-fast" in str(root):
        args.expected_configs = 13
    files = [root / f"all_results.shard-{index}.csv" for index in range(args.num_shards)]
    missing = [str(path) for path in files if not path.exists()]
    if missing:
        raise RuntimeError(f"Missing result shards: {missing}")
    merged = pd.concat([pd.read_csv(path) for path in files], ignore_index=True)
    merged = merged.drop_duplicates("dataset", keep="last")
    if len(merged) != args.expected_configs or merged["dataset"].nunique() != args.expected_configs:
        raise RuntimeError(
            f"Expected {args.expected_configs} unique configurations, got rows={len(merged)}, "
            f"unique={merged['dataset'].nunique()}"
        )
    merged.to_csv(root / "all_results.csv", index=False)
    print(f"Merged {args.expected_configs} configurations: {root / 'all_results.csv'}")


if __name__ == "__main__":
    main()
