from __future__ import annotations

import json
from pathlib import Path

import torch
from einops import rearrange, repeat
from einops.layers.torch import Rearrange
from torch import nn
from einops import reduce

from toto2 import Toto2Model
from toto2.model import InputResidualMLP, OutputResidualMLP, Toto2ModelOutputs, backfill_short_patches


class Toto2MultimodalModel(nn.Module):
    """Toto-2 CPM model with patch-aligned image/text conditioning.

    The base Toto-2 model remains unchanged. Image and text embeddings are
    projected to d_model, masked with the same CPM patch mask, added to the
    time-series patch embedding, and then passed through the original
    transformer and quantile head.
    """

    def __init__(self, base_model: Toto2Model, image_dim: int = 512, text_dim: int = 512):
        super().__init__()
        self.base_model = base_model
        config = base_model.config
        d_model = config.d_model
        hidden_dim = 4 * d_model

        self.image_projector = InputResidualMLP(
            in_dim=image_dim,
            hidden_dim=hidden_dim,
            out_dim=d_model,
            dropout_p=0.0,
            bias=True,
        )
        self.text_projector = InputResidualMLP(
            in_dim=text_dim,
            hidden_dim=hidden_dim,
            out_dim=d_model,
            dropout_p=0.0,
            bias=True,
        )
        self.image_decoder = OutputResidualMLP(
            in_dim=d_model,
            hidden_dim=hidden_dim,
            out_dim=image_dim,
            dropout_p=0.0,
            bias=True,
        )
        self.text_decoder = OutputResidualMLP(
            in_dim=d_model,
            hidden_dim=hidden_dim,
            out_dim=text_dim,
            dropout_p=0.0,
            bias=True,
        )
        self.image_mask_token = nn.Parameter(torch.zeros(1, 1, 1, d_model))
        self.text_mask_token = nn.Parameter(torch.zeros(1, 1, 1, d_model))
        self.image_dim = int(image_dim)
        self.text_dim = int(text_dim)

    @property
    def config(self):
        return self.base_model.config

    @property
    def patch_size(self) -> int:
        return int(self.base_model.config.patch_size)

    @property
    def d_model(self) -> int:
        return int(self.base_model.config.d_model)

    def forward(
        self,
        target: torch.Tensor,
        target_mask: torch.Tensor,
        cpm_mask: torch.Tensor,
        series_ids: torch.Tensor,
        image_tokens: torch.Tensor,
        text_tokens: torch.Tensor,
        modal_patch_mask: torch.Tensor | None = None,
    ):
        base = self.base_model
        patch_size = self.patch_size
        scaled_series, loc, scale = base.scaler(target, target_mask & cpm_mask)
        scaled_series = scaled_series.asinh()
        time_x = base.patch_proj(
            torch.cat(
                [
                    rearrange(scaled_series, "... (seq patch) -> ... seq patch", patch=patch_size),
                    rearrange(
                        (~(target_mask & cpm_mask)).to(target.dtype),
                        "... (seq patch) -> ... seq patch", patch=patch_size,
                    ),
                ],
                dim=-1,
            )
        )

        n_patches = time_x.shape[-2]
        if image_tokens.shape[-2] != n_patches or text_tokens.shape[-2] != n_patches:
            raise ValueError(
                f"Modal patch count mismatch: time={n_patches}, "
                f"image={image_tokens.shape[-2]}, text={text_tokens.shape[-2]}"
            )
        image_tokens = image_tokens.to(dtype=time_x.dtype)
        text_tokens = text_tokens.to(dtype=time_x.dtype)
        image_x = self.image_projector(image_tokens)
        text_x = self.text_projector(text_tokens)

        if modal_patch_mask is None:
            visible_patch = cpm_mask.unflatten(-1, (n_patches, patch_size)).any(dim=-1)
        else:
            visible_patch = modal_patch_mask.bool()
        visible_patch = visible_patch.unsqueeze(-1)
        image_x = torch.where(visible_patch, image_x, self.image_mask_token.to(image_x.dtype))
        text_x = torch.where(visible_patch, text_x, self.text_mask_token.to(text_x.dtype))
        x = time_x

        group_ids = repeat(series_ids, "... n_var -> ... n_var seq", seq=n_patches).clone()
        group_ids[
            (reduce(target_mask, "... (seq patch) -> ... seq", "sum", patch=patch_size) == 0)
            & (reduce(cpm_mask, "... (seq patch) -> ... seq", "prod", patch=patch_size) == 1)
        ] = -1
        hidden = base.transformer(x, group_ids=group_ids)
        quantiles = base.output_head(hidden, q=None)
        return Toto2ModelOutputs(quantiles, loc, scale), hidden

    @torch.no_grad()
    def forecast_parallel(
        self, target, target_mask, image_tokens, text_tokens, horizon,
        has_missing_values=True, scaler_fallback_min_obs=8,
    ):
        """Parallel Toto2 forecast with patch-aligned multimodal context."""
        base = self.base_model
        patch = self.patch_size
        initial_len = target.shape[-1]
        num_patches = (int(horizon) + patch - 1) // patch
        future_len = num_patches * patch
        full_target = torch.cat(
            [target, torch.zeros(*target.shape[:-1], future_len, device=target.device, dtype=target.dtype)],
            dim=-1,
        )
        full_mask = torch.cat(
            [target_mask, torch.zeros(*target_mask.shape[:-1], future_len, device=target.device, dtype=torch.bool)],
            dim=-1,
        )
        _, loc, scale = base.scaler(full_target, full_mask)
        if scaler_fallback_min_obs:
            loc, scale = backfill_short_patches(
                full_target, loc, scale, full_mask, patch, int(scaler_fallback_min_obs)
            )
        scaled = ((full_target - loc) / scale).asinh()
        scaled = torch.where(full_mask, scaled, torch.zeros_like(scaled))
        time_x = base._embed_patches(scaled, full_mask, patch)
        n_total = time_x.shape[-2]
        if image_tokens.shape[-2] != initial_len // patch or text_tokens.shape[-2] != initial_len // patch:
            raise ValueError("Multimodal context patch count does not match time-series context")
        zeros_modal = torch.zeros(
            *image_tokens.shape[:-2], num_patches, image_tokens.shape[-1],
            device=image_tokens.device, dtype=image_tokens.dtype,
        )
        image_x = self.image_projector(torch.cat([image_tokens, zeros_modal], dim=-2)).to(time_x.dtype)
        text_x = self.text_projector(
            torch.cat([text_tokens, torch.zeros_like(zeros_modal)], dim=-2)
        ).to(time_x.dtype)
        visible = target_mask.reshape(*target_mask.shape[:-1], -1, patch).any(-1)
        visible = torch.cat(
            [visible, torch.zeros(*visible.shape[:-1], num_patches, device=visible.device, dtype=torch.bool)],
            dim=-1,
        ).unsqueeze(-1)
        image_x = torch.where(visible, image_x, self.image_mask_token.to(image_x.dtype))
        text_x = torch.where(visible, text_x, self.text_mask_token.to(text_x.dtype))
        x = time_x
        series_ids = torch.zeros(*target.shape[:-1], device=target.device, dtype=torch.long)
        group_ids = repeat(series_ids, "... n_var -> ... n_var seq", seq=n_total).clone()
        context_obs = reduce(target_mask, "... (seq patch) -> ... seq", "sum", patch=patch)
        group_ids[..., : context_obs.shape[-1]][context_obs == 0] = -1
        hidden = base.transformer(
            x, group_ids=group_ids, has_missing_values=has_missing_values
        )
        pred_hidden = hidden[..., -(num_patches + 1) : -1, :]
        nop = base.config.num_output_patches
        q = base.output_head(pred_hidden, q=None)[..., ::nop, :]
        future_loc = rearrange(loc[..., initial_len : initial_len + future_len], "... (s p) -> ... s p", p=patch)
        future_scale = rearrange(scale[..., initial_len : initial_len + future_len], "... (s p) -> ... s p", p=patch)
        q = q.sinh() * future_scale + future_loc
        q = base._clamp_nonfinite(q).sort(dim=0).values
        q = rearrange(q, "... seq patch -> ... (seq patch)")
        return q[..., : int(horizon)]

    def save_pretrained(self, output_dir: str | Path) -> None:
        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)
        self.base_model.save_pretrained(output_dir)
        torch.save(
            {
                "image_projector": self.image_projector.state_dict(),
                "text_projector": self.text_projector.state_dict(),
                "image_decoder": self.image_decoder.state_dict(),
                "text_decoder": self.text_decoder.state_dict(),
                "image_mask_token": self.image_mask_token.detach().cpu(),
                "text_mask_token": self.text_mask_token.detach().cpu(),
                "image_dim": self.image_dim,
                "text_dim": self.text_dim,
            },
            output_dir / "multimodal_state.pt",
        )
        (output_dir / "multimodal_config.json").write_text(
            json.dumps({"image_dim": self.image_dim, "text_dim": self.text_dim}, indent=2) + "\n"
        )

    @classmethod
    def from_pretrained(cls, model_dir: str | Path, map_location: str = "cpu"):
        model_dir = Path(model_dir)
        base = Toto2Model.from_pretrained(model_dir, map_location=map_location)
        state_path = model_dir / "multimodal_state.pt"
        config_path = model_dir / "multimodal_config.json"
        if state_path.exists():
            state = torch.load(state_path, map_location=map_location)
            image_dim = int(state.get("image_dim", 512))
            text_dim = int(state.get("text_dim", 512))
        elif config_path.exists():
            config = json.loads(config_path.read_text())
            image_dim = int(config.get("image_dim", 512))
            text_dim = int(config.get("text_dim", 512))
            state = None
        else:
            image_dim = text_dim = 512
            state = None
        model = cls(base, image_dim=image_dim, text_dim=text_dim)
        if state is not None:
            model.image_projector.load_state_dict(state["image_projector"])
            model.text_projector.load_state_dict(state["text_projector"])
            model.image_decoder.load_state_dict(state["image_decoder"])
            model.text_decoder.load_state_dict(state["text_decoder"])
            model.image_mask_token.data.copy_(state["image_mask_token"])
            model.text_mask_token.data.copy_(state["text_mask_token"])
        return model
