from __future__ import annotations

import os
import sys
from pathlib import Path
from typing import Iterable, Sequence

import numpy as np
import torch
import zarr
from torch.utils.data import IterableDataset


class Toto2MultimodalZarrDataset(IterableDataset):
    """Stream multiple finite Zarr banks exactly once per shuffled cycle.

    Work is sharded by compressed Zarr chunk across all DDP ranks and
    DataLoader workers. This keeps reads sequential within a chunk while every
    sample is visited once globally before the next data cycle begins. Training
    itself remains step-based and has no epoch dependency.
    """

    REQUIRED_KEYS = (
        "time_series_8192",
        "target_mask_8192",
        "image_global_fp16",
        "image_scale",
        "text_global_fp16",
        "text_scale",
    )

    def __init__(
        self,
        data_dirs: Sequence[str] | str,
        seed: int = 5252,
        expected_sequence_length: int = 8192,
        expected_patches: int = 256,
        expected_modal_dim: int = 512,
    ):
        super().__init__()
        if isinstance(data_dirs, (str, Path)):
            data_dirs = [str(data_dirs)]
        self.data_dirs = tuple(Path(p) for p in data_dirs)
        self.seed = int(seed)
        self.expected_sequence_length = int(expected_sequence_length)
        self.expected_patches = int(expected_patches)
        self.expected_modal_dim = int(expected_modal_dim)

    def _blocks(self) -> list[Path]:
        candidates: list[Path] = []
        for root in self.data_dirs:
            if not root.is_dir():
                raise FileNotFoundError(f"Multimodal Zarr root does not exist: {root}")
            # Completed merged banks live directly under a root. Unmerged but
            # finalized generator shards live one level deeper under a block
            # directory and are independently readable Zarr stores.
            candidates.extend(sorted(root.glob("block-*.zarr")))
            candidates.extend(sorted(root.glob("block-*/block-*.rank-*.zarr")))

        blocks: list[Path] = []
        seen: set[Path] = set()
        for path in candidates:
            path = path.resolve()
            if path in seen or not path.is_dir() or path.name.endswith(".zarr.tmp"):
                continue
            seen.add(path)
            try:
                count, _ = self._block_info(path)
                if count <= 0:
                    raise ValueError("written_count is zero")
            except Exception as exc:
                print(f"Skipping unreadable multimodal Zarr store {path}: {exc}", file=sys.stderr, flush=True)
                continue
            blocks.append(path)
        if not blocks:
            raise FileNotFoundError(
                "No readable merged or rank-sharded Zarr stores found under: "
                + ", ".join(str(p) for p in self.data_dirs)
            )
        return blocks

    def _block_info(self, path: Path) -> tuple[int, int]:
        group = zarr.open_group(str(path), mode="r")
        missing = [key for key in self.REQUIRED_KEYS if key not in group]
        if missing:
            raise KeyError(f"{path} is missing arrays: {missing}")
        count = int(group.attrs.get("written_count", group["time_series_8192"].shape[0]))
        count = min(count, int(group["time_series_8192"].shape[0]))
        chunk = int(group["time_series_8192"].chunks[0])
        return count, chunk

    @staticmethod
    def _decode_tokens(values: np.ndarray, scale: np.ndarray) -> np.ndarray:
        return values.astype(np.float32) * scale.astype(np.float32)

    def _read_chunk(self, path: Path, left: int, right: int, order: np.ndarray):
        group = zarr.open_group(str(path), mode="r")
        target = np.asarray(group["time_series_8192"][left:right], dtype=np.float32)
        target_mask = np.asarray(group["target_mask_8192"][left:right], dtype=np.uint8).astype(np.bool_)
        image = self._decode_tokens(
            np.asarray(group["image_global_fp16"][left:right]),
            np.asarray(group["image_scale"][left:right]),
        )
        text = self._decode_tokens(
            np.asarray(group["text_global_fp16"][left:right]),
            np.asarray(group["text_scale"][left:right]),
        )

        expected_target = (right - left, self.expected_sequence_length)
        expected_modal = (right - left, self.expected_patches, self.expected_modal_dim)
        if target.shape != expected_target or target_mask.shape != expected_target:
            raise ValueError(f"Invalid time-series shape in {path}: {target.shape}, {target_mask.shape}")
        if image.shape != expected_modal or text.shape != expected_modal:
            raise ValueError(f"Invalid modal shape in {path}: {image.shape}, {text.shape}")

        for index in order:
            i = int(index)
            yield {
                "target": torch.from_numpy(np.nan_to_num(target[i], nan=0.0, posinf=0.0, neginf=0.0)),
                "target_mask": torch.from_numpy(target_mask[i]),
                "image_tokens": torch.from_numpy(image[i]),
                "text_tokens": torch.from_numpy(text[i]),
            }

    def __iter__(self) -> Iterable[dict[str, torch.Tensor]]:
        rank = int(os.environ.get("RANK", "0"))
        world = int(os.environ.get("WORLD_SIZE", "1"))
        worker = torch.utils.data.get_worker_info()
        worker_id = worker.id if worker else 0
        workers = worker.num_workers if worker else 1
        shard_id = rank * workers + worker_id
        num_shards = world * workers
        cycle = 0

        while True:
            blocks = self._blocks()
            chunk_refs: list[tuple[Path, int, int]] = []
            for path in blocks:
                count, chunk = self._block_info(path)
                chunk_refs.extend(
                    (path, left, min(left + chunk, count))
                    for left in range(0, count, chunk)
                )

            cycle_rng = np.random.default_rng(self.seed + cycle)
            cycle_rng.shuffle(chunk_refs)
            local_refs = chunk_refs[shard_id::num_shards]
            for ref_index, (path, left, right) in enumerate(local_refs):
                sample_order = np.arange(right - left)
                chunk_seed = (
                    self.seed
                    + cycle * 1_000_003
                    + shard_id * 10_007
                    + ref_index
                )
                np.random.default_rng(chunk_seed).shuffle(sample_order)
                yield from self._read_chunk(path, left, right, sample_order)
            cycle += 1
