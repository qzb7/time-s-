from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import torch


class MetadataEmbeddingLookup:
    """Read the deduplicated metadata table by dataset/horizon pair."""

    def __init__(self, root: str | Path):
        self.root = Path(root)
        if not (self.root / ".complete").is_file():
            raise RuntimeError(f"Metadata index is incomplete: {self.root}")
        plan = json.loads((self.root / "generation_plan.json").read_text())
        self.table = np.load(
            self.root / "metadata_embeddings.fp16.npy", mmap_mode="r"
        )
        pair_to_ids: dict[tuple[str, str], set[int]] = {}
        for raw, metadata_id in plan["raw_to_id"].items():
            dataset, term, _source_type = json.loads(raw)
            key = (str(dataset).casefold(), str(term).casefold())
            pair_to_ids.setdefault(key, set()).add(int(metadata_id))
        self.pair_to_id = {}
        for key, values in pair_to_ids.items():
            if len(values) != 1:
                raise RuntimeError(f"Ambiguous metadata mapping for {key}: {values}")
            self.pair_to_id[key] = next(iter(values))

    def numpy(self, dataset: str, term: str, count: int) -> np.ndarray:
        key = (str(dataset).casefold(), str(term).casefold())
        if key not in self.pair_to_id:
            raise KeyError(f"Metadata not found for dataset/term={dataset}/{term}")
        row = np.asarray(self.table[self.pair_to_id[key]], dtype=np.float32)
        return np.broadcast_to(row, (int(count), row.shape[0])).copy()

    def tensor(self, dataset: str, term: str, count: int, device) -> torch.Tensor:
        return torch.from_numpy(self.numpy(dataset, term, count)).to(device)
