from __future__ import annotations

import json
from pathlib import Path

import torch
from einops import rearrange, reduce, repeat
from torch import nn

from toto2 import Toto2Model
from toto2.model import (
    Toto2ModelOutputs,
    backfill_short_patches,
)


class LateFusionMLP(nn.Module):
    """Project [time hidden, one modality] into the Toto hidden space.

    The last layer starts at zero, so the initial forward is exactly the
    original time-only model: 0.5*h + 0.5*h + zero residual = h.
    """

    def __init__(self, d_model: int, modal_dim: int):
        super().__init__()
        hidden = 4 * d_model
        self.norm = nn.LayerNorm(d_model + modal_dim)
        self.fc1 = nn.Linear(d_model + modal_dim, hidden)
        self.act = nn.GELU()
        self.fc2 = nn.Linear(hidden, d_model)
        nn.init.zeros_(self.fc2.weight)
        nn.init.zeros_(self.fc2.bias)

    def forward(self, hidden: torch.Tensor, modal: torch.Tensor) -> torch.Tensor:
        return self.fc2(self.act(self.fc1(self.norm(torch.cat([hidden, modal], dim=-1)))))


class Toto2LateFusionMultimodalModel(nn.Module):
    """Toto-2 with time-only layers 1-12 and late image/text fusion.

    h12 is split into two branches:
        z_image = 0.5*h12 + ImageFusion([h12, image_patch])
        z_text  = 0.5*h12 + TextFusion([h12, text_patch])
        h12_fused = z_image + z_text
    The fused state is then processed by layers 13-24.
    """

    def __init__(self, base_model: Toto2Model, image_dim: int = 512, text_dim: int = 512):
        super().__init__()
        self.base_model = base_model
        self.image_dim = int(image_dim)
        self.text_dim = int(text_dim)
        d_model = int(base_model.config.d_model)
        self.image_fusion = LateFusionMLP(d_model, self.image_dim)
        self.text_fusion = LateFusionMLP(d_model, self.text_dim)
        self.image_decoder = nn.Sequential(nn.LayerNorm(d_model), nn.Linear(d_model, 4 * d_model), nn.GELU(), nn.Linear(4 * d_model, self.image_dim))
        self.text_decoder = nn.Sequential(nn.LayerNorm(d_model), nn.Linear(d_model, 4 * d_model), nn.GELU(), nn.Linear(4 * d_model, self.text_dim))
        self.image_mask_token = nn.Parameter(torch.zeros(1, 1, 1, self.image_dim))
        self.text_mask_token = nn.Parameter(torch.zeros(1, 1, 1, self.text_dim))

    @property
    def config(self):
        return self.base_model.config

    @property
    def patch_size(self) -> int:
        return int(self.base_model.config.patch_size)

    @property
    def d_model(self) -> int:
        return int(self.base_model.config.d_model)

    def _transformer_range(self, state, time_ids, group_ids, start, end, has_missing_values=True):
        """Run an exact subset of the original Transformer decoder layers."""
        tr = self.base_model.transformer
        time_kwargs, var_kwargs = tr._sdpa_kwargs(
            state, time_ids, group_ids, has_missing_values=has_missing_values
        )
        num_series, seq_len = state.shape[-3], state.shape[-2]
        if time_ids is not None and time_ids.dim() > 1:
            flat_time_ids = time_ids.expand(*state.shape[:-1]).flatten(0, -2)
        else:
            flat_time_ids = time_ids
        leading = state.shape[:-2]
        state = rearrange(state, "... seq_len dim -> (...) seq_len dim")
        for idx in range(start, end):
            layer = tr.layers[idx]
            if tr._if_variate_layer(idx):
                state = rearrange(state, "(b n) s d -> (b s) n d", n=num_series)
                state = layer(state, **var_kwargs)
                state = rearrange(state, "(b s) n d -> (b n) s d", s=seq_len)
            else:
                state = layer(state, seq_ids=flat_time_ids, **time_kwargs)
        return state.unflatten(0, leading)

    def _late_fuse(self, h12, image_tokens, text_tokens, visible_patch):
        image_tokens = image_tokens.to(dtype=h12.dtype)
        text_tokens = text_tokens.to(dtype=h12.dtype)
        visible_patch = visible_patch.unsqueeze(-1)
        image_tokens = torch.where(visible_patch, image_tokens, self.image_mask_token.to(image_tokens.dtype))
        text_tokens = torch.where(visible_patch, text_tokens, self.text_mask_token.to(text_tokens.dtype))
        image_delta = self.image_fusion(h12, image_tokens)
        text_delta = self.text_fusion(h12, text_tokens)
        return 0.5 * h12 + image_delta + 0.5 * h12 + text_delta

    def _encode(self, time_x, group_ids, image_tokens, text_tokens, visible_patch, has_missing_values=True):
        time_ids = torch.arange(time_x.shape[-2], device=time_x.device, dtype=torch.int32)
        h12 = self._transformer_range(time_x, time_ids, group_ids, 0, 12, has_missing_values)
        if image_tokens.shape[-2] != h12.shape[-2] or text_tokens.shape[-2] != h12.shape[-2]:
            raise ValueError("Modal patch count does not match time patches")
        fused = self._late_fuse(h12, image_tokens, text_tokens, visible_patch)
        hidden = self._transformer_range(fused, time_ids, group_ids, 12, len(self.base_model.transformer.layers), has_missing_values)
        return self.base_model.transformer.out_norm(hidden)

    def _time_embed(self, target, target_mask, cpm_mask):
        base = self.base_model
        scaled, loc, scale = base.scaler(target, target_mask & cpm_mask)
        scaled = scaled.asinh()
        time_x = base.patch_proj(torch.cat([
            rearrange(scaled, "... (seq patch) -> ... seq patch", patch=self.patch_size),
            rearrange((~(target_mask & cpm_mask)).to(target.dtype), "... (seq patch) -> ... seq patch", patch=self.patch_size),
        ], dim=-1))
        return time_x, loc, scale

    def _group_ids(self, target_mask, cpm_mask, series_ids, n_patches):
        group_ids = repeat(series_ids, "... n_var -> ... n_var seq", seq=n_patches).clone()
        empty = reduce(target_mask, "... (seq patch) -> ... seq", "sum", patch=self.patch_size) == 0
        cpm_full = reduce(cpm_mask, "... (seq patch) -> ... seq", "prod", patch=self.patch_size) == 1
        group_ids[empty & cpm_full] = -1
        return group_ids

    def forward(self, target, target_mask, cpm_mask, series_ids, image_tokens, text_tokens, modal_patch_mask=None):
        time_x, loc, scale = self._time_embed(target, target_mask, cpm_mask)
        n_patches = time_x.shape[-2]
        if modal_patch_mask is None:
            visible = cpm_mask.unflatten(-1, (n_patches, self.patch_size)).any(dim=-1)
        else:
            visible = modal_patch_mask.bool()
        group_ids = self._group_ids(target_mask, cpm_mask, series_ids, n_patches)
        hidden = self._encode(time_x, group_ids, image_tokens, text_tokens, visible)
        quantiles = self.base_model.output_head(hidden, q=None)
        return Toto2ModelOutputs(quantiles, loc, scale), hidden

    @torch.inference_mode()
    def forecast_parallel(self, target, target_mask, image_tokens, text_tokens, horizon,
                          has_missing_values=True, scaler_fallback_min_obs=8):
        """Parallel multi-horizon forecast using the same late-fusion path."""
        base = self.base_model
        patch = self.patch_size
        initial_len = target.shape[-1]
        num_patches = (int(horizon) + patch - 1) // patch
        future_len = num_patches * patch
        full_target = torch.cat([
            target,
            torch.zeros(*target.shape[:-1], future_len, device=target.device, dtype=target.dtype),
        ], dim=-1)
        full_mask = torch.cat([
            target_mask,
            torch.zeros(*target_mask.shape[:-1], future_len, device=target_mask.device, dtype=torch.bool),
        ], dim=-1)
        _, loc, scale = base.scaler(full_target, full_mask)
        if scaler_fallback_min_obs:
            loc, scale = backfill_short_patches(
                full_target, loc, scale, full_mask, patch, int(scaler_fallback_min_obs)
            )
        scaled = ((full_target - loc) / scale).asinh()
        scaled = torch.where(full_mask, scaled, torch.zeros_like(scaled))
        time_x = base._embed_patches(scaled, full_mask, patch)
        n_total = time_x.shape[-2]
        context_patches = initial_len // patch
        if image_tokens.shape[-2] != context_patches or text_tokens.shape[-2] != context_patches:
            raise ValueError("Multimodal context patch count does not match time-series context")
        zeros_image = torch.zeros(
            *image_tokens.shape[:-2], num_patches, image_tokens.shape[-1],
            device=image_tokens.device, dtype=image_tokens.dtype,
        )
        zeros_text = torch.zeros(
            *text_tokens.shape[:-2], num_patches, text_tokens.shape[-1],
            device=text_tokens.device, dtype=text_tokens.dtype,
        )
        all_image = torch.cat([image_tokens, zeros_image], dim=-2)
        all_text = torch.cat([text_tokens, zeros_text], dim=-2)
        visible = target_mask.reshape(*target_mask.shape[:-1], -1, patch).any(-1)
        visible = torch.cat([
            visible,
            torch.zeros(*visible.shape[:-1], num_patches, device=visible.device, dtype=torch.bool),
        ], dim=-1)
        series_ids = torch.zeros(*target.shape[:-1], device=target.device, dtype=torch.long)
        group_ids = self._group_ids(full_mask, full_mask, series_ids, n_total)
        hidden = self._encode(time_x, group_ids, all_image, all_text, visible, has_missing_values)
        pred_hidden = hidden[..., -(num_patches + 1):-1, :]
        nop = base.config.num_output_patches
        q = base.output_head(pred_hidden, q=None)[..., ::nop, :]
        future_loc = rearrange(loc[..., initial_len:initial_len + future_len], "... (s p) -> ... s p", p=patch)
        future_scale = rearrange(scale[..., initial_len:initial_len + future_len], "... (s p) -> ... s p", p=patch)
        q = q.sinh() * future_scale + future_loc
        q = base._clamp_nonfinite(q).sort(dim=0).values
        return rearrange(q, "... seq patch -> ... (seq patch)")[..., :int(horizon)]

    def save_pretrained(self, output_dir: str | Path):
        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)
        self.base_model.save_pretrained(output_dir)
        torch.save({
            "image_fusion": self.image_fusion.state_dict(),
            "text_fusion": self.text_fusion.state_dict(),
            "image_decoder": self.image_decoder.state_dict(),
            "text_decoder": self.text_decoder.state_dict(),
            "image_mask_token": self.image_mask_token.detach().cpu(),
            "text_mask_token": self.text_mask_token.detach().cpu(),
            "image_dim": self.image_dim,
            "text_dim": self.text_dim,
        }, output_dir / "late_fusion_state.pt")
        (output_dir / "late_fusion_config.json").write_text(json.dumps({"image_dim": self.image_dim, "text_dim": self.text_dim, "fusion_after_layer": 12}, indent=2) + "\n")

    @classmethod
    def from_pretrained(cls, model_dir: str | Path, map_location="cpu"):
        model_dir = Path(model_dir)
        base = Toto2Model.from_pretrained(model_dir, map_location=map_location)
        state_path = model_dir / "late_fusion_state.pt"
        if state_path.exists():
            state = torch.load(state_path, map_location=map_location)
            image_dim = int(state.get("image_dim", 512))
            text_dim = int(state.get("text_dim", 512))
        else:
            state = None
            image_dim = text_dim = 512
        model = cls(base, image_dim=image_dim, text_dim=text_dim)
        if state is not None:
            model.image_fusion.load_state_dict(state["image_fusion"])
            model.text_fusion.load_state_dict(state["text_fusion"])
            model.image_decoder.load_state_dict(state["image_decoder"])
            model.text_decoder.load_state_dict(state["text_decoder"])
            model.image_mask_token.data.copy_(state["image_mask_token"])
            model.text_mask_token.data.copy_(state["text_mask_token"])
        return model
