import csv
import math
import sys
from pathlib import Path

ROOT = Path(__import__('os').environ.get(
    'RESULT_ROOT', '/home/toto-main/results/toto2-313m-cpm256-time-only-gifteval'
))
GIFT_ROOT = Path(__import__('os').environ.get(
    'GIFT_ROOT', '/home/chronos-forecasting-main/gift-eval/results'
))
BASELINE = GIFT_ROOT / 'seasonal_naive' / 'all_results.csv'
MASE = 'eval_metrics/MASE[0.5]'
CRPS = 'eval_metrics/mean_weighted_sum_quantile_loss'


def load(path):
    with path.open(newline='') as f:
        return list(csv.DictReader(f))


def aliases(key):
    parts = key.split('/')
    if len(parts) != 3:
        return [key]
    dataset, freq, term = parts
    return [key, f'{dataset}/{freq.split("-", 1)[0]}/{term}']


def mapped(rows, baseline):
    out = {}
    for row in rows:
        key = next((candidate for candidate in aliases(row['dataset']) if candidate in baseline), None)
        if key is not None:
            out[key] = row
    return out


def gm(values):
    return math.exp(sum(math.log(max(value, 1e-12)) for value in values) / len(values))


def build(step):
    baseline_rows = {row['dataset']: row for row in load(BASELINE)}
    if len(baseline_rows) != 97:
        raise RuntimeError(f'expected 97 baseline rows, got {len(baseline_rows)}')

    model_values = {}
    for path in sorted(GIFT_ROOT.glob('*/all_results.csv')):
        if path == BASELINE:
            continue
        rows = mapped(load(path), baseline_rows)
        if len(rows) != 97:
            continue
        model = path.parent.name
        model_values[model] = {
            metric: {dataset: float(rows[dataset][metric]) / float(baseline_rows[dataset][metric])
                     for dataset in baseline_rows}
            for metric in (MASE, CRPS)
        }

    checkpoint = ROOT / f'checkpoint-{step}' / 'all_results.csv'
    if not checkpoint.exists():
        raise FileNotFoundError(checkpoint)
    target_rows = mapped(load(checkpoint), baseline_rows)
    if len(target_rows) != 97:
        raise RuntimeError(f'checkpoint-{step} aligned only {len(target_rows)}/97 rows')

    target = f'toto2-313m-multimodal-localstationarity-step-{step}'
    model_values[target] = {
        metric: {dataset: float(target_rows[dataset][metric]) / float(baseline_rows[dataset][metric])
                 for dataset in baseline_rows}
        for metric in (MASE, CRPS)
    }

    ranks = {}
    for metric in (MASE, CRPS):
        for dataset in baseline_rows:
            entries = sorted((values[metric][dataset], model) for model, values in model_values.items())
            for rank, (_, model) in enumerate(entries, 1):
                ranks[metric, model, dataset] = rank

    output = []
    for model, values in model_values.items():
        mase_ranks = [ranks[MASE, model, dataset] for dataset in baseline_rows]
        crps_ranks = [ranks[CRPS, model, dataset] for dataset in baseline_rows]
        output.append({
            'T': '',
            'model': model,
            'Organization': 'local-toto2-continued-pretraining' if model == target else '',
            'Test Leak.': 'No',
            'Replication Code': 'Yes' if model == target else 'No',
            'MASE': f'{gm([values[MASE][dataset] for dataset in baseline_rows]):.15f}',
            'MASE_Rank': f'{sum(mase_ranks) / len(mase_ranks):.15f}',
            'CRPS': f'{gm([values[CRPS][dataset] for dataset in baseline_rows]):.15f}',
            'CRPS_Rank': f'{sum(crps_ranks) / len(crps_ranks):.15f}',
        })
    output.sort(key=lambda row: (float(row['MASE_Rank']) + float(row['CRPS_Rank']), row['model']))

    ranking_dir = ROOT / f'checkpoint-{step}' / 'ranking'
    ranking_dir.mkdir(parents=True, exist_ok=True)
    output_path = ranking_dir / 'leaderboard_official_style.csv'
    with output_path.open('w', newline='') as f:
        fields = ['T', 'model', 'Organization', 'Test Leak.', 'Replication Code',
                  'MASE', 'MASE_Rank', 'CRPS', 'CRPS_Rank']
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(output)
    target_row = next(row for row in output if row['model'] == target)
    print(f'checkpoint={step} models={len(output)}')
    print('target=' + ','.join(f'{key}={target_row[key]}' for key in ['MASE', 'MASE_Rank', 'CRPS', 'CRPS_Rank']))
    print(f'output={output_path}')


if __name__ == '__main__':
    for arg in sys.argv[1:]:
        build(int(arg))
