import argparse
from pathlib import Path
import pandas as pd

p = argparse.ArgumentParser()
p.add_argument("--ours", required=True)
p.add_argument("--tirex", required=True)
p.add_argument("--output", required=True)
a = p.parse_args()

def key(value):
    parts = str(value).split("/")
    if len(parts) >= 4 and parts[-3] == parts[-2]:
        parts.pop(-2)
    # Our evaluator writes pandas' anchored weekly frequency (W-FRI), while
    # official GIFTEval result keys use the dataset frequency label W.
    if len(parts) >= 4 and parts[-2].upper().startswith("W-"):
        parts.pop(-2)
    return "/".join(parts).lower()

ours = pd.read_csv(a.ours)
tirex = pd.read_csv(a.tirex)
ours["key"] = ours["dataset"].map(key)
tirex["key"] = tirex["dataset"].map(key)
metrics = {
    "MASE": "eval_metrics/MASE[0.5]",
    "CRPS": "eval_metrics/mean_weighted_sum_quantile_loss",
}
left = ours[["dataset", "key", *metrics.values()]].rename(
    columns={value: f"ours_{name}" for name, value in metrics.items()}
)
right = tirex[["key", *metrics.values()]].rename(
    columns={value: f"tirex2_{name}" for name, value in metrics.items()}
)
result = left.merge(right, on="key", how="left")
for name in metrics:
    result[f"gap_vs_tirex2_{name}_pct"] = (
        result[f"ours_{name}"] / result[f"tirex2_{name}"] - 1.0
    ) * 100.0
result = result.sort_values("gap_vs_tirex2_MASE_pct", ascending=False)
Path(a.output).parent.mkdir(parents=True, exist_ok=True)
result.to_csv(a.output, index=False)
print(result.to_string(index=False))
