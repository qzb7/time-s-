from __future__ import annotations

import argparse
import contextlib
import json
import math
import os
import random
import sys
from pathlib import Path

import numpy as np
import torch
import torch.distributed as dist
import zarr
from torch.nn.parallel import DistributedDataParallel
from torch.utils.data import DataLoader, IterableDataset


def parse_bool(v):
    if isinstance(v, bool):
        return v
    return str(v).lower() in {"1", "true", "yes", "y", "on"}


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--model_name_or_path", required=True)
    p.add_argument("--metadata_root", required=True)
    p.add_argument("--new_clean_data_dirs", nargs="+", required=True)
    p.add_argument("--old_clean_data_dirs", nargs="+", required=True)
    p.add_argument("--earlier_context_data_dirs", nargs="+", required=True)
    p.add_argument("--previous_targeted_data_dir", required=True)
    p.add_argument("--new_targeted_data_dir", required=True)
    p.add_argument("--time_test_data_dir", required=True)
    p.add_argument("--time_test_ratio", type=float, default=0.10)
    p.add_argument("--gifteval_test_ratio", type=float, default=0.30)
    p.add_argument("--new_clean_ratio", type=float, default=0.45)
    p.add_argument("--old_clean_ratio", type=float, default=0.30)
    p.add_argument("--gift_short_ratio", type=float, default=0.60)
    p.add_argument("--gift_medium_ratio", type=float, default=0.15)
    p.add_argument("--gift_long_ratio", type=float, default=0.25)
    p.add_argument("--test_boost_steps", type=int, default=1_000)
    p.add_argument("--strong_mix_steps", type=int, default=2_500)
    p.add_argument("--stabilize_mix_steps", type=int, default=2_500)
    p.add_argument("--phase_c_targeted_ratio", type=float, default=0.15)
    p.add_argument("--new_only_steps", type=int, default=1_000)
    p.add_argument("--new_mix_ratio", type=float, default=0.4)
    p.add_argument("--early_mix_steps", type=int, default=1_000)
    p.add_argument("--early_new_ratio", type=float, default=0.7)
    p.add_argument("--late_new_ratio", type=float, default=0.5)
    p.add_argument("--output_dir", required=True)
    p.add_argument("--toto2_src", default="/home/toto-main/toto2")
    p.add_argument("--max_steps", type=int, default=1_000_000)
    p.add_argument("--stage1_steps", type=int, default=2_500)
    p.add_argument("--save_steps", type=int, default=500)
    p.add_argument("--logging_steps", type=int, default=1)
    p.add_argument("--per_device_train_batch_size", type=int, default=112)
    p.add_argument("--gradient_accumulation_steps", type=int, default=1)
    p.add_argument("--learning_rate", type=float, default=5e-5)
    p.add_argument("--min_learning_rate", type=float, default=5e-6)
    p.add_argument("--warmup_steps", type=int, default=1_000)
    p.add_argument("--weight_decay", type=float, default=0.01)
    p.add_argument("--max_grad_norm", type=float, default=1.0)
    p.add_argument("--cpm_max_span_patches", type=int, default=4)
    p.add_argument("--cpm_max_mask_probability", type=float, default=0.4)
    p.add_argument("--image_dim", type=int, default=512)
    p.add_argument("--text_dim", type=int, default=512)
    p.add_argument("--num_workers", type=int, default=0)
    p.add_argument("--bf16", type=parse_bool, default=False)
    p.add_argument("--seed", type=int, default=5252)
    p.add_argument("--resume_from_checkpoint", default=None)
    return p.parse_args()


class TimeGiftCleanFixedHorizonDataset(IterableDataset):
    """Fixed source mix while preserving natural horizon frequencies."""

    def __init__(
        self,
        dataset_cls,
        new_clean_dirs,
        old_clean_dirs,
        earlier_context_dirs,
        previous_targeted_dir,
        new_targeted_dir,
        time_test_dir,
        batch_size,
        source_ratios,
        gift_horizon_ratios,
        seed,
    ):
        super().__init__()
        self.dataset_cls = dataset_cls
        self.new_clean_dirs = tuple(new_clean_dirs)
        self.old_clean_dirs = tuple(old_clean_dirs)
        self.earlier_context_dirs = tuple(earlier_context_dirs)
        self.previous_targeted_dir = str(previous_targeted_dir)
        self.new_targeted_dir = str(new_targeted_dir)
        self.time_test_dir = str(time_test_dir)
        self.batch_size = int(batch_size)
        self.source_ratios = tuple(float(x) for x in source_ratios)
        self.gift_horizon_ratios = tuple(float(x) for x in gift_horizon_ratios)
        self.seed = int(seed)
        if len(self.source_ratios) != 4 or not math.isclose(sum(self.source_ratios), 1.0):
            raise ValueError(f"TIME/GIFTEval/new-clean/old-clean ratios must sum to 1, got {self.source_ratios}")
        if len(self.gift_horizon_ratios) != 3 or not math.isclose(sum(self.gift_horizon_ratios), 1.0):
            raise ValueError(
                f"GIFTEval short/medium/long ratios must sum to 1, got {self.gift_horizon_ratios}"
            )

    @staticmethod
    def _take(iterator, count, group):
        for _ in range(count):
            row = next(iterator)
            row["mix_group"] = group
            yield row

    @staticmethod
    def _take_gifteval_horizon_balanced(iterator, counts):
        """Fill exact S/M/L quotas while reading the combined banks once.

        Legacy rows without a short/medium/long source_term and surplus rows
        for an already-full term are skipped.  The stored term distribution is
        close to 60/15/25, so rejection overhead stays small and no large tensor
        queues accumulate in host memory.
        """
        terms = ("short", "medium", "long")
        remaining = dict(zip(terms, counts))
        while any(remaining.values()):
            row = next(iterator)
            term = str(row.get("source_term", "")).lower()
            if term not in remaining or remaining[term] <= 0:
                continue
            row["mix_group"] = "gifteval_test"
            remaining[term] -= 1
            yield row

    def _mixed_forever(self, iterators, groups):
        previous = [0] * len(self.source_ratios)
        local_step = 0
        while True:
            counts = []
            for index, ratio in enumerate(self.source_ratios[:-1]):
                cumulative = round((local_step + 1) * self.batch_size * ratio)
                counts.append(cumulative - previous[index])
                previous[index] = cumulative
            counts.append(self.batch_size - sum(counts))
            yield from self._take(iterators[0], counts[0], groups[0])
            yield from self._take(iterators[1], counts[1], groups[1])
            yield from self._take(iterators[2], counts[2], groups[2])
            yield from self._take(iterators[3], counts[3], groups[3])
            local_step += 1

    def __iter__(self):
        gifteval_test_dirs = [
            *self.earlier_context_dirs,
            self.previous_targeted_dir,
            self.new_targeted_dir,
        ]
        iterators = (
            iter(self.dataset_cls([self.time_test_dir], seed=self.seed + 11)),
            iter(self.dataset_cls(gifteval_test_dirs, seed=self.seed + 23)),
            iter(self.dataset_cls(self.new_clean_dirs, seed=self.seed + 37)),
            iter(self.dataset_cls(self.old_clean_dirs, seed=self.seed + 41)),
        )
        groups = ("time_test", "gifteval_test", "new_clean", "old_clean")
        yield from self._mixed_forever(iterators, groups)


def setup(args):
    sys.path.insert(0, args.toto2_src)
    rank = int(os.environ.get("RANK", "0"))
    local_rank = int(os.environ.get("LOCAL_RANK", "0"))
    world = int(os.environ.get("WORLD_SIZE", "1"))
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA is required")
    torch.cuda.set_device(local_rank)
    if world > 1:
        dist.init_process_group("nccl")
    return rank, local_rank, world, torch.device("cuda", local_rank)


def cosine_factor(step, max_steps, min_lr, lr, warmup_steps):
    current = step + 1
    if warmup_steps and current <= warmup_steps:
        return current / warmup_steps
    decay_steps = max(1, max_steps - warmup_steps)
    progress = min(1.0, max(0.0, (current - warmup_steps) / decay_steps))
    return min_lr / lr + (1.0 - min_lr / lr) * 0.5 * (1.0 + math.cos(math.pi * progress))


def modal_loss(pred, target, masked, world):
    pred = pred[..., :-1, :]
    target = target[..., 1:, :]
    mask = masked[..., 1:].unsqueeze(-1).to(pred.dtype)
    per_patch = torch.nn.functional.smooth_l1_loss(pred, target, reduction="none").mean(dim=-1)
    valid_patch = mask.squeeze(-1).bool()
    local_sum = (per_patch * valid_patch).sum(dtype=torch.float32)
    local_count = valid_patch.sum(dtype=torch.float32)
    global_sum = local_sum.detach().clone()
    global_count = local_count.detach().clone()
    if world > 1:
        dist.all_reduce(global_sum)
        dist.all_reduce(global_count)
    return local_sum * world / global_count.clamp_min(1.0), global_sum / global_count.clamp_min(1.0), global_count


def toto_pinball_loss_global_masked_patch_average(outputs, prepared, *, patch_size, world_size):
    """Quantile -> valid points/patch -> distributed global masked-patch mean."""
    target = prepared["target"]
    target_mask = prepared["target_mask"]
    total_length = target.shape[-1]
    if total_length % patch_size:
        raise ValueError(
            f"Toto inputs must be patch aligned: total={total_length}, patch={patch_size}."
        )
    num_patches = total_length // patch_size
    predicted = outputs.quantiles[..., :-1, :]
    scaled_target = torch.asinh((target - outputs.loc) / outputs.scale)
    target_patches = scaled_target.unflatten(-1, (num_patches, patch_size))[..., 1:, :]
    point_valid = target_mask.unflatten(-1, (num_patches, patch_size))[..., 1:, :]
    supervised_patch = prepared["masked_patches"][..., 1:]
    valid = point_valid & supervised_patch.unsqueeze(-1)
    if predicted.shape[1:] != target_patches.shape:
        raise RuntimeError(
            f"Unexpected Toto output shape {tuple(predicted.shape)} for "
            f"target patches {tuple(target_patches.shape)}."
        )

    quantile_levels = torch.tensor(
        [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9],
        device=predicted.device,
        dtype=predicted.dtype,
    ).view(-1, *([1] * (predicted.ndim - 1)))
    errors = target_patches.unsqueeze(0) - predicted
    pinball = torch.maximum(
        quantile_levels * errors, (quantile_levels - 1.0) * errors
    )
    point_loss = pinball.mean(dim=0, dtype=torch.float32)

    valid_points_per_patch = valid.sum(dim=-1)
    valid_patch = supervised_patch & (valid_points_per_patch > 0)
    patch_loss = (
        (point_loss * valid).sum(dim=-1)
        / valid_points_per_patch.clamp_min(1)
    )
    local_loss_sum = (patch_loss * valid_patch).sum(dtype=torch.float32)
    local_patch_count = valid_patch.sum(dtype=torch.float32)
    global_patch_count = local_patch_count.detach().clone()
    if world_size > 1:
        dist.all_reduce(global_patch_count)
    if global_patch_count.item() <= 0:
        raise RuntimeError("The distributed micro-batch has no valid CPM patch.")

    # DDP averages gradients; multiplying by world_size recovers the exact
    # distributed global masked-patch mean.
    loss = local_loss_sum * world_size / global_patch_count
    with torch.no_grad():
        global_loss_sum = local_loss_sum.detach().clone()
        global_valid_points = valid.sum(dtype=torch.float32)
        global_valid_series = (valid_patch.sum(dim=-1) > 0).sum(dtype=torch.float32)
        if world_size > 1:
            dist.all_reduce(global_loss_sum)
            dist.all_reduce(global_valid_points)
            dist.all_reduce(global_valid_series)
        global_loss = global_loss_sum / global_patch_count
    return loss, {
        "loss": global_loss,
        "valid_masked_points": global_valid_points,
        "masked_patches": global_patch_count,
        "valid_series": global_valid_series,
    }


def sample_tail_first_patch_mask(
    target_mask, *, patch_size, max_span_patches, max_mask_probability
):
    """Always mask a random 1--K patch suffix, then fill up to <=40% elsewhere."""
    if max_span_patches < 1:
        raise ValueError("max_span_patches must be positive")
    if not 0.0 < max_mask_probability <= 1.0:
        raise ValueError("max_mask_probability must be in (0, 1]")
    if target_mask.shape[-1] % patch_size:
        raise ValueError("target length must be patch aligned")
    patch_valid = target_mask.unflatten(
        -1, (target_mask.shape[-1] // patch_size, patch_size)
    ).any(dim=-1)
    masked = torch.zeros_like(patch_valid)
    flat_valid = patch_valid.reshape(-1, patch_valid.shape[-1])
    flat_masked = masked.reshape(-1, masked.shape[-1])
    for row in range(flat_valid.shape[0]):
        valid = torch.where(flat_valid[row])[0]
        # The first valid patch must remain visible because output patch t-1
        # supervises target patch t.
        if valid.numel() < 2:
            continue
        eligible = valid[1:]
        # Preserve the original CPM coverage distribution: draw p uniformly
        # from [0, max_mask_probability] and round p * eligible_count.
        probability = float(torch.rand((), device=target_mask.device).item())
        probability *= max_mask_probability
        target_count = max(1, int(round(probability * eligible.numel())))
        target_count = min(target_count, max(1, int(math.floor(max_mask_probability * eligible.numel()))))
        # The only semantic addition to the old CPM sampler: guarantee that a
        # random 1--4-patch suffix is selected first.
        tail_span = int(torch.randint(
            1, min(max_span_patches, target_count, eligible.numel()) + 1,
            (), device=target_mask.device,
        ).item())
        flat_masked[row, eligible[-tail_span:]] = True

        interior = eligible[:-tail_span]
        attempts = 0
        while int(flat_masked[row].sum().item()) < target_count and interior.numel() and attempts < 8 * flat_valid.shape[-1]:
            remaining = target_count - int(flat_masked[row].sum().item())
            span = int(torch.randint(
                1, min(max_span_patches, remaining) + 1,
                (), device=target_mask.device,
            ).item())
            start_pos = int(torch.randint(0, interior.numel(), (), device=target_mask.device).item())
            chosen = interior[start_pos : min(interior.numel(), start_pos + span)]
            chosen = chosen[~flat_masked[row, chosen]][:remaining]
            flat_masked[row, chosen] = True
            attempts += 1
    cpm_mask = (~masked).repeat_interleave(patch_size, dim=-1)
    return cpm_mask, masked


def prepare_tail_first_batch(batch, device, *, patch_size, max_span_patches, max_mask_probability):
    target = batch["target"].to(device, non_blocking=True).unsqueeze(1)
    target_mask = batch["target_mask"].to(device, non_blocking=True).unsqueeze(1).bool()
    cpm_mask, masked_patches = sample_tail_first_patch_mask(
        target_mask,
        patch_size=patch_size,
        max_span_patches=max_span_patches,
        max_mask_probability=max_mask_probability,
    )
    # Only the newly generated bank uses horizon-aware suffix supervision.
    # The old banks retain their proven 1--4 suffix + random CPM behavior.
    source_banks = batch.get("source_bank", [])
    source_terms = batch.get("source_term", [])
    source_datasets = batch.get("source_dataset", [])
    mix_groups = batch.get("mix_group", [])
    flat_valid = target_mask.unflatten(
        -1, (target_mask.shape[-1] // patch_size, patch_size)
    ).any(dim=-1).reshape(-1, target_mask.shape[-1] // patch_size)
    flat_masked = masked_patches.reshape(-1, masked_patches.shape[-1])
    for row in range(flat_valid.shape[0]):
        dataset_name = (
            source_datasets[row].lower() if row < len(source_datasets) else ""
        )
        is_m4_short = dataset_name in {
            "m4_yearly",
            "m4_quarterly",
            "m4_monthly",
            "m4_weekly",
            "m4_daily",
            "m4_hourly",
        }
        is_new = (
            (row < len(mix_groups) and mix_groups[row] == "new")
            or (
                row < len(source_banks)
                and source_banks[row]
                == "toto2_multimodal_gifteval_test_context_nonsolar_targeted_400k"
            )
            or is_m4_short
        )
        if not is_new:
            continue
        valid = torch.where(flat_valid[row])[0]
        if valid.numel() < 2:
            flat_masked[row].zero_()
            continue
        eligible = valid[1:]
        term = source_terms[row].lower() if row < len(source_terms) else "short"
        if dataset_name == "m4_hourly":
            low, high = (2, 2)
        elif is_m4_short:
            low, high = (1, 1)
        else:
            low, high = {
                "short": (1, 4),
                "medium": (4, 8),
                "long": (8, 12),
            }.get(term, (1, 4))
        high = min(high, int(eligible.numel()))
        low = min(low, high)
        span = int(torch.randint(low, high + 1, (), device=target_mask.device).item())
        flat_masked[row].zero_()
        flat_masked[row, eligible[-span:]] = True
    cpm_mask = (~masked_patches).repeat_interleave(patch_size, dim=-1)
    if not masked_patches.any():
        raise RuntimeError("distributed micro-batch has no valid CPM patch")
    return {
        "target": target,
        "target_mask": target_mask,
        "cpm_mask": cpm_mask,
        "masked_patches": masked_patches,
        "series_ids": torch.zeros(target.shape[:-1], dtype=torch.long, device=device),
    }


def set_stage(model, stage1: bool):
    """Learn metadata mapping first, then jointly tune layer 16+ and all modalities."""
    model.requires_grad_(False)
    if not stage1:
        layers = model.base_model.transformer.layers
        if len(layers) != 24:
            raise ValueError(f"Expected 24 transformer layers, got {len(layers)}")
        for layer_index in range(16, 24):
            layers[layer_index].requires_grad_(True)
        model.base_model.transformer.out_norm.requires_grad_(True)
        model.base_model.output_head.requires_grad_(True)
    model.metadata_type_embedding.requires_grad = True
    model.metadata_position_embedding.requires_grad = True
    model.metadata_projector.requires_grad_(True)
    if not stage1:
        for module in (
            model.image_projector,
            model.text_projector,
            model.image_decoder,
            model.text_decoder,
        ):
            module.requires_grad_(True)
        model.image_mask_token.requires_grad = True
        model.text_mask_token.requires_grad = True


def parameter_counts(model):
    total = sum(parameter.numel() for parameter in model.parameters())
    trainable = sum(
        parameter.numel() for parameter in model.parameters() if parameter.requires_grad
    )
    return total, trainable


def wrap_ddp(raw_model, local_rank, world):
    if world <= 1:
        return raw_model
    return DistributedDataParallel(
        raw_model,
        device_ids=[local_rank],
        output_device=local_rank,
        find_unused_parameters=False,
    )


def save_checkpoint(model, out, step, optimizer, scheduler, args, stage):
    path = Path(out) / f"checkpoint-{step}"
    path.mkdir(parents=True, exist_ok=True)
    model.save_pretrained(path)
    torch.save(
        {
            "global_step": step,
            "optimizer": optimizer.state_dict(),
            "scheduler": scheduler.state_dict(),
            "stage": stage,
            "torch_rng_state": torch.get_rng_state(),
            "cuda_rng_state_all": torch.cuda.get_rng_state_all(),
        },
        path / "training_state.pt",
    )
    (path / "training_args.json").write_text(json.dumps(vars(args), indent=2, sort_keys=True) + "\n")


def main():
    args = parse_args()
    rank, local_rank, world, device = setup(args)
    random.seed(args.seed + rank)
    np.random.seed(args.seed + rank)
    torch.manual_seed(args.seed + rank)
    torch.cuda.manual_seed_all(args.seed + rank)

    from load_toto2_multimodal_zarr import Toto2MultimodalZarrDataset
    from pretrain_toto2_short_balanced import toto_pinball_loss
    from toto2_layer16_metadata_token_model import Toto2Layer16MetadataTokenModel

    metadata_root = Path(args.metadata_root)
    if not (metadata_root / ".complete").is_file():
        raise RuntimeError(f"Metadata index is incomplete: {metadata_root}")
    metadata_plan = json.loads((metadata_root / "generation_plan.json").read_text())
    metadata_table = np.load(metadata_root / "metadata_embeddings.fp16.npy", mmap_mode="r")
    metadata_sidecars = {}
    for item in metadata_plan["stores"]:
        store = str(Path(item["store"]).resolve())
        root = Path(item["root"])
        relative = Path(store).relative_to(root)
        alias = root.name.lstrip(".")
        sidecar = metadata_root / "sidecars" / alias / relative.parent / f"{relative.name}.metadata_id.npy"
        if not sidecar.is_file():
            raise FileNotFoundError(f"Missing metadata sidecar for {store}: {sidecar}")
        metadata_sidecars[store] = sidecar

    class SourceAwareToto2MultimodalZarrDataset(Toto2MultimodalZarrDataset):
        def _read_chunk(self, path, left, right, order):
            group = zarr.open_group(str(path), mode="r")
            resolved_path = str(Path(path).resolve())
            sidecar_path = metadata_sidecars.get(resolved_path)
            if sidecar_path is None:
                raise RuntimeError(f"Zarr store is not covered by metadata index: {resolved_path}")
            metadata_ids = np.load(sidecar_path, mmap_mode="r")[left:right]
            count = right - left
            if "source_term" in group:
                terms = [
                    value.decode().rstrip("\x00")
                    for value in group["source_term"][left:right]
                ]
            else:
                terms = [""] * count
            if "source_dataset" in group:
                datasets = [
                    value.decode().rstrip("\x00")
                    for value in group["source_dataset"][left:right]
                ]
            else:
                datasets = [""] * count
            bank = path.parent.name
            for index, row in zip(order, super()._read_chunk(path, left, right, order)):
                i = int(index)
                term = terms[i]
                dataset = datasets[i]
                # The legacy 29,106-row test-context bank predates the
                # short/medium/long labels.  Its M4 rows are short-horizon
                # forecasting examples and must not be rejected by the exact
                # horizon sampler.
                if term.startswith("test_input_") and dataset.lower() in {
                    "m4_yearly",
                    "m4_hourly",
                }:
                    term = "short"
                row["source_term"] = term
                row["source_dataset"] = dataset
                row["source_bank"] = bank
                row["metadata_embedding"] = np.asarray(
                    metadata_table[int(metadata_ids[i])], dtype=np.float16
                )
                yield row

    raw_model = Toto2Layer16MetadataTokenModel.from_pretrained(
        args.model_name_or_path, map_location="cpu"
    )
    if raw_model.patch_size != 32:
        raise ValueError(f"Expected patch_size=32, got {raw_model.patch_size}")
    set_stage(raw_model, stage1=True)
    raw_model.to(device)
    model = wrap_ddp(raw_model, local_rank, world)
    raw_model = model.module if isinstance(model, DistributedDataParallel) else model

    optimizer = torch.optim.AdamW(raw_model.parameters(), lr=args.learning_rate, weight_decay=args.weight_decay)
    scheduler = torch.optim.lr_scheduler.LambdaLR(optimizer, lambda s: cosine_factor(s, args.max_steps, args.min_learning_rate, args.learning_rate, args.warmup_steps))
    start_step = 0
    if args.resume_from_checkpoint:
        state_path = Path(args.resume_from_checkpoint) / "training_state.pt"
        if not state_path.exists():
            raise FileNotFoundError(f"Missing resume state: {state_path}")
        state = torch.load(state_path, map_location="cpu")
        optimizer.load_state_dict(state["optimizer"])
        scheduler.load_state_dict(state["scheduler"])
        start_step = int(state.get("global_step", 0))
        if "torch_rng_state" in state:
            torch.set_rng_state(state["torch_rng_state"])
        if torch.cuda.is_available() and "cuda_rng_state_all" in state:
            torch.cuda.set_rng_state_all(state["cuda_rng_state_all"])
        if rank == 0:
            print(json.dumps({"event": "resume", "checkpoint": args.resume_from_checkpoint, "global_step": start_step}, sort_keys=True), flush=True)
    def resolve_dirs(data_dirs):
        resolved = []
        for data_dir in data_dirs:
            root = Path(data_dir)
            resolved.append(str(root / "generation") if (root / "generation").is_dir() else str(root))
        return resolved

    resolved_new_clean_dirs = resolve_dirs(args.new_clean_data_dirs)
    resolved_old_clean_dirs = resolve_dirs(args.old_clean_data_dirs)
    resolved_earlier_context_dirs = resolve_dirs(args.earlier_context_data_dirs)
    previous_root = Path(args.previous_targeted_data_dir)
    resolved_previous_targeted_dir = str(
        previous_root / "generation"
        if (previous_root / "generation").is_dir()
        else previous_root
    )
    new_root = Path(args.new_targeted_data_dir)
    resolved_new_targeted_dir = str(
        new_root / "generation" if (new_root / "generation").is_dir() else new_root
    )
    time_root = Path(args.time_test_data_dir)
    resolved_time_test_dir = str(
        time_root / "generation" if (time_root / "generation").is_dir() else time_root
    )
    train_dataset = TimeGiftCleanFixedHorizonDataset(
        SourceAwareToto2MultimodalZarrDataset,
        new_clean_dirs=resolved_new_clean_dirs,
        old_clean_dirs=resolved_old_clean_dirs,
        earlier_context_dirs=resolved_earlier_context_dirs,
        previous_targeted_dir=resolved_previous_targeted_dir,
        new_targeted_dir=resolved_new_targeted_dir,
        time_test_dir=resolved_time_test_dir,
        batch_size=args.per_device_train_batch_size,
        source_ratios=(args.time_test_ratio, args.gifteval_test_ratio, args.new_clean_ratio, args.old_clean_ratio),
        gift_horizon_ratios=(
            args.gift_short_ratio,
            args.gift_medium_ratio,
            args.gift_long_ratio,
        ),
        seed=args.seed,
    )
    loader_options = dict(num_workers=args.num_workers, pin_memory=True, drop_last=True)
    train_iterator = iter(DataLoader(
        train_dataset, batch_size=args.per_device_train_batch_size, **loader_options
    ))

    if rank == 0:
        total, trainable = parameter_counts(raw_model)
        print(json.dumps({"parameters": total, "trainable_parameters": trainable, "world_size": world, "effective_batch": args.per_device_train_batch_size * world * args.gradient_accumulation_steps, "stage1_steps": args.stage1_steps, "fusion_after_layer": 16, "fusion": "time_plus_image_plus_text_then_one_metadata_token", "optimizer_restored": False, "scheduler_restored": False, "loss_reduction": "quantile_mean_then_valid_point_patch_mean_then_global_masked_patch_mean_for_all_three_losses", "cpm_max_span_patches": args.cpm_max_span_patches, "max_steps": args.max_steps, "new_clean_data_dirs": resolved_new_clean_dirs, "old_clean_data_dirs": resolved_old_clean_dirs, "gifteval_test_data_dirs": [*resolved_earlier_context_dirs, resolved_previous_targeted_dir, resolved_new_targeted_dir], "time_test_data_dir": resolved_time_test_dir, "metadata_root": args.metadata_root, "local_schedule": {"time_gifteval_clean_unused": [args.time_test_ratio, args.gifteval_test_ratio, args.new_clean_ratio, args.old_clean_ratio], "gifteval_horizon_sampling": "natural_no_quota"}}, sort_keys=True), flush=True)

    optimizer.zero_grad(set_to_none=True)
    model.train()
    stage = 1 if start_step < args.stage1_steps else 2
    if stage == 2:
        # DDP was initially constructed while the backbone was frozen. Rewrap
        # after a stage-2 resume so newly trainable backbone parameters receive
        # gradient hooks and are synchronized across every rank.
        if world > 1:
            del model
            torch.cuda.empty_cache()
        set_stage(raw_model, stage1=False)
        model = wrap_ddp(raw_model, local_rank, world)
        raw_model = model.module if isinstance(model, DistributedDataParallel) else model
        model.train()
        if rank == 0:
            total, trainable = parameter_counts(raw_model)
            print(json.dumps({"event": "resume_stage2_ddp_rewrap", "step": start_step, "parameters": total, "trainable_parameters": trainable, "optimizer_restarted": False, "scheduler_restarted": False}), flush=True)
    for step in range(start_step, args.max_steps):
        if stage == 1 and step >= args.stage1_steps:
            if world > 1:
                dist.barrier()
                del model
                torch.cuda.empty_cache()
            set_stage(raw_model, stage1=False)
            model = wrap_ddp(raw_model, local_rank, world)
            raw_model = model.module if isinstance(model, DistributedDataParallel) else model
            model.train()
            stage = 2
            if rank == 0:
                total, trainable = parameter_counts(raw_model)
                print(json.dumps({"event": "unfreeze_layers_16_23_out_norm_output_head", "step": step + 1, "parameters": total, "trainable_parameters": trainable, "optimizer_restarted": False, "scheduler_restarted": False}), flush=True)
        stats = []
        for micro in range(args.gradient_accumulation_steps):
            batch = next(train_iterator)
            data_mix = (
                f"time{args.time_test_ratio:g}_gifteval{args.gifteval_test_ratio:g}"
                f"_clean{args.new_clean_ratio + args.old_clean_ratio:g}_giftSMLnatural"
            )
            prepared = prepare_tail_first_batch(batch, device, patch_size=raw_model.patch_size, max_span_patches=args.cpm_max_span_patches, max_mask_probability=args.cpm_max_mask_probability)
            image = batch["image_tokens"].to(device, non_blocking=True).unsqueeze(1)
            text = batch["text_tokens"].to(device, non_blocking=True).unsqueeze(1)
            sync = micro == args.gradient_accumulation_steps - 1
            ctx = contextlib.nullcontext() if sync or not isinstance(model, DistributedDataParallel) else model.no_sync()
            with ctx:
                with torch.autocast(device_type="cuda", dtype=torch.bfloat16, enabled=args.bf16):
                    metadata_embedding = batch["metadata_embedding"].to(device, non_blocking=True)
                    outputs, hidden = model(target=prepared["target"], target_mask=prepared["target_mask"], cpm_mask=prepared["cpm_mask"], series_ids=prepared["series_ids"], image_tokens=image, text_tokens=text, metadata_embedding=metadata_embedding)
                    task_loss, task_metrics = toto_pinball_loss_global_masked_patch_average(
                        outputs,
                        prepared,
                        patch_size=raw_model.patch_size,
                        world_size=world,
                    )
                    image_pred = raw_model.image_decoder(hidden)
                    text_pred = raw_model.text_decoder(hidden)
                    image_loss, image_global, image_count = modal_loss(image_pred, image, prepared["masked_patches"], world)
                    text_loss, text_global, _ = modal_loss(text_pred, text, prepared["masked_patches"], world)
                    loss = (task_loss + image_loss + text_loss) / args.gradient_accumulation_steps
                loss.backward()
            stats.append((task_metrics["loss"].detach(), image_global.detach(), text_global.detach(), image_count.detach()))
        grad = torch.nn.utils.clip_grad_norm_(raw_model.parameters(), args.max_grad_norm)
        optimizer.step()
        scheduler.step()
        optimizer.zero_grad(set_to_none=True)
        if rank == 0 and (step + 1) % args.logging_steps == 0:
            a = torch.stack([x[0] for x in stats]).mean().item()
            b = torch.stack([x[1] for x in stats]).mean().item()
            c = torch.stack([x[2] for x in stats]).mean().item()
            d = torch.stack([x[3] for x in stats]).mean().item()
            print(json.dumps({"step": step + 1, "stage": stage, "data_mix": data_mix, "loss": a + b + c, "loss_task": a, "loss_image": b, "loss_text": c, "masked_patches": d, "grad_norm": float(grad), "learning_rate": optimizer.param_groups[0]["lr"]}, sort_keys=True), flush=True)
        if (step + 1) % args.save_steps == 0 or step + 1 == args.max_steps:
            if world > 1:
                dist.barrier()
            if rank == 0:
                save_checkpoint(raw_model, args.output_dir, step + 1, optimizer, scheduler, args, stage)
            if world > 1:
                dist.barrier()
    if world > 1:
        dist.destroy_process_group()


if __name__ == "__main__":
    main()
