from __future__ import annotations
import argparse, csv, importlib.util, json, math, os, sys, traceback
from pathlib import Path
import numpy as np
import torch
from gluonts.ev.metrics import MAE, MAPE, MASE, MSE, MSIS, ND, NRMSE, RMSE, SMAPE, MeanWeightedSumQuantileLoss
from gluonts.model import evaluate_model
from gluonts.model.forecast import QuantileForecast
from gluonts.time_feature import get_seasonality

QUANTILES=[0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9]
CSV_HEADER=["dataset","checkpoint","model","eval_metrics/MSE[mean]","eval_metrics/MSE[0.5]","eval_metrics/MAE[0.5]","eval_metrics/MASE[0.5]","eval_metrics/MAPE[0.5]","eval_metrics/sMAPE[0.5]","eval_metrics/MSIS","eval_metrics/RMSE[mean]","eval_metrics/NRMSE[mean]","eval_metrics/ND[0.5]","eval_metrics/mean_weighted_sum_quantile_loss","domain","num_variates","term"]

def args():
 p=argparse.ArgumentParser()
 p.add_argument("--checkpoint",required=True); p.add_argument("--data_dir",required=True)
 p.add_argument("--output_dir",required=True); p.add_argument("--model_name",required=True)
 p.add_argument("--gift_eval_path",default="/data/GIFTEval"); p.add_argument("--gift_eval_src",default="/home/chronos-forecasting-main/gift-eval/src")
 p.add_argument("--toto2_src",default="/home/toto-main/toto2"); p.add_argument("--batch_size",type=int,default=128)
 p.add_argument("--device",default="cuda:0"); p.add_argument("--shard_id",type=int,default=0); p.add_argument("--num_shards",type=int,default=1)
 return p.parse_args()

def load_common():
 path=Path("/home/chronos-forecasting-main/evaluate_chronos2_gifteval_chy_aligned.py")
 spec=importlib.util.spec_from_file_location("common",path); mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod

class FixedPredictor:
 def __init__(self, forecasts): self.forecasts=forecasts
 def predict(self, dataset, **kwargs):
  yield from self.forecasts

def impute_for_model(target: np.ndarray, valid: np.ndarray) -> np.ndarray:
    """Match the pure Toto2 evaluator's forward-fill input handling."""
    target = np.asarray(target, dtype=np.float32)
    valid = np.asarray(valid, dtype=bool) & np.isfinite(target)
    if not valid.any():
        return np.zeros_like(target, dtype=np.float32)
    first = int(np.flatnonzero(valid)[0])
    out = target.copy()
    out[~valid] = np.nan
    out[:first] = out[first]
    last = out[first]
    for i in range(first, len(out)):
        if valid[i]:
            last = out[i]
        else:
            out[i] = last
    return np.nan_to_num(out, nan=0.0, posinf=0.0, neginf=0.0).astype(np.float32)


def impute_batch_for_model(target: np.ndarray, valid: np.ndarray) -> np.ndarray:
    """Vectorized equivalent of impute_for_model for [batch, time]."""
    target = np.asarray(target, dtype=np.float32)
    valid = np.asarray(valid, dtype=np.bool_) & np.isfinite(target)
    batch, length = target.shape
    any_valid = valid.any(axis=1)
    safe = np.nan_to_num(target, nan=0.0, posinf=0.0, neginf=0.0)
    source_index = np.where(valid, np.arange(length, dtype=np.int32)[None, :], 0)
    np.maximum.accumulate(source_index, axis=1, out=source_index)
    output = np.take_along_axis(safe, source_index, axis=1)
    first_index = valid.argmax(axis=1)
    first_value = safe[np.arange(batch), first_index]
    leading = np.arange(length)[None, :] < first_index[:, None]
    output = np.where(leading, first_value[:, None], output)
    output[~any_valid] = 0.0
    return output.astype(np.float32, copy=False)


def forecast_batch(model, target, target_mask, image, text, horizon, device):
    q = model.forecast_parallel(
        target, target_mask, image, text, int(horizon),
        has_missing_values=True, scaler_fallback_min_obs=8,
    )
    if q.is_sparse:
        q = q.to_dense()
    if q.ndim == 5:
        q = q.flatten(-2, -1)
    return q.permute(1, 2, 0, 3)

def metric_value(result,name):
 v=result[name]
 return float(v.iloc[0]) if hasattr(v,"iloc") else float(v[0])

def move_model_unique(model, device, dtype):
 """Move shared Toto2 parameters once instead of repeated Module._apply copies."""
 with torch.no_grad():
  for parameter in model.parameters():
   parameter.data=parameter.data.to(device=device,dtype=dtype)
   if parameter.grad is not None:
    parameter.grad=None
  for buffer in model.buffers():
   target_dtype=dtype if buffer.is_floating_point() else buffer.dtype
   buffer.data=buffer.data.to(device=device,dtype=target_dtype)
 return model

def main():
 a=args(); os.environ["GIFT_EVAL"]=a.gift_eval_path; os.environ["GIFT_EVAL_PATH"]=a.gift_eval_path
 sys.path[:0]=["/home/toto-main/dd_unit_scaling","/home/toto-main",a.toto2_src,"/home/chronos-forecasting-main/src",a.gift_eval_src]
 from gift_eval.data import Dataset
 from toto2_layer8_additive_model import Toto2Layer8AdditiveMultimodalModel
 root=Path(a.data_dir); configs=[]
 for manifest_path in sorted(root.glob("*/manifest.json")):
  try:
   manifest=json.loads(manifest_path.read_text())
   configs.append((manifest["dataset"],manifest["term"],manifest_path.parent,manifest))
  except Exception as e: print("manifest skip",manifest_path,repr(e),flush=True)
 configs=sorted(configs,key=lambda x:(x[0],x[1]))[a.shard_id::a.num_shards]
 print(f"Grouped configs assigned: {len(configs)}",flush=True)
 device=torch.device(a.device)
 model=Toto2Layer8AdditiveMultimodalModel.from_pretrained(a.checkpoint,map_location="cpu")
 model=move_model_unique(model,device,torch.float32).eval()
 outdir=Path(a.output_dir); outdir.mkdir(parents=True,exist_ok=True)
 csvpath=outdir/f"all_results.shard-{a.shard_id}.csv"
 with csvpath.open("w",newline="") as f:
  csv.writer(f).writerow(CSV_HEADER)
 for config_index,(dataset_name,term,config_dir,manifest) in enumerate(configs,1):
  try:
   meta=Dataset(name=dataset_name,term=term,to_univariate=False)
   uni=Dataset(name=dataset_name,term=term,to_univariate=meta.target_dim!=1)
   pairs=list(zip(uni.test_data.input,uni.test_data.label))
   eval_inputs=[]; eval_labels=[]; forecasts=[]; seen=0
   for shard_info in manifest["shards"]:
    npz=config_dir/shard_info["file"]
    try:
     with np.load(npz,allow_pickle=False) as z:
      target_all=np.asarray(z["time_series_8192"],np.float32)
      tm_all=np.asarray(z["target_mask_8192"],np.bool_)
      pm_all=np.asarray(z["padding_mask_8192"],np.bool_)
      image_all=np.asarray(z["image_global"],np.float32)
      text_all=np.asarray(z["text_global"],np.float32)
      wi_all=np.asarray(z["window_index"],np.int64)
      vi_all=np.asarray(z["variate_index"],np.int32)
      count=len(wi_all)
      if target_all.shape!=(count,8192) or tm_all.shape!=(count,8192) or pm_all.shape!=(count,8192): raise ValueError("time/mask shape")
      if image_all.shape!=(count,256,512) or text_all.shape!=(count,256,512): raise ValueError("modal shape")
      for start in range(0,count,a.batch_size):
       stop=min(start+a.batch_size,count)
       wi=wi_all[start:stop]; vi=vi_all[start:stop]
       in_range=wi<len(pairs)
       if not in_range.all(): print("skip out-of-range",dataset_name,term,int((~in_range).sum()),len(pairs),flush=True)
       if not in_range.any(): continue
       wi=wi[in_range]; vi=vi[in_range]
       raw_target=target_all[start:stop][in_range]
       tm=tm_all[start:stop][in_range] & ~pm_all[start:stop][in_range] & np.isfinite(raw_target)
       target=impute_batch_for_model(raw_target,tm)
       image=np.nan_to_num(image_all[start:stop][in_range],nan=0.0,posinf=0.0,neginf=0.0)
       text=np.nan_to_num(text_all[start:stop][in_range],nan=0.0,posinf=0.0,neginf=0.0)
       t=torch.from_numpy(np.ascontiguousarray(target)).to(device).unsqueeze(1)
       m=torch.from_numpy(np.ascontiguousarray(tm)).to(device).unsqueeze(1)
       im=torch.from_numpy(np.ascontiguousarray(image)).to(device).unsqueeze(1)
       tx=torch.from_numpy(np.ascontiguousarray(text)).to(device).unsqueeze(1)
       horizon=int(uni.prediction_length)
       with torch.inference_mode(): pred=forecast_batch(model,t,m,im,tx,horizon,device).cpu().numpy()
       for j,window_index in enumerate(wi):
        lab=pairs[int(window_index)][1]
        if not np.isfinite(pred[j]).all():
         print(f"sample skip nonfinite forecast {dataset_name}/{term} window={window_index} variate={vi[j]}",flush=True)
         continue
        forecasts.append(QuantileForecast(pred[j,0,:,:],lab["start"],[str(q) for q in QUANTILES],item_id=lab.get("item_id")))
        eval_inputs.append(pairs[int(window_index)][0]); eval_labels.append(lab)
       seen+=len(wi)
       print(f"Progress {config_index}/{len(configs)} {dataset_name}/{term}: {seen}/{manifest['written_samples']}",flush=True)
    except Exception as e:
     print(f"shard failed {npz}: {type(e).__name__}: {e}",flush=True); raise
   if not forecasts: continue
   class TD: pass
   td=TD(); td.input=eval_inputs; td.label=eval_labels
   result=evaluate_model(FixedPredictor(forecasts),test_data=td,metrics=[MSE(forecast_type="mean"),MSE(forecast_type=0.5),MAE(),MASE(),MAPE(),SMAPE(),MSIS(),RMSE(),NRMSE(),ND(),MeanWeightedSumQuantileLoss(quantile_levels=QUANTILES)],batch_size=a.batch_size,axis=None,mask_invalid_label=True,allow_nan_forecast=False,seasonality=get_seasonality(uni.freq))
   row=[f"{dataset_name}/{uni.freq}/{term}",a.checkpoint,a.model_name,metric_value(result,"MSE[mean]"),metric_value(result,"MSE[0.5]"),metric_value(result,"MAE[0.5]"),metric_value(result,"MASE[0.5]"),metric_value(result,"MAPE[0.5]"),metric_value(result,"sMAPE[0.5]"),metric_value(result,"MSIS"),metric_value(result,"RMSE[mean]"),metric_value(result,"NRMSE[mean]"),metric_value(result,"ND[0.5]"),metric_value(result,"mean_weighted_sum_quantile_loss"),"Unknown",meta.target_dim,term]
   with csvpath.open("a",newline="") as f: csv.writer(f).writerow(row)
   print(f"Wrote {dataset_name}/{term}: {len(forecasts)} samples ({config_index}/{len(configs)})",flush=True)
  except Exception:
   traceback.print_exc(); raise

if __name__=="__main__": main()
