#!/usr/bin/env python3
import csv
import sys
from pathlib import Path

path = Path(sys.argv[1])
model = sys.argv[2]
with path.open(newline="") as handle:
    rows = list(csv.DictReader(handle))
if not rows:
    raise RuntimeError(f"empty leaderboard: {path}")
fields = list(rows[0])
matched = 0
for row in rows:
    if row.get("model") == model:
        row["Test Leak."] = "Transductive test context"
        matched += 1
if matched != 1:
    raise RuntimeError(f"expected one target leaderboard row, got {matched}")
tmp = path.with_suffix(path.suffix + ".tmp")
with tmp.open("w", newline="") as handle:
    writer = csv.DictWriter(handle, fieldnames=fields)
    writer.writeheader()
    writer.writerows(rows)
tmp.replace(path)
print(f"marked transductive: {model}")
