#!/usr/bin/env python3
import csv
import math
import os
import sys
from pathlib import Path

ROOT = Path(os.environ.get("RESULT_ROOT", "/home/toto-main/results/toto2-313m-multimodal-localstationarity-gifteval"))
GIFT_ROOT = Path(os.environ.get("GIFT_ROOT", "/home/chronos-forecasting-main/gift-eval/results"))
BASELINE = GIFT_ROOT / "seasonal_naive" / "all_results.csv"
MASE = "eval_metrics/MASE[0.5]"
CRPS = "eval_metrics/mean_weighted_sum_quantile_loss"

def canon(name):
    parts = str(name).strip().lower().split("/")
    if len(parts) >= 4 and parts[1] == parts[2]:
        parts.pop(1)
    if len(parts) == 4 and parts[-2] in {"w-fri", "w-thu", "w-wed", "w-tue", "w-sun"}:
        parts.pop(-2)
    dataset_alias = {
        "car_parts_with_missing": "car_parts",
        "kdd_cup_2018_with_missing": "kdd_cup_2018",
        "saugeenday": "saugeen",
        "temperature_rain_with_missing": "temperature_rain",
    }
    if parts:
        parts[0] = dataset_alias.get(parts[0], parts[0])
    if len(parts) >= 2:
        parts[1] = {
            "a-dec": "a", "q-dec": "q", "me": "m", "qe": "q", "ye": "a",
            "w-sun": "w", "w-fri": "w", "w-thu": "w", "w-wed": "w", "w-tue": "w",
        }.get(parts[1], parts[1])
    return "/".join(parts)

def read(path):
    with path.open(newline="") as f:
        rows = list(csv.DictReader(f))
    return {canon(r["dataset"]): r for r in rows}

def gm(values):
    return math.exp(sum(math.log(max(float(v), 1e-12)) for v in values) / len(values))

def build(step):
    baseline = read(BASELINE)
    if len(baseline) != 97:
        raise RuntimeError(f"baseline aligned rows={len(baseline)}, expected 97")
    model_values = {}
    for path in sorted(GIFT_ROOT.glob("*/all_results.csv")):
        if path == BASELINE:
            continue
        rows = read(path)
        if len(rows) != 97:
            continue
        model = path.parent.name
        model_values[model] = {
            metric: {key: float(rows[key][metric]) / float(baseline[key][metric]) for key in baseline}
            for metric in (MASE, CRPS)
        }
    checkpoint = ROOT / f"checkpoint-{step}" / "all_results.csv"
    target_rows = read(checkpoint)
    missing = sorted(set(baseline) - set(target_rows))
    if missing:
        raise RuntimeError(f"checkpoint-{step} aligned {len(target_rows)}/97; missing={missing}")
    target = f"toto2-313m-multimodal-localstationarity-step-{step}"
    model_values[target] = {
        metric: {key: float(target_rows[key][metric]) / float(baseline[key][metric]) for key in baseline}
        for metric in (MASE, CRPS)
    }
    ranks = {}
    for metric in (MASE, CRPS):
        for key in baseline:
            entries = sorted((v[metric][key], model) for model, v in model_values.items())
            for rank, (_, model) in enumerate(entries, 1):
                ranks[metric, model, key] = rank
    output = []
    for model, values in model_values.items():
        mase_ranks = [ranks[MASE, model, key] for key in baseline]
        crps_ranks = [ranks[CRPS, model, key] for key in baseline]
        output.append({
            "T": "", "model": model,
            "Organization": "local-toto2-continued-pretraining" if model == target else "",
            "Test Leak.": "No", "Replication Code": "Yes" if model == target else "No",
            "MASE": f"{gm(values[MASE].values()):.15f}",
            "MASE_Rank": f"{sum(mase_ranks)/len(mase_ranks):.15f}",
            "CRPS": f"{gm(values[CRPS].values()):.15f}",
            "CRPS_Rank": f"{sum(crps_ranks)/len(crps_ranks):.15f}",
        })
    output.sort(key=lambda r: (float(r["MASE_Rank"])+float(r["CRPS_Rank"]), r["model"]))
    outdir = ROOT / f"checkpoint-{step}" / "ranking"
    outdir.mkdir(parents=True, exist_ok=True)
    outpath = outdir / "leaderboard_official_style.csv"
    with outpath.open("w", newline="") as f:
        fields = ["T", "model", "Organization", "Test Leak.", "Replication Code", "MASE", "MASE_Rank", "CRPS", "CRPS_Rank"]
        writer = csv.DictWriter(f, fieldnames=fields); writer.writeheader(); writer.writerows(output)
    tv = model_values[target]
    rel = []
    for term in ("short", "medium", "long"):
        keys = [k for k in baseline if k.endswith("/"+term)]
        rel.append({"horizon": term, "num_configs": len(keys), "MASE_geomean": gm([tv[MASE][k] for k in keys]), "CRPS_geomean": gm([tv[CRPS][k] for k in keys])})
    rel.append({"horizon":"overall", "num_configs":len(baseline), "MASE_geomean":gm(tv[MASE].values()), "CRPS_geomean":gm(tv[CRPS].values())})
    with (ROOT / f"checkpoint-{step}" / "relative_to_seasonal_naive.csv").open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=["horizon","num_configs","MASE_geomean","CRPS_geomean"]); writer.writeheader(); writer.writerows(rel)
    print(f"checkpoint={step} aligned=97 models={len(output)}")
    print(f"target={next(r for r in output if r['model']==target)}")
    print(f"leaderboard={outpath}")

if __name__ == "__main__":
    for arg in sys.argv[1:]: build(int(arg))
