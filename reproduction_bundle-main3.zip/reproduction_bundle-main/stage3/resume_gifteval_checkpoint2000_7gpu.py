#!/usr/bin/env python3
"""Redistribute unfinished GIFTEval configs over GPUs 0-6 and merge all 97 rows."""

from __future__ import annotations

import csv
import json
import os
import re
import shutil
import subprocess
from pathlib import Path

ROOT = Path("/home/toto-main")
NAME = "toto2-313m-multimodal-layer16-metadata-token-allmeta-newopt-from16500-rgbfixed"
STEP = 2000
CHECKPOINT = ROOT / "output" / NAME / f"checkpoint-{STEP}"
DATA = Path("/public_data/toto2_gifteval_test_multimodal_local_stationarity_8192_patch32_gpu234567_grouped_npz")
RESULT = ROOT / "results" / f"{NAME}-gifteval-full97-gpu0123" / f"checkpoint-{STEP}"
LOG_ROOT = ROOT / "logs" / f"{NAME}-gifteval-full97-resume-gpu0-6"
META = Path("/public_data/toto2_metadata_embedding_source_provenance_v4_rgbfixed")
MODEL = f"{NAME}-checkpoint-{STEP}"
PY = "/opt/conda/envs/toto2mm/bin/python"


def canonical(name: str) -> str:
    parts = str(name).strip().lower().split("/")
    if len(parts) >= 4 and parts[1] == parts[2]:
        parts.pop(1)
    if len(parts) == 4 and parts[-2] in {"w-fri", "w-thu", "w-wed", "w-tue", "w-sun"}:
        parts.pop(-2)
    aliases = {
        "car_parts_with_missing": "car_parts",
        "kdd_cup_2018_with_missing": "kdd_cup_2018",
        "saugeenday": "saugeen",
        "temperature_rain_with_missing": "temperature_rain",
    }
    if parts:
        parts[0] = aliases.get(parts[0], parts[0])
    if len(parts) >= 2:
        parts[1] = {
            "a-dec": "a", "q-dec": "q", "me": "m", "qe": "q", "ye": "a",
            "w-sun": "w", "w-fri": "w", "w-thu": "w", "w-wed": "w", "w-tue": "w",
        }.get(parts[1], parts[1])
    return "/".join(parts)


def main() -> None:
    LOG_ROOT.mkdir(parents=True, exist_ok=True)
    RESULT.mkdir(parents=True, exist_ok=True)
    configs = []
    for manifest_path in sorted(DATA.glob("*/manifest.json")):
        manifest = json.loads(manifest_path.read_text())
        key = (str(manifest["dataset"]), str(manifest["term"]))
        configs.append({
            "dataset": manifest["dataset"],
            "term": manifest["term"],
            "samples": int(manifest.get("written_samples", 0)),
            "key": key,
        })
    expected = {item["key"] for item in configs}
    if len(expected) != 97:
        raise RuntimeError(f"expected 97 unique configs, found {len(expected)}")

    def row_key(row):
        term = str(row["term"])
        value = str(row["dataset"]).casefold()
        candidates = [
            item["key"] for item in configs
            if item["term"] == term
            and value.startswith(str(item["dataset"]).casefold() + "/")
        ]
        if not candidates:
            raise RuntimeError(f"cannot map result row to manifest: {row['dataset']}")
        return max(candidates, key=lambda key: len(key[0]))

    completed = {}
    header = None
    for path in sorted(RESULT.glob("all_results.shard-*.csv")):
        with path.open(newline="") as handle:
            reader = csv.DictReader(handle)
            header = header or reader.fieldnames
            for row in reader:
                key = row_key(row)
                if key in expected:
                    completed[key] = row
    remaining = [item for item in configs if item["key"] not in completed]
    print(f"existing={len(completed)} remaining={len(remaining)}", flush=True)

    bins = [[] for _ in range(7)]
    loads = [0] * 7
    for item in sorted(remaining, key=lambda x: x["samples"], reverse=True):
        worker = min(range(7), key=lambda i: (loads[i], i))
        bins[worker].append(item)
        loads[worker] += item["samples"]
    print(f"balanced_remaining_written_samples={loads}", flush=True)

    resume_root = RESULT / "resume-gpu0-6"
    if resume_root.exists():
        shutil.rmtree(resume_root)
    resume_root.mkdir()
    processes = []
    for gpu, items in enumerate(bins):
        if not items:
            continue
        output = resume_root / f"gpu-{gpu}"
        output.mkdir()
        command = [
            PY, str(ROOT / "evaluate_toto2_layer16_metadata_grouped_gifteval_fast.py"),
            "--checkpoint", str(CHECKPOINT), "--data_dir", str(DATA),
            "--output_dir", str(output), "--model_name", MODEL,
            "--gift_eval_path", "/public_data/GIFTEval",
            "--gift_eval_src", "/home/chronos-forecasting-main/gift-eval/src",
            "--toto2_src", str(ROOT / "toto2"), "--batch_size", "1024",
            "--device", "cuda:0", "--metadata_root", str(META),
            "--shard_id", "0", "--num_shards", "1",
        ]
        for item in items:
            command.extend(["--include_config", f"{item['dataset']}/{item['term']}"])
        log = (LOG_ROOT / f"gpu-{gpu}.log").open("w")
        env = os.environ.copy()
        env["CUDA_VISIBLE_DEVICES"] = str(gpu)
        env["PYTORCH_CUDA_ALLOC_CONF"] = "expandable_segments:True"
        process = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT, env=env)
        processes.append((gpu, process, log, output, len(items)))

    failures = []
    for gpu, process, log, output, count in processes:
        code = process.wait()
        log.close()
        if code:
            failures.append((gpu, code))
            continue
        csv_path = output / "all_results.shard-0.csv"
        with csv_path.open(newline="") as handle:
            rows = list(csv.DictReader(handle))
        if len(rows) != count:
            failures.append((gpu, f"rows={len(rows)} expected={count}"))
            continue
        for row in rows:
            completed[row_key(row)] = row
    if failures:
        raise RuntimeError(f"resume failures: {failures}")
    missing = sorted(expected - set(completed))
    extra = sorted(set(completed) - expected)
    if missing or extra or len(completed) != 97:
        raise RuntimeError(f"combined={len(completed)} missing={missing} extra={extra}")

    if header is None:
        header = list(next(iter(completed.values())))
    final_partial = RESULT / "all_results.csv.partial"
    with final_partial.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=header)
        writer.writeheader()
        for key in sorted(completed):
            writer.writerow(completed[key])
    os.replace(final_partial, RESULT / "all_results.csv")

    board_dir = RESULT / "ranking_official97"
    with (LOG_ROOT / "leaderboard.log").open("w") as log:
        subprocess.run([
            PY, str(ROOT / "build_generic_gifteval_leaderboard.py"),
            "--result_csv", str(RESULT / "all_results.csv"),
            "--output_dir", str(board_dir), "--model_name", MODEL,
        ], stdout=log, stderr=subprocess.STDOUT, check=True)
    subprocess.run([
        PY, str(ROOT / "mark_leaderboard_transductive.py"),
        str(board_dir / "leaderboard_official_style.csv"), MODEL,
    ], check=True)
    (RESULT / ".complete97").touch()
    print(f"COMPLETE result={RESULT} leaderboard={board_dir}", flush=True)


if __name__ == "__main__":
    main()
