from __future__ import annotations

import json
from pathlib import Path

import torch
from einops import rearrange, reduce, repeat
from torch import nn

from toto2 import Toto2Model
from toto2.model import (
    OutputResidualMLP,
    Toto2ModelOutputs,
    backfill_short_patches,
)


class Toto2Layer16ConcatAdditiveMultimodalModel(nn.Module):
    """Toto-2 with direct additive concat-residual-MLP fusion after layer 16."""

    def __init__(self, base_model: Toto2Model, image_dim: int = 512, text_dim: int = 512):
        super().__init__()
        self.base_model = base_model
        self.image_dim = int(image_dim)
        self.text_dim = int(text_dim)
        d_model = int(base_model.config.d_model)
        self.fusion_after_layer = 16
        num_layers = len(base_model.transformer.layers)
        if num_layers != 24:
            raise ValueError(f"Expected a 24-layer Toto-2 backbone, got {num_layers} layers")

        self.image_projector = OutputResidualMLP(
            in_dim=d_model + self.image_dim,
            hidden_dim=4 * d_model,
            out_dim=d_model,
            dropout_p=base_model.config.dropout_p,
            bias=True,
        )
        self.text_projector = OutputResidualMLP(
            in_dim=d_model + self.text_dim,
            hidden_dim=4 * d_model,
            out_dim=d_model,
            dropout_p=base_model.config.dropout_p,
            bias=True,
        )
        self.image_decoder = nn.Sequential(nn.LayerNorm(d_model), nn.Linear(d_model, 4 * d_model), nn.GELU(), nn.Linear(4 * d_model, self.image_dim))
        self.text_decoder = nn.Sequential(nn.LayerNorm(d_model), nn.Linear(d_model, 4 * d_model), nn.GELU(), nn.Linear(4 * d_model, self.text_dim))
        self.image_mask_token = nn.Parameter(torch.zeros(1, 1, 1, self.image_dim))
        self.text_mask_token = nn.Parameter(torch.zeros(1, 1, 1, self.text_dim))

    @property
    def config(self):
        return self.base_model.config

    @property
    def patch_size(self) -> int:
        return int(self.base_model.config.patch_size)

    @property
    def d_model(self) -> int:
        return int(self.base_model.config.d_model)

    def _transformer_range(self, state, time_ids, group_ids, start, end, has_missing_values=True):
        """Run an exact subset of the original Transformer decoder layers."""
        tr = self.base_model.transformer
        time_kwargs, var_kwargs = tr._sdpa_kwargs(
            state, time_ids, group_ids, has_missing_values=has_missing_values
        )
        num_series, seq_len = state.shape[-3], state.shape[-2]
        if time_ids is not None and time_ids.dim() > 1:
            flat_time_ids = time_ids.expand(*state.shape[:-1]).flatten(0, -2)
        else:
            flat_time_ids = time_ids
        leading = state.shape[:-2]
        state = rearrange(state, "... seq_len dim -> (...) seq_len dim")
        for idx in range(start, end):
            layer = tr.layers[idx]
            if tr._if_variate_layer(idx):
                state = rearrange(state, "(b n) s d -> (b s) n d", n=num_series)
                state = layer(state, **var_kwargs)
                state = rearrange(state, "(b s) n d -> (b n) s d", s=seq_len)
            else:
                state = layer(state, seq_ids=flat_time_ids, **time_kwargs)
        return state.unflatten(0, leading)

    def _fuse(self, hidden, image_tokens, text_tokens, visible_patch):
        image_tokens = image_tokens.to(dtype=hidden.dtype)
        text_tokens = text_tokens.to(dtype=hidden.dtype)
        visible_patch = visible_patch.unsqueeze(-1)
        image_tokens = torch.where(
            visible_patch,
            image_tokens,
            self.image_mask_token.to(dtype=hidden.dtype),
        )
        text_tokens = torch.where(
            visible_patch,
            text_tokens,
            self.text_mask_token.to(dtype=hidden.dtype),
        )
        image_input = torch.cat([hidden, image_tokens], dim=-1)
        text_input = torch.cat([hidden, text_tokens], dim=-1)
        image_feature = self.image_projector(image_input)
        text_feature = self.text_projector(text_input)
        return hidden + image_feature + text_feature

    def _encode(self, time_x, group_ids, image_tokens, text_tokens, visible_patch, has_missing_values=True):
        time_ids = torch.arange(time_x.shape[-2], device=time_x.device, dtype=torch.int32)
        split = self.fusion_after_layer
        hidden = self._transformer_range(time_x, time_ids, group_ids, 0, split, has_missing_values)
        if image_tokens.shape[-2] != hidden.shape[-2] or text_tokens.shape[-2] != hidden.shape[-2]:
            raise ValueError("Modal patch count does not match time patches")
        fused = self._fuse(hidden, image_tokens, text_tokens, visible_patch)
        hidden = self._transformer_range(
            fused,
            time_ids,
            group_ids,
            split,
            len(self.base_model.transformer.layers),
            has_missing_values,
        )
        return self.base_model.transformer.out_norm(hidden)

    def _time_embed(self, target, target_mask, cpm_mask):
        base = self.base_model
        scaled, loc, scale = base.scaler(target, target_mask & cpm_mask)
        scaled = scaled.asinh()
        time_x = base.patch_proj(torch.cat([
            rearrange(scaled, "... (seq patch) -> ... seq patch", patch=self.patch_size),
            rearrange((~(target_mask & cpm_mask)).to(target.dtype), "... (seq patch) -> ... seq patch", patch=self.patch_size),
        ], dim=-1))
        return time_x, loc, scale

    def _group_ids(self, target_mask, cpm_mask, series_ids, n_patches):
        group_ids = repeat(series_ids, "... n_var -> ... n_var seq", seq=n_patches).clone()
        empty = reduce(target_mask, "... (seq patch) -> ... seq", "sum", patch=self.patch_size) == 0
        cpm_full = reduce(cpm_mask, "... (seq patch) -> ... seq", "prod", patch=self.patch_size) == 1
        group_ids[empty & cpm_full] = -1
        return group_ids

    def forward(self, target, target_mask, cpm_mask, series_ids, image_tokens, text_tokens, modal_patch_mask=None):
        time_x, loc, scale = self._time_embed(target, target_mask, cpm_mask)
        n_patches = time_x.shape[-2]
        if modal_patch_mask is None:
            visible = cpm_mask.unflatten(-1, (n_patches, self.patch_size)).any(dim=-1)
        else:
            visible = modal_patch_mask.bool()
        group_ids = self._group_ids(target_mask, cpm_mask, series_ids, n_patches)
        hidden = self._encode(time_x, group_ids, image_tokens, text_tokens, visible)
        quantiles = self.base_model.output_head(hidden, q=None)
        return Toto2ModelOutputs(quantiles, loc, scale), hidden

    @torch.no_grad()
    def forecast_parallel_hidden(self, target, target_mask, image_tokens, text_tokens, horizon,
                                 has_missing_values=True, scaler_fallback_min_obs=8,
                                 forecast_patch_mask=None):
        """Return the exact shifted hidden states consumed by ``output_head``.

        This is the encoder half of :meth:`forecast_parallel`.  Keeping it here
        gives external modules the same scaling, missing-value embedding,
        multimodal mask-token handling and one-patch prediction shift as native
        Toto2 forecasting, without running the output head.
        """
        base = self.base_model
        patch = self.patch_size
        initial_len = target.shape[-1]
        num_patches = (int(horizon) + patch - 1) // patch
        future_len = num_patches * patch
        if initial_len % patch:
            raise ValueError("Context length must be divisible by patch size")
        if forecast_patch_mask is None:
            forecast_patch_mask = torch.ones(
                *target.shape[:-2], num_patches,
                device=target.device, dtype=torch.bool,
            )
        else:
            forecast_patch_mask = forecast_patch_mask.to(
                device=target.device, dtype=torch.bool
            )
        if forecast_patch_mask.shape != target.shape[:-2] + (num_patches,):
            raise ValueError(
                "forecast_patch_mask must have shape "
                f"{target.shape[:-2] + (num_patches,)}, got {forecast_patch_mask.shape}"
            )
        full_target = torch.cat([
            target,
            torch.zeros(*target.shape[:-1], future_len, device=target.device, dtype=target.dtype),
        ], dim=-1)
        full_mask = torch.cat([
            target_mask,
            torch.zeros(*target_mask.shape[:-1], future_len, device=target_mask.device, dtype=torch.bool),
        ], dim=-1)
        _, loc, scale = base.scaler(full_target, full_mask)
        if scaler_fallback_min_obs:
            loc, scale = backfill_short_patches(
                full_target, loc, scale, full_mask, patch, int(scaler_fallback_min_obs)
            )
        scaled = ((full_target - loc) / scale).asinh()
        scaled = torch.where(full_mask, scaled, torch.zeros_like(scaled))
        time_x = base._embed_patches(scaled, full_mask, patch)
        n_total = time_x.shape[-2]
        context_patches = initial_len // patch
        if image_tokens.shape[-2] != context_patches or text_tokens.shape[-2] != context_patches:
            raise ValueError("Multimodal context patch count does not match time-series context")
        zeros_image = torch.zeros(
            *image_tokens.shape[:-2], num_patches, image_tokens.shape[-1],
            device=image_tokens.device, dtype=image_tokens.dtype,
        )
        zeros_text = torch.zeros(
            *text_tokens.shape[:-2], num_patches, text_tokens.shape[-1],
            device=text_tokens.device, dtype=text_tokens.dtype,
        )
        all_image = torch.cat([image_tokens, zeros_image], dim=-2)
        all_text = torch.cat([text_tokens, zeros_text], dim=-2)
        visible = target_mask.reshape(*target_mask.shape[:-1], -1, patch).any(-1)
        visible = torch.cat([
            visible,
            torch.zeros(*visible.shape[:-1], num_patches, device=visible.device, dtype=torch.bool),
        ], dim=-1)
        series_ids = torch.zeros(*target.shape[:-1], device=target.device, dtype=torch.long)
        # A forecast patch is a valid query token even though its values are
        # unknown. Conversely, an entirely unobserved context patch and a
        # forecast patch beyond this sample's horizon are padding and must not
        # share an attention group with valid tokens.
        group_ids = repeat(series_ids, "... n_var -> ... n_var seq", seq=n_total).clone()
        context_patch_valid = target_mask.reshape(
            *target_mask.shape[:-1], context_patches, patch
        ).any(-1)
        group_ids[..., :context_patches].masked_fill_(~context_patch_valid, -1)
        expanded_forecast_mask = forecast_patch_mask.unsqueeze(-2).expand(
            *target.shape[:-2], target.shape[-2], num_patches
        )
        group_ids[..., context_patches:].masked_fill_(~expanded_forecast_mask, -1)
        if torch.any((group_ids[..., :context_patches] >= 0) != context_patch_valid):
            raise RuntimeError("Context padding leaked into the attention group")
        if torch.any((group_ids[..., context_patches:] >= 0) != expanded_forecast_mask):
            raise RuntimeError("Future padding leaked into the attention group")
        hidden = self._encode(time_x, group_ids, all_image, all_text, visible, has_missing_values)
        pred_hidden = hidden[..., -(num_patches + 1):-1, :]
        future_loc = rearrange(loc[..., initial_len:initial_len + future_len], "... (s p) -> ... s p", p=patch)
        future_scale = rearrange(scale[..., initial_len:initial_len + future_len], "... (s p) -> ... s p", p=patch)
        return pred_hidden, future_loc, future_scale

    @torch.no_grad()
    def normalize_known_target_patches(self, future, future_mask, scaler_fallback_min_obs=8):
        """Encode a known bank target using its real future values and mask.

        Candidate targets are retrieved knowledge rather than unknown query
        labels, so their own observed future is used to estimate the native
        patch-aware scale.  Missing/padded values never enter the statistics.
        Each patch contains 32 asinh-normalized values and 32 missing flags.
        """
        patch = self.patch_size
        if future.shape[-1] % patch:
            raise ValueError("Future length must be divisible by patch size")
        scaled, loc, scale = self.base_model.scaler(future, future_mask)
        if scaler_fallback_min_obs:
            loc, scale = backfill_short_patches(
                future, loc, scale, future_mask, patch, int(scaler_fallback_min_obs)
            )
            scaled = torch.where(future_mask, (future - loc) / scale, torch.zeros_like(future))
        scaled = scaled.asinh()
        scaled = torch.where(future_mask, scaled, torch.zeros_like(scaled))
        values = rearrange(scaled, "... (seq patch) -> ... seq patch", patch=patch)
        missing = rearrange(
            (~future_mask).to(scaled.dtype), "... (seq patch) -> ... seq patch", patch=patch
        )
        return torch.cat([values, missing], dim=-1)

    @torch.inference_mode()
    def forecast_parallel(self, target, target_mask, image_tokens, text_tokens, horizon,
                          has_missing_values=True, scaler_fallback_min_obs=8):
        """Parallel multi-horizon forecast using layer-16 concat-additive fusion."""
        base = self.base_model
        patch = self.patch_size
        num_patches = (int(horizon) + patch - 1) // patch
        pred_hidden, future_loc, future_scale = self.forecast_parallel_hidden(
            target, target_mask, image_tokens, text_tokens, horizon,
            has_missing_values=has_missing_values,
            scaler_fallback_min_obs=scaler_fallback_min_obs,
            forecast_patch_mask=None,
        )
        nop = base.config.num_output_patches
        q = base.output_head(pred_hidden, q=None)[..., ::nop, :]
        q = q.sinh() * future_scale + future_loc
        q = base._clamp_nonfinite(q).sort(dim=0).values
        return rearrange(q, "... seq patch -> ... (seq patch)")[..., :int(horizon)]

    def save_pretrained(self, output_dir: str | Path):
        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)
        self.base_model.save_pretrained(output_dir)
        torch.save({
            "image_projector": self.image_projector.state_dict(),
            "text_projector": self.text_projector.state_dict(),
            "image_decoder": self.image_decoder.state_dict(),
            "text_decoder": self.text_decoder.state_dict(),
            "image_mask_token": self.image_mask_token.detach().cpu(),
            "text_mask_token": self.text_mask_token.detach().cpu(),
            "image_dim": self.image_dim,
            "text_dim": self.text_dim,
        }, output_dir / "layer16_concat_additive_state.pt")
        (output_dir / "layer16_concat_additive_config.json").write_text(
            json.dumps(
                {
                    "image_dim": self.image_dim,
                    "text_dim": self.text_dim,
                    "fusion_after_layer": self.fusion_after_layer,
                    "fusion": "time_plus_resmlp_concat_time_image_plus_resmlp_concat_time_text",
                },
                indent=2,
            )
            + "\n"
        )

    @classmethod
    def from_pretrained(cls, model_dir: str | Path, map_location="cpu"):
        model_dir = Path(model_dir)
        base = Toto2Model.from_pretrained(model_dir, map_location=map_location)
        state_path = model_dir / "layer16_concat_additive_state.pt"
        if state_path.exists():
            state = torch.load(state_path, map_location=map_location)
            image_dim = int(state.get("image_dim", 512))
            text_dim = int(state.get("text_dim", 512))
        else:
            state = None
            image_dim = text_dim = 512
        model = cls(base, image_dim=image_dim, text_dim=text_dim)
        if state is not None:
            model.image_projector.load_state_dict(state["image_projector"])
            model.text_projector.load_state_dict(state["text_projector"])
            model.image_decoder.load_state_dict(state["image_decoder"])
            model.text_decoder.load_state_dict(state["text_decoder"])
            model.image_mask_token.data.copy_(state["image_mask_token"])
            model.text_mask_token.data.copy_(state["text_mask_token"])
        return model
