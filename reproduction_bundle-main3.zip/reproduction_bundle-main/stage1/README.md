# Stage1 — Toto-2 313M 继续预训练（CPM 连续 Patch 掩码）

本目录实现 Toto-2.0 **313M time-only** 模型的继续预训练（continued pretraining）。训练目标是对时间序列做 **CPM（Contiguous Patch Masking，连续 patch 掩码）** 自监督：随机掩掉若干连续的 patch，让模型预测被掩码位置在 9 个分位点（0.1~0.9）上的取值，用 pinball（分位数）损失监督。

核心特点：

- **动态 8192 点序列**：固定宽度输入，短序列用其最长可用长度左填充，长序列随机截取连续窗口。
- **双数据源混合**：GIFTEvalPretrain（预训练 arrow 数据，70%）+ GIFT-Eval 训练集（30%）。
- **双优化器**：NorMuon（二维权重矩阵）+ AdamW（bias / norm / 输出投影）。
- **u-μP 缩放**：通过 `dd_unit_scaling` 对上游 `unit_scaling` 做薄封装。
- **昇腾 NPU 迁移**：CUDA / Ascend 双后端，NPU 下用纯 eager 的 Polar Express 替代 Triton Newton-Schulz。

---

## 目录结构

```
stage1/
├── pretrain_toto2_short_balanced.py       # 训练主脚本（torchrun 入口）
├── pretrain_toto2_short_balanced.py.original  # 上游原始版本（参考）
├── load_gifteval_toto2_cpm_pretrain.py    # CPM 数据加载入口，拼接双数据源
├── chronos/
│   ├── load_gifteval_pretrain_dataset_dynamic.py   # GIFTEval 动态流式数据集 + arrow 读取
│   ├── load_gifteval_short_balanced_pretrain.py    # 平衡的短序列预训练数据集
│   └── gift-eval/src/gift_eval/                     # GIFTEval 官方数据集解析
│       ├── data.py                                  #   数据集类（含 dotenv 依赖）
│       ├── __about__.py
│       └── analysis/                                #   评测分析（非预训练路径）
├── dd_unit_scaling/                        # u-μP 优化器薄封装（依赖 unit-scaling + dion）
│   ├── dd_unit_scaling/{__init__,functional,optim,scale,_modules}.py
│   └── pyproject.toml
└── toto2/                                  # Toto-2 模型定义
    ├── toto2/{__init__,configuration,model}.py
    └── pyproject.toml
```

---

## 启动方式

入口是仓库根目录的 `start_stage1.sh`，链路为：

```
start_stage1.sh  →  python -m torch.distributed.run  →  pretrain_toto2_short_balanced.py
```

### 参数优先级

`命令行参数 > STAGE1_* 环境变量 > 脚本内默认值`。

例如数据路径可用三种方式覆盖：

```bash
# 1) 命令行
bash start_stage1.sh --data_dir /data/GIFTEvalPretrain --gift_eval_path /data/GIFTEval

# 2) 环境变量（STAGE1_ 前缀，或用别名）
export STAGE1_DATA_DIR=/data/GIFTEvalPretrain
export STAGE1_GIFTEVAL=/data/GIFTEval

# 3) 不设，走脚本默认值
```

### 启动器关键行为

- **加速器自动检测**：优先 `torch_npu.npu`（昇腾），否则回退 `torch.cuda`。
- **华为云拓扑注入**：识别 `VC_WORKER_HOSTS` / `MA_NUM_HOSTS` / `VC_TASK_INDEX` / `MA_NUM_GPUS` 自动填充 `NODES / NODE_RANK / GPUS / MASTER_ADDR`。
- **单机 / 多机 / 已由上层启动（PRELAUNCHED）**：三类模式都支持，多机需 `MASTER_ADDR`。
- **前台 / 后台**：`--launch-mode background` 仅限单机、非 prelaunched。
- **dry-run**：`bash start_stage1.sh --dry-run` 只打印最终 torchrun 命令不执行。

封装参数（`--gpus/--nodes/--node-rank/--master-addr/--master-port/--launch-mode`）由启动器消费；其余 `--xxx` 一律透传给训练脚本，连字符别名自动归一化为下划线。

---

## 参数与配置

### 默认配置来源

- 训练脚本本身有 `parse_args()` 默认值（[pretrain_toto2_short_balanced.py](pretrain_toto2_short_balanced.py#L86-L140)）。
- 仓库根目录的 `stage1_options.py` 提供**不 import torch 的 dry-run 参数解析**，其默认值从 `configs/stage1.original.json` 读取，并支持 `STAGE1_<大写参数名>` 环境变量与别名（`STAGE1_MODEL` / `STAGE1_PRETRAIN` / `STAGE1_GIFTEVAL` / `STAGE1_OUTPUT`）。

### 关键超参数（`configs/stage1.original.json`）

| 参数 | 默认值 | 说明 |
|---|---|---|
| `model_name_or_path` | `Toto-2.0-313m-time-only` | 初始权重（继续预训练起点） |
| `max_sequence_length` | `8192` | 固定序列长度 |
| `patch_size` | `32`（从 checkpoint 读取） | 每个 patch 的时间步数 |
| `per_device_train_batch_size` | `112` | 每卡 micro-batch |
| `gradient_accumulation_steps` | `1` | 梯度累积步数 |
| `max_steps` | `1000000` | 训练上限 |
| `stop_after_steps` | `27000` | 实际停止步（由 `stage1_options.py` 注入） |
| `warmup_steps` | `1000` | 线性 warmup |
| `scheduler` | `cosine` | 学习率调度 |
| `cpm_max_mask_probability` | `0.4` | CPM 最大掩码比例 |
| `cpm_max_span_patches` | `8` | 单个连续 span 的最大 patch 数 |
| `adamw_learning_rate` / `adamw_min_lr` | `6e-5` / `6e-6` | AdamW 学习率 |
| `normuon_learning_rate` / `normuon_min_lr` | `3.25e-3` / `3.25e-4` | NorMuon 学习率 |
| `normuon_mu` / `normuon_beta2` | `0.96` / `0.999` | NorMuon 动量 |
| `adamw_beta1` / `adamw_beta2` | `0.91` / `0.972` | AdamW 动量 |
| `normuon_weight_decay` | `2e-8` | NorMuon 权重衰减 |
| `max_grad_norm` | `7.0` | 梯度裁剪 |
| `bf16` / `tf32` | `false` / `false` | 精度开关 |
| `freeze_variate_layers` | `false` | 是否冻结 variate attention 层 |
| `seed` | `5252` | 随机种子 |

流式采样参数（`stream_*`）控制 arrow 数据读取的缓存/预取/分池粒度，详见下文「数据加载」。

---

## 训练主脚本：`pretrain_toto2_short_balanced.py`

### NPU / GPU 迁移

脚本顶部先尝试 `import torch_npu`：若可用则开启昇腾路径（`transfer_to_npu`、`jit_compile=False`），后端用 `hccl`；否则回退 CUDA（后端 `nccl`）。

### 关键函数

| 函数 | 作用 |
|---|---|
| `add_source_paths(args)` | 把 `chronos_repo` / `toto2_src` / `dd_unit_scaling_src` 加入 `sys.path` |
| `ensure_dion()` | 优先用已安装的 `dion`，缺失则回退到仓库内 `vendor/dion`（追加到 `sys.path`，不抢占 site-packages 优先级） |
| `distributed_setup()` | 初始化进程组，返回 `rank / local_rank / world_size / device` |
| `freeze_variate_attention_layers(model)` | 冻结所有 variate 层（可选） |
| `split_optimizer_parameters(model)` | 按参数类型拆成 NorMuon / AdamW 两组 |
| `eager_polar_express(grad, eps)` | NPU 安全的纯 eager Polar Express 正交化（替代 Triton） |
| `make_scheduler(...)` | 线性 warmup + cosine 衰减到 `min_lr` |
| `sample_contiguous_patch_mask(...)` | 生成 CPM 连续 patch 掩码 |
| `prepare_toto_batch(...)` | 组装 target / mask / cpm_mask / masked_patches |
| `toto_pinball_loss(...)` | 分位数损失 + CPM 监督 + world_size 校正 |
| `save_checkpoint(...)` / `load_training_state(...)` | 保存 / 恢复检查点 |
| `build_dataloader(...)` | 构建 `create_toto2_cpm_pretraining_dataset` 的数据集与 DataLoader |

### 优化器拆分逻辑

遍历 `model.named_parameters()`：

- 满足 `ndim == 2` 且 `mup_type == "weight"` 且**不是** `patch_proj.*` / `output_head.*` → **NorMuon**。
- 其余（bias、norm 权重、输入/输出投影等）→ **AdamW**。

NorMuon 在 NPU 上 `use_polar_express=True`、`use_triton=False`，并传入 `newton_schulz_func=eager_polar_express`；CUDA 上则启用 Triton。

### 训练循环（`main()`）

1. 校验输出目录为空、warmup/max_steps 合法。
2. `add_source_paths` → `ensure_dion` → `import dd_unit_scaling as uu`、`from toto2 import Toto2Model`。
3. 分布式初始化、设置随机种子。
4. `Toto2Model.from_pretrained(model_path)`，从模型 config 读 `patch_size`。
5. 可选冻结 variate 层。
6. `uu.cache_fan_values(...)` → `uu.init_world_size_cache(...)` → `uu.set_grad_accumulation_steps(...)`（u-μP 元数据缓存，须在 DDP 包装前）。
7. 拆分参数 → `model.to(device)` → DDP 包装。
8. 构造 NorMuon / AdamW 及各自 scheduler。
9. 恢复训练状态 → 构建 dataloader → 进入主循环。
10. 每个 step：取 batch → `prepare_toto_batch` → 前向（`bf16` autocast）→ `toto_pinball_loss` → 反传 → 梯度裁剪 → 双优化器 step → scheduler step → 记录日志 → 按 `save_steps` 保存 checkpoint。

---

## 模型结构：`toto2/toto2/model.py`

`Toto2Model` 是一个 decoder-only、交替 time/variate attention 的多元时间序列模型。

```
target, target_mask, cpm_mask
        │
        ▼
PatchedCausalStdScaler        # patch 级因果标准化，输出 (loc, scale)
        │  asinh 缩放
        ▼
InputResidualMLP (patch_proj) # 输入 2*patch_size（数值 + 掩码）→ d_model
        ▼
VariateTimeTransformerDecoder # 交替 time / variate attention，共 num_layers 层
        ▼
QuantileKnotsOutputHead       # 输出 9 个分位数（0.1~0.9）
        ▼
quantiles + loc + scale
```

### 关键组件

- **`PatchedCausalStdScaler`**：对每个 patch 做因果标准化，避免未来信息泄漏。
- **`VariateTimeTransformerDecoder`**：按 `layer_group_size` 分组，每组内部分层为 time attention 与 variate attention。`_if_variate_layer(idx)` 判定当前层类型；`freeze_variate_layers` 即冻结这些层。
- **`SelfAttention`**：原生 `F.scaled_dot_product_attention`（非 unit-scaled，为兼容 KV-cache），配 RoPE（`RotaryProjection`）。
- **`QueryKeyProjection`**：q/k 分离投影，支持 `partial_factor`。
- **`GatedLinearUnitFeedForwardNetwork` / `ResidualMLP`**：前馈与残差 MLP。
- **`QuantileKnotsOutputHead`**：分位数 knots 输出头。

### 配置要点（`Toto2ModelConfig`）

- `residual_attn_ratio = sqrt(S / log(S))`（`S = context_length / patch_size`）用于补偿「未使用 unit-scaled SDPA」带来的 attention/MLP 方差失衡。
- `residual_mult` 默认 `0.75`（上游 `unit_scaling` 默认 `1.0`）。
- `dropout_p` 必须为 0（继续预训练稳定性要求，脚本会强制校验）。
- 前向签名：`forward(target, target_mask, cpm_mask, series_ids)`；`cpm_mask` 参与 scaler 的 mask 合并，避免被掩码位置泄漏进标准化统计量。

---

## 数据加载

### 入口

`load_gifteval_toto2_cpm_pretrain.py::create_toto2_cpm_pretraining_dataset` 是数据加载入口，构造两个子数据集并混合。

### 两个数据源

| 子数据集 | 基类 | 数据来源 | 用途 |
|---|---|---|---|
| `Toto2CPMPretrainDataset` | `BalancedShortPretrainDataset` | `--data_dir`（GIFTEvalPretrain 的 arrow 文件） | 大规模预训练语料 |
| `Toto2CPMGIFTEvalDataset` | `GIFTEvalTrainPartStreamingDataset` | `--gift_eval_path`（GIFTEval 原始数据集） | 官方训练集，含 hard/balanced 分池 |

### 序列采样（`Toto2SequenceMixin`）

- 固定 `max_sequence_length = 8192`。
- **短序列**：贡献其最长可用长度一次，向左对齐填充（`target[-n:]`），其余位置为 `NaN` 且 `target_mask=0`。
- **长序列**：随机截取若干独立 8192 点连续窗口（`windows_per_series` 控制数量）。
- 只有 ≥2 个有效 patch 的样本才被采用（第一个有效 patch 没有可监督的前置隐状态）。

### GIFT-Eval 分池（`Toto2CPMGIFTEvalDataset`）

- 校验恰好 **97 个 GIFT-Eval 训练配置**（short/medium/long）。
- 维护 7 个采样池，权重为：
  - `uniform_all`：0.60
  - `hard_short` / `hard_medium` / `hard_long`：各 0.25/3
  - `balanced_short` / `balanced_medium` / `balanced_long`：各 0.15/3
- 「hard」池来自 `MASE_HARD_CONFIGS` + `CRPS_HARD_CONFIGS` + checkpoint-4000 退化短配置列表。

### 预训练数据分桶（`BalancedShortPretrainDataset`）

按数据集名分 5 桶：`general` / `cmip6` / `era5` / `short_irregular` / `high_frequency`，采样概率依次 0.50 / 0.10 / 0.10 / 0.20 / 0.10。

### 混合（`ScheduledToto2SourceMixedDataset`）

每个 micro-batch 按 `pretrain_ratio = 0.70` 混合：70% 来自 pretrain 数据源，30% 来自 GIFT-Eval 数据源，拼接后 shuffle。`batch_size=None` 的 DataLoader 配合 `IterableDataset` 输出完整 batch。

### arrow 读取

`load_gifteval_pretrain_dataset_dynamic.py` 中的 `PreparedArrowChronos2Dataset` / `GIFTEvalDynamicStreamingDataset` 负责流式读取 arrow 文件（`data-*.arrow`），并支持 `stream_*` 参数控制：

- `stream_arrow_cache_size`：arrow 文件缓存数
- `stream_arrow_row_chunk_size`：每次读取的行块大小
- `stream_sample_pool_size`：采样池大小
- `stream_samples_per_arrow` / `stream_samples_per_dataset_block`：每个 arrow / 数据集块的采样数
- `stream_prefetch_pools` / `stream_windows_per_series`：预取池数 / 每序列窗口数
- `stream_log_interval`：日志间隔

> `import_gifteval_dataset(gift_eval_path, gift_eval_src)` 会把 `gift_eval_src` 加入 `sys.path` 并 `import gift_eval.data.Dataset`，这也是 `gift_eval/data.py` 里 `from dotenv import load_dotenv` 成为硬依赖的原因。

---

## 优化器与调度

### u-μP 与 `dd_unit_scaling`

`dd_unit_scaling` 是对 [graphcore-research/unit-scaling](https://github.com/graphcore-research/unit-scaling) 的薄封装：re-export 上游全部内容，仅覆盖无法与 `torch.compile` / FSDP2 / 分布式协同的部分。

- 提供 `AdamW` / `Muon` / `Dion2` / `NorMuon`，并对每个参数施加 u-μP 学习率缩放。
- 元数据（fan-in / fan-out / `mup_type`）在 FSDP/DDP 包装前按参数名缓存。
- `init_world_size_cache` / `set_grad_accumulation_steps` 须在 `torch.compile` 前调用，避免图打断。

Stage1 中的调用顺序（与 README 一致）：

```python
uu.cache_fan_values(model.named_parameters())   # DDP 包装前
uu.init_world_size_cache(world_size=world_size)
uu.set_grad_accumulation_steps(args.gradient_accumulation_steps)
```

### NorMuon（`dion`）

NorMuon 来自 [microsoft/dion](https://github.com/microsoft/dion)。`ensure_dion()` 优先使用已安装版本，缺失时用 `vendor/dion` 的 Torch 2.4 兜底。

- 默认使用 Polar Express 正交化（`use_polar_express=True`）。
- **NPU 上**：`use_triton=False`，`use_polar_express=True`，用纯 eager 的 `eager_polar_express` 作为 `newton_schulz_func`（避开 Ascend 上不可用的 CUDA Triton kernel 与 `torch.compile`）。
- **CUDA 上**：启用 Triton + Newton-Schulz。

> **注意**：`dion` 库内部大量用 `@torch.compile(fullgraph=True)` 装饰更新 kernel（如 `muon.py` 的 `muon_update_pre_orthogonalize`、`normuon.py` 的 `normuon_normalization_stacked`）。这些装饰器在昇腾上仍会触发 TorchDynamo 追踪并报错（`TypeError: '>=' not supported between instances of 'NoneType' and 'tuple'`）。训练脚本因此在 NPU 检测后全局执行 `torch._dynamo.config.disable = True`，让所有优化器 kernel 走纯 eager。

### 调度器

两组优化器各有独立的 `LambdaLR`，统一使用「线性 warmup + cosine 衰减」：

```
lr(step) = min_lr + (base_lr - min_lr) * 0.5 * (1 + cos(π * progress))
```

其中 `progress` 在 warmup 后从 0 → 1。

---

## 损失函数：`toto_pinball_loss`

1. 输出 patch `i` 预测目标 patch `i+1`，因此用 `outputs.quantiles[..., :-1, :]` 对 `target_patches[..., 1:, :]` 做监督。
2. 目标先做 `asinh` 缩放：`scaled_target = asinh((target - loc) / scale)`。
3. 计算 9 个分位点的 pinball 损失：`max(q·err, (q-1)·err)`。
4. 仅在 `valid & supervised_patch` 位置计损，按有效点数归一化。
5. 分布式校正：`loss = local_loss_sum * world_size / global_patch_count`，抵消 DDP 的梯度平均，保证不同 world size 下超参稳定。

---

## Checkpoint 保存 / 恢复

`save_checkpoint` 每次保存：

- `checkpoint-{step}/` 目录
- `model.save_pretrained(...)`（模型权重 + config）
- `training_state.pt`：两个优化器、两个 scheduler 的 state_dict、`global_step`、Torch / 加速器 RNG 状态
- `training_args.json`：本次运行参数快照

`load_training_state` 从 `resume_from_checkpoint` 恢复上述全部状态；恢复时要求 `model_name_or_path` 与 `resume_from_checkpoint` 指向同一 checkpoint。

---

## 依赖与已知注意点

Stage1 训练路径的第三方依赖（对照 `configs/environment207.txt` / `environment209.txt`）：

| 依赖 | 用途 | 注意 |
|---|---|---|
| `torch` + `torch_npu`（昇腾） | 训练框架 | 昇腾镜像须匹配 torch 版本的 `torch_npu` |
| `unit-scaling` | u-μP 缩放 | **外部 pip 包，不是 `dd_unit_scaling` 的子目录**；`import unit_scaling` 是绝对导入 |
| `dion` | NorMuon 优化器 | 可 pip 安装，缺失时回退 `vendor/dion` |
| `toto-2` | 模型 | 本地 `stage1/toto2` |
| `dd-unit-scaling` | 优化器封装 | 本地 `stage1/dd_unit_scaling` |
| `python-dotenv`（`dotenv`） | `gift_eval.data` 导入 | 训练数据加载路径的硬依赖 |
| `datasets` / `pyarrow` / `toolz` | arrow 数据流式读取 | |
| `gluonts` / `einops` / `jaxtyping` / `safetensors` / `huggingface_hub` / `pandas` | 模型 / 数据 | |

### 容易踩的坑

1. **`No module named 'unit_scaling'`**：这是容器没装 `unit-scaling`（pip 包），不是源码目录丢失。修复方式为 `pip install "unit-scaling>=0.2.0"`，**不要**把 `dd_unit_scaling/__init__.py` 里的绝对导入改成相对导入。
2. **`No module named 'dotenv'`**：`gift_eval/data.py` 顶层 `from dotenv import load_dotenv`，需 `pip install python-dotenv`。`environment209.txt` 中缺此包（`environment207.txt` 有）。
3. 评测/分析脚本（`gift_eval.analysis`）额外需要 `tsfeatures`、`ray`，预训练路径不涉及。
4. `patch_size` 不通过命令行传入，而是从模型 checkpoint 的 config 读取；`max_sequence_length` 必须能被 `patch_size` 整除。
5. 输出目录必须为空目录，否则脚本直接报错退出。

---

## 关键参数速查

```bash
# 单机多卡（自动检测卡数）
bash start_stage1.sh

# 指定卡数 / 关键路径
bash start_stage1.sh \
  --gpus 8 \
  --data_dir /data/GIFTEvalPretrain \
  --gift_eval_path /data/GIFTEval \
  --output_dir ./outputs/stage1/timeonly \
  --max_steps 27000

# 仅打印将执行的 torchrun 命令（不真正启动）
bash start_stage1.sh --dry-run
```

数据路径对应的两个数据集是不同的：

- `--data_dir` → GIFTEvalPretrain 的 **arrow 预训练数据**（`data-*.arrow`）。
- `--gift_eval_path` → GIFTEval **原始数据集**（供 `gift_eval.data` 解析）。

两者都需要，缺一不可。
