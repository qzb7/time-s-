from __future__ import annotations

import os
import random
import time
from collections import OrderedDict

import numpy as np
import torch
from torch.utils.data import IterableDataset, get_worker_info

from load_gifteval_pretrain_dataset_dynamic import (
    GIFTEvalTrainPartStreamingDataset,
    GIFT_EVAL_SHORT_DATASETS,
    import_gifteval_dataset,
)
from load_gifteval_short_balanced_pretrain import (
    BalancedShortPretrainDataset,
    CRPS_HARD_CONFIGS,
    MASE_HARD_CONFIGS,
)


CHECKPOINT_4000_DEGRADED_SHORT_CONFIGS = (
    "bitbrains_fast_storage/5T", "bitbrains_fast_storage/H",
    "bitbrains_rnd/5T", "bitbrains_rnd/H",
    "bizitobs_application/10S", "bizitobs_l2c/H", "covid_deaths/D",
    "electricity/15T", "ett1/D", "ett1/W-THU", "ett2/D", "ett2/W-THU",
    "hierarchical_sales/D", "hierarchical_sales/W-WED", "hospital/M",
    "jena_weather/10T", "jena_weather/D", "kdd_cup_2018/D",
    "loop_seattle/5T", "loop_seattle/D", "m4_daily/D", "m4_monthly/M",
    "m4_quarterly/Q-DEC", "m4_weekly/W-SUN", "m4_yearly/A-DEC",
    "saugeen/D", "saugeen/M", "solar/D", "solar/H", "solar/W-FRI",
    "us_births/D", "us_births/M",
)


class Toto2SequenceMixin:
    """Sample fixed-width Toto-2 sequences while preserving natural missingness."""

    max_sequence_length = 8192
    history_length = 8192
    # CPM uses the complete fixed-width sequence; no synthetic future patch.
    padded_prediction_length = 8192

    def __init__(self, *args, toto2_sequence_length=8192, **kwargs):
        self.max_sequence_length = int(toto2_sequence_length)
        self.history_length = int(toto2_sequence_length)
        super().__init__(*args, **kwargs)

    @staticmethod
    def _sanitize_series(series: np.ndarray) -> np.ndarray:
        series = np.asarray(series, dtype=np.float32).copy()
        series[~np.isfinite(series)] = np.nan
        return series

    def _sample_toto2_windows(
        self,
        series: np.ndarray,
        rng: random.Random,
        max_windows: int,
    ) -> list[dict]:
        series = self._sanitize_series(series)
        series_length = int(series.shape[0])
        if series_length < 2 or not np.isfinite(series).any():
            return []

        # A short series contributes its longest available sequence once.
        # A long series contributes independently sampled 8192-point windows.
        num_windows = 1 if series_length <= self.max_sequence_length else min(
            self.windows_per_series, max_windows
        )
        windows = []
        for _ in range(num_windows):
            if series_length <= self.max_sequence_length:
                start = 0
            else:
                start = rng.randint(0, series_length - self.max_sequence_length)
            values = series[start : start + self.max_sequence_length]
            valid = np.isfinite(values)
            if not valid.any():
                continue

            target = np.full(self.max_sequence_length, np.nan, dtype=np.float32)
            target_mask = np.zeros(self.max_sequence_length, dtype=np.float32)
            target[-values.shape[0] :] = values
            target_mask[-values.shape[0] :] = valid.astype(np.float32)

            patch_valid = target_mask.reshape(-1, self.patch_len).sum(axis=-1) > 0
            # The first valid patch has no preceding hidden position from which
            # a next-patch prediction can be supervised.
            if int(patch_valid.sum()) < 2:
                continue
            windows.append(
                {
                    "target": target,
                    "target_mask": target_mask,
                    "sequence_length": int(values.shape[0]),
                }
            )
            if len(windows) >= max_windows:
                break
        return windows

    def _collate_chronos2_batch(self, samples):
        return {
            "target": torch.as_tensor(
                np.stack([item["target"] for item in samples]), dtype=torch.float32
            ),
            "target_mask": torch.as_tensor(
                np.stack([item["target_mask"] for item in samples]),
                dtype=torch.float32,
            ),
            "sequence_length": torch.as_tensor(
                [item["sequence_length"] for item in samples], dtype=torch.long
            ),
        }

    def _curriculum_limits(self, batch_index):
        return self.max_sequence_length, self.patch_len


class Toto2CPMPretrainDataset(Toto2SequenceMixin, BalancedShortPretrainDataset):
    def _sample_from_record(
        self, sample, rng, max_windows, max_history_len=None, max_pred_len=None
    ):
        target = np.asarray(sample["target"], dtype=np.float32)
        if target.ndim == 1:
            target = target.reshape(1, -1)
        elif target.ndim != 2:
            return []
        windows = []
        channel_indices = list(range(target.shape[0]))
        rng.shuffle(channel_indices)
        for channel_idx in channel_indices:
            windows.extend(
                self._sample_toto2_windows(
                    target[channel_idx],
                    rng,
                    max_windows - len(windows),
                )
            )
            if len(windows) >= max_windows:
                break
        return windows


class Toto2CPMGIFTEvalDataset(
    Toto2SequenceMixin, GIFTEvalTrainPartStreamingDataset
):
    def __init__(
        self,
        *args,
        short_prediction_lengths=None,
        official_history_lengths=None,
        **kwargs,
    ):
        super().__init__(*args, **kwargs)
        self.mase_hard_configs = [
            (name, "short")
            for name in MASE_HARD_CONFIGS
            if (name, "short") in self.dataset_configs
        ]
        self.crps_hard_configs = [
            (name, "short")
            for name in CRPS_HARD_CONFIGS
            if (name, "short") in self.dataset_configs
        ]
        self.degraded_4000_configs = self._resolve_degraded_configs()
        if len(self.dataset_configs) != 97:
            raise ValueError(
                "Expected 97 GIFT-Eval training configs "
                f"(short/medium/long), got {len(self.dataset_configs)}"
            )
        if not self.mase_hard_configs or not self.crps_hard_configs:
            raise ValueError("Hard short config pools did not resolve.")
        if not self.degraded_4000_configs:
            raise ValueError("Checkpoint-4000 degraded short pool is empty.")
        previous_hard_bases = set(MASE_HARD_CONFIGS) | set(CRPS_HARD_CONFIGS)
        previous_hard = [
            config
            for config in self.dataset_configs
            if any(
                config[0] == base
                or config[0].startswith(f"{base}/")
                or config[0].split("/")[0] == base
                for base in previous_hard_bases
            )
        ]
        # The concrete difficult datasets come from the previous registry and
        # checkpoint-4000 degraded list. Expand each source to all available
        # short/medium/long terms, then remove overlaps once.
        hard_order = list(dict.fromkeys(self.degraded_4000_configs + previous_hard))
        hard_used = set()
        hard_by_term = {"short": [], "medium": [], "long": []}
        for config in hard_order:
            if config in hard_used:
                continue
            hard_used.add(config)
            if config[1] in hard_by_term:
                hard_by_term[config[1]].append(config)
        self.pool_configs = {
            "uniform_all": list(self.dataset_configs),
            "hard_short": hard_by_term["short"],
            "hard_medium": hard_by_term["medium"],
            "hard_long": hard_by_term["long"],
            "balanced_short": [c for c in self.dataset_configs if c[1] == "short"],
            "balanced_medium": [c for c in self.dataset_configs if c[1] == "medium"],
            "balanced_long": [c for c in self.dataset_configs if c[1] == "long"],
        }
        self.pool_names = tuple(self.pool_configs)
        self.pool_weights = (
            0.60,
            0.25 / 3.0,
            0.25 / 3.0,
            0.25 / 3.0,
            0.15 / 3.0,
            0.15 / 3.0,
            0.15 / 3.0,
        )
        if any(not self.pool_configs[name] for name in self.pool_names[1:]):
            raise ValueError(f"One or more hard/balanced pools are empty: {self.pool_configs}")
        print(
            "Balanced GIFT-Eval train pools: "
            f"configs={len(self.dataset_configs)} "
            f"hard_short={len(self.pool_configs['hard_short'])} "
            f"hard_medium={len(self.pool_configs['hard_medium'])} "
            f"hard_long={len(self.pool_configs['hard_long'])} "
            "mix=uniform60/hard25-balanced15",
            flush=True,
        )

    def _choose_config(self, rng: random.Random, pool_state):
        pool_name = rng.choices(
            self.pool_names, weights=self.pool_weights, k=1
        )[0]
        queue = pool_state[pool_name]
        if not queue:
            queue.extend(self.pool_configs[pool_name])
            rng.shuffle(queue)
        return pool_name, queue.pop()

    def _resolve_degraded_configs(self):
        """Map evaluation aliases to the corresponding train-part configs."""
        lookup = {
            (str(name).lower(), str(term).lower()): (name, term)
            for name, term in self.dataset_configs
        }
        aliases = {
            "saugeen": "saugeenday",
            "kdd_cup_2018": "kdd_cup_2018_with_missing",
            "loop_seattle": "LOOP_SEATTLE",
        }
        resolved = []
        for config in CHECKPOINT_4000_DEGRADED_SHORT_CONFIGS:
            name, frequency = config.rsplit("/", 1)
            name_candidates = (name, aliases.get(name.lower(), name))
            frequency = {
                "A-DEC": "A",
                "Q-DEC": "Q",
                "W-SUN": "W",
                "W-WED": "W",
                "W-THU": "W",
                "W-FRI": "W",
            }.get(frequency, frequency)
            candidates = []
            for candidate_name in name_candidates:
                candidates.extend(
                    (
                        (candidate_name, frequency),
                        (candidate_name, "short"),
                        (f"{candidate_name}/{frequency}", "short"),
                    )
                )
            for candidate_name, candidate_term in candidates:
                match = lookup.get(
                    (candidate_name.lower(), candidate_term.lower())
                )
                if match is not None:
                    resolved.append(match)
                    break
        return list(dict.fromkeys(resolved))

    def _iter_pool_generator(
        self,
        Dataset,
        rng,
        dataset_rng,
        shard_id,
        num_shards,
        global_num_shards,
        rank,
        worker_id,
    ):
        emitted = 0
        skipped = 0
        pool_epoch = 0
        start_time = time.time()
        while True:
            pool = []
            pool_counts = {name: 0 for name in self.pool_names}
            pool_state = {name: list(configs) for name, configs in self.pool_configs.items()}
            for configs in pool_state.values():
                rng.shuffle(configs)
            while len(pool) < self.sample_pool_size:
                pool_name, (dataset_name, term) = self._choose_config(dataset_rng, pool_state)
                pool_counts[pool_name] += 1
                target_windows = min(
                    self.samples_per_dataset_block,
                    self.sample_pool_size - len(pool),
                )
                block = self._sample_dataset_config(
                    Dataset=Dataset,
                    dataset_name=dataset_name,
                    term=term,
                    rng=rng,
                    shard_id=shard_id,
                    num_shards=num_shards,
                    target_windows=target_windows,
                    max_history_len=self.max_sequence_length,
                    max_pred_len=self.max_sequence_length,
                )
                if block:
                    pool.extend(block)
                else:
                    skipped += 1
            rng.shuffle(pool)
            pool_epoch += 1
            emitted += len(pool)
            if (
                self.log_interval
                and rank == 0
                and worker_id == 0
                and emitted % self.log_interval < len(pool)
            ):
                print(
                    f"[balanced gifteval rank={rank} worker={worker_id}] "
                    f"pool_epoch={pool_epoch} pool_ready={len(pool)} "
                    f"worker_windows={emitted} pool_blocks={pool_counts} "
                    f"skipped={skipped} elapsed={time.time() - start_time:.1f}s",
                    flush=True,
                )
            while pool:
                yield pool.pop()

    def _sample_dataset_config(
        self,
        Dataset,
        dataset_name,
        term,
        rng,
        shard_id,
        num_shards,
        target_windows,
        max_history_len,
        max_pred_len,
    ):
        metadata = Dataset(name=dataset_name, term=term, to_univariate=False)
        dataset = Dataset(
            name=dataset_name,
            term=term,
            to_univariate=metadata.target_dim != 1,
        )
        windows = []
        for entry in dataset.training_dataset:
            target = np.asarray(entry["target"], dtype=np.float32)
            if target.ndim == 1:
                target = target.reshape(1, -1)
            elif target.ndim != 2:
                continue
            channel_indices = list(range(target.shape[0]))
            rng.shuffle(channel_indices)
            for channel_idx in channel_indices:
                windows.extend(
                    self._sample_toto2_windows(
                        target[channel_idx],
                        rng,
                        target_windows - len(windows),
                    )
                )
                if len(windows) >= target_windows:
                    return windows
        return windows


class ScheduledToto2SourceMixedDataset(IterableDataset):
    def __init__(
        self,
        pretrain_dataset,
        gifteval_dataset,
        batch_size,
        gradient_accumulation_steps,
        start_optimizer_step=0,
        seed=5252,
    ):
        self.pretrain_dataset = pretrain_dataset
        self.gifteval_dataset = gifteval_dataset
        self.batch_size = int(batch_size)
        self.gradient_accumulation_steps = max(1, int(gradient_accumulation_steps))
        self.start_optimizer_step = max(0, int(start_optimizer_step))
        self.seed = int(seed)
        print(
            "Use scheduled Toto-2 source mix: "
            "steps=[0,100000]:70/30",
            flush=True,
        )

    @staticmethod
    def pretrain_ratio(step: int) -> float:
        return 0.70

    @staticmethod
    def _slice_range(batch, start: int, end: int):
        batch_size = int(batch["target"].shape[0])
        indices = torch.arange(start, end, dtype=torch.long)
        return {
            key: (
                value.index_select(0, indices.to(value.device))
                if torch.is_tensor(value)
                and value.ndim > 0
                and value.shape[0] == batch_size
                else value
            )
            for key, value in batch.items()
        }

    @staticmethod
    def _concat_and_shuffle(parts, rng: random.Random):
        merged = {}
        for key in parts[0]:
            values = [part[key] for part in parts]
            merged[key] = torch.cat(values, dim=0)
        order = list(range(int(merged["target"].shape[0])))
        rng.shuffle(order)
        index = torch.as_tensor(order, dtype=torch.long)
        return {
            key: value.index_select(0, index.to(value.device))
            for key, value in merged.items()
        }

    def __iter__(self):
        worker_info = get_worker_info()
        worker_id = worker_info.id if worker_info is not None else 0
        rank = int(os.getenv("RANK", "0"))
        num_workers = worker_info.num_workers if worker_info is not None else 1
        rng = random.Random(self.seed + (rank * num_workers + worker_id) * 1237)
        iterators = {
            "pretrain": iter(self.pretrain_dataset),
            "gifteval": iter(self.gifteval_dataset),
        }
        pending = {"pretrain": None, "gifteval": None}
        offsets = {"pretrain": 0, "gifteval": 0}
        local_micro_batch = 0
        last_ratio = None

        def take(source: str, count: int):
            parts = []
            remaining = count
            while remaining > 0:
                batch = pending[source]
                offset = offsets[source]
                if batch is None or offset >= int(batch["target"].shape[0]):
                    try:
                        batch = next(iterators[source])
                    except StopIteration:
                        dataset = (
                            self.pretrain_dataset
                            if source == "pretrain"
                            else self.gifteval_dataset
                        )
                        iterators[source] = iter(dataset)
                        batch = next(iterators[source])
                    pending[source] = batch
                    offset = 0
                available = int(batch["target"].shape[0]) - offset
                size = min(remaining, available)
                parts.append(self._slice_range(batch, offset, offset + size))
                offsets[source] = offset + size
                remaining -= size
            return parts

        while True:
            optimizer_step = (
                self.start_optimizer_step
                + local_micro_batch // self.gradient_accumulation_steps
            )
            ratio = self.pretrain_ratio(optimizer_step)
            pretrain_rows = int(round(self.batch_size * ratio))
            gifteval_rows = self.batch_size - pretrain_rows
            parts = take("pretrain", pretrain_rows)
            parts.extend(take("gifteval", gifteval_rows))
            mixed = self._concat_and_shuffle(parts, rng)
            if ratio != last_ratio and rank == 0 and worker_id == 0:
                print(
                    f"Toto-2 source transition: optimizer_step={optimizer_step} "
                    f"pretrain_rows={pretrain_rows} gifteval_rows={gifteval_rows}",
                    flush=True,
                )
                last_ratio = ratio
            local_micro_batch += 1
            yield mixed


def create_toto2_cpm_pretraining_dataset(
    *,
    data_dir: str,
    gift_eval_path: str,
    gift_eval_src: str | None,
    batch_size: int,
    patch_size: int,
    max_sequence_length: int,
    gradient_accumulation_steps: int,
    start_optimizer_step: int,
    seed: int,
    **stream_kwargs,
):
    if batch_size <= 1:
        raise ValueError("batch_size must be greater than one.")
    if max_sequence_length <= patch_size or max_sequence_length % patch_size:
        raise ValueError(
            "max_sequence_length must be greater than and divisible by patch_size."
        )

    Dataset = import_gifteval_dataset(gift_eval_path, gift_eval_src)
    short_prediction_lengths = []
    official_history_lengths = {}
    for dataset_name in GIFT_EVAL_SHORT_DATASETS:
        metadata = Dataset(name=dataset_name, term="short", to_univariate=False)
        short_prediction_lengths.append(int(metadata.prediction_length))
        official_history_lengths[(dataset_name, "short")] = tuple(
            min(max_sequence_length, int(np.asarray(entry["target"]).shape[-1]))
            for entry in metadata.test_data.input
        )

    common = dict(
        max_seq_len=max_sequence_length,
        # No extra 32-point patch is appended by the loader.
        max_pred_len=max_sequence_length,
        batch_size=batch_size,
        output_patch_size=patch_size,
        patch_len=patch_size,
        min_history_len=2,
        min_pred_len=1,
        history_patch_multiple=False,
        prediction_patch_multiple=False,
        curriculum_enable=False,
    )
    pretrain = Toto2CPMPretrainDataset(
        data_dir=data_dir,
        toto2_sequence_length=max_sequence_length,
        short_prediction_lengths=short_prediction_lengths,
        official_history_lengths=official_history_lengths,
        seed=seed + 11,
        **common,
        **stream_kwargs,
    )
    gifteval = Toto2CPMGIFTEvalDataset(
        gift_eval_path=gift_eval_path,
        toto2_sequence_length=max_sequence_length,
        gift_eval_src=gift_eval_src,
        dataset_names="all",
        terms="all",
        short_prediction_lengths=short_prediction_lengths,
        official_history_lengths=official_history_lengths,
        seed=seed + 29,
        **common,
        **{
            key: value
            for key, value in stream_kwargs.items()
            if key
            not in {
                "window_stride",
                "samples_per_arrow",
                "arrow_row_chunk_size",
                "prefetch_pools",
                "arrow_cache_size",
            }
        },
    )
    mixed = ScheduledToto2SourceMixedDataset(
        pretrain_dataset=pretrain,
        gifteval_dataset=gifteval,
        batch_size=batch_size,
        gradient_accumulation_steps=gradient_accumulation_steps,
        start_optimizer_step=start_optimizer_step,
        seed=seed + 47,
    )
    mixed.max_sequence_length = max_sequence_length
    print(
        "Use Toto-2 CPM pretraining loader: "
        f"max_sequence_length={max_sequence_length}, patch_size={patch_size}, "
        "short_series=longest_available_left_padded, "
        "long_series=random_contiguous_max_length_window, "
        f"batch_size={batch_size}",
        flush=True,
    )
    return mixed
