from __future__ import annotations

import os
import random
import time
from collections import OrderedDict

import numpy as np
import torch
from torch.utils.data import IterableDataset, get_worker_info

from load_gifteval_pretrain_dataset_dynamic import (
    GIFTEvalDynamicStreamingDataset,
    GIFTEvalTrainPartStreamingDataset,
    GIFT_EVAL_SHORT_DATASETS,
    GroupAwareMixedChronos2BatchDataset,
    import_gifteval_dataset,
)


MASE_HARD_CONFIGS = (
    "m4_hourly",
    "us_births/M",
    "bizitobs_application",
    "m4_daily",
    "ett2/D",
    "solar/10T",
    "bizitobs_service",
    "m4_monthly",
    "covid_deaths",
    "bizitobs_l2c/H",
    "solar/D",
)

CRPS_HARD_CONFIGS = (
    "bitbrains_rnd/H",
    "bitbrains_rnd/5T",
    "bitbrains_fast_storage/H",
    "bitbrains_fast_storage/5T",
    "bizitobs_application",
    "us_births/M",
    "covid_deaths",
)

SHORT_IRREGULAR_PRETRAIN_DATASETS = {
    "monash_m3_yearly",
    "m1_yearly",
    "tourism_yearly",
    "cif_2016_6",
    "godaddy",
    "m1_quarterly",
    "monash_m3_quarterly",
    "monash_m3_other",
    "m1_monthly",
    "vehicle_trips_with_missing",
    "traffic_weekly",
    "tourism_quarterly",
    "nn5_weekly",
    "cif_2016_12",
    "kaggle_web_traffic_weekly",
    "monash_m3_monthly",
    "uber_tlc_daily",
    "cdc_fluview_who_nrevss",
    "tourism_monthly",
    "rideshare_with_missing",
    "m5",
    "favorita_sales",
    "taxi_30min",
}

HIGH_FREQUENCY_KEYWORDS = (
    "building",
    "azure",
    "borg",
    "alibaba",
    "taxi",
    "metro",
    "pems",
    "traffic",
    "electric",
    "solar",
    "wind",
    "web",
    "load",
)


class ShortNaNPaddingMixin:
    history_length = 2048
    padded_prediction_length = 192
    pretrain_uniform_horizon_ratio = 0.20

    def _set_official_history_lengths(self, values_by_config) -> None:
        normalized = {}
        for config, values in values_by_config.items():
            clipped = tuple(
                max(1, min(self.history_length, int(value)))
                for value in values
                if int(value) > 0
            )
            if clipped:
                normalized[tuple(config)] = clipped
        if len(normalized) != 55:
            raise ValueError(
                f"Expected history distributions for 55 short configs, got {len(normalized)}"
            )
        self.official_history_lengths = normalized
        self.official_history_configs = tuple(normalized)
        self.eligible_histories_by_horizon = {}
        self.eligible_configs_by_horizon = {}
        for prediction_length in range(1, self.padded_prediction_length + 1):
            by_config = {
                config: tuple(
                    value for value in values if value > prediction_length
                )
                for config, values in normalized.items()
            }
            by_config = {
                config: values for config, values in by_config.items() if values
            }
            self.eligible_histories_by_horizon[prediction_length] = by_config
            self.eligible_configs_by_horizon[prediction_length] = tuple(by_config)

    @staticmethod
    def _sanitize_series(series: np.ndarray) -> np.ndarray:
        series = np.asarray(series, dtype=np.float32).copy()
        series[~np.isfinite(series)] = np.nan
        return series

    def _sample_history_length(
        self,
        rng: random.Random,
        prediction_length: int,
        history_config: tuple[str, str] | None = None,
    ) -> int | None:
        prediction_length = int(prediction_length)
        eligible_by_config = self.eligible_histories_by_horizon.get(
            prediction_length, {}
        )
        if history_config is None:
            # Pretraining data has no matching GIFT-Eval config. Choose
            # uniformly among configs that can provide history > horizon.
            eligible_configs = self.eligible_configs_by_horizon.get(
                prediction_length, ()
            )
            if not eligible_configs:
                return None
            history_config = rng.choice(eligible_configs)
        elif tuple(history_config) not in self.official_history_lengths:
            raise KeyError(f"Missing official history distribution for {history_config}")
        eligible_histories = eligible_by_config.get(tuple(history_config), ())
        if not eligible_histories:
            return None
        return int(rng.choice(eligible_histories))

    def _sample_prediction_length(
        self,
        rng: random.Random,
        series_length: int,
        fixed_prediction_length: int | None,
    ) -> int | None:
        if fixed_prediction_length is not None:
            choices = (int(fixed_prediction_length),)
        elif rng.random() < self.pretrain_uniform_horizon_ratio:
            choices = tuple(range(self.output_patch_size, self.padded_prediction_length + 1, self.output_patch_size))
        else:
            choices = self.short_prediction_lengths
        valid = [value for value in choices if 0 < int(value) < series_length]
        return int(rng.choice(valid)) if valid else None

    def _sample_short_windows(
        self,
        series: np.ndarray,
        rng: random.Random,
        max_windows: int,
        fixed_prediction_length: int | None = None,
        history_config: tuple[str, str] | None = None,
    ) -> list[dict]:
        series = self._sanitize_series(series)
        series_length = int(series.shape[0])
        windows = []
        for _ in range(min(self.windows_per_series, max_windows)):
            prediction_length = self._sample_prediction_length(
                rng, series_length, fixed_prediction_length
            )
            if prediction_length is None:
                continue
            requested_history = self._sample_history_length(
                rng,
                prediction_length=prediction_length,
                history_config=history_config,
            )
            if requested_history is None:
                continue
            latest_start = series_length - prediction_length
            # Match official short evaluation geometry: every forecast must
            # have a strictly longer observed history than its horizon.
            if latest_start <= prediction_length:
                continue
            if latest_start >= requested_history:
                forecast_start = rng.randint(requested_history, latest_start)
            else:
                forecast_start = latest_start
            history = series[
                max(0, forecast_start - requested_history) : forecast_start
            ]
            future = series[
                forecast_start : forecast_start + prediction_length
            ]
            history_valid = np.isfinite(history)
            future_valid = np.isfinite(future)
            if history.shape[0] <= prediction_length:
                continue
            if not history_valid.any() or not future_valid.any():
                continue

            context = np.full(self.history_length, np.nan, dtype=np.float32)
            context_mask = np.zeros(self.history_length, dtype=np.float32)
            future_target = np.full(
                self.padded_prediction_length, np.nan, dtype=np.float32
            )
            future_target_mask = np.zeros(
                self.padded_prediction_length, dtype=np.float32
            )
            context[-history.shape[0] :] = history
            context_mask[-history.shape[0] :] = history_valid.astype(np.float32)
            future_target[:prediction_length] = future
            future_target_mask[:prediction_length] = future_valid.astype(np.float32)
            windows.append(
                {
                    "context": context,
                    "context_mask": context_mask,
                    "future_target": future_target,
                    "future_target_mask": future_target_mask,
                    "history_length": int(history_valid.sum()),
                    "prediction_length": prediction_length,
                }
            )
        return windows

    def _curriculum_limits(self, batch_index):
        return self.history_length, self.padded_prediction_length

    def _collate_chronos2_batch(self, samples):
        context = torch.as_tensor(
            np.stack([item["context"] for item in samples]), dtype=torch.float32
        )
        context_mask = torch.as_tensor(
            np.stack([item["context_mask"] for item in samples]), dtype=torch.float32
        )
        future_target = torch.as_tensor(
            np.stack([item["future_target"] for item in samples]), dtype=torch.float32
        )
        future_target_mask = torch.as_tensor(
            np.stack([item["future_target_mask"] for item in samples]),
            dtype=torch.float32,
        )
        return {
            "context": context,
            "context_mask": context_mask,
            "future_target": future_target,
            "future_target_mask": future_target_mask,
            "group_ids": torch.arange(len(samples), dtype=torch.long),
            "future_covariates": None,
            "future_covariates_mask": None,
            "num_output_patches": self.padded_prediction_length
            // self.output_patch_size,
        }


class BalancedShortPretrainDataset(
    ShortNaNPaddingMixin, GIFTEvalDynamicStreamingDataset
):
    def __init__(
        self,
        *args,
        short_prediction_lengths,
        official_history_lengths,
        **kwargs,
    ):
        super().__init__(*args, **kwargs)
        self.short_prediction_lengths = tuple(int(x) for x in short_prediction_lengths)
        self._set_official_history_lengths(official_history_lengths)
        self.dataset_buckets = self._build_dataset_buckets()
        print(
            "Balanced pretrain buckets: "
            + ", ".join(
                f"{name}={len(values)}" for name, values in self.dataset_buckets.items()
            ),
            flush=True,
        )

    def _build_dataset_buckets(self):
        buckets = {
            "general": [],
            "cmip6": [],
            "era5": [],
            "short_irregular": [],
            "high_frequency": [],
        }
        for dataset_name in self.dataset_names:
            normalized = dataset_name.lower()
            if normalized.startswith("cmip6_"):
                bucket = "cmip6"
            elif normalized.startswith("era5_"):
                bucket = "era5"
            elif normalized in SHORT_IRREGULAR_PRETRAIN_DATASETS:
                bucket = "short_irregular"
            elif any(token in normalized for token in HIGH_FREQUENCY_KEYWORDS):
                bucket = "high_frequency"
            else:
                bucket = "general"
            buckets[bucket].append(dataset_name)
        if any(not values for values in buckets.values()):
            raise ValueError(f"Empty pretrain sampling bucket: {buckets}")
        return buckets

    def _choose_dataset(self, rng: random.Random) -> tuple[str, str]:
        draw = rng.random()
        if draw < 0.50:
            bucket = "general"
        elif draw < 0.60:
            bucket = "cmip6"
        elif draw < 0.70:
            bucket = "era5"
        elif draw < 0.90:
            bucket = "short_irregular"
        else:
            bucket = "high_frequency"
        return bucket, rng.choice(self.dataset_buckets[bucket])

    def _sample_from_record(
        self, sample, rng, max_windows, max_history_len=None, max_pred_len=None
    ):
        target = np.asarray(sample["target"], dtype=np.float32)
        if target.ndim == 1:
            target = target.reshape(1, -1)
        elif target.ndim != 2:
            return []
        windows = []
        channel_indices = list(range(target.shape[0]))
        rng.shuffle(channel_indices)
        for channel_idx in channel_indices:
            windows.extend(
                self._sample_short_windows(
                    target[channel_idx],
                    rng,
                    max_windows - len(windows),
                )
            )
            if len(windows) >= max_windows:
                break
        return windows

    def _iter_pool_generator(
        self,
        arrow_orders,
        arrow_positions,
        rng,
        dataset_rng,
        shard_id,
        num_shards,
        global_num_shards,
        rank,
        worker_id,
    ):
        arrow_cache = OrderedDict()
        invalid_arrow_paths = set()
        emitted = 0
        skipped = 0
        pool_epoch = 0
        start_time = time.time()
        while True:
            pool = []
            bucket_counts = {name: 0 for name in self.dataset_buckets}
            while len(pool) < self.sample_pool_size:
                bucket, dataset_name = self._choose_dataset(dataset_rng)
                bucket_counts[bucket] += 1
                target = min(
                    self.samples_per_dataset_block,
                    self.sample_pool_size - len(pool),
                )
                block = []
                skipped += self._fill_dataset_block(
                    block=block,
                    dataset_name=dataset_name,
                    arrow_orders=arrow_orders,
                    arrow_positions=arrow_positions,
                    rng=rng,
                    shard_id=shard_id,
                    num_shards=num_shards,
                    arrow_cache=arrow_cache,
                    invalid_arrow_paths=invalid_arrow_paths,
                    target_windows=target,
                    max_history_len=self.history_length,
                    max_pred_len=self.padded_prediction_length,
                )
                pool.extend(block)
            rng.shuffle(pool)
            pool_epoch += 1
            emitted += len(pool)
            if (
                self.log_interval
                and rank == 0
                and worker_id == 0
                and emitted % self.log_interval < len(pool)
            ):
                print(
                    f"[balanced pretrain rank={rank} worker={worker_id}] "
                    f"pool_epoch={pool_epoch} pool_ready={len(pool)} "
                    f"worker_windows={emitted} bucket_blocks={bucket_counts} "
                    f"skipped={skipped} elapsed={time.time() - start_time:.1f}s",
                    flush=True,
                )
            while pool:
                yield pool.pop()


class BalancedShortGIFTEvalDataset(
    ShortNaNPaddingMixin, GIFTEvalTrainPartStreamingDataset
):
    def __init__(
        self,
        *args,
        short_prediction_lengths,
        official_history_lengths,
        **kwargs,
    ):
        super().__init__(*args, **kwargs)
        self.short_prediction_lengths = tuple(int(x) for x in short_prediction_lengths)
        self._set_official_history_lengths(official_history_lengths)
        self.mase_hard_configs = [
            (name, "short") for name in MASE_HARD_CONFIGS
            if (name, "short") in self.dataset_configs
        ]
        self.crps_hard_configs = [
            (name, "short") for name in CRPS_HARD_CONFIGS
            if (name, "short") in self.dataset_configs
        ]
        if len(self.dataset_configs) != 55:
            raise ValueError(
                f"Expected all 55 GIFT-Eval short configs, got {len(self.dataset_configs)}"
            )
        if not self.mase_hard_configs or not self.crps_hard_configs:
            raise ValueError("Hard short config pools did not resolve.")
        raw_weights = {}
        for config in self.dataset_configs:
            weight = 0.55 / len(self.dataset_configs)
            if config in self.mase_hard_configs:
                weight += 0.30 / len(self.mase_hard_configs)
            if config in self.crps_hard_configs:
                weight += 0.15 / len(self.crps_hard_configs)
            raw_weights[config] = min(weight, 3.0 / len(self.dataset_configs))
        normalizer = sum(raw_weights.values())
        self.config_weights = [
            raw_weights[config] / normalizer for config in self.dataset_configs
        ]
        print(
            f"Balanced GIFT-Eval short pools: uniform={len(self.dataset_configs)}, "
            f"mase_hard={len(self.mase_hard_configs)}, "
            f"crps_hard={len(self.crps_hard_configs)}",
            flush=True,
        )

    def _choose_config(self, rng: random.Random):
        config = rng.choices(
            self.dataset_configs, weights=self.config_weights, k=1
        )[0]
        in_mase = config in self.mase_hard_configs
        in_crps = config in self.crps_hard_configs
        if in_mase and in_crps:
            pool_name = "overlap_hard"
        elif in_mase:
            pool_name = "mase_hard"
        elif in_crps:
            pool_name = "crps_hard"
        else:
            pool_name = "uniform"
        return pool_name, config

    def _sample_dataset_config(
        self,
        Dataset,
        dataset_name,
        term,
        rng,
        shard_id,
        num_shards,
        target_windows,
        max_history_len,
        max_pred_len,
    ):
        metadata = Dataset(name=dataset_name, term=term, to_univariate=False)
        prediction_length = min(
            int(metadata.prediction_length), self.padded_prediction_length
        )
        dataset = Dataset(
            name=dataset_name,
            term=term,
            to_univariate=metadata.target_dim != 1,
        )
        windows = []
        for entry in dataset.training_dataset:
            target = np.asarray(entry["target"], dtype=np.float32)
            if target.ndim == 1:
                target = target.reshape(1, -1)
            elif target.ndim != 2:
                continue
            channel_indices = list(range(target.shape[0]))
            rng.shuffle(channel_indices)
            for channel_idx in channel_indices:
                windows.extend(
                    self._sample_short_windows(
                        target[channel_idx],
                        rng,
                        target_windows - len(windows),
                        fixed_prediction_length=prediction_length,
                        history_config=(dataset_name, term),
                    )
                )
                if len(windows) >= target_windows:
                    return windows
        return windows

    def _iter_pool_generator(
        self,
        Dataset,
        rng,
        dataset_rng,
        shard_id,
        num_shards,
        global_num_shards,
        rank,
        worker_id,
    ):
        emitted = 0
        skipped = 0
        pool_epoch = 0
        start_time = time.time()
        while True:
            pool = []
            pool_counts = {
                "uniform": 0,
                "mase_hard": 0,
                "crps_hard": 0,
                "overlap_hard": 0,
            }
            while len(pool) < self.sample_pool_size:
                pool_name, (dataset_name, term) = self._choose_config(dataset_rng)
                pool_counts[pool_name] += 1
                target_windows = min(
                    self.samples_per_dataset_block,
                    self.sample_pool_size - len(pool),
                )
                block = self._sample_dataset_config(
                    Dataset=Dataset,
                    dataset_name=dataset_name,
                    term=term,
                    rng=rng,
                    shard_id=shard_id,
                    num_shards=num_shards,
                    target_windows=target_windows,
                    max_history_len=self.history_length,
                    max_pred_len=self.padded_prediction_length,
                )
                if block:
                    pool.extend(block)
                else:
                    skipped += 1
            rng.shuffle(pool)
            pool_epoch += 1
            emitted += len(pool)
            if (
                self.log_interval
                and rank == 0
                and worker_id == 0
                and emitted % self.log_interval < len(pool)
            ):
                print(
                    f"[balanced gifteval rank={rank} worker={worker_id}] "
                    f"pool_epoch={pool_epoch} pool_ready={len(pool)} "
                    f"worker_windows={emitted} pool_blocks={pool_counts} "
                    f"skipped={skipped} elapsed={time.time() - start_time:.1f}s",
                    flush=True,
                )
            while pool:
                yield pool.pop()


class ScheduledSourceMixedDataset(IterableDataset):
    def __init__(
        self,
        pretrain_dataset,
        gifteval_dataset,
        batch_size,
        gradient_accumulation_steps,
        start_optimizer_step=0,
        seed=5252,
    ):
        self.pretrain_dataset = pretrain_dataset
        self.gifteval_dataset = gifteval_dataset
        self.batch_size = int(batch_size)
        self.gradient_accumulation_steps = max(1, int(gradient_accumulation_steps))
        self.start_optimizer_step = max(0, int(start_optimizer_step))
        self.seed = int(seed)
        print(
            "Use scheduled short source mix: "
            "steps=[0,3000):70/30, [3000,6000):60/40, "
            "[6000,50000]:50/50",
            flush=True,
        )

    @staticmethod
    def pretrain_ratio(step: int) -> float:
        if step < 3000:
            return 0.70
        if step < 6000:
            return 0.60
        return 0.50

    @staticmethod
    def _slice_range(batch, start: int, end: int):
        batch_size = int(batch["context"].shape[0])
        indices = torch.arange(start, end, dtype=torch.long)
        sliced = {}
        for key, value in batch.items():
            if torch.is_tensor(value) and value.ndim > 0 and value.shape[0] == batch_size:
                sliced[key] = value.index_select(0, indices.to(value.device))
            else:
                sliced[key] = value
        return sliced

    def __iter__(self):
        worker_info = get_worker_info()
        worker_id = worker_info.id if worker_info is not None else 0
        rank = int(os.getenv("RANK", "0"))
        num_workers = worker_info.num_workers if worker_info is not None else 1
        rng = random.Random(self.seed + (rank * num_workers + worker_id) * 1237)
        iterators = {
            "pretrain": iter(self.pretrain_dataset),
            "gifteval": iter(self.gifteval_dataset),
        }
        pending = {"pretrain": None, "gifteval": None}
        offsets = {"pretrain": 0, "gifteval": 0}
        local_micro_batch = 0
        last_ratio = None

        def take(source: str, count: int):
            parts = []
            remaining = count
            while remaining > 0:
                batch = pending[source]
                offset = offsets[source]
                if batch is None or offset >= int(batch["context"].shape[0]):
                    try:
                        batch = next(iterators[source])
                    except StopIteration:
                        iterators[source] = iter(
                            self.pretrain_dataset
                            if source == "pretrain"
                            else self.gifteval_dataset
                        )
                        batch = next(iterators[source])
                    pending[source] = batch
                    offset = 0
                available = int(batch["context"].shape[0]) - offset
                size = min(remaining, available)
                parts.append(self._slice_range(batch, offset, offset + size))
                offsets[source] = offset + size
                remaining -= size
            return parts

        while True:
            optimizer_step = (
                self.start_optimizer_step
                + local_micro_batch // self.gradient_accumulation_steps
            )
            ratio = self.pretrain_ratio(optimizer_step)
            pretrain_rows = int(round(self.batch_size * ratio))
            gifteval_rows = self.batch_size - pretrain_rows
            parts = take("pretrain", pretrain_rows)
            parts.extend(take("gifteval", gifteval_rows))
            mixed = GroupAwareMixedChronos2BatchDataset._concat_and_shuffle_groups(
                parts, rng
            )
            if ratio != last_ratio and rank == 0 and worker_id == 0:
                print(
                    f"Short source schedule transition: optimizer_step={optimizer_step} "
                    f"pretrain_rows={pretrain_rows} gifteval_rows={gifteval_rows}",
                    flush=True,
                )
                last_ratio = ratio
            local_micro_batch += 1
            yield mixed


def create_short_balanced_pretraining_dataset(
    *,
    data_dir: str,
    gift_eval_path: str,
    gift_eval_src: str | None,
    batch_size: int,
    patch_size: int,
    gradient_accumulation_steps: int,
    start_optimizer_step: int,
    seed: int,
    **stream_kwargs,
):
    if batch_size <= 1:
        raise ValueError("batch_size must be greater than one.")
    Dataset = import_gifteval_dataset(gift_eval_path, gift_eval_src)
    short_prediction_lengths = []
    official_history_lengths = {}
    for dataset_name in GIFT_EVAL_SHORT_DATASETS:
        metadata = Dataset(name=dataset_name, term="short", to_univariate=False)
        prediction_length = int(metadata.prediction_length)
        if 0 < prediction_length <= 192:
            short_prediction_lengths.append(prediction_length)
        history_lengths = tuple(
            min(2048, int(np.asarray(entry["target"]).shape[-1]))
            for entry in metadata.test_data.input
        )
        if not history_lengths or min(history_lengths) <= 0:
            raise ValueError(
                f"Invalid official short history distribution for {dataset_name}"
            )
        official_history_lengths[(dataset_name, "short")] = history_lengths
    if len(short_prediction_lengths) != 55:
        raise ValueError(
            f"Expected 55 official short horizons, got {len(short_prediction_lengths)}"
        )

    common = dict(
        max_seq_len=2048,
        max_pred_len=192,
        batch_size=batch_size,
        output_patch_size=patch_size,
        patch_len=patch_size,
        min_history_len=1,
        min_pred_len=1,
        history_patch_multiple=False,
        prediction_patch_multiple=False,
        curriculum_enable=False,
    )
    pretrain = BalancedShortPretrainDataset(
        data_dir=data_dir,
        short_prediction_lengths=short_prediction_lengths,
        official_history_lengths=official_history_lengths,
        seed=seed + 11,
        **common,
        **stream_kwargs,
    )
    gifteval = BalancedShortGIFTEvalDataset(
        gift_eval_path=gift_eval_path,
        gift_eval_src=gift_eval_src,
        dataset_names="all",
        terms="short",
        short_prediction_lengths=short_prediction_lengths,
        official_history_lengths=official_history_lengths,
        seed=seed + 29,
        **common,
        **{
            key: value
            for key, value in stream_kwargs.items()
            if key
            not in {
                "window_stride",
                "samples_per_arrow",
                "arrow_row_chunk_size",
                "prefetch_pools",
                "arrow_cache_size",
            }
        },
    )
    mixed = ScheduledSourceMixedDataset(
        pretrain_dataset=pretrain,
        gifteval_dataset=gifteval,
        batch_size=batch_size,
        gradient_accumulation_steps=gradient_accumulation_steps,
        start_optimizer_step=start_optimizer_step,
        seed=seed + 47,
    )
    mixed.short_prediction_lengths = tuple(short_prediction_lengths)
    print(
        "Use balanced short pretraining: "
        f"gifteval_configs=55, horizons={sorted(set(short_prediction_lengths))}, "
        "history_sampling=official_test_windows_clipped_to_2048, "
        f"context_tensor=2048, future_tensor=192, batch_size={batch_size}",
        flush=True,
    )
    return mixed
