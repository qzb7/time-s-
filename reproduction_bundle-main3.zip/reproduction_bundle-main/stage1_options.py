"""Resolve Stage1 options without importing Torch; used by dry-run tests."""
import argparse
import ast
import json
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent

def boolean(value):
    if str(value).lower() in {"1", "true", "yes", "on"}: return True
    if str(value).lower() in {"0", "false", "no", "off"}: return False
    raise argparse.ArgumentTypeError("Expected true/false")

def resolve(argv=None):
    cfg = json.loads((ROOT/"configs/stage1.original.json").read_text())
    cfg.pop("patch_size")
    cfg["stop_after_steps"] = 27000
    cfg.update(chronos_repo=str(ROOT/"stage1/chronos"), toto2_src=str(ROOT/"stage1/toto2"),
               dd_unit_scaling_src=str(ROOT/"stage1/dd_unit_scaling"),
               gift_eval_src=str(ROOT/"stage1/chronos/gift-eval/src"),
               model_name_or_path=None, data_dir=None, gift_eval_path=None,
               output_dir=str(ROOT/"outputs/stage1/timeonly"))
    p = argparse.ArgumentParser(description="Stage1: CLI > STAGE1_<UPPERCASE_ARG> > script/defaults. Both --snake_case and --kebab-case supported.")
    aliases = {"model_name_or_path":"STAGE1_MODEL", "data_dir":"STAGE1_PRETRAIN",
               "gift_eval_path":"STAGE1_GIFTEVAL", "output_dir":"STAGE1_OUTPUT"}
    for key, default in cfg.items():
        convert = boolean if isinstance(default,bool) else type(default) if default is not None else str
        env = os.environ.get("STAGE1_"+key.upper(), os.environ.get(aliases.get(key,"")))
        if env not in (None, ""):
            default = convert(env)
        flags = list(dict.fromkeys(["--"+key,"--"+key.replace("_","-")]))
        p.add_argument(*flags, dest=key, type=convert, default=default)
    p.add_argument("--gpus",type=int,default=os.getenv("STAGE1_GPUS",6))
    p.add_argument("--master-port",type=int,default=os.getenv("STAGE1_MASTER_PORT",29677))
    p.add_argument("--launch-mode",choices=["foreground","background"],default=os.getenv("STAGE1_LAUNCH_MODE","foreground"))
    p.add_argument("--check",action="store_true")
    p.add_argument("--emit-shell",type=Path,help=argparse.SUPPRESS)
    p.add_argument("--dry-run",action="store_true",help="Print resolved parameters without checking hardware or starting")
    a = p.parse_args(argv)
    for key in ("gpus","per_device_train_batch_size","gradient_accumulation_steps","max_steps","stop_after_steps","save_steps","logging_steps"):
        if getattr(a,key)<=0: p.error(f"{key} must be positive")
    if not 0<=a.warmup_steps<a.max_steps: p.error("Require 0 <= warmup_steps < max_steps")
    if a.stop_after_steps>a.max_steps: p.error("stop_after_steps exceeds max_steps")
    if not 0<a.cpm_max_mask_probability<=1: p.error("CPM probability must be in (0,1]")
    for prefix in ("adamw", "normuon"):
        if not 0<=getattr(a,prefix+"_min_lr")<=getattr(a,prefix+"_learning_rate"):
            p.error(f"Invalid {prefix} learning rates")
    return a, {key:getattr(a,key) for key in cfg}

def arguments(config):
    result=[]
    for key,value in config.items():
        if value is not None:
            result.extend(["--"+key,str(value).lower() if isinstance(value,bool) else str(value)])
    return result
