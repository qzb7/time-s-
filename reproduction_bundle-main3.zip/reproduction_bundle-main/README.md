# Toto2 内源多模态复现交接包

## Dion 环境优先、包内兜底（2026-09-18）

Stage1 优先加载当前 Python 环境里的 `dion`；仅当环境完全没有 `dion` 时，
才加载包内 `vendor/dion` 的 MIT 许可 NorMuon 副本，不需要华为平台预装或联网下载 `dion`。
包内副本针对 207 的 PyTorch 2.4.1 调整了 DeviceMesh/DTensor 导入位置，
并在 207 完成一次极小 CUDA 优化器更新。若环境中已有但损坏/不兼容的 `dion`，
会明确报错，不会悄悄换成包内实现。来源、改动及验证边界见
[vendor/dion/README.md](vendor/dion/README.md)。完整训练仍取决于其他依赖和 CUDA 环境。
Stage1 Toto2 模型还针对 PyTorch 2.4 缺少 `enable_gqa` 的情况增加了
K/V 分组展开的兼容路径；较新 PyTorch 仍保持原生 `enable_gqa` 调用。
207 上的单卡极小训练测试已越过模型加载和数据加载，但 240 秒限时内
尚未完成首步，因此**不应把它视为 8192 长度或多机训练成功验证**。

## 2026-09-18 启动器修正（多机作业以此为准）

`start_stage1.sh` 现支持 `--参数 值` 和 `--参数=值`，并接收 `--gpus`、
`--master-port`、`--launch-mode` 等启动器参数，不会把它们传给训练器。
**不写 `--gpus` 时自动读取本节点可见 GPU 数**；4 节点各 8 卡时是
`--nnodes=4 --nproc_per_node=8`，不是每节点传 `--gpus 32`。
同时兼容平台已启动的 `RANK/WORLD_SIZE/LOCAL_RANK` 进程，不再嵌套 torchrun。
详见 [STAGE1_MULTINODE.md](STAGE1_MULTINODE.md)。先用 `--dry-run` 核对拓扑。

下面较早章节中提及“仅单机”、默认 6 卡和旧启动脚本的描述属于历史版本；
请以本节与 `STAGE1_MULTINODE.md` 为准。

## 最新入口：纯Bash直接torchrun（覆盖下文旧bootstrap说明）

已删除`stage1_bootstrap.py`。`start_stage1.sh`直接调用`python -m torch.distributed.run stage1/pretrain_toto2_short_balanced.py`。所有路径和默认训练参数集中在sh，CLI参数在末尾直接透传给训练器，覆盖默认值；继承当前激活环境的`python`，不再优先选择旧服务器conda路径。

`bash start_stage1.sh --dry-run`查看最终命令；`--check`旧预检已移除。新机先激活Chronos2环境，再改sh顶部路径。前台用于平台；`--launch-mode background`为setsid+nohup。默认模型在包内weights/Toto-2.0-313m-time-only，模型/数据不随本包提供。输出必须新空目录。

### 能训Chronos2的环境能否直接训Stage1？

不能仅凭Chronos2能运行保证。当前Toto2/dd_unit_scaling包声明Python>=3.12，原209运行Python3.12.13、Torch2.6.0+cu124；基础Chronos2环境可能是Python3.10/3.11。建议用Python3.12独立环境，不直接升级破坏现有环境。

还需核对：gluonts[torch]（会引入Lightning）、einops、jaxtyping、unit-scaling、datasets、pyarrow、safetensors、huggingface_hub（本代码使用load_torch_model）、pandas、python-dotenv、toolz、以及NorMuon优化器所需依赖。基础Chronos2环境不一定包含这些。源码已随包提供Toto2/dd_unit_scaling，但它们的第三方依赖仍须存在；CLIP/Zarr不是Stage1必要依赖。

可以在新环境中先执行`python -m pip install -e ./stage1/dd_unit_scaling -e ./stage1/toto2`，让包管理器解析声明依赖；随后核对原configs/environment209.txt中的datasets/pyarrow等版本。不要把这当作已验证的一键安装，也不建议盲目升级现有CUDA Torch。可用`python -c "import torch; print(torch.__version__, torch.version.cuda, torch.cuda.is_available()); import toto2, dd_unit_scaling"`检查核心导入。完整验收仍需实际batch前向/反向与NCCL多卡测试；batch112能否放下取决于GPU显存。

NorMuon明确依赖`dion.NorMuon`，不仅是普通AdamW环境。检查`python -c "from dion import NorMuon"`；如缺少或版本没有该类，需要按原环境清单补齐。已运行test_direct_launch.py与bash语法检查，未在新服务器运行真实训练。

## 最新：Stage1脚本参数与作业平台透传

以本节为准：`start_stage1.sh`顶部可以直接修改batch、LR、warmup、停止步数等默认值。优先级为 **命令行 > STAGE1_*环境变量 > 脚本默认值/原始预设**。未列在shell顶部的训练参数也支持透传，完整列表 `bash start_stage1.sh --help`；未知参数报错，不会静默忽略。

默认改为**前台运行**，适合作业平台跟踪进程、日志和退出码；无需再在平台入口外套nohup。此入口单机多卡；`--gpus`为本机进程数，不代表多节点总GPU数。继承平台CUDA_VISIBLE_DEVICES，不覆写平台卡映射。

```bash
# 平台启动命令；可在平台“参数”栏填写以下选项
bash start_stage1.sh \
  --model_name_or_path /models/Toto-2.0-313m-time-only \
  --data_dir /data/GIFTEvalPretrain --gift_eval_path /data/GIFTEval \
  --output_dir /outputs/stage1-run1 --gpus 6 \
  --per_device_train_batch_size 112 --gradient_accumulation_steps 1 \
  --adamw_learning_rate 6e-5 --adamw_min_lr 6e-6 \
  --normuon_learning_rate 0.00325 --normuon_min_lr 0.000325 \
  --warmup_steps 1000 --max_steps 1000000 --stop_after_steps 27000
```

参数名支持下划线与短横线，如`--per-device-train-batch-size`等价。bool参数显式传`true`/`false`。

环境变量方式：`STAGE1_PER_DEVICE_TRAIN_BATCH_SIZE=112`、`STAGE1_ADAMW_LEARNING_RATE=6e-5`等，为`STAGE1_`加训练参数全大写；路径兼容`STAGE1_MODEL/STAGE1_PRETRAIN/STAGE1_GIFTEVAL`。**STAGE1_OUTPUT/--output_dir现在是最终checkpoint输出目录，不再追加timeonly**。

```bash
# 只核对参数，不检查CUDA/路径，也不启动
bash start_stage1.sh --dry-run --per_device_train_batch_size 64
# 检查真实环境，不启动
bash start_stage1.sh --check
# SSH脱离终端模式
bash start_stage1.sh --launch-mode background
```

最终解析参数打印到日志，并保存`logs/stage1-resolved-时间-PID.json`。后台模式额外保存训练log；前台模式stdout/stderr交给平台采集。所有优化参数直接传入stage1训练器，不再被run.py中的固定预设覆盖。

完整恢复优化器时同时传`--model_name_or_path /path/checkpoint-X --resume_from_checkpoint /path/checkpoint-X`，输出仍需新目录，并保证停止步数大于已训练步数。新初始化模式默认不恢复optimizer。改变GPU/batch会改变有效batch与历史可比性；历史原值为6×112×1=672。cosine调度max_steps与stop_after_steps相互独立。

已做shell→Python透传测试（覆盖优先级、别名、空格路径、bool和错误参数），未启动GPU训练。

## Stage1一键启动（新增）

在Linux服务器上解压后，进入本目录执行：

```bash
bash start_stage1.sh
```

会检查初始time-only模型、Arrow数据、Python依赖、6张可见GPU，然后以setsid+nohup后台启动。日志在包内logs，结果在包内outputs/stage1/timeonly。不自动安装环境，不停止其他任务，不覆盖已有结果，也不恢复已有训练优化器。

**只复制代码包并不足以训练：模型权重、数据和CUDA环境必须存在。** 可将资源按下列位置放入包内，或使用服务器原路径（自动查找/home/toto-main/models、/data、/public_data）：

```text
weights/Toto-2.0-313m-time-only/config.json
weights/Toto-2.0-313m-time-only/model.safetensors
data/GIFTEvalPretrain/
data/GIFTEval/
```

只检查不启动：`bash start_stage1.sh --check`。
非标准路径可设置STAGE1_MODEL、STAGE1_PRETRAIN、STAGE1_GIFTEVAL；Python可设置STAGE1_PYTHON，输出可设置STAGE1_OUTPUT。默认GPU0–5；要使用其他六卡，设置CUDA_VISIBLE_DEVICES。脚本只做资源/导入预检，不能保证全部数据内容有效、显存足够或逐位复现历史结果。

采集日期：2026-09-09。代码来源：209（313M time-only 续训）、207（TIME20W 生成、内源多模态训练）。没有停止、重启或修改服务器上的训练。

## 先说明复现边界

- 包含源代码、checkpoint 中保存的参数、环境包版本、可迁移启动入口；**不包含模型权重或训练数据**。接收者仍须准备下面的资源并修改路径，不需要重新选择学习率等超参数。
- 原始代码是当前服务器文件快照，不是历史 commit；尚未证明这些文件自当年运行以来完全未修改。因此不能承诺逐位重现历史 checkpoint 或同样的排行榜数值。
- `multimodal` 是从 time-only27000 开始的原 all7 实验；`resume22000` 是复现后来22000实验的续训入口，实际起点为多模态14000并恢复 optimizer/scheduler。两者不能混为一轮训练。
- 历史22000经过多轮中间实验，**本包不是从零到22000全部中间阶段的一键流水线**。要严格复现22000那一段，须提供对应14000完整checkpoint和相同数据。
- TIME20W来自 `test_data.input`，GIFTEval部分旧数据也是 test-input adaptation。不得把使用它们的结果报告为干净 zero-shot；生成器虽不读取未来标签，但测试历史参与训练须披露。

## 目录

| 目录/文件 | 内容 |
|---|---|
| stage1 | 209 time-only训练器、CPM loader、Toto2、dd_unit_scaling、Chronos/GIFTEval依赖 |
| generator | 207生成器及图像renderer、文本模板、旧辅助脚本 |
| stage3 | 207训练代码快照及Toto2，包含历史其他实验依赖；只使用下述入口 |
| vendor/TIME/src | TIME官方本地版本的loader/config依赖 |
| configs/*.original.json | 从checkpoint读取的原始参数，未改写 |
| configs/environment207.txt / environment209.txt | 当前远端环境版本清单（不是历史环境锁） |
| run.py | 参数预设、路径映射、单机/多机torchrun入口，默认只打印命令 |
| merge_safe.py | 完整性检查后合并，保留原rank分片，不截断 |
| check_package.py / SHA256.json | 静态检查及文件校验和 |

## 1. 环境和路径准备

Linux + NVIDIA CUDA。Stage1当前209环境 Python3.12、Torch2.6.0+cu124；生成/多模态当前207环境 Python3.11、Torch2.4.1、torchvision0.19.1。推荐使用两个独立环境。完整版本见environment清单；CUDA版Torch须使用对应官方wheel源，不能在不同Python/CUDA平台上盲目安装整个清单。

关键依赖：numpy、torch/torchvision、einops、datasets、pyarrow、gluonts、pandas、scipy、zarr **2.18.7**、numcodecs **0.15.1**、open_clip_torch **3.3.0**、safetensors、ftfy、timm、PyYAML、tqdm。模型源码与dd_unit_scaling随包提供。先由管理员按版本清单部署环境；本包没有做新机器的依赖安装验证。

复制并编辑 `configs/paths.example.json`（可以原地改，或者用 `--paths /绝对路径/paths.json`）。最长路径前缀优先匹配，可添加某个具体数据目录的映射。

必须单独准备：

1. Stage1初始模型：209 `/home/toto-main/models/Toto-2.0-313m-time-only/{model.safetensors,config.json}`。这不是未经转换的原始313M模型。对应配置已另存 `configs/timeonly_initial_model_config.json`：24层、d_model1024、16头、patch32、无变量层。
2. 原始 `/data/GIFTEvalPretrain`、`/data/GIFTEval`，以及生成用TIME数据。
3. `/home/.../ViT-B-32.pt` 的原始CLIP权重（通过 `CLIP_CHECKPOINT` 指定）。不要使用随机初始化权重。
4. 多模态训练所需七个原始Zarr目录见 `stage3_from27000.original.json`。不能只生成TIME20W就代替全部七个目录。
5. 可选精确续训14000：`model.safetensors`、`config.json`、`layer16_concat_additive_state.pt`、对应config、`training_state.pt`。缺少多模态pt会导致重新初始化融合层，不能接受。

## 2. 从313M续训到27000

```bash
python run.py timeonly                 # 先核对打印路径
mkdir -p logs
CUDA_VISIBLE_DEVICES=0,1,2,3,4,5 setsid nohup python -u run.py timeonly --execute > logs/timeonly.log 2>&1 < /dev/null &
```

真实入口：`stage1/pretrain_toto2_short_balanced.py`，loader `load_gifteval_toto2_cpm_pretrain.py`。日志证实原world_size=6、每GPU112、全局batch672。

参数：序列8192，patch32，CPM最大跨度8、覆盖0.4，warmup1000，clip7，seed5252，FP32、TF32关闭。**NorMuon+AdamW**：NorMuon LR0.00325/min0.000325、mu0.96、beta2=.999；AdamW LR6e-5/min6e-6、betas .91/.972。不是纯AdamW。

原调度max_steps=1,000,000保持不变；便携补丁 `stop_after_steps=27000` 在保存27000后退出，不改变cosine。原文件保留`.original`供diff。

## 3. TIME20W内源图文生成

```bash
python run.py generate
CUDA_VISIBLE_DEVICES=0,1,2,3,4,5 setsid nohup python -u run.py generate --execute > logs/generate.log 2>&1 < /dev/null &
```

默认完全使用旧TIME20W的配置配额与seed20260901。选择TIME其他source和数量：编辑 `configs/quotas.example.json`，每行明确dataset/frequency、term、count，然后：

```bash
python run.py generate --quotas configs/quotas.example.json --execute
```

总量自动求和。这一接口选择的是TIME loader支持的source/term；不把任意Arrow目录误当成TIME数据。若要添加新格式数据源，应实现生成器的loader协议，不能仅修改字符串路径。

历史最多8192，左padding，原缺失点保留mask；源context重复时按8192/6144/4096/3072/2048裁剪。每个样本256个patch。图像使用原 `rgb_overlay_raw_independent_diff_shared_q01_q99_v1 / render_rgb_overlay()`；文本原 `toto2_stats_template.describe_patch`；CLIP编码代码未重写。

保存时 image/text embedding 使用FP16，另存每patch max-abs FP32 scale；训练loader恢复尺度。不要仅转float32而漏乘scale。输出Zarr还包含序列、有效mask、padding mask与source字段，以源码schema为准。

并行参数沿用TIME20W：每rank64条/group、CLIP batch16384、CPU workers16/rank、prefetch6、写入batch64。

### 32卡

单机32卡：`python run.py generate --gpus 32 --execute`。

四节点×8卡：代码、CLIP、数据、输出路径须在各节点一致；输出须共享文件系统。四台机器分别运行（将node-rank改为0/1/2/3，master填第0台内网IP）：

```bash
python run.py generate --gpus 8 --nodes 4 --node-rank 0 --master-addr 10.0.0.1 --execute
```

没有实际做32卡吞吐测试。16 workers/rank在32卡合计512个CPU进程，prefetch队列还会消耗大量RAM；如资源不足用 `--workers 4 --prefetch 2`。编码相同不代表总吞吐必然是6卡的32/6倍。rank数量变化会改变写入顺序，但相同配额仍按全局索引分片、不缺额。块大小取不超过100000的world倍数（6卡99996，32卡100000）。

所有节点成功结束后再合并：

```bash
python merge_safe.py /outputs/toto_reproduction/generation_shards /outputs/time200k_merged --expected 200000
```

自定义数量同步修改expected。不要运行旧 `merge_rank_zarr.py`：旧脚本会截断并删分片。新合并器仅在总数匹配时运行，保留所有原分片；合并失败保留现场，不自动删除重来。

## 4. 从27000开始内源多模态训练

为避免复制27000，paths.json增加精确键 `/home/toto-main/output/toto2-313m-cpm256-time-only/checkpoint-27000`，值填第2步输出的完整checkpoint路径。

```bash
python run.py multimodal
CUDA_VISIBLE_DEVICES=0,1,2,3,4,5 setsid nohup python -u run.py multimodal --execute > logs/multimodal.log 2>&1 < /dev/null &
```

入口：`pretrain_toto2_313m_multimodal_layer16_all7_tailcpm_globalavg_additive.py`。batch224/GPU，acc1；新AdamW LR5e-5/min5e-6，warmup1000，max200000，clip1，seed260817。前1500步训练多模态部分，随后后8层/out_norm/head等按原set_stage解冻。融合为additive，无metadata。CPM4、最大覆盖40%。三个loss沿实际调用的helper做global masked-patch reduction；不是只看目录名字判断。保存每500步。

若希望重现后期22000那一段，使用 `python run.py resume22000 --execute`，需原多模态14000和对应数据目录。名字表示22000所属实验，不表示从22000恢复，也不会自动停在22000。其原mix为TIME20%/GIF10%/clean70%，自然horizon采样；恢复optimizer/scheduler。不得把这个入口与从27000的新optimizer训练混淆。

## 5. 验证状态与交付检查

已做：三个checkpoint参数与argparse选项逐项检查；6/8/32 rank样本数量及块边界静态检查；启动命令dry run；便携文件语法检查。发现并修复 `patch_size` 是运行时记录而非CLI参数的问题。

未做：新环境安装、真实GPU完整训练、CLIP数值回归、32卡吞吐、重新生成完整20W。上传本地包到207做GPU/导入检查被权限审核阻止；没有绕过，也未改动线上任务。需你明确同意上传并做小规模验证后，才能补充运行验收。

```bash
python check_package.py
```

重要：源码共享函数后来可能被修改，精确历史复现还需历史快照/数据内容指纹/权重及完整阶段链。本包提供当前可审计的启动逻辑，不保证达到某个分数。输出目录非空时启动器拒绝写入，请换OUTPUT_ROOT，避免覆盖实验。
