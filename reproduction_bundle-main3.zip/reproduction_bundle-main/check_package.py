"""CPU static checks; does not claim a full GPU training reproduction."""
import ast
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent
presets = [
    ("stage1.original.json", "stage1/pretrain_toto2_short_balanced.py"),
    ("stage3_from27000.original.json", "stage3/pretrain_toto2_313m_multimodal_layer16_all7_tailcpm_globalavg_additive.py"),
    ("stage3.original.json", "stage3/pretrain_toto2_nonmetadata_natural_mix.py"),
]
for config, script in presets:
    tree = ast.parse((root / script).read_text(encoding="utf-8"))
    flags = {x.value[2:] for node in ast.walk(tree) if isinstance(node, ast.Call)
             and isinstance(node.func, ast.Attribute) and node.func.attr == "add_argument"
             for x in node.args if isinstance(x, ast.Constant) and isinstance(x.value, str)
             and x.value.startswith("--")}
    unknown = set(json.loads((root / "configs" / config).read_text(encoding="utf-8"))) - flags
    if config == "stage1.original.json":
        unknown -= {"patch_size"}  # populated from loaded model at runtime
    assert not unknown, (script, unknown)
    print("PASS config flags:", config)
for world in (6, 8, 32):
    for n in (200000, 200003, 32):
        counts = [max(0, (n-r+world-1)//world) for r in range(world)]
        assert sum(counts) == n and max(counts)-min(counts) <= 1
    assert ((100000//world)*world + world-1)//world*world <= 100000
print("PASS rank counts and block bounds: world=6,8,32")
for relative in ["run.py", "merge_safe.py", "stage1/toto2/toto2/model.py",
                 "generator/time_test_context_targeted_200k_loader.py",
                 "generator/extract_gifteval_test_context_transductive_105k_latest107.py"]:
    ast.parse((root / relative).read_text(encoding="utf-8"))
print("PASS portable entry syntax")
vendor = root / "vendor" / "dion"
assert (vendor / "dion-0.1.0.dist-info" / "licenses" / "LICENSE").is_file()
assert (vendor / "dion-0.1.0.dist-info" / "licenses" / "NOTICE.md").is_file()
for path in (vendor / "dion").glob("*.py"):
    if path.name.startswith("._"):
        continue
    ast.parse(path.read_text(encoding="utf-8"))
print("PASS vendored Dion syntax and license")
manifest = {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(root.rglob("*")) if p.is_file() and p.name != "SHA256.json"
            and "__pycache__" not in p.parts}
(root / "SHA256.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
print("SHA256.json updated")
