# Stage1 华为云道昇腾运行说明

当前 Stage1 入口仍为 `start_stage1.sh`。启动器检测到 `VC_WORKER_HOSTS`
后，会自动读取云道注入的拓扑：

| 云道环境变量 | torchrun 参数 |
|---|---|
| `VC_WORKER_HOSTS` 的第一个地址 | `master_addr` |
| `MA_NUM_HOSTS` | `nnodes` |
| `VC_TASK_INDEX` | `node_rank` |
| `MA_NUM_GPUS` | `nproc_per_node` |

命令行及 `STAGE1_*` 环境变量的优先级高于自动检测值。不要把集群总卡数
传给 `--gpus`；该参数始终表示每个节点上的设备数。

## 镜像与依赖

平台教程中的 `forecast_pretrain` 基础镜像已包含匹配的 `torch==2.3.1` 和
`torch_npu==2.3.1`。若使用其他镜像，必须保证 Torch、torch_npu、CANN
三者版本匹配。训练器启动时会：

1. 导入 `torch_npu.contrib.transfer_to_npu`；
2. 调用 `torch.npu.set_compile_mode(jit_compile=False)`；
3. 分布式训练使用 HCCL；
4. NorMuon 在 NPU 上禁用 CUDA Triton kernel。

Toto2、dd_unit_scaling 及 Dion 还有独立依赖，基础镜像是否完整提供这些依赖
需要在正式训练前验证。仓库内源码声明的原始环境为 Python >= 3.12、
Torch >= 2.4；教程镜像的 Torch 2.3.1 尚未在本仓库完成真实 NPU
前向/反向验证。不要在未验证的情况下直接覆盖平台预装的 Torch 或 torch_npu。

## 作业命令

平台应在每个节点执行同一条命令，拓扑参数由环境自动填充：

```bash
bash start_stage1.sh \
  --model_name_or_path /共享路径/Toto-2.0-313m-time-only \
  --data_dir /共享路径/GIFTEvalPretrain \
  --gift_eval_path /共享路径/GIFTEval \
  --output_dir /共享路径/outputs/stage1-run1 \
  --launch-mode foreground
```

模型、数据和输出目录必须能被所有节点访问，输出目录必须为空。云端多机任务
必须使用前台模式，以便平台跟踪所有节点的退出码。

只检查拓扑和最终命令时，可以加上 `--dry-run`。

## 正式训练前的最小检查

```bash
python -c "import torch, torch_npu; print(torch.__version__, torch_npu.__version__, torch_npu.npu.is_available(), torch_npu.npu.device_count())"
PYTHONPATH="$PWD/vendor/dion:$PWD/stage1/toto2:$PWD/stage1/dd_unit_scaling" \
  python -c "from dion import NorMuon; import toto2, dd_unit_scaling; print('imports ok')"
```

建议先提交单节点、单卡、小 batch、单步作业，确认 HCCL、模型前向/反向、
NorMuon 以及 checkpoint 保存均正常，再扩大到正式拓扑：

```bash
bash start_stage1.sh --gpus 1 \
  --per_device_train_batch_size 1 \
  --max_steps 1 --stop_after_steps 1 --save_steps 1 \
  --model_name_or_path /共享路径/Toto-2.0-313m-time-only \
  --data_dir /共享路径/GIFTEvalPretrain \
  --gift_eval_path /共享路径/GIFTEval \
  --output_dir /共享路径/outputs/stage1-npu-smoke
```

该 smoke test 仍会读取真实数据和完整模型；它不是 CPU 单元测试。
