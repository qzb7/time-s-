"""Merge only after every rank exits successfully; retain all original shards."""
import argparse
from pathlib import Path
import json
import numpy as np
import zarr

p = argparse.ArgumentParser()
p.add_argument("shards", type=Path)
p.add_argument("output", type=Path)
p.add_argument("--expected", type=int, required=True)
a = p.parse_args()
stores = sorted(a.shards.glob("block-*.rank-*.zarr"))
if not stores:
    raise SystemExit("No stores")
blocks = {}
total = 0
for path in stores:
    g = zarr.open_group(str(path), mode="r")
    sizes = {g[k].shape[0] for k in g.array_keys()}
    if len(sizes) != 1:
        raise ValueError(f"Inconsistent array lengths: {path}")
    total += next(iter(sizes))
    blocks.setdefault(path.name.split(".rank-")[0], []).append(path)
if total != a.expected:
    raise ValueError(f"Found {total}, expected {a.expected}; do not merge incomplete run")
if a.output.exists():
    raise FileExistsError(a.output)
a.output.mkdir(parents=True)
for block, paths in blocks.items():
    groups = [zarr.open_group(str(path), mode="r") for path in paths]
    keys = sorted(groups[0].array_keys())
    if any(sorted(g.array_keys()) != keys for g in groups):
        raise ValueError("Schema mismatch")
    count = sum(g[keys[0]].shape[0] for g in groups)
    dest = zarr.open_group(str(a.output / (block + ".zarr")), mode="w")
    dest.attrs.update(dict(groups[0].attrs))
    for key in keys:
        src = groups[0][key]
        dest.create_dataset(key, shape=(count,) + src.shape[1:], chunks=src.chunks,
                            dtype=src.dtype, compressor=src.compressor)
    offset = 0
    for g in groups:
        n = g[keys[0]].shape[0]
        for left in range(0, n, 64):
            right = min(n, left + 64)
            for key in keys:
                dest[key][offset+left:offset+right] = g[key][left:right]
        offset += n
    dest.attrs["written_count"] = count
    print(block, count, flush=True)
(a.output / "COMPLETE.json").write_text(json.dumps({"written_count": total,
    "source_type": "time_test_input_transductive", "labels_accessed": False,
    "source_shards_retained": True}, indent=2))
