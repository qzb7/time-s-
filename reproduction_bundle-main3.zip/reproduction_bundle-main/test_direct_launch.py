import os
from pathlib import Path
import shlex
import subprocess
import sys

root=Path(__file__).resolve().parent
env=dict(os.environ,STAGE1_PYTHON=sys.executable,STAGE1_PER_DEVICE_TRAIN_BATCH_SIZE='64')
cmd=['bash',str(root/'start_stage1.sh'),'--dry-run','--gpus','8','--per-device-train-batch-size','32',
     '--model_name_or_path','/models/path with spaces','--adamw_learning_rate','0.00008']
r=subprocess.run(cmd,env=env,text=True,capture_output=True,check=True)
tokens=shlex.split(r.stdout)
assert 'torch.distributed.run' in tokens and '--nproc_per_node=8' in tokens
def last(flag): return tokens[max(i for i,x in enumerate(tokens) if x==flag)+1]
assert last('--per_device_train_batch_size')=='32'
assert last('--model_name_or_path')=='/models/path with spaces'
assert last('--adamw_learning_rate')=='0.00008'
assert not (root/'stage1_bootstrap.py').exists()
assert all('bootstrap' not in x for x in tokens)
multi_env=dict(env,CUDA_VISIBLE_DEVICES='0,1,2,3,4,5,6,7',
               SLURM_NNODES='4',SLURM_NODEID='2',MASTER_ADDR='10.0.0.1')
multi=subprocess.run(['bash',str(root/'start_stage1.sh'),'--dry-run',
    '--model_name_or_path=/models/toto2', '--master_port=29677',
    '--launch_mode=foreground'],env=multi_env,capture_output=True,text=True,check=True).stdout
assert 'nodes=4 node_rank=2 local_gpus=8 prelaunched=0' in multi
assert '--nnodes=4 --node_rank=2 --nproc_per_node=8' in multi
assert '--master_port=29677' in multi and '--model_name_or_path /models/toto2' in multi
prelaunched_env=dict(env,RANK='9',WORLD_SIZE='32',LOCAL_RANK='1',LOCAL_WORLD_SIZE='8')
prelaunched=subprocess.run(['bash',str(root/'start_stage1.sh'),'--dry-run'],
    env=prelaunched_env,capture_output=True,text=True,check=True).stdout
assert 'prelaunched=1' in prelaunched and 'torch.distributed.run' not in prelaunched
cloud_env=dict(env,VC_WORKER_HOSTS='10.0.0.1,10.0.0.2',MA_NUM_HOSTS='2',
               VC_TASK_INDEX='1',MA_NUM_GPUS='8')
cloud=subprocess.run(['bash',str(root/'start_stage1.sh'),'--dry-run'],
    env=cloud_env,capture_output=True,text=True,check=True).stdout
assert 'nodes=2 node_rank=1 local_gpus=8 prelaunched=0' in cloud
assert '--nnodes=2 --node_rank=1 --nproc_per_node=8' in cloud
assert '--master_addr=10.0.0.1' in cloud
print('PASS direct Bash torchrun; local/SLURM/Huawei Cloud; equals options; prelaunched rank; no bootstrap')
