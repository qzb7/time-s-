#!/usr/bin/env bash
# Direct launch: bash -> torchrun -> pretrain_toto2_short_balanced.py
# Priority: command-line > STAGE1_* environment > defaults below.
set -euo pipefail
TASK_ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$TASK_ROOT"
TASK_PYTHON="${STAGE1_PYTHON:-python}" # Use the activated Chronos2 environment.
GPUS="${STAGE1_GPUS:-auto}"
NODES="${STAGE1_NODES:-auto}"
NODE_RANK="${STAGE1_NODE_RANK:-${NODE_RANK:-auto}}"
MASTER_ADDR="${STAGE1_MASTER_ADDR:-${MASTER_ADDR:-auto}}"
MASTER_PORT="${STAGE1_MASTER_PORT:-29677}"
LAUNCH_MODE="${STAGE1_LAUNCH_MODE:-foreground}"
TASK_LOG_DIR="${STAGE1_LOG_DIR:-$TASK_ROOT/logs}"
TASK_TRAIN_SCRIPT="$TASK_ROOT/stage1/pretrain_toto2_short_balanced.py"

# Edit paths / training defaults here. Environment names match CLI names.
ADAMW_BETA1="${STAGE1_ADAMW_BETA1:-0.91}"
ADAMW_BETA2="${STAGE1_ADAMW_BETA2:-0.972}"
ADAMW_LEARNING_RATE="${STAGE1_ADAMW_LEARNING_RATE:-0.00006}"
ADAMW_MIN_LR="${STAGE1_ADAMW_MIN_LR:-0.000006}"
BF16="${STAGE1_BF16:-false}"
CHRONOS_REPO="${STAGE1_CHRONOS_REPO:-$TASK_ROOT/stage1/chronos}"
CPM_MAX_MASK_PROBABILITY="${STAGE1_CPM_MAX_MASK_PROBABILITY:-0.4}"
CPM_MAX_SPAN_PATCHES="${STAGE1_CPM_MAX_SPAN_PATCHES:-8}"
DATA_DIR="${STAGE1_DATA_DIR:-${STAGE1_PRETRAIN:-/data/GIFTEvalPretrain}}"
DATALOADER_NUM_WORKERS="${STAGE1_DATALOADER_NUM_WORKERS:-0}"
DATALOADER_PIN_MEMORY="${STAGE1_DATALOADER_PIN_MEMORY:-true}"
DATALOADER_PREFETCH_FACTOR="${STAGE1_DATALOADER_PREFETCH_FACTOR:-2}"
DD_UNIT_SCALING_SRC="${STAGE1_DD_UNIT_SCALING_SRC:-$TASK_ROOT/stage1/dd_unit_scaling}"
DECAY_STEPS="${STAGE1_DECAY_STEPS:-0}"
FREEZE_VARIATE_LAYERS="${STAGE1_FREEZE_VARIATE_LAYERS:-false}"
GIFT_EVAL_PATH="${STAGE1_GIFT_EVAL_PATH:-${STAGE1_GIFTEVAL:-/data/GIFTEval}}"
GIFT_EVAL_SRC="${STAGE1_GIFT_EVAL_SRC:-$TASK_ROOT/stage1/chronos/gift-eval/src}"
GRADIENT_ACCUMULATION_STEPS="${STAGE1_GRADIENT_ACCUMULATION_STEPS:-1}"
LOGGING_STEPS="${STAGE1_LOGGING_STEPS:-1}"
MAX_GRAD_NORM="${STAGE1_MAX_GRAD_NORM:-7}"
MAX_SEQUENCE_LENGTH="${STAGE1_MAX_SEQUENCE_LENGTH:-8192}"
MAX_STEPS="${STAGE1_MAX_STEPS:-1000000}"
MODEL_NAME_OR_PATH="${STAGE1_MODEL_NAME_OR_PATH:-${STAGE1_MODEL:-$TASK_ROOT/weights/Toto-2.0-313m-time-only}}"
NORMUON_BETA2="${STAGE1_NORMUON_BETA2:-0.999}"
NORMUON_LEARNING_RATE="${STAGE1_NORMUON_LEARNING_RATE:-0.00325}"
NORMUON_MIN_LR="${STAGE1_NORMUON_MIN_LR:-0.000325}"
NORMUON_MU="${STAGE1_NORMUON_MU:-0.96}"
NORMUON_WEIGHT_DECAY="${STAGE1_NORMUON_WEIGHT_DECAY:-2e-8}"
OUTPUT_DIR="${STAGE1_OUTPUT_DIR:-${STAGE1_OUTPUT:-$TASK_ROOT/outputs/stage1/timeonly}}"
PER_DEVICE_TRAIN_BATCH_SIZE="${STAGE1_PER_DEVICE_TRAIN_BATCH_SIZE:-112}"
SAVE_STEPS="${STAGE1_SAVE_STEPS:-500}"
SCHEDULER="${STAGE1_SCHEDULER:-cosine}"
SEED="${STAGE1_SEED:-5252}"
STREAM_ARROW_CACHE_SIZE="${STAGE1_STREAM_ARROW_CACHE_SIZE:-1024}"
STREAM_ARROW_ROW_CHUNK_SIZE="${STAGE1_STREAM_ARROW_ROW_CHUNK_SIZE:-4096}"
STREAM_LOG_INTERVAL="${STAGE1_STREAM_LOG_INTERVAL:-4096}"
STREAM_PREFETCH_POOLS="${STAGE1_STREAM_PREFETCH_POOLS:-16}"
STREAM_SAMPLE_POOL_SIZE="${STAGE1_STREAM_SAMPLE_POOL_SIZE:-61440}"
STREAM_SAMPLES_PER_ARROW="${STAGE1_STREAM_SAMPLES_PER_ARROW:-512}"
STREAM_SAMPLES_PER_DATASET_BLOCK="${STAGE1_STREAM_SAMPLES_PER_DATASET_BLOCK:-256}"
STREAM_WINDOWS_PER_SERIES="${STAGE1_STREAM_WINDOWS_PER_SERIES:-16}"
TF32="${STAGE1_TF32:-false}"
TOTO2_SRC="${STAGE1_TOTO2_SRC:-$TASK_ROOT/stage1/toto2}"
WARMUP_STEPS="${STAGE1_WARMUP_STEPS:-1000}"
STOP_AFTER_STEPS="${STAGE1_STOP_AFTER_STEPS:-27000}"

TRAIN_ARGS=(
  --adamw_beta1 "$ADAMW_BETA1"
  --adamw_beta2 "$ADAMW_BETA2"
  --adamw_learning_rate "$ADAMW_LEARNING_RATE"
  --adamw_min_lr "$ADAMW_MIN_LR"
  --bf16 "$BF16"
  --chronos_repo "$CHRONOS_REPO"
  --cpm_max_mask_probability "$CPM_MAX_MASK_PROBABILITY"
  --cpm_max_span_patches "$CPM_MAX_SPAN_PATCHES"
  --data_dir "$DATA_DIR"
  --dataloader_num_workers "$DATALOADER_NUM_WORKERS"
  --dataloader_pin_memory "$DATALOADER_PIN_MEMORY"
  --dataloader_prefetch_factor "$DATALOADER_PREFETCH_FACTOR"
  --dd_unit_scaling_src "$DD_UNIT_SCALING_SRC"
  --decay_steps "$DECAY_STEPS"
  --freeze_variate_layers "$FREEZE_VARIATE_LAYERS"
  --gift_eval_path "$GIFT_EVAL_PATH"
  --gift_eval_src "$GIFT_EVAL_SRC"
  --gradient_accumulation_steps "$GRADIENT_ACCUMULATION_STEPS"
  --logging_steps "$LOGGING_STEPS"
  --max_grad_norm "$MAX_GRAD_NORM"
  --max_sequence_length "$MAX_SEQUENCE_LENGTH"
  --max_steps "$MAX_STEPS"
  --model_name_or_path "$MODEL_NAME_OR_PATH"
  --normuon_beta2 "$NORMUON_BETA2"
  --normuon_learning_rate "$NORMUON_LEARNING_RATE"
  --normuon_min_lr "$NORMUON_MIN_LR"
  --normuon_mu "$NORMUON_MU"
  --normuon_weight_decay "$NORMUON_WEIGHT_DECAY"
  --output_dir "$OUTPUT_DIR"
  --per_device_train_batch_size "$PER_DEVICE_TRAIN_BATCH_SIZE"
  --save_steps "$SAVE_STEPS"
  --scheduler "$SCHEDULER"
  --seed "$SEED"
  --stream_arrow_cache_size "$STREAM_ARROW_CACHE_SIZE"
  --stream_arrow_row_chunk_size "$STREAM_ARROW_ROW_CHUNK_SIZE"
  --stream_log_interval "$STREAM_LOG_INTERVAL"
  --stream_prefetch_pools "$STREAM_PREFETCH_POOLS"
  --stream_sample_pool_size "$STREAM_SAMPLE_POOL_SIZE"
  --stream_samples_per_arrow "$STREAM_SAMPLES_PER_ARROW"
  --stream_samples_per_dataset_block "$STREAM_SAMPLES_PER_DATASET_BLOCK"
  --stream_windows_per_series "$STREAM_WINDOWS_PER_SERIES"
  --tf32 "$TF32"
  --toto2_src "$TOTO2_SRC"
  --warmup_steps "$WARMUP_STEPS"
  --stop_after_steps "$STOP_AFTER_STEPS"
)
# Wrapper arguments are consumed here; every other --name VALUE goes directly
# to the trainer. Hyphenated aliases are normalized to trainer's underscores.
EXTRA_ARGS=()
DRY_RUN=0
while (( $# )); do
  if [[ "$1" == --*=* ]]; then
    set -- "${1%%=*}" "${1#*=}" "${@:2}"
  fi
  case "$1" in
    --gpus|--nodes|--node-rank|--node_rank|--master-addr|--master_addr|--master-port|--master_port|--launch-mode|--launch_mode)
      if (( $# < 2 )); then echo "Missing value for $1" >&2; exit 2; fi
      case "$1" in
        --gpus) GPUS="$2";;
        --nodes) NODES="$2";;
        --node-rank|--node_rank) NODE_RANK="$2";;
        --master-addr|--master_addr) MASTER_ADDR="$2";;
        --master-port|--master_port) MASTER_PORT="$2";;
        *) LAUNCH_MODE="$2";;
      esac
      shift 2;;
    --dry-run|--dry_run) DRY_RUN=1; shift;;
    --check) echo "--check removed. Use --dry-run, or test environment as in README." >&2; exit 2;;
    --*)
      option="${1#--}"
      EXTRA_ARGS+=("--${option//-/_}"); shift;;
    *) EXTRA_ARGS+=("$1"); shift;;
  esac
done
positive() { [[ "$1" =~ ^[1-9][0-9]*$ ]]; }

# Huawei Cloud VC injects the cluster topology through these variables.  Keep
# explicit CLI/STAGE1_* values authoritative and only fill values still set to
# auto, so the same launcher continues to work outside the platform.
if [[ -n ${VC_WORKER_HOSTS:-} ]]; then
  cloud_master="${VC_WORKER_HOSTS%%,*}"
  cloud_master="${cloud_master// /}"
  cloud_master="${cloud_master//\"/}"
  cloud_master="${cloud_master#\[}"
  cloud_master="${cloud_master%\]}"
  [[ "$NODES" != auto ]] || NODES="${MA_NUM_HOSTS:-auto}"
  [[ "$NODE_RANK" != auto ]] || NODE_RANK="${VC_TASK_INDEX:-auto}"
  [[ "$GPUS" != auto ]] || GPUS="${MA_NUM_GPUS:-auto}"
  [[ "$MASTER_ADDR" != auto ]] || MASTER_ADDR="$cloud_master"
  echo "Detected Huawei Cloud topology from VC_WORKER_HOSTS"
fi

accelerator_count() {
  "$TASK_PYTHON" -c '
import torch
try:
    import torch_npu
except ImportError:
    torch_npu = None
if torch_npu is not None and torch_npu.npu.is_available():
    print(torch_npu.npu.device_count())
else:
    print(torch.cuda.device_count())
' 2>/dev/null || true
}

is_npu() {
  "$TASK_PYTHON" -c '
import torch
try:
    import torch_npu
except ImportError:
    torch_npu = None
print(torch_npu is not None and torch_npu.npu.is_available())
' 2>/dev/null
}

# 双保险：dion 优化器内部的 @torch.compile 在昇腾上会触发 TorchDynamo 崩溃。
# 训练脚本内已做 torch._dynamo.config.disable = True，这里仅在 NPU 下再兜底一次，
# 不影响 CUDA 本地开发路径的 torch.compile。
if [[ "$(is_npu)" == True ]]; then
  export TORCHDYNAMO_DISABLE=1
fi

PRELAUNCHED=0
if [[ -n ${RANK:-} || -n ${WORLD_SIZE:-} || -n ${LOCAL_RANK:-} ]]; then
  [[ -n ${RANK:-} && -n ${WORLD_SIZE:-} && -n ${LOCAL_RANK:-} ]] || {
    echo 'Incomplete distributed environment: need RANK, WORLD_SIZE and LOCAL_RANK together' >&2; exit 2;
  }
  PRELAUNCHED=1
fi
if [[ "$GPUS" == auto ]]; then
  if (( PRELAUNCHED )) && positive "${LOCAL_WORLD_SIZE:-0}"; then
    GPUS="$LOCAL_WORLD_SIZE"
  else
    GPUS="$(accelerator_count)"
    visible_devices_value="${ASCEND_RT_VISIBLE_DEVICES:-${CUDA_VISIBLE_DEVICES:-}}"
    if ! positive "$GPUS" && [[ "$DRY_RUN" == 1 && -n "$visible_devices_value" && "$visible_devices_value" != -1 ]]; then
      IFS=, read -r -a visible_devices <<< "$visible_devices_value"
      GPUS="${#visible_devices[@]}"
    fi
  fi
fi
positive "$GPUS" || { echo 'Cannot detect local NPU/GPU devices; activate torch_npu/CUDA PyTorch or set --gpus to the per-node count' >&2; exit 2; }
if [[ "$DRY_RUN" != 1 ]]; then
  visible_count="$(accelerator_count)"
  positive "$visible_count" && (( GPUS <= visible_count )) || {
    echo "Requested $GPUS devices on this node, but PyTorch sees $visible_count. For 4 nodes x 8 devices, omit --gpus (do not pass 32)." >&2; exit 2;
  }
fi
if [[ "$NODES" == auto ]]; then
  NODES="${SLURM_NNODES:-${SLURM_JOB_NUM_NODES:-${NNODES:-1}}}"
  if (( PRELAUNCHED )) && positive "${LOCAL_WORLD_SIZE:-0}" && (( WORLD_SIZE % LOCAL_WORLD_SIZE == 0 )); then
    NODES="$((WORLD_SIZE / LOCAL_WORLD_SIZE))"
  fi
fi
positive "$NODES" || { echo 'Invalid node count' >&2; exit 2; }
if [[ "$NODE_RANK" == auto ]]; then
  NODE_RANK="${SLURM_NODEID:-${GROUP_RANK:-auto}}"
  if [[ "$NODE_RANK" == auto ]] && (( NODES == 1 )); then NODE_RANK=0; fi
  if [[ "$NODE_RANK" == auto ]] && (( PRELAUNCHED )) && positive "${LOCAL_WORLD_SIZE:-0}"; then
    NODE_RANK="$((RANK / LOCAL_WORLD_SIZE))"
  fi
fi
[[ "$NODE_RANK" =~ ^[0-9]+$ ]] && (( NODE_RANK < NODES )) || {
  echo 'Cannot determine node rank; set STAGE1_NODE_RANK or --node-rank' >&2; exit 2;
}
if (( ! PRELAUNCHED && NODES > 1 )); then
  if [[ ${SLURM_NTASKS:-0} =~ ^[0-9]+$ ]] && (( ${SLURM_NTASKS:-0} > NODES )); then
    echo 'Run this launcher once per node, or supply RANK/WORLD_SIZE/LOCAL_RANK for each process' >&2; exit 2
  fi
  if [[ "$MASTER_ADDR" == auto ]] && command -v scontrol >/dev/null && [[ -n ${SLURM_JOB_NODELIST:-} ]]; then
    MASTER_ADDR="$(scontrol show hostnames "$SLURM_JOB_NODELIST" | head -n 1)"
  fi
  [[ "$MASTER_ADDR" != auto && -n "$MASTER_ADDR" ]] || {
    echo 'Multi-node training needs MASTER_ADDR or --master-addr' >&2; exit 2;
  }
fi
if [[ "$MASTER_ADDR" == auto ]]; then MASTER_ADDR=127.0.0.1; fi
[[ "$MASTER_PORT" =~ ^[0-9]+$ ]] || { echo "Invalid master port" >&2; exit 2; }
[[ "$LAUNCH_MODE" == foreground || "$LAUNCH_MODE" == background ]] || { echo "Invalid launch mode" >&2; exit 2; }
if [[ "$LAUNCH_MODE" == background ]] && (( NODES > 1 || PRELAUNCHED )); then
  echo 'Multi-node/already-distributed jobs require foreground mode' >&2; exit 2
fi
export OMP_NUM_THREADS="${OMP_NUM_THREADS:-1}"
export MKL_NUM_THREADS="${MKL_NUM_THREADS:-1}"
# argparse uses the LAST supplied value, so EXTRA_ARGS override defaults.
if (( PRELAUNCHED )); then
  TORCHRUN=("$TASK_PYTHON" -u "$TASK_TRAIN_SCRIPT" "${TRAIN_ARGS[@]}" ${EXTRA_ARGS[@]+"${EXTRA_ARGS[@]}"})
else
  TORCHRUN=("$TASK_PYTHON" -u -m torch.distributed.run
    --nnodes="$NODES" --node_rank="$NODE_RANK" --nproc_per_node="$GPUS"
    --master_addr="$MASTER_ADDR" --master_port="$MASTER_PORT"
    "$TASK_TRAIN_SCRIPT" "${TRAIN_ARGS[@]}" ${EXTRA_ARGS[@]+"${EXTRA_ARGS[@]}"})
fi
echo "Topology: nodes=$NODES node_rank=$NODE_RANK local_gpus=$GPUS prelaunched=$PRELAUNCHED"
printf '%q ' "${TORCHRUN[@]}"
printf '\n'
if [[ "$DRY_RUN" == 1 ]]; then exit 0; fi
if [[ " ${EXTRA_ARGS[*]-} " == *" --help "* ]]; then
  exec "$TASK_PYTHON" "$TASK_TRAIN_SCRIPT" --help
fi
mkdir -p "$TASK_LOG_DIR"
TASK_LOG="$TASK_LOG_DIR/stage1-$(date +%Y%m%d-%H%M%S)-$$.log"
if [[ "$LAUNCH_MODE" == background ]]; then
  setsid nohup "${TORCHRUN[@]}" > "$TASK_LOG" 2>&1 < /dev/null &
  echo "Launcher PID=$! Log=$TASK_LOG (check first successful training step)"
else
  exec "${TORCHRUN[@]}"
fi
