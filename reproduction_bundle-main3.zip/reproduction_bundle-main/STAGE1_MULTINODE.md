# Stage1 多机启动说明

运行入口是 `start_stage1.sh`，不要直接把 `--gpus`、`--master-port`、
`--launch-mode` 传给 `stage1/pretrain_toto2_short_balanced.py`。

脚本不指定 `--gpus` 时自动读取本节点可见 GPU 数。四节点各 8 卡时，
平台应**每节点运行一次**相同命令；`--gpus 32` 表示每节点 32 卡，
因此应删除，不是填全局卡数。两个入口都支持 `--name value` 和
`--name=value`，以及参数名中的 `-`/`_` 别名。

```bash
bash start_stage1.sh \
  --model_name_or_path /models/Toto-2.0-313m-time-only \
  --data_dir /data/GIFTEvalPretrain \
  --gift_eval_path /data/GIFTEval \
  --output_dir /shared/output/toto2-stage1-run1 \
  --master-port 29677 \
  --per_device_train_batch_size 112 \
  --max_steps 1000000 --stop_after_steps 1000000 \
  --launch-mode foreground
```

原命令中其余训练超参数可照常接在末尾。先加 `--dry-run`，
确认各节点依次为 `node_rank=0..3`、`local_gpus=8`，且命令含
`--nnodes=4 --nproc_per_node=8`。

脚本优先从 `SLURM_NNODES`、`SLURM_NODEID`、`MASTER_ADDR` 检测拓扑；
也接受 `NNODES`、`NODE_RANK`，以及 `STAGE1_NODES`、
`STAGE1_NODE_RANK`、`STAGE1_MASTER_ADDR`。如果平台不提供这些环境变量，
须显式设置节点数、每节点不同的 rank 和相同的主节点地址；GPU 数仍可自动检测。
如果平台已为每 GPU 启动进程并设置 `RANK/WORLD_SIZE/LOCAL_RANK`，
脚本直接运行训练器，不再重复启动 torchrun。

模型路径、训练数据和输出目录必须在所有节点可访问；输出目录必须是共享文件系统
上的新目录。脚本不会主动 SSH 到其他节点。多机使用 foreground，
让平台追踪所有节点的退出码。已验证 Bash 语法及模拟拓扑 dry-run，
未在目标 4×8 卡平台完成真实训练。
