#!/usr/bin/env python3
"""Evaluate the internal22000 + joint1000 shared-head endogenous model."""
from eval_common import main

if __name__ == '__main__':
    main('endogenous')
