#!/usr/bin/env python3
"""Compare matching rows against an existing 207-style grouped NPZ cache."""
import argparse
from pathlib import Path
import json
import numpy as np


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--generated', type=Path, required=True)
    p.add_argument('--reference', type=Path, required=True)
    p.add_argument('--atol', type=float, default=1e-3)
    p.add_argument('--rtol', type=float, default=1e-3)
    a = p.parse_args()
    report = {}
    with np.load(a.generated, allow_pickle=False) as generated, np.load(a.reference, allow_pickle=False) as reference:
        lookup = {(int(w), int(v)): i for i, (w, v) in enumerate(zip(reference['window_index'], reference['variate_index']))}
        common = [(i, lookup[(int(w), int(v))]) for i, (w, v) in enumerate(zip(generated['window_index'], generated['variate_index'])) if (int(w), int(v)) in lookup]
        if not common:
            raise ValueError('No common window/variate keys')
        gi, ri = map(list, zip(*common))
        for name in ('time_series_8192', 'target_mask_8192', 'padding_mask_8192', 'sequence_length'):
            np.testing.assert_array_equal(generated[name][gi], reference[name][ri])
            report[name] = 'exact_match'
        for name in ('image_global', 'text_global'):
            x, y = generated[name][gi], reference[name][ri]
            np.testing.assert_allclose(x, y, atol=a.atol, rtol=a.rtol)
            cosine = (x * y).sum(-1) / np.maximum(np.linalg.norm(x, axis=-1) * np.linalg.norm(y, axis=-1), 1e-12)
            report[name] = {'max_abs_error': float(np.abs(x - y).max()), 'min_cosine': float(cosine.min())}
        report['matched_rows'] = len(common)
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
