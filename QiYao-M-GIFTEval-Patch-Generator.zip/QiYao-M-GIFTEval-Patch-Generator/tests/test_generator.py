"""Synthetic history-only tests; no GPU, CLIP checkpoint, or GIFT-Eval data."""
import ast
import json
from pathlib import Path
import tempfile
import unittest

import numpy as np
import torch

from gift_patch.core import align_history, make_record, atomic_json, sha256_file, completed_shard
from gift_patch.encoder import describe_row
from gift_patch.render import compute_differences, render_rgb_overlay


class GeneratorTests(unittest.TestCase):
    def test_left_padding_missing_and_cropping(self):
        values, mask, pad, length = align_history([0, np.nan, 2])
        self.assertEqual(length, 3)
        self.assertTrue(pad[:-3].all())
        self.assertFalse(pad[-3:].any())
        self.assertEqual(mask[-3:].tolist(), [True, False, True])
        self.assertEqual(float(values[-3]), 0.0)  # observed zero stays valid
        values, _, pad, length = align_history(np.arange(9000))
        np.testing.assert_array_equal(values, np.arange(808, 9000))
        self.assertFalse(pad.any()); self.assertEqual(length, 8192)

    def test_empty_history_and_identity(self):
        values, mask, pad, length = align_history([])
        self.assertTrue(np.isnan(values).all()); self.assertTrue(pad.all())
        self.assertFalse(mask.any()); self.assertEqual(length, 0)
        entry = make_record({'target': np.array([1, 2, 3])}, 7)
        self.assertEqual(entry['window_index'], 7)
        self.assertEqual(entry['variate_index'], 0)

    def test_lag_two_not_second_derivative_and_missing(self):
        x = (np.arange(64, dtype=np.float32) ** 2)[None]
        valid = np.ones_like(x, dtype=bool)
        a, b = compute_differences(x, valid)
        self.assertEqual(float(a[0, 32]), 63.0)
        self.assertEqual(float(b[0, 32]), 124.0)  # not 2.0
        valid[0, 31] = False
        a, b = compute_differences(x, valid)
        self.assertTrue(np.isnan(a[0, 32]))
        self.assertTrue(np.isnan(b[0, 32]))  # all three masks required

    def test_blank_image_and_true_rgb(self):
        raw = torch.full((1, 32), float('nan'))
        im = render_rgb_overlay(raw, torch.zeros_like(raw, dtype=torch.bool), raw, raw)
        self.assertEqual(tuple(im.shape), (1, 3, 224, 224))
        self.assertTrue((im == 255).all().item())
        raw = torch.linspace(0, 1, 32)[None]
        nan = torch.full_like(raw, float('nan'))
        im = render_rgb_overlay(raw, torch.ones_like(raw, dtype=torch.bool), nan, nan)
        colors = im[0].permute(1, 2, 0).reshape(-1, 3)
        self.assertTrue(((colors == torch.tensor([220, 40, 40])).all(-1)).any())

    def test_text_is_patch_local(self):
        x, valid, pad, _ = align_history(np.arange(64, dtype=np.float32))
        original = describe_row((x, valid, pad))
        x[-64:-32] *= 100
        modified = describe_row((x, valid, pad))
        self.assertEqual(original[-1], modified[-1])
        self.assertIn('left padding', original[0])
        self.assertEqual(len(original), 256)

    def test_catalogue_97(self):
        root = Path(__file__).resolve().parents[1]
        ref = json.loads((root / 'reference207.json').read_text())
        self.assertEqual(len(ref['configs']), 97)
        self.assertEqual(sum(x['written_samples'] for x in ref['configs']), 371330)
        self.assertEqual(len({x['config'] for x in ref['configs']}), 97)

    def test_no_label_access(self):
        root = Path(__file__).resolve().parents[1]
        # The vendored benchmark defines labels for evaluation, but generation
        # never reads them. Assert this in the generation/encoding paths.
        for path in [root / 'generate_gifteval.py', root / 'gift_patch/core.py', root / 'gift_patch/encoder.py']:
            tree = ast.parse(path.read_text())
            self.assertFalse(any(isinstance(n, ast.Attribute) and n.attr == 'label' for n in ast.walk(tree)))

    def test_resume_receipt_validation(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'samples-00000.npz'
            self.assertFalse(completed_shard(path, {'signature': 's', 'start': 0, 'count': 1}))
            path.write_bytes(b'fixture')
            expected = dict(signature='s', start=0, count=1)
            atomic_json(path.with_suffix('.done.json'), dict(expected, bytes=7, sha256=sha256_file(path)))
            self.assertTrue(completed_shard(path, expected, verify_hash=True))
            with self.assertRaises(ValueError):
                completed_shard(path, dict(expected, signature='different'))


if __name__ == '__main__':
    torch.set_num_threads(1)
    unittest.main()
