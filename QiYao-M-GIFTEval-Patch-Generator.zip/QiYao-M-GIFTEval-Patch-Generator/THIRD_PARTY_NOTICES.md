# Third-party provenance

- `gift_patch/gift_data.py` is the GIFT-Eval dataset/split implementation from
  Salesforce. Its original copyright and Apache-2.0 notice are retained.
  A copy of that license is in `licenses/Apache-2.0.txt`.
  Upstream: https://github.com/SalesforceAIResearch/gift-eval
- `gift_patch/text_template.py` and the numerical renderer functions are
  copied from the user's existing evaluation generator. The text template
  and vendored data loader are byte-identical to the inspected 207 versions;
  the renderer function bodies are unchanged. `reference207.json` records
  the source checksums and measured environment versions.
- CLIP is executed through the separately installed `open_clip_torch` package.
  The optional full archive contains the user's supplied OpenAI ViT-B/32
  checkpoint, whose SHA-256 matches the checkpoint used on 207.
  Its upstream MIT license is retained in `licenses/CLIP-MIT.txt`.
  CLIP upstream: https://github.com/openai/CLIP
  OpenCLIP upstream: https://github.com/mlfoundations/open_clip
- No GIFT-Eval dataset observations, forecasting-model weights, training
  samples, API credentials, or private server access keys are distributed.
