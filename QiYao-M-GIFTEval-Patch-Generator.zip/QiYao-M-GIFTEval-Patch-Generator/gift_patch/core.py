"""Window alignment, output validation, and atomic I/O (no neural dependency)."""
from __future__ import annotations

from contextlib import contextmanager
import hashlib
import json
import os
from pathlib import Path
import tempfile

import numpy as np

CONTEXT = 8192
PATCH = 32
PATCHES = CONTEXT // PATCH
EMBED_DIM = 512
FIELDS = (
    'time_series_8192', 'target_mask_8192', 'padding_mask_8192',
    'image_global', 'text_global', 'sequence_length',
    'window_index', 'variate_index', 'sample_id',
)


def align_history(series):
    """Keep the latest observations; pad on the LEFT, never append labels."""
    series = np.asarray(series, dtype=np.float32)
    if series.ndim != 1:
        raise ValueError('Each input must be one univariate historical series.')
    length = min(len(series), CONTEXT)
    values = np.full(CONTEXT, np.nan, dtype=np.float32)
    valid = np.zeros(CONTEXT, dtype=bool)
    padding = np.arange(CONTEXT) < CONTEXT - length
    if length:
        values[-length:] = series[-length:]
        valid[-length:] = np.isfinite(series[-length:])
    return values, valid, padding, length


def make_record(entry, window_index):
    # `entry` is from Dataset.test_data.input, NOT its corresponding label.
    target = np.asarray(entry['target'], dtype=np.float32)
    if target.ndim == 2 and target.shape[0] == 1:
        target = target[0]
    values, mask, padding, length = align_history(target)
    return dict(time_series_8192=values, target_mask_8192=mask,
                padding_mask_8192=padding, sequence_length=np.int32(length),
                window_index=np.int64(window_index), variate_index=np.int32(0),
                sample_id=f'window-{window_index:09d}-variate-000')


def collate(records):
    if not records:
        raise ValueError('Cannot collate an empty shard.')
    return {key: np.asarray([row[key] for row in records]) for key in records[0]}


def sha256_file(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def atomic_json(path, obj):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, name = tempfile.mkstemp(prefix=path.name + '.', suffix='.tmp', dir=path.parent)
    try:
        with os.fdopen(fd, 'w') as stream:
            json.dump(obj, stream, indent=2, ensure_ascii=False)
            stream.write('\n'); stream.flush(); os.fsync(stream.fileno())
        os.replace(name, path)
    finally:
        if os.path.exists(name):
            os.unlink(name)


def atomic_npz(path, arrays):
    path = Path(path)
    fd, name = tempfile.mkstemp(prefix=path.name + '.', suffix='.tmp', dir=path.parent)
    try:
        with os.fdopen(fd, 'wb') as stream:
            np.savez_compressed(stream, **arrays)
            stream.flush(); os.fsync(stream.fileno())
        os.replace(name, path)
    finally:
        if os.path.exists(name):
            os.unlink(name)


@contextmanager
def lock_file(path):
    # Advisory locks prevent two jobs from overwriting the same output shard.
    import fcntl
    with Path(path).open('a') as handle:
        fcntl.flock(handle, fcntl.LOCK_EX)
        try:
            yield
        finally:
            fcntl.flock(handle, fcntl.LOCK_UN)


def validate_arrays(arrays, count, start):
    for name in FIELDS:
        if name not in arrays:
            raise ValueError(f'Missing field {name}')
    for name in ('time_series_8192', 'target_mask_8192', 'padding_mask_8192'):
        if arrays[name].shape != (count, CONTEXT):
            raise ValueError(f'Invalid {name} shape: {arrays[name].shape}')
    for name in ('image_global', 'text_global'):
        if arrays[name].shape != (count, PATCHES, EMBED_DIM):
            raise ValueError(f'Invalid {name} shape')
        if arrays[name].dtype != np.float32 or not np.isfinite(arrays[name]).all():
            raise ValueError(f'Invalid {name} dtype/values')
    if arrays['time_series_8192'].dtype != np.float32:
        raise ValueError('Time-series values must be float32')
    if any(arrays[name].dtype != np.bool_ for name in ('target_mask_8192', 'padding_mask_8192')):
        raise ValueError('Masks must have bool dtype')
    for name in ('sequence_length', 'window_index', 'variate_index', 'sample_id'):
        if arrays[name].shape != (count,):
            raise ValueError(f'Invalid {name} shape')
    if not np.array_equal(arrays['window_index'], np.arange(start, start + count)):
        raise ValueError('Window indices must preserve official input order')
    if np.any(arrays['variate_index'] != 0):
        raise ValueError('Inputs must already be converted to univariate entries')
    lengths = arrays['sequence_length']
    if np.any(lengths < 0) or np.any(lengths > CONTEXT):
        raise ValueError('Invalid history lengths')
    padding = np.arange(CONTEXT)[None, :] < CONTEXT - lengths[:, None]
    if not np.array_equal(arrays['padding_mask_8192'], padding):
        raise ValueError('Padding must be left-aligned')
    valid = np.isfinite(arrays['time_series_8192']) & ~padding
    if not np.array_equal(arrays['target_mask_8192'], valid):
        raise ValueError('Observation mask mismatch')


def validate_npz(path, count, start):
    with np.load(path, allow_pickle=False) as data:
        arrays = {key: data[key] for key in data.files}
    validate_arrays(arrays, count, start)


def completed_shard(path, expected, verify_hash=False):
    """A shard is reusable only with its matching atomic completion receipt."""
    receipt = Path(path).with_suffix('.done.json')
    if not Path(path).exists() or not receipt.exists():
        return False
    data = json.loads(receipt.read_text())
    for key, value in expected.items():
        if data.get(key) != value:
            raise ValueError(f'Incompatible existing shard {path}: {key}')
    if Path(path).stat().st_size != data['bytes']:
        raise ValueError(f'Shard size mismatch: {path}; use a fresh output directory')
    if verify_hash and sha256_file(path) != data['sha256']:
        raise ValueError(f'Shard checksum mismatch: {path}')
    return True
