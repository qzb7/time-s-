"""History-only patch-level text and image features for QiYao-M evaluation."""
