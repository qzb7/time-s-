"""The same local template and unnormalized CLIP features as the 207 cache."""
from __future__ import annotations

from concurrent.futures import ProcessPoolExecutor
import multiprocessing as mp
import os
from pathlib import Path

import numpy as np
import torch

from .core import CONTEXT, PATCH, PATCHES, EMBED_DIM
from .render import CLIP_MEAN, CLIP_STD, compute_differences, render_rgb_overlay
from .text_template import describe_patch


def describe_row(payload):
    row, target_mask, padding = payload
    return [describe_patch(
        row[start:start + PATCH],
        target_mask[start:start + PATCH] & np.isfinite(row[start:start + PATCH]) & ~padding[start:start + PATCH],
        padding[start:start + PATCH], None, start=start,
    ) for start in range(0, CONTEXT, PATCH)]


class PatchEncoder:
    def __init__(self, checkpoint, device='cuda:0', clip_batch_size=256, text_workers=4):
        import open_clip
        if not Path(checkpoint).is_file():
            raise FileNotFoundError(f'Local CLIP checkpoint not found: {checkpoint}')
        self.device = torch.device(device)
        if self.device.type == 'cuda':
            if os.getenv('NVIDIA_TF32_OVERRIDE') == '0' or os.getenv('TORCH_ALLOW_TF32_CUBLAS_OVERRIDE') == '1':
                raise ValueError('Environment overrides conflict with the reference207 TF32 settings')
            # Reference207 used FP32 tensors, TF32-enabled cuDNN convolutions,
            # and TF32-disabled matmuls. This materially affects CLIP images.
            torch.backends.cuda.matmul.allow_tf32 = False
            torch.backends.cudnn.allow_tf32 = True
        self.model, _, _ = open_clip.create_model_and_transforms(
            'ViT-B-32', pretrained=str(checkpoint), device=self.device, precision='fp32',
        )
        self.model.eval()
        self.tokenizer = open_clip.get_tokenizer('ViT-B-32')
        self.batch = int(clip_batch_size)
        if self.batch < 1 or text_workers < 0:
            raise ValueError('clip_batch_size must be positive and workers nonnegative')
        self.executor = ProcessPoolExecutor(
            max_workers=text_workers, mp_context=mp.get_context('spawn'),
        ) if text_workers else None
        self.mean = torch.tensor(CLIP_MEAN, device=self.device).view(1, 3, 1, 1)
        self.std = torch.tensor(CLIP_STD, device=self.device).view(1, 3, 1, 1)
        self.padding_image = None

    def close(self):
        if self.executor:
            self.executor.shutdown(wait=True, cancel_futures=True)

    def descriptions(self, values, valid, padding):
        payloads = zip(values, valid, padding)
        rows = (self.executor.map(describe_row, payloads, chunksize=1)
                if self.executor else map(describe_row, payloads))
        return [text for row in rows for text in row]

    @torch.inference_mode()
    def encode_text(self, descriptions):
        unique, inverse = np.unique(np.asarray(descriptions, dtype=object), return_inverse=True)
        output = np.empty((len(unique), EMBED_DIM), dtype=np.float32)
        for left in range(0, len(unique), self.batch):
            text = [str(x) for x in unique[left:left + self.batch]]
            tokens = self.tokenizer(text).to(self.device)
            # Deliberately no L2 normalization: the trained predictor expects
            # raw encode_text / encode_image outputs, as saved in the cache.
            output[left:left + len(text)] = self.model.encode_text(tokens).float().cpu().numpy()
        return output[inverse]

    @torch.inference_mode()
    def encode_images(self, rows, target_mask, padding_mask):
        valid = target_mask & ~padding_mask & np.isfinite(rows)
        diff1, diff2 = compute_differences(rows, valid)
        patches = rows.reshape(-1, PATCH)
        patch_valid = valid.reshape(-1, PATCH)
        d1 = diff1.reshape(-1, PATCH)
        d2 = diff2.reshape(-1, PATCH)
        full_padding = padding_mask.reshape(-1, PATCH).all(-1)
        output = np.empty((len(patches), EMBED_DIM), dtype=np.float32)
        indices = np.flatnonzero(~full_padding)
        if self.padding_image is None and full_padding.any():
            indices = np.concatenate((indices, np.flatnonzero(full_padding)[:1]))
        for left in range(0, len(indices), self.batch):
            take = indices[left:left + self.batch]
            args = [torch.from_numpy(x[take]).to(self.device) for x in (patches, patch_valid, d1, d2)]
            images = render_rgb_overlay(*args).float().div_(255.0)
            images = (images - self.mean) / self.std
            encoded = self.model.encode_image(images).float().cpu().numpy()
            output[take] = encoded
            if self.padding_image is None:
                found = np.flatnonzero(full_padding[take])
                if len(found):
                    self.padding_image = encoded[found[0]].copy()
        if self.padding_image is not None:
            output[full_padding] = self.padding_image
        return output

    def encode(self, rows, valid, padding):
        count = len(rows)
        image = self.encode_images(rows, valid, padding).reshape(count, PATCHES, EMBED_DIM)
        descriptions = self.descriptions(rows, valid, padding)
        text = self.encode_text(descriptions).reshape(count, PATCHES, EMBED_DIM)
        if not np.isfinite(image).all() or not np.isfinite(text).all():
            raise ValueError('Nonfinite CLIP embeddings; refusing to write invalid results')
        return image, text

    def export_example(self, output, row, target, padding):
        """Optional inspectable text/PNG examples; never adds forecast labels."""
        from PIL import Image
        from .core import atomic_json
        output = Path(output)
        output.mkdir(parents=True, exist_ok=True)
        descriptions = describe_row((row, target, padding))
        valid = target & ~padding & np.isfinite(row)
        d1, d2 = compute_differences(row[None], valid[None])
        examples = []
        # Show up to four non-padding patches, not hundreds of blank images.
        selected = np.flatnonzero(~padding.reshape(PATCHES, PATCH).all(-1))[-4:]
        for index in selected:
            left, right = int(index) * PATCH, (int(index) + 1) * PATCH
            tensors = [torch.from_numpy(x).to(self.device) for x in (
                row[None, left:right], valid[None, left:right], d1[:, left:right], d2[:, left:right])]
            rgb = render_rgb_overlay(*tensors)[0].cpu().numpy().transpose(1, 2, 0)
            Image.fromarray(rgb).save(output / f'patch-{index:03d}.png')
            examples.append({'patch_index': int(index), 'start': left,
                'values': [float(v) if np.isfinite(v) else None for v in row[left:right]],
                'valid_mask': valid[left:right].tolist(), 'padding_mask': padding[left:right].tolist(),
                'description': descriptions[int(index)]})
        atomic_json(output / 'patches.json', examples)
