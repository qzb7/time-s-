# QiYao-M：GIFT-Eval patch 级内源多模态评测数据生成器

这份代码专门生成 **GIFT-Eval 测试输入的图像/文本 embedding 缓存**。
它不是训练集四源混合抽样器，也不进行预测模型训练或评测指标计算。
不需要 QiYao-M 模型权重、不调用大语言模型/API。

## 1. 对齐的参考版本

参考 207 上已经用于评测的缓存：

```text
/public_data/toto2_gifteval_test_multimodal_local_stationarity_8192_patch32_gpu234567_grouped_npz
```

- 配置数：**97**（55 个 short、21 个 medium、21 个 long）。
- 展开后的测试输入数：**371,330**。
- 原始窗口：与参考版本一致的 GIFT-Eval `Dataset.test_data.input`。
- 多变量处理：先用官方 `to_univariate=True` 展开，再按输入顺序建立 `window_index`。
- 历史长度：保留最新 **8192** 个点；不足时**左侧补齐**，不是右侧补齐。
- patch：固定 **32** 点、不重叠，得到 **256** 个 patch。
- 文本：固定统计模板；CLIP ViT-B/32 文本编码器。
- 图像：修订后的真实 RGB 三曲线；CLIP ViT-B/32 图像编码器。
- 两种 embedding 均为 **[样本数, 256, 512]、float32、未做 L2 归一化**。
- 精度：FP32 张量、`cuda.matmul.allow_tf32=False`、`cudnn.allow_tf32=True`，显式对齐旧 GPU 缓存。
- 默认每个 NPZ 分片 **512** 个输入；最后不足一个分片的样本全部保留。

`reference207.json` 保存了每个配置的参考样本数、源文件校验和及读取到的环境版本。
程序会拒绝样本数量不同的数据副本，而不是静默漏配置或重新随机抽样。
数量一致不等于原始数值一定一致，严格复现仍需使用同一份 GIFT-Eval 原始数据。

## 2. 发给同学需要什么

1. 本代码包。完整 tar.gz 自带 `weights/ViT-B-32.pt`；轻量源码 ZIP 不带权重。
2. GIFT-Eval 原始数据目录，必须是 Hugging Face `load_from_disk` 结构，例如：

```text
/data/GIFTEval/
├── m4_yearly/
├── electricity/15T/
├── ett1/H/
└── ...
```

这里不要传 `GIFTEvalPretrain`，也不要传以前生成的图文缓存目录。
完整包中的 CLIP 权重来自你提供的四源生成器，已与 207 校验 SHA-256 一致：

```text
40d365715913c9da98579312b702a82c18be219cc2a73407c4526f58eba950af
```

## 3. 安装

建议新建 Python 3.11 环境，不修改正在跑实验的环境。
根据目标服务器驱动安装合适的 Torch wheel；参考环境为 Torch 2.4.1、torchvision 0.19.1。

```bash
cd /path/to/QiYao-M-GIFTEval-Patch-Generator
python -m pip install -r requirements-torch.txt
python -m pip install -r requirements.txt
```

已有兼容 Torch 时可不执行第一条安装。`requirements.txt` 对齐的是读取到的 207 环境；
离线机器需另外准备 Python 依赖 wheel，本包只包含源码和（完整版的）CLIP 权重，不包含整个 Conda 环境。

## 4. 直接全量生成：单机多卡

```bash
cd /path/to/QiYao-M-GIFTEval-Patch-Generator

CUDA_VISIBLE_DEVICES=0,1,2,3,4,5,6,7 \
bash start_gifteval.sh \
  --gift-eval-dir /data/GIFTEval \
  --output /data/QiYao-M_gifteval_patch32_grouped_npz \
  --clip-checkpoint ./weights/ViT-B-32.pt \
  --sample-group-size 8 \
  --clip-batch-size 256 \
  --text-workers 4 \
  --save-examples
```

- 不需要 `--gpus`、`--master-port` 或 `--launch-mode`，也不要传四源比例和 `--total`。
- 启动器自动使用**可见的本机 GPU**；`CUDA_VISIBLE_DEVICES` 可限制使用范围。
  不设置则使用环境可见的所有 GPU；不要在别人使用中的卡上直接启动。
- `GENERATOR_PYTHON=/path/to/python` 可选；默认调用当前环境的 `python`。
- `NPROC_PER_NODE=2` 可显式限制本地进程数，默认等于可见 GPU 数；无 GPU 时单进程 CPU。
  指定进程数超过可见 GPU 数时启动器会提前报错；不要填写多机总 GPU 数。
- `--clip-batch-size` 是一次编码的 **patch 数量**，不是窗口数。256 是保守起点，
  显存充裕可尝试 512/1024；发生 OOM 可减小并用相同输出目录重启。
- `--text-workers` 是**每张卡**的 CPU 进程数，8 卡 × 4 即 32 个模板进程。
- 只生成缓存，不启动预测评测。程序不需要 NCCL 通信，卡间不传特征或梯度。

后台执行可自行加：

```bash
CUDA_VISIBLE_DEVICES=0,1 nohup bash start_gifteval.sh \
  --gift-eval-dir /data/GIFTEval \
  --output /data/QiYao-M_gifteval_patch32_grouped_npz \
  > generation.log 2>&1 &
```

## 5. 先核对数据、少量预览

只核对 97 个配置的测试窗口数量，不加载 CLIP、不写输出：

```bash
bash start_gifteval.sh --gift-eval-dir /data/GIFTEval \
  --output /data/QiYao-M_gifteval_patch32_grouped_npz --plan-only
```

只生成两个 M4 yearly 窗口并输出可读 patch 文本/PNG：

```bash
CUDA_VISIBLE_DEVICES=0 bash start_gifteval.sh \
  --gift-eval-dir /data/GIFTEval \
  --output /data/QiYao-M_gifteval_preview \
  --include m4_yearly/short --max-samples-per-config 2 \
  --save-examples --text-workers 0
```

预览使用独立目录，只写 `preview-manifest.json`，**不会伪装成完整评测缓存**。
全量生成不要带 `--max-samples-per-config`，不要复用预览目录。
`--include` 可以多次指定，例如 `--include ett1/H/short`。

## 6. 多机（每机 8 卡）

所有节点需要相同源码、数据副本、权重，以及**共享输出目录**；共享文件系统需要支持文件锁。
不要在每台机器上各自启动一个 `--standalone` 任务。
由平台启动 torchrun 时，代码读取 `RANK/WORLD_SIZE/LOCAL_RANK`，不会再次嵌套 torchrun。
手动运行示例（每台机器分别设置其 `NODE_RANK`、同一 `MASTER_ADDR`）：

```bash
python -m torch.distributed.run \
  --nnodes=4 --nproc_per_node=8 \
  --node_rank="$NODE_RANK" --master_addr="$MASTER_ADDR" --master_port=29777 \
  generate_gifteval.py \
  --gift-eval-dir /data/GIFTEval \
  --output /shared/QiYao-M_gifteval_patch32_grouped_npz
```

**所有节点退出成功后**，在任意一台执行一次：

```bash
python generate_gifteval.py --gift-eval-dir /data/GIFTEval \
  --output /shared/QiYao-M_gifteval_patch32_grouped_npz --finalize-only
```

单机 `start_gifteval.sh` 已自动包含最后这个步骤。最终汇总之前不应开始全量评测。

## 7. 生成规则（重要）

### 只从历史构造模态

生成阶段只迭代 `test_data.input`，不读取 `test_data.label`。
更早窗口的标签可能成为更晚窗口的已观测历史，这是官方滚动评测的正常行为；
任何一个窗口都不使用自身尚未观测的未来值。
评测标签应由同版本官方 Dataset 在预测阶段读取，不能把测试标签再转成输入模态。
本缓存是测试输入缓存，不应作为零样本实验的训练数据。

### 文本模板

`gift_patch/text_template.py` 与 207 的模板逐字节一致。
统计量在每个 32 点 patch 内计算：padding、missingness、coverage、趋势、形状、
变化程度、波动、粗糙度、局部周期性启发式、相关性、事件、局部平稳性和置信度。
不添加股票名称、频率等额外元数据，也不使用序列级统计给每个 patch 补充信息。
缺失值与左补齐位置分开处理；真实零值仍是观测值。
文本编码使用原版 CLIP tokenizer 的 **77 token** 长度限制/截断行为，与现有缓存一致。
完整描述可在 examples 中查看，但模型输入的是 CLIP embedding，不是原始字符串。

### RGB 图像

在完整的已对齐历史上先计算差分，再切成 32 点 patch，保留合法的跨 patch 邻接信息：

- 红线：`x[t]`。
- 绿线：`x[t] - x[t-1]`，要求相邻两点有效。
- 蓝线：`x[t] - x[t-2]`，原代码还要求中间点也有效。

**蓝线是 lag-2 / 两步差分，不是 `x[t]-2*x[t-1]+x[t-2]` 的二阶差分。**
为复现既有模型输入，本版不擅自修改这个定义。
raw 曲线按 patch 有效值的 1%/99% 分位缩放，退化时退回最小/最大值；
两条差分曲线共用绝对值 99% 分位确定的尺度，零差分对应中线。
输出为白底 224×224 真 RGB 叠加图，缺失/补齐位置断线，不能跨缺失点连线。
之后按 CLIP 官方均值/标准差标准化，不额外 resize/crop、不改曲线颜色。
全 padding patch 是白图，仍保存其真实 CLIP embedding，**不是全零 embedding**。

### CPU/GPU 精度差异不能忽略

在 207 实测，CPU 与旧 GPU 缓存的图像向量最大差异约 0.032，
不是窗口或绘图错误，而是 cuDNN TF32 卷积差异；三个实际窗口同设置 GPU 重算最大误差约 1.05e-5。
因此正式复现推荐支持 TF32 的 NVIDIA GPU，保留代码中的精度设置。
CPU 可用于运行检查和预览，不能声称与旧 GPU embedding 逐元素一致。
程序将 CPU/GPU backend 写入缓存签名，不允许混用两种缓存；
多机最终汇总也需使用同一 backend（GPU 生成时不要在完全无 CUDA 的机器上 finalize）。

### 数值和 embedding

缓存内数值保留原始尺度，不进行 z-score，也不预先填补缺失观测。
图像内部的绘图缩放只用于渲染，不改变 `time_series_8192`。
这与预测模型内部的数值标准化、MASE/CRPS 等评测指标的计算是三个不同步骤。

## 8. 输出与接入评测

```text
output/
├── summary.json
└── ett1__H__short/
    ├── generation.json
    ├── manifest.json
    ├── samples-00000.npz
    ├── samples-00000.done.json
    └── examples/                 # 仅 --save-examples 时
```

NPZ 字段（`N` 为当前分片实际样本数）：

| 字段 | shape / dtype | 含义 |
|---|---|---|
| time_series_8192 | N×8192 / float32 | 截断/左补齐后的历史 |
| target_mask_8192 | N×8192 / bool | 有效观测 |
| padding_mask_8192 | N×8192 / bool | 左补齐位置 |
| image_global | N×256×512 / float32 | 每个 patch 的图像 embedding |
| text_global | N×256×512 / float32 | 每个 patch 的文本 embedding |
| sequence_length | N / int32 | 保留历史点数，包含历史区间内缺失位置 |
| window_index | N / int64 | 官方展开后 test_data.input 的顺序索引 |
| variate_index | N / int32 | 0；变量已通过官方 Dataset 展开 |
| sample_id | N / Unicode | 稳定标识，不依赖 rank |

`image_global/text_global` 虽然叫 global，**这里实际存的是 patch 级向量**，
名字保留只是为了兼容 207 的评测读取代码。
`sample_id` 不复刻旧版含 rank 的字符串；评测对齐依据是 dataset/term/window_index/variate_index。
其余字段名、shape、顺序与参考缓存一致。

现有 grouped-NPZ 评测程序可直接将 `data_dir` 指向这个输出根目录；不需要先合并 rank。
评测读取 `manifest['shards']` 的顺序，以 `window_index` 映射官方输入/标签对。
检查 `summary.json` 的 `complete=true`、97 configs、371330 completed_samples 后再跑全量评测。

## 9. 断点续跑、速度与磁盘

同一条生成命令重启即可。已完成分片通过 receipt/签名验证后跳过，未完成分片重新生成。
可以更换 GPU 数、编码 batch 或 CPU worker 数；数据版本、分片大小、模板、代码、依赖环境变化
会触发签名不匹配，应使用新输出目录，不能混用缓存。
`--verify-existing` 会额外完整核对旧分片的 SHA-256，适合传输后校验，代价是读盘时间。
不会覆盖/删除原有 207 缓存，不会跳过失败样本并假装完成。

完整 float32 图文 embedding 未压缩约 **389 GB（362.6 GiB）**，外加数值与掩码。
NPZ 会压缩，实际体积取决于 padding 和数据内容，但应提前准备足够磁盘，不承诺固定压缩率。
每个 512 样本分片仅图文数组约 512 MiB，多卡运行需要留足 CPU 内存和压缩 I/O 余量。
默认不保存全部 PNG/文本，只在要求时导出每个配置首条输入末尾几个非补齐 patch 的例子。

## 10. 验证

交付前的实际对照结果及未覆盖范围见 `VALIDATION.md`。
`SHA256SUMS` 包含完整包文件校验和；轻量 ZIP 不带权重，需自行放入上述相同权重后再全量校验。

```bash
python -m unittest discover -s tests -v

python compare_reference.py \
  --generated /new/cache/m4_yearly__short/samples-00000.npz \
  --reference /old/cache/m4_yearly__short/samples-00000.npz
```

比较程序按窗口/变量索引取共同样本：数值/掩码必须完全一致，embedding 容许相同 GPU 精度设置下
编码 batch 等因素造成的小浮点误差（默认 atol=rtol=1e-3），不会修改任何对比结果。
CPU 图像编码可能超出这个容差；不要通过放大容差掩盖它与 TF32 GPU 缓存的区别。
本交付的实际验证范围见 `VALIDATION.md`，不等同于重新生成了全部 371,330 个窗口。
