#!/usr/bin/env python3
"""Generate the 97-config, history-only GIFT-Eval patch cache used by QiYao-M."""
from __future__ import annotations

import argparse
import hashlib
import importlib.metadata
import itertools
import json
import math
import os
from pathlib import Path
import time

import numpy as np

from gift_patch.core import (
    CONTEXT, PATCH, PATCHES, EMBED_DIM, FIELDS, atomic_json, atomic_npz,
    collate, completed_shard, lock_file, make_record, sha256_file,
    validate_arrays, validate_npz,
)

ROOT = Path(__file__).resolve().parent


def arguments():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--gift-eval-dir', required=True, type=Path, help='GIFT-Eval load_from_disk root, not pretraining data')
    p.add_argument('--clip-checkpoint', type=Path, default=ROOT / 'weights/ViT-B-32.pt')
    p.add_argument('--output', required=True, type=Path)
    p.add_argument('--device', default='auto', help='auto, cpu, cuda, or cuda:N')
    p.add_argument('--clip-batch-size', type=int, default=256, help='Number of patch images/texts per CLIP call, NOT windows')
    p.add_argument('--sample-group-size', type=int, default=8)
    p.add_argument('--samples-per-shard', type=int, default=512)
    p.add_argument('--text-workers', type=int, default=4, help='Per GPU; 0 executes templates in-process')
    p.add_argument('--include', action='append', default=[], help='Exact dataset[/frequency]/term, e.g. ett1/H/short; repeatable')
    p.add_argument('--max-samples-per-config', type=int, default=0, help='Preview only; no evaluation manifest is published')
    p.add_argument('--save-examples', action='store_true', help='Save a few patch PNGs and template descriptions per task')
    p.add_argument('--verify-existing', action='store_true', help='Recheck full SHA-256 before skipping completed shards')
    p.add_argument('--plan-only', action='store_true', help='Check all splits/counts; do not load CLIP or create output')
    p.add_argument('--finalize-only', action='store_true', help='Publish manifests only when every expected shard is complete')
    a = p.parse_args()
    for key in ('clip_batch_size', 'sample_group_size', 'samples_per_shard'):
        if getattr(a, key) <= 0:
            p.error(key + ' must be positive')
    if a.text_workers < 0 or a.max_samples_per_config < 0:
        p.error('workers / max samples cannot be negative')
    if not a.gift_eval_dir.is_dir():
        p.error('GIFT-Eval directory does not exist')
    return a


def log(event, **kwargs):
    print(json.dumps(dict(event=event, **kwargs), ensure_ascii=False), flush=True)


def resolve_device(local_rank: int = 0) -> str:
    """Pick an accelerator device: Ascend NPU first, then CUDA, then CPU."""
    try:
        import torch_npu
        if torch_npu.npu.is_available():
            return f'npu:{local_rank}'
    except Exception:
        pass
    if torch.cuda.is_available():
        return f'cuda:{local_rank}'
    return 'cpu'


def build_plan(args, reference):
    # Vendored Dataset is byte-identical to the source used on 207. It is not
    # replaced with an installed benchmark version with potentially new splits.
    from gift_patch.gift_data import Dataset
    os.environ['GIFT_EVAL'] = str(args.gift_eval_dir.resolve())
    os.environ['GIFT_EVAL_PATH'] = os.environ['GIFT_EVAL']
    requested = set(args.include)
    available = {f"{x['dataset']}/{x['term']}" for x in reference['configs']}
    if requested - available:
        raise ValueError('Unknown configurations: ' + repr(sorted(requested - available)))
    plan, offset = [], 0
    for item in reference['configs']:
        key = f"{item['dataset']}/{item['term']}"
        if requested and key not in requested:
            continue
        meta = Dataset(name=item['dataset'], term=item['term'], to_univariate=False)
        count = len(meta.hf_dataset) * int(meta.target_dim) * int(meta.windows)
        if count != item['written_samples']:
            raise ValueError(f'{key}: current data has {count} windows, reference207 has '
                             f"{item['written_samples']}. Use the same GIFT-Eval data snapshot; do not silently change the split.")
        size = min(count, args.max_samples_per_config) if args.max_samples_per_config else count
        shards = math.ceil(size / args.samples_per_shard)
        plan.append(dict(item, key=key, expected_samples=count, output_samples=size,
                         target_dim=int(meta.target_dim), frequency=str(meta.freq),
                         prediction_length=int(meta.prediction_length), windows=int(meta.windows),
                         data_fingerprint=str(meta.hf_dataset._fingerprint),
                         shard_count=shards, shard_offset=offset))
        offset += shards
    return plan


def protocol(args, clip_sha, backend):
    sources = ['generate_gifteval.py', 'gift_patch/core.py', 'gift_patch/encoder.py',
               'gift_patch/gift_data.py', 'gift_patch/text_template.py', 'gift_patch/render.py', 'reference207.json']
    packages = {}
    for name in ('torch', 'torchvision', 'numpy', 'statsmodels', 'datasets', 'gluonts',
                 'pandas', 'pyarrow', 'open_clip_torch', 'timm', 'ftfy'):
        packages[name] = importlib.metadata.version(name)
    return dict(version=1, context_length=CONTEXT, patch_size=PATCH, feature_dim=EMBED_DIM,
        left_padding=True, split='test_data.input only', to_univariate=True,
        image_style='rgb_overlay_shared_difference_scale', difference2='x[t]-x[t-2]',
        feature_dtype='float32', feature_l2_normalized=False, precision='fp32',
        compute_backend=backend, cuda_matmul_allow_tf32=False, cudnn_allow_tf32=True,
        clip_sha256=clip_sha, samples_per_shard=args.samples_per_shard,
        max_samples_per_config=args.max_samples_per_config,
        sources={x: sha256_file(ROOT / x) for x in sources}, packages=packages)


def signature(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True).encode()).hexdigest()


def setup_config(args, item, common):
    config_dir = args.output / item['config']
    config_dir.mkdir(parents=True, exist_ok=True)
    metadata = dict(protocol=common, task=item)
    identifier = signature(metadata)
    with lock_file(config_dir / '.metadata.lock'):
        config_file = config_dir / 'generation.json'
        if config_file.exists():
            previous = json.loads(config_file.read_text())
            if previous['signature'] != identifier:
                raise ValueError(f'Output protocol/data changed at {config_dir}; choose a NEW output directory')
        else:
            if list(config_dir.glob('samples-*.npz')) or (config_dir / 'manifest.json').exists():
                raise ValueError(f'Refusing to overwrite an existing foreign cache: {config_dir}')
            atomic_json(config_file, dict(signature=identifier, **metadata))
    return config_dir, identifier


def shard_info(item, index, size, identifier):
    start = index * size
    count = min(size, item['output_samples'] - start)
    return dict(signature=identifier, start=start, count=count)


def finalize(args, plan, common):
    missing = []
    total = 0
    for item in plan:
        config_dir, identifier = setup_config(args, item, common)
        entries = []
        for index in range(item['shard_count']):
            expected = shard_info(item, index, args.samples_per_shard, identifier)
            path = config_dir / f'samples-{index:05d}.npz'
            if not completed_shard(path, expected, verify_hash=args.verify_existing):
                missing.append(str(path)); continue
            entries.append(dict(file=path.name, samples=expected['count']))
        if len(entries) == item['shard_count']:
            manifest = dict(config=item['config'], dataset=item['dataset'], term=item['term'],
                sort_order=['window_index', 'variate_index', 'sample_id'],
                source_samples=item['output_samples'], written_samples=item['output_samples'],
                skipped_samples=0, samples_per_shard=args.samples_per_shard,
                fields=list(FIELDS), shards=entries, generation_signature=identifier,
                preview_only=bool(args.max_samples_per_config),
                prediction_length=item['prediction_length'], frequency=item['frequency'])
            # Preview runs must not look like a finished cache to old evaluators.
            filename = 'preview-manifest.json' if args.max_samples_per_config else 'manifest.json'
            atomic_json(config_dir / filename, manifest)
            total += item['output_samples']
    summary = dict(configs=len(plan), completed_samples=total,
        expected_samples=sum(x['output_samples'] for x in plan),
        missing_shards=missing, complete=not missing,
        preview_only=bool(args.max_samples_per_config), protocol=common)
    atomic_json(args.output / ('preview-summary.json' if args.max_samples_per_config else 'summary.json'), summary)
    log('finalize', complete=not missing, completed_samples=total, missing_shards=len(missing))
    return not missing


def run(args):
    reference = json.loads((ROOT / 'reference207.json').read_text())
    rank, world, local_rank = (int(os.getenv(key, default)) for key, default in
                               (('RANK', '0'), ('WORLD_SIZE', '1'), ('LOCAL_RANK', '0')))
    if not 0 <= rank < world:
        raise ValueError('Invalid distributed rank/world size')
    plan = build_plan(args, reference)
    log('plan', rank=rank, world_size=world, configs=len(plan),
        samples=sum(x['output_samples'] for x in plan),
        shards=sum(x['shard_count'] for x in plan), preview_only=bool(args.max_samples_per_config))
    if args.plan_only:
        return
    if not args.clip_checkpoint.is_file():
        raise FileNotFoundError(args.clip_checkpoint)
    clip_sha = sha256_file(args.clip_checkpoint)
    if clip_sha != reference['sha256']['ViT-B-32.pt']:
        raise ValueError('CLIP checkpoint differs from the reference207 checkpoint')
    import torch
    device = args.device
    if device == 'auto':
        device = resolve_device(local_rank)
    elif device == 'cuda':
        device = f'cuda:{local_rank}'
    common = protocol(args, clip_sha, torch.device(device).type)
    if args.finalize_only:
        if not finalize(args, plan, common):
            raise RuntimeError('Incomplete output; finish generation before evaluation')
        return

    from gift_patch.encoder import PatchEncoder
    from gift_patch.gift_data import Dataset
    if world > 1 and device != 'cpu' and device != f'{device.split(":")[0]}:{local_rank}':
        raise ValueError('Use --device auto under torchrun to avoid all ranks using one GPU')
    if device.startswith('npu'):
        import torch_npu
        torch_npu.npu.set_device(torch.device(device))
    elif device.startswith('cuda'):
        torch.cuda.set_device(torch.device(device))
    else:
        log('cpu_precision_notice', message='CPU image embeddings do not reproduce the TF32 CUDA cache exactly; use a separate output for CPU previews')
    torch.set_num_threads(max(1, int(os.getenv('OMP_NUM_THREADS', '1'))))
    encoder = None
    try:
        for item in plan:
            config_dir, identifier = setup_config(args, item, common)
            owned = [j for j in range(item['shard_count']) if (item['shard_offset'] + j) % world == rank]
            pending = []
            for j in owned:
                path = config_dir / f'samples-{j:05d}.npz'
                expected = shard_info(item, j, args.samples_per_shard, identifier)
                if not completed_shard(path, expected, verify_hash=args.verify_existing):
                    pending.append(j)
            if not pending:
                continue
            if encoder is None:
                encoder = PatchEncoder(args.clip_checkpoint, device, args.clip_batch_size, args.text_workers)
            dataset = Dataset(name=item['dataset'], term=item['term'], to_univariate=item['target_dim'] != 1)
            # Stream official windows once per task/rank. Never list every input
            # history in memory, and never touch test_data.label for generation.
            iterator = iter(dataset.test_data.input)
            cursor = 0
            for j in pending:
                expected = shard_info(item, j, args.samples_per_shard, identifier)
                path = config_dir / f'samples-{j:05d}.npz'
                with lock_file(path.with_suffix('.lock')):
                    if completed_shard(path, expected, verify_hash=args.verify_existing):
                        continue
                    started = time.time()
                    skip = expected['start'] - cursor
                    if skip < 0:
                        raise RuntimeError('Non-monotone shard scheduling')
                    # Consume skipped entries without constructing padded arrays.
                    for _ in itertools.islice(iterator, skip):
                        cursor += 1
                    if cursor != expected['start']:
                        raise RuntimeError('Dataset ended before the expected official window')
                    records = []
                    for entry in itertools.islice(iterator, expected['count']):
                        records.append(make_record(entry, cursor)); cursor += 1
                    if len(records) != expected['count']:
                        raise RuntimeError('Dataset has fewer windows than the recorded split')
                    arrays = collate(records)
                    n = len(records)
                    images = np.empty((n, PATCHES, EMBED_DIM), dtype=np.float32)
                    texts = np.empty_like(images)
                    for left in range(0, n, args.sample_group_size):
                        right = min(n, left + args.sample_group_size)
                        images[left:right], texts[left:right] = encoder.encode(
                            arrays['time_series_8192'][left:right],
                            arrays['target_mask_8192'][left:right], arrays['padding_mask_8192'][left:right])
                    arrays['image_global'], arrays['text_global'] = images, texts
                    validate_arrays(arrays, n, expected['start'])
                    atomic_npz(path, arrays)
                    atomic_json(path.with_suffix('.done.json'), dict(expected,
                        bytes=path.stat().st_size, sha256=sha256_file(path)))
                    if args.save_examples and j == 0:
                        encoder.export_example(config_dir / 'examples',
                            arrays['time_series_8192'][0], arrays['target_mask_8192'][0], arrays['padding_mask_8192'][0])
                    log('shard_complete', rank=rank, config=item['key'], shard=j,
                        samples=n, elapsed_seconds=round(time.time() - started, 2))
    finally:
        if encoder:
            encoder.close()
    # No NCCL rendezvous/barrier: feature generation needs no gradient sync.
    # The parent launcher calls --finalize-only after every local worker exits.
    if world == 1:
        if not finalize(args, plan, common):
            raise RuntimeError('Missing shards after generation')
    log('rank_complete', rank=rank)


if __name__ == '__main__':
    run(arguments())
