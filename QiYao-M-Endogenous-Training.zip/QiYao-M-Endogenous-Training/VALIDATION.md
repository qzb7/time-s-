# 验证记录（2026-10-11）

## 已验证

- 本地全部Python文件语法检查、Bash语法检查。
- CLI help、带空格路径、指定GPU编号/数量、四机各8进程命令展开。
- 平台已有RANK/WORLD_SIZE/LOCAL_RANK时不嵌套torchrun；launcher参数不传入train.py。
- 207现有toto2mm：Python3.11、Torch2.4.1+cu121、Zarr2.18.7。
- 4项CPU单元检查：globalavg数值loss、图文Smooth L1及移位、参数冻结/反向传播、
  新旧Zarr目录发现和FP16尺度恢复。额外用8192点合成样本检查完整shape/schema。
- 两进程CPU/gloo随机小模型：第1步heads-only、第2步解冻后8层，成功保存两个checkpoint；
  随后单进程CPU加载checkpoint-2，恢复optimizer/scheduler并完成第3步。
- 与207现存旧all7训练实现比较：24层、d_model16、patch32、图文512维、128点随机输入；
  相同state_dict与seed下，CPM mask完全一致，融合前向结果、三项loss、64个有梯度的
  参数张量均逐元素完全一致（最大绝对差0）。

CPU测试代码上传到了207独立目录 `/tmp/qiyaom-endo-check-7Kt8Nx/`。
测试没有读取真实训练数据/完整预训练权重，没有使用GPU或停止任何任务。
微型集成测试的随机数据与checkpoint位于测试自建的临时子目录，结束后由测试清理。

## 未验证 / 不承诺

- 未运行真实8192长度、原尺寸模型的GPU完整训练或显存/吞吐验证。
- 未实际运行NCCL多GPU或多机训练；已验证的是CPU/gloo两进程切换和多机命令展开。
- 未重跑所有历史中间训练流程，不承诺复现历史22000榜单数值。
- checkpoint恢复不包含Zarr数据游标，也不承诺逐位复现随机数/数据轨迹。
- requirements为最低依赖说明而非历史完整lock；不应盲目升级已有Torch环境。

复查方式：

```bash
CUDA_VISIBLE_DEVICES= python tests/run_checks.py
CUDA_VISIBLE_DEVICES= python tests/run_checks.py --integration
```

以上测试只创建随机微型模型；不是正式训练入口。
