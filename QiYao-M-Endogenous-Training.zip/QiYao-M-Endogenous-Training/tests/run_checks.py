"""CPU-only unit checks and a tiny two-rank integration test. No real weights/data."""
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
os.environ["CUDA_VISIBLE_DEVICES"] = ""
import numpy as np
import torch
import zarr
from data import MultimodalZarrDataset
from qiyaom import QiYaoMBackbone, QiYaoMBackboneConfig, EndoMultimodalPredictor
from qiyaom.backbone_qiyaom import QiYaoMModelOutputs
from training_ops import modal_loss, pinball_loss, prepare_tail_first_batch, set_stage

torch.set_num_threads(1)


def small_model():
    return EndoMultimodalPredictor(QiYaoMBackbone(QiYaoMBackboneConfig(
        patch_size=32, d_model=16, d_ff=32, num_heads=2, num_layers=24,
        layer_group_size=24, num_variate_layers_per_group=0,
        variate_layer_first=False, residual_attn_ratio=1.0)))


def write_bank(path, rows=8, length=96):
    rng = np.random.default_rng(7)
    patches = length // 32
    g = zarr.open_group(str(path), mode="w")
    g.create_dataset("time_series_8192", data=rng.normal(size=(rows, length)).astype("f4"),
                     chunks=(2, length))
    g.create_dataset("target_mask_8192", data=np.ones((rows, length), dtype="u1"),
                     chunks=(2, length))
    for mod in ["image", "text"]:
        g.create_dataset(f"{mod}_global_fp16",
            data=rng.normal(size=(rows, patches, 512)).astype("f2"), chunks=(2, patches, 512))
        g.create_dataset(f"{mod}_scale", data=np.full((rows, patches, 1), 2, dtype="f4"),
                         chunks=(2, patches, 1))
    g.attrs["written_count"] = rows


class CoreChecks(unittest.TestCase):
    def test_pinball_is_patch_not_series_average(self):
        x = torch.tensor([[0, 1, 2, 3], [0, 4, 5, 6]], dtype=torch.float32)
        target = x[:, None, :].repeat_interleave(32, dim=-1)
        mask = torch.ones_like(target, dtype=torch.bool)
        mask[0, 0, 32:56] = False  # A partial patch must not receive lower weight.
        masked = torch.tensor([[[False, True, False, True]],
                               [[False, True, True, True]]])
        pred = torch.zeros(9, 2, 1, 4, 32, requires_grad=True)
        out = QiYaoMModelOutputs(pred, torch.zeros_like(target), torch.ones_like(target))
        prepared = {"target": target, "target_mask": mask, "masked_patches": masked}
        loss, info = pinball_loss(out, prepared, patch_size=32, world_size=1)
        expected = torch.asinh(torch.tensor([1., 3., 4., 5., 6.])).mean() * .5
        torch.testing.assert_close(loss, expected)
        self.assertEqual(info["masked_patches"].item(), 5)
        loss.backward()
        self.assertTrue(torch.isfinite(pred.grad).all())

    def test_modal_shift_scale_and_average(self):
        pred = torch.zeros(2, 1, 3, 512, requires_grad=True)
        target = torch.ones_like(pred) * 2
        masked = torch.tensor([[[False, True, False]], [[False, True, True]]])
        loss, logged, count = modal_loss(pred, target, masked, 1)
        torch.testing.assert_close(loss, torch.tensor(1.5))
        torch.testing.assert_close(logged, loss.detach())
        self.assertEqual(count.item(), 3)
        loss.backward()

    def test_stage_freezing_forward_backward(self):
        torch.manual_seed(4)
        model = small_model()
        batch = {"target": torch.randn(2, 96),
                 "target_mask": torch.ones(2, 96, dtype=torch.bool)}
        prepared = prepare_tail_first_batch(batch, torch.device("cpu"), patch_size=32,
                       max_span_patches=4, max_mask_probability=.4)
        image, text = torch.randn(2, 1, 3, 512), torch.randn(2, 1, 3, 512)
        set_stage(model, True)
        self.assertFalse(any(p.requires_grad for p in model.base_model.parameters()))
        self.assertTrue(all(p.requires_grad for p in model.image_projector.parameters()))
        optimizer = torch.optim.AdamW(model.parameters(), lr=1e-3)
        before = {k: v.detach().clone() for k, v in model.base_model.state_dict().items()}
        for head in [True, False]:
            set_stage(model, head)
            out, hidden = model(**prepared_inputs(prepared), image_tokens=image, text_tokens=text)
            loss, _ = pinball_loss(out, prepared, patch_size=32, world_size=1)
            for decoder, target in [(model.image_decoder, image), (model.text_decoder, text)]:
                loss = loss + modal_loss(decoder(hidden), target, prepared["masked_patches"], 1)[0]
            self.assertTrue(torch.isfinite(loss))
            loss.backward()
            optimizer.step()
            optimizer.zero_grad(set_to_none=True)
            if head:
                for k, v in model.base_model.state_dict().items():
                    torch.testing.assert_close(v, before[k], atol=0, rtol=0)
        for idx in range(16):
            self.assertFalse(any(p.requires_grad for p in model.base_model.transformer.layers[idx].parameters()))
        for idx in range(16, 24):
            self.assertTrue(all(p.requires_grad for p in model.base_model.transformer.layers[idx].parameters()))
        changed = [k for k, v in model.base_model.state_dict().items()
                   if not torch.equal(v, before[k])]
        self.assertTrue(any(k.startswith("transformer.layers.16.") for k in changed))
        self.assertFalse(any(k.startswith("patch_proj.") for k in changed))

    def test_dataset_formats_and_embedding_restore(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            write_bank(root / "merged/block-00000.zarr")
            write_bank(root / "shards/block-00000.rank-0.zarr")
            write_bank(root / "test_inputs/merged/block-00000.zarr")
            dataset = MultimodalZarrDataset([root], sequence_length=96)
            self.assertEqual(dataset.report()["rows"], 8)
            self.assertEqual(len(dataset.stores), 1)
            expected = zarr.open_group(str(dataset.stores[0]), mode="r")["image_global_fp16"][0].astype("f4") * 2
            item = next(dataset.read_chunk(dataset.stores[0], 0, 2, [0]))
            np.testing.assert_array_equal(item["image_tokens"].numpy(), expected)
            legacy = root / "legacy"
            write_bank(legacy / "generation/block-00000/block-00000.rank-0.zarr")
            self.assertEqual(MultimodalZarrDataset([legacy], sequence_length=96).report()["rows"], 8)
            # The real schema/default length is checked without an expensive model forward.
            write_bank(root / "full/block-00000.zarr", rows=2, length=8192)
            self.assertEqual(MultimodalZarrDataset([root / "full"]).report()["patches"], 256)


def prepared_inputs(prepared):
    return {k: prepared[k] for k in ["target", "target_mask", "cpm_mask", "series_ids"]}


def integration():
    with tempfile.TemporaryDirectory(prefix="qiyaom-endo-cpu-") as temporary:
        root = Path(temporary)
        small_model().base_model.save_pretrained(root / "initial")
        write_bank(root / "data/block-00000.zarr")
        env = dict(os.environ, PYTHONPATH=str(ROOT), OMP_NUM_THREADS="1", CUDA_VISIBLE_DEVICES="")
        common = ["--data-dir", str(root / "data"), "--device", "cpu", "--sequence-length", "96",
                  "--head-steps", "1", "--max-steps", "4", "--warmup-steps", "0",
                  "--batch-size", "2", "--save-steps", "1"]
        command = [sys.executable, "-m", "torch.distributed.run", "--standalone", "--nproc_per_node", "2",
                   str(ROOT / "train.py"), "--model-dir", str(root / "initial"),
                   "--output-dir", str(root / "run"), "--stop-after-steps", "2", *common]
        subprocess.run(command, env=env, check=True, timeout=150)
        state = torch.load(root / "run/checkpoint-2/training_state.pt", map_location="cpu", weights_only=True)
        assert state["global_step"] == 2 and not state["head_only"]
        assert len(state["rng_by_rank"]) == 2
        # Resume past the unfreeze point, with a new output but the same cosine schedule.
        command = [sys.executable, str(ROOT / "train.py"), "--resume-dir", str(root / "run/checkpoint-2"),
                   "--output-dir", str(root / "resumed"), "--stop-after-steps", "3", *common]
        subprocess.run(command, env=env, check=True, timeout=90)
        state = torch.load(root / "resumed/checkpoint-3/training_state.pt", map_location="cpu", weights_only=True)
        assert state["global_step"] == 3
        print("INTEGRATION PASSED: 2-rank CPU heads -> last8, checkpoint reload, optimizer/scheduler resume")


if __name__ == "__main__":
    if "--integration" in sys.argv:
        integration()
    else:
        unittest.main()
