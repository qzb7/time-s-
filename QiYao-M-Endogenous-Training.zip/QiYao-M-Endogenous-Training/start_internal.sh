#!/usr/bin/env bash
# Launch options are consumed HERE; all other arguments go directly to train.py.
set -euo pipefail
root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
python="${TRAIN_PYTHON:-python}"
gpus=auto
gpu_ids=""
nodes="${NNODES:-${SLURM_NNODES:-1}}"
node_rank="${NODE_RANK:-${SLURM_NODEID:-0}}"
master_addr="${MASTER_ADDR:-}"
master_port="${MASTER_PORT:-29877}"
launch_mode=foreground
log_file=""
dry_run=0
args=()
die() { echo "Launch error: $*" >&2; exit 2; }

while (($#)); do
  key="${1%%=*}"; key="${key//_/-}"
  case "$key" in
    --dry-run) dry_run=1; shift ;;
    --python|--gpus|--gpu-ids|--nodes|--nnodes|--node-rank|--master-addr|--master-port|--launch-mode|--log-file)
      if [[ "$1" == *=* ]]; then value="${1#*=}"; shift
      else (($# >= 2)) || die "$1 needs a value"; value="$2"; shift 2; fi
      case "$key" in
        --python) python="$value" ;;
        --gpus) gpus="$value" ;;
        --gpu-ids) gpu_ids="$value" ;;
        --nodes|--nnodes) nodes="$value" ;;
        --node-rank) node_rank="$value" ;;
        --master-addr) master_addr="$value" ;;
        --master-port) master_port="$value" ;;
        --launch-mode) launch_mode="$value" ;;
        --log-file) log_file="$value" ;;
      esac ;;
    -h|--help)
      echo 'Launch: --python PATH --gpu-ids 0,1,2 --gpus auto|N --master-port 29877'
      echo '        --nodes N --node-rank N --master-addr HOST'
      echo '        --launch-mode foreground|background --log-file PATH --dry-run'
      "$python" "$root/train.py" --help
      exit 0 ;;
    *) args+=("$1"); shift ;;
  esac
done
[[ "$nodes" =~ ^[1-9][0-9]*$ ]] || die '--nodes must be a positive integer'
[[ "$node_rank" =~ ^[0-9]+$ ]] && ((node_rank < nodes)) || die 'Invalid node rank'
[[ "$master_port" =~ ^[0-9]+$ ]] && ((master_port > 0 && master_port < 65536)) || die 'Invalid port'
[[ "$launch_mode" == foreground || "$launch_mode" == background ]] || die 'Invalid launch mode'
command -v "$python" >/dev/null 2>&1 || die "Python not found: $python"
if [[ -n "$gpu_ids" ]]; then
  [[ -z "${LOCAL_RANK+x}" ]] || die 'Do not change GPU IDs inside an already launched worker'
  [[ "$gpu_ids" =~ ^[0-9]+(,[0-9]+)*$ ]] || die 'Use --gpu-ids 0,1,2 (integer IDs)'
  export CUDA_VISIBLE_DEVICES="$gpu_ids"
fi
export PYTHONPATH="$root${PYTHONPATH:+:$PYTHONPATH}"
export OMP_NUM_THREADS="${OMP_NUM_THREADS:-1}"

# Platform already created workers: never nest torchrun, never forward --gpus.
if [[ -n "${RANK+x}" && -n "${WORLD_SIZE+x}" && -n "${LOCAL_RANK+x}" ]]; then
  command=("$python" -u "$root/train.py" "${args[@]}")
else
  if [[ "$gpus" == auto ]]; then
    if [[ -n "${CUDA_VISIBLE_DEVICES:-}" && "${CUDA_VISIBLE_DEVICES}" != -1 ]]; then
      IFS=',' read -r -a visible_ids <<< "$CUDA_VISIBLE_DEVICES"
      gpus="${#visible_ids[@]}"
    else
      gpus="$("$python" -c 'import torch; print(torch.cuda.device_count())')"
    fi
  fi
  [[ "$gpus" =~ ^[1-9][0-9]*$ ]] || die 'No visible GPUs; choose GPU IDs or use --gpus 1 for CPU verification'
  if [[ -n "${CUDA_VISIBLE_DEVICES:-}" && "${CUDA_VISIBLE_DEVICES}" != -1 ]]; then
    IFS=',' read -r -a visible_ids <<< "$CUDA_VISIBLE_DEVICES"
    ((gpus <= ${#visible_ids[@]})) || die '--gpus exceeds visible GPU count'
  fi
  if ((nodes > 1)); then
    [[ -n "$master_addr" ]] || die 'Multi-node launch needs --master-addr or MASTER_ADDR'
  else
    master_addr="${master_addr:-127.0.0.1}"
  fi
  command=("$python" -m torch.distributed.run --nproc_per_node "$gpus"
           --nnodes "$nodes" --node_rank "$node_rank"
           --master_addr "$master_addr" --master_port "$master_port"
           "$root/train.py" "${args[@]}")
fi
printf 'Command: '; printf '%q ' "${command[@]}"; printf '\n'
((dry_run == 0)) || exit 0
if [[ "$launch_mode" == background ]]; then
  [[ -z "${LOCAL_RANK+x}" ]] || die 'Platform workers must run in foreground'
  log_file="${log_file:-$root/logs/internal-$(date +%Y%m%d-%H%M%S)-$$.log}"
  mkdir -p "$(dirname -- "$log_file")"
  [[ ! -e "$log_file" && ! -e "$log_file.pid" ]] || die "Log already exists: $log_file"
  if command -v setsid >/dev/null 2>&1; then
    nohup setsid "${command[@]}" > "$log_file" 2>&1 < /dev/null &
  else
    nohup "${command[@]}" > "$log_file" 2>&1 < /dev/null &
  fi
  pid=$!
  printf '%s\n' "$pid" > "$log_file.pid"
  echo "Dispatched launcher PID=$pid; initialization/training success must be checked in $log_file"
else
  exec "${command[@]}"
fi
