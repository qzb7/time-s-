# QiYao-M 内源多模态连续训练

一个入口、一个训练进程组、两段参数解冻策略。默认算法对应原 all7 additive/globalavg
内源训练；不再串联历史 all9、nonsolar、longbalanced、TIME/GIFT 比例切换等实验。
**它不是历史 checkpoint-22000 的逐位复现，也不能保证相同榜单指标。**
这里只训练内源模块，不包含数值预训练、外源检索训练或评测调度器。

## 1. 训练流程

| 优化器步数 | 可训练参数 | 冻结参数 |
|---|---|---|
| 1–1500，`--head-steps` 可改 | 图文projector、图文decoder/head、图文mask token | 全部数值骨干，包括数值head |
| 1501起 | 上述模块 + Transformer后8层（索引16–23）+ out_norm + 数值output_head | 前16层与数值patch embedding |

“先训head”严格沿用旧代码定义：第一段不是只训数值head，而是先对齐新加入的图文模块。
切换阶段不重建AdamW或LR调度；DDP重新封装，以同步新解冻参数的梯度。

保留的数学实现：

- 第16层后 `h + ResMLP([h,image]) + ResMLP([h,text])`，再过后8层。
- CPM后缀优先 + 内部连续span masking；默认跨度4、mask比例上限0.4。
- 数值：9分位点Pinball，先均分位点、再均patch内有效点、最后全GPU监督patch平均。
- 图文：512维embedding的Smooth L1，先均特征维、再全GPU监督patch平均。
- 总loss为三项之和，显式系数1:1:1；没有逐序列等权平均的隐藏分支。
- 保留下一patch预测移位、mask token、标准化/asinh与fp16 embedding尺度恢复。

数据采样：所有显式提供的Zarr样本按chunk打乱、跨rank/worker分片，循环读取。
不同目录没有额外人工比例；样本数量决定长期占比。各rank步数相同，但数据不一定
在同一个优化器步恰好结束一轮，因此不要把step当成严格同步epoch。

## 2. 环境

207现有 `toto2mm` 可以作为起点。先激活已装好的CUDA版Torch环境，不要为本包盲目升级Torch。
源码带有 `dd_unit_scaling` 和数值骨干，不需要安装外部同名模型包；AdamW训练不需要Dion。
本包没有权重、原始数据、CLIP权重或完整conda环境。

```bash
conda activate toto2mm
cd /path/to/QiYao-M-Endogenous-Training
# 仅缺依赖时安装；pip可能解析传递依赖，请先检查，不要直接破坏现有环境。
python -m pip install --dry-run -r requirements.txt
python -m pip install -r requirements.txt
```

Python建议3.11或3.12，Torch至少2.4。保留旧Torch的GQA兼容展开逻辑。
无需再次生成文本/图片、运行CLIP或调用LLM，因为训练输入已有逐patch特征。

## 3. 模型和数据

`--model-dir` 指定一个本地数值权重目录，例如原数值训练的checkpoint-27000：

```text
checkpoint-27000/
  config.json
  model.safetensors  （或标准safetensors分片及index）
```

要求24层、patch32；正式历史配置d_model1024。若起点是内源权重，必须同时带上
`layer16_concat_additive_state.pt`，否则图文模块会重新初始化。
保留这个旧文件名是为了兼容已有checkpoint，不表示调用另一个模型。

`--data-dir` 可重复指定，也可一个参数后放多个目录。支持：

```text
/data/my_generated/merged/block-00000.zarr       # 新生成器合并结果，推荐
/data/my_generated/shards/block-00000.rank-0.zarr
/data/legacy/generation/block-00000/block-00000.rank-0.zarr
/data/legacy/block-00000.zarr
```

可直接传Zarr目录、merged目录或生成器输出根目录。根目录同时有merged/shards时
优先merged，防止重复计数。只使用生成完成的数据；不会自动扫描test_inputs目录。
测试历史数据只有显式传入时才参与训练，并应在论文中披露，不能报告为clean zero-shot。

每个Zarr的必要数组：

| 字段 | shape | 含义 |
|---|---|---|
| time_series_8192 | N × 8192 | 数值序列 |
| target_mask_8192 | N × 8192 | 真实有效点mask，padding/缺失不作标签 |
| image_global_fp16 / text_global_fp16 | N × 256 × 512 | patch级图文特征 |
| image_scale / text_scale | N × 256 × 1 | 还原FP32特征的尺度 |

加载时计算 `embedding.float() * scale.float()`，不是直接把FP16转FP32。
`written_count` 决定读取多少条。额外metadata/padding等字段可保留，但训练不使用。

只检查schema和样本数，不训练、不申请GPU：

```bash
python train.py --data-dir /data/my_generated/merged --check-data
```

## 4. 直接启动

```bash
bash start_internal.sh \
  --model-dir /home/toto-main/output/toto2-313m-cpm256-time-only/checkpoint-27000 \
  --data-dir /data/my_generated/merged \
  --output-dir /data/output/QiYao-M-internal-run1 \
  --gpu-ids 0,1,2,3,4,5 \
  --head-steps 1500 \
  --max-steps 200000 \
  --stop-after-steps 34000 \
  --batch-size 224 \
  --learning-rate 5e-5 --min-learning-rate 5e-6 \
  --warmup-steps 1000 \
  --cpm-max-span-patches 4 --cpm-max-mask-probability 0.4 \
  --save-steps 500 --bf16 false --tf32 false
```

把模型/数据/输出路径换成自己的路径即可。可追加第二个 `--data-dir /data/another_bank`。
`max-steps`控制cosine调度长度；`stop-after-steps`控制这次实际停止位置。
上例训练34000步，但保持原200000步调度，而不是将cosine压缩到34000步。
不需要写七个固定数据目录，也不需要手动停止再启动第二阶段。

后台运行：在同一命令末尾加

```bash
  --launch-mode background --log-file /data/logs/QiYao-M-internal-run1.log
```

只核对命令：在同一命令末尾加 `--dry-run`。完整参数：`bash start_internal.sh --help`。
输出目录必须为空；脚本不会覆盖原实验或停止其他任务，也不会自动避开繁忙GPU。
请显式选择自己获分配的GPU。batch224是旧6卡实验值，不保证所有显卡都放得下。

## 5. GPU/多机参数

- `--gpu-ids 0,1,2` 选择本节点物理GPU；不传则继承CUDA_VISIBLE_DEVICES。
- `--gpus N` 是本节点进程数，不是多机总卡数。默认auto读取当前可见卡数。
- 选择GPU0、2、5时建议 `--gpu-ids 0,2,5`，不要写 `--gpus 0,2,5`。
- 默认前台、端口29877；并行实验用不同端口。`TRAIN_PYTHON`或`--python`选择解释器。
- 4机各8卡：每机运行同一命令，添加 `--nodes 4 --gpus 8 --node-rank 0`
  和 `--master-addr 主节点内网IP`，其他节点rank改为1/2/3。
  代码/数据/模型路径必须各机可读；checkpoint输出在rank0节点，推荐共享盘。
- 平台已设置RANK/WORLD_SIZE/LOCAL_RANK时直接进入训练器，不嵌套torchrun。
  平台worker必须前台，不要再传GPU编号来改变映射。
- sh吸收gpus、端口、launch-mode等参数，不会误传给训练器；未知训练参数明确报错。

## 6. 断点与输出

输出包含：模型safetensors、原兼容命名的内源模块state、训练参数、optimizer/scheduler、
step和Torch RNG。阶段1/2均用同一optimizer。checkpoint先写临时目录，再改为完整名称。

完整恢复时把上例 `--model-dir` 换成 `--resume-dir /path/checkpoint-5000`，
其他训练超参数保持原值，并将stop-after-steps设为更大的值。
输出可沿用原run或使用新目录；不覆盖同step已存在的checkpoint。
恢复optimizer/scheduler，但**不恢复Zarr迭代器位置，也不保证逐位复现随机数据轨迹**。

验证记录见 `VALIDATION.md`。仅CPU小模型测试不等于真实8192长度GPU训练通过。
