"""Historical CPM masking, global patch-average losses, and stage freezing."""
import math
import torch
import torch.distributed as dist


def _all_reduce_sum(value, world_size):
    if world_size > 1:
        dist.all_reduce(value)
    return value


def modal_loss(pred, target, masked, world):
    pred = pred[..., :-1, :]
    target = target[..., 1:, :]
    mask = masked[..., 1:].unsqueeze(-1).to(pred.dtype)
    per_patch = torch.nn.functional.smooth_l1_loss(pred, target, reduction="none").mean(dim=-1)
    valid_patch = mask.squeeze(-1).bool()
    local_sum = (per_patch * valid_patch).sum(dtype=torch.float32)
    local_count = valid_patch.sum(dtype=torch.float32)
    global_sum = local_sum.detach().clone()
    global_count = local_count.detach().clone()
    if world > 1:
        dist.all_reduce(global_sum)
        dist.all_reduce(global_count)
    return local_sum * world / global_count.clamp_min(1.0), global_sum / global_count.clamp_min(1.0), global_count



def pinball_loss(
    outputs,
    prepared: dict[str, torch.Tensor],
    *,
    patch_size: int,
    world_size: int,
) -> tuple[torch.Tensor, dict[str, torch.Tensor]]:
    target = prepared["target"]
    target_mask = prepared["target_mask"]
    total_length = target.shape[-1]
    if total_length % patch_size:
        raise ValueError(
            f"Toto inputs must be patch aligned: total={total_length}, patch={patch_size}."
        )

    num_patches = total_length // patch_size
    # Output patch i predicts target patch i+1. CPM supervision is therefore
    # selected with masked_patches[..., 1:] against outputs[..., :-1, :].
    predicted = outputs.quantiles[..., :-1, :]
    scaled_target = torch.asinh((target - outputs.loc) / outputs.scale)
    target_patches = scaled_target.unflatten(-1, (num_patches, patch_size))[
        ..., 1:, :
    ]
    point_valid = target_mask.unflatten(-1, (num_patches, patch_size))[
        ..., 1:, :
    ]
    supervised_patch = prepared["masked_patches"][..., 1:]
    valid = point_valid & supervised_patch.unsqueeze(-1)
    if predicted.shape[1:] != target_patches.shape:
        raise RuntimeError(
            f"Unexpected Toto output shape {tuple(predicted.shape)} for "
            f"target patches {tuple(target_patches.shape)}."
        )

    quantile_levels = torch.tensor(
        [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9],
        device=predicted.device,
        dtype=predicted.dtype,
    ).view(-1, *([1] * (predicted.ndim - 1)))
    errors = target_patches.unsqueeze(0) - predicted
    pinball = torch.maximum(quantile_levels * errors, (quantile_levels - 1.0) * errors)
    point_loss = pinball.mean(dim=0, dtype=torch.float32)
    valid_count_per_patch = valid.sum(dim=-1)
    valid_supervised_patch = supervised_patch & (valid_count_per_patch > 0)
    patch_loss = (point_loss * valid).sum(dim=-1) / valid_count_per_patch.clamp_min(1)
    local_loss_sum = (patch_loss * valid_supervised_patch).sum(dtype=torch.float32)
    local_patch_count = valid_supervised_patch.sum(dtype=torch.float32)
    global_patch_count = _all_reduce_sum(
        local_patch_count.detach().clone(), world_size
    )
    if global_patch_count.item() <= 0:
        raise RuntimeError("The current distributed micro-batch has no valid CPM targets.")

    # DDP averages gradients. Multiplying by world_size makes the resulting
    # gradient equal to a global average over the sampled CPM patch set M.
    loss = local_loss_sum * world_size / global_patch_count
    with torch.no_grad():
        global_loss_sum = _all_reduce_sum(local_loss_sum.detach().clone(), world_size)
        global_loss = global_loss_sum / global_patch_count
        global_valid_points = _all_reduce_sum(
            valid.sum(dtype=torch.float32), world_size
        )
    return loss, {
        "loss": global_loss,
        "valid_masked_points": global_valid_points,
        "masked_patches": global_patch_count,
    }


def sample_tail_first_patch_mask(
    target_mask, *, patch_size, max_span_patches, max_mask_probability
):
    """Always mask a random 1--K patch suffix, then fill up to <=40% elsewhere."""
    if max_span_patches < 1:
        raise ValueError("max_span_patches must be positive")
    if not 0.0 < max_mask_probability <= 1.0:
        raise ValueError("max_mask_probability must be in (0, 1]")
    if target_mask.shape[-1] % patch_size:
        raise ValueError("target length must be patch aligned")
    patch_valid = target_mask.unflatten(
        -1, (target_mask.shape[-1] // patch_size, patch_size)
    ).any(dim=-1)
    masked = torch.zeros_like(patch_valid)
    flat_valid = patch_valid.reshape(-1, patch_valid.shape[-1])
    flat_masked = masked.reshape(-1, masked.shape[-1])
    for row in range(flat_valid.shape[0]):
        valid = torch.where(flat_valid[row])[0]
        # The first valid patch must remain visible because output patch t-1
        # supervises target patch t.
        if valid.numel() < 2:
            continue
        eligible = valid[1:]
        # Preserve the original CPM coverage distribution: draw p uniformly
        # from [0, max_mask_probability] and round p * eligible_count.
        probability = float(torch.rand((), device=target_mask.device).item())
        probability *= max_mask_probability
        target_count = max(1, int(round(probability * eligible.numel())))
        target_count = min(target_count, max(1, int(math.floor(max_mask_probability * eligible.numel()))))
        # The only semantic addition to the old CPM sampler: guarantee that a
        # random 1--4-patch suffix is selected first.
        tail_span = int(torch.randint(
            1, min(max_span_patches, target_count, eligible.numel()) + 1,
            (), device=target_mask.device,
        ).item())
        flat_masked[row, eligible[-tail_span:]] = True

        interior = eligible[:-tail_span]
        attempts = 0
        while int(flat_masked[row].sum().item()) < target_count and interior.numel() and attempts < 8 * flat_valid.shape[-1]:
            remaining = target_count - int(flat_masked[row].sum().item())
            span = int(torch.randint(
                1, min(max_span_patches, remaining) + 1,
                (), device=target_mask.device,
            ).item())
            start_pos = int(torch.randint(0, interior.numel(), (), device=target_mask.device).item())
            chosen = interior[start_pos : min(interior.numel(), start_pos + span)]
            chosen = chosen[~flat_masked[row, chosen]][:remaining]
            flat_masked[row, chosen] = True
            attempts += 1
    cpm_mask = (~masked).repeat_interleave(patch_size, dim=-1)
    return cpm_mask, masked


def prepare_tail_first_batch(batch, device, *, patch_size, max_span_patches, max_mask_probability):
    target = batch["target"].to(device, non_blocking=True).unsqueeze(1)
    target_mask = batch["target_mask"].to(device, non_blocking=True).unsqueeze(1).bool()
    cpm_mask, masked_patches = sample_tail_first_patch_mask(
        target_mask,
        patch_size=patch_size,
        max_span_patches=max_span_patches,
        max_mask_probability=max_mask_probability,
    )
    if not masked_patches.any():
        raise RuntimeError("distributed micro-batch has no valid CPM patch")
    return {
        "target": target,
        "target_mask": target_mask,
        "cpm_mask": cpm_mask,
        "masked_patches": masked_patches,
        "series_ids": torch.zeros(target.shape[:-1], dtype=torch.long, device=device),
    }


def set_stage(model, stage1: bool):
    """Freeze the full backbone in stage 1; then train only layers 16+ and head."""
    model.base_model.requires_grad_(False)
    if not stage1:
        layers = model.base_model.transformer.layers
        if len(layers) != 24:
            raise ValueError(f"Expected 24 transformer layers, got {len(layers)}")
        for layer_index in range(16, 24):
            layers[layer_index].requires_grad_(True)
        model.base_model.transformer.out_norm.requires_grad_(True)
        model.base_model.output_head.requires_grad_(True)
    for module in (
        model.image_projector,
        model.text_projector,
        model.image_decoder,
        model.text_decoder,
    ):
        for p in module.parameters():
            p.requires_grad = True
    model.image_mask_token.requires_grad = True
    model.text_mask_token.requires_grad = True



