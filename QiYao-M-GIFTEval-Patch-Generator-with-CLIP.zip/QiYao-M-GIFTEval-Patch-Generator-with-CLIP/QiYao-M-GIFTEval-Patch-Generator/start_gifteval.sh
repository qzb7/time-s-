#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
PYTHON_BIN="${GENERATOR_PYTHON:-python}"
export OMP_NUM_THREADS="${OMP_NUM_THREADS:-1}"
export MKL_NUM_THREADS="${MKL_NUM_THREADS:-1}"

# Already inside a platform's torchrun: respect its global/local ranks.
if [[ -n "${RANK:-}" && -n "${WORLD_SIZE:-}" ]]; then
    exec "$PYTHON_BIN" "$SCRIPT_DIR/generate_gifteval.py" "$@"
fi

# Planning/finalization are CPU metadata tasks and need one process only.
for arg in "$@"; do
    if [[ "$arg" == "--plan-only" || "$arg" == "--finalize-only" ]]; then
        exec "$PYTHON_BIN" "$SCRIPT_DIR/generate_gifteval.py" "$@"
    fi
done

NPROC="${NPROC_PER_NODE:-auto}"
GPU_COUNT="$("$PYTHON_BIN" -c 'import torch; print(torch.cuda.device_count())')"
CPU_ONLY=false
PREVIOUS_ARG=""
for arg in "$@"; do
    if [[ "$arg" == "--device=cpu" || ( "$PREVIOUS_ARG" == "--device" && "$arg" == "cpu" ) ]]; then
        CPU_ONLY=true
    fi
    PREVIOUS_ARG="$arg"
done
if [[ "$NPROC" == "auto" ]]; then
    NPROC="$GPU_COUNT"
    if [[ "$CPU_ONLY" == true || "$NPROC" -eq 0 ]]; then NPROC=1; fi
fi
if [[ ! "$NPROC" =~ ^[1-9][0-9]*$ ]]; then
    echo "NPROC_PER_NODE must be auto or a positive integer" >&2
    exit 2
fi
if [[ "$CPU_ONLY" == false && "$GPU_COUNT" -gt 0 && "$NPROC" -gt "$GPU_COUNT" ]]; then
    echo "NPROC_PER_NODE=$NPROC exceeds the $GPU_COUNT visible local GPUs; use auto or reduce it." >&2
    exit 2
fi
if [[ "$NPROC" -eq 1 ]]; then
    exec "$PYTHON_BIN" "$SCRIPT_DIR/generate_gifteval.py" "$@"
fi

# The process count is LOCAL visible GPUs, never total GPUs across all nodes.
# --standalone uses an automatically selected rendezvous port.
"$PYTHON_BIN" -m torch.distributed.run --standalone --nproc_per_node="$NPROC" \
    "$SCRIPT_DIR/generate_gifteval.py" "$@"
"$PYTHON_BIN" "$SCRIPT_DIR/generate_gifteval.py" "$@" --finalize-only
