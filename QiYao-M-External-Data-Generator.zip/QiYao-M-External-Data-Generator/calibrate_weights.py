"""Offline leave-overlap-out retrieval-aggregate MSE calibration, all queries."""
import argparse, hashlib, json, os, time
from pathlib import Path
import numpy as np
import torch
from bootstrap import rank_info, resolve_device

VERSION='v11_top1500_aggregate_futurez_common80_meanmse_softmax_T1'
KEYS=['image_key','text_key','timeseries_key']

def calibrate_source(path,device):
    records=[json.loads(x) for x in (path/'records.jsonl').read_text().splitlines()]
    with np.load(path/'bank_arrays.npz') as f:
        arrays={k:f[k] for k in KEYS+['future_values','future_valid_mask','history_valid_mask']}
    n=len(records);h=np.array([r['prediction_length'] for r in records])
    available=np.array([r['available_future_length'] for r in records])
    future=arrays['future_values'];mask=arrays['future_valid_mask'].astype(bool)&np.isfinite(future)&(np.arange(192)[None]<available[:,None])
    cutoff=np.array([r['forecast_cutoff'] for r in records]);start=cutoff-np.array([r['lookback_length'] for r in records])
    series=np.array([str(r['series_id']) for r in records]);allowed=np.zeros((n,n),bool)
    for i in range(n):
        end=cutoff+np.minimum(((h[i]+31)//32)*32,available)
        overlap=(series==series[i])&(np.maximum(cutoff[i],start)<np.minimum(cutoff[i]+h[i],end))
        allowed[i]=(available>=h[i])&~overlap;allowed[i,i]=False
    scores=[]
    for name in KEYS:
        x=torch.as_tensor(arrays[name],device=device,dtype=torch.float32)
        x=torch.nn.functional.normalize(x,dim=-1)
        scores.append((x@x.T).clamp(-1,1))
    scores=torch.stack(scores,-1);ok=torch.as_tensor(allowed,device=device)&torch.isfinite(scores).all(-1)
    temperatures=torch.stack([scores[:,:,m][ok].std(unbiased=False) if ok.any() else scores.new_tensor(.03) for m in range(3)]).clamp(.03,1)
    y=torch.as_tensor(np.where(mask,future,0),device=device,dtype=torch.float32)
    fm=torch.as_tensor(mask,device=device);Hs=torch.as_tensor(h,device=device)
    errors=torch.full((n,3),torch.nan,device=device)
    anchor=torch.as_tensor(arrays['history_valid_mask'][:,-32:].any(-1),device=device)
    # Same normalization for all three modalities. Each future is z-scored
    # on its own real points in the query's H. No padding enters statistics.
    for horizon in np.unique(h):
        hh=int(horizon);m=fm[:,:hh];v=y[:,:hh];cnt=m.sum(-1,keepdim=True)
        mean=(v*m).sum(-1,keepdim=True)/cnt.clamp_min(1)
        std=(((v-mean).square()*m).sum(-1,keepdim=True)/cnt.clamp_min(1)).sqrt().clamp_min(1e-6)
        z=((v-mean)/std).masked_fill(~m,0)
        ids=torch.where(Hs==hh)[0]
        for chunk in ids.split(32):
            predictions=[];supports=[]
            for mod in range(3):
                logits=(scores[chunk,:,mod]/temperatures[mod]).masked_fill(~ok[chunk],-torch.inf)
                values,indices=logits.topk(min(1500,n),dim=-1)
                finite=torch.isfinite(values);maximum=values.masked_fill(~finite,-1e30).max(-1,keepdim=True).values
                weights=torch.exp((values-maximum).masked_fill(~finite,-torch.inf))
                weights=weights/weights.sum(-1,keepdim=True).clamp_min(1e-30)
                a=torch.zeros_like(logits).scatter(1,indices,weights)
                denom=a@m.float();pred=(a@z)/denom.clamp_min(1e-30)
                predictions.append(pred);supports.append(denom>0)
            common=m[chunk]&torch.stack(supports).all(0)
            count=common.sum(-1);usable=(count>=2)&(count>=.8*m[chunk].sum(-1))&anchor[chunk]
            for mod,pred in enumerate(predictions):
                e=((pred-z[chunk]).square()*common).sum(-1)/count.clamp_min(1)
                errors[chunk,mod]=e.masked_fill(~usable,torch.nan)
    usable=torch.isfinite(errors).all(-1)
    means=errors[usable].mean(0) if usable.any() else torch.zeros(3,device=device)
    weights=(-means).softmax(-1)
    candidates=np.full((n,24),-1,np.int64)
    for i in range(n):
        union=[]
        for mod in range(3):
            vals,ix=scores[i,:,mod].masked_fill(~ok[i],-torch.inf).topk(min(10,n))
            union.append(ix[torch.isfinite(vals)])
        u=torch.cat(union).unique()
        if len(u):
            fused=(((scores[i,u]+1)/2)*weights).sum(-1)
            selected=u[torch.argsort(fused,descending=True,stable=True)[:24]].cpu().numpy()
            candidates[i,:len(selected)]=selected
    supervised=(mask&(np.arange(192)[None]<h[:,None])).any(-1)&arrays['history_valid_mask'][:,-32:].any(-1)
    report=dict(version=VERSION,cases=n,calibration_queries=int(usable.sum()),mean_mse=means.cpu().tolist(),weights=weights.cpu().tolist(),temperature=temperatures.cpu().tolist(),weight_temperature=1.,normalization='per_future_masked_zscore_within_query_H_identical_across_modalities',minimum_common_coverage=.8,per_modality_calibration_topk=1500,per_modality_training_topk=10,final_training_topk=24,fallback='uniform_no_valid_calibration' if not usable.any() else None)
    return dict(candidate_ids=candidates,weights=weights.cpu().numpy(),temperature=temperatures.cpu().numpy(),eligible_query_ids=np.flatnonzero(supervised),per_query_mse=errors.cpu().numpy()),report

def main():
    p=argparse.ArgumentParser();p.add_argument('--root',required=True)
    p.add_argument('--device',default='auto',choices=['auto','cuda','npu','cpu']);a=p.parse_args()
    rank,world,local=rank_info()
    device,_backend=resolve_device(local,a.device);torch.set_num_threads(2)
    root=Path(a.root);out=root/'calibration_v11';out.mkdir(exist_ok=True)
    sources=json.loads((root/'source_registry.json').read_text())['sources']
    for index,source in enumerate(sources):
        if index%world!=rank:continue
        sid=source['source_id'];slug=hashlib.sha1(sid.encode()).hexdigest()[:16];path=root/'sources'/slug
        if not (path/'.complete').exists() or not (path/'.internal_patch_tokens_complete').exists():
            raise RuntimeError(f"Bank/patch tokens incomplete: {sid}")
        dest=out/(slug+'.npz');marker=out/(slug+'.json')
        if dest.exists() and marker.exists():continue
        if dest.exists() or marker.exists():
            raise FileExistsError(f"Partial calibration exists; inspect before retry: {slug}")
        start=time.time();data,report=calibrate_source(path,device);report['source_id']=sid
        tmp=out/(slug+'.tmp.npz');np.savez_compressed(tmp,**data);os.replace(tmp,dest)
        marker.write_text(json.dumps(report,indent=2));print(json.dumps(dict(rank=rank,seconds=time.time()-start,**report)),flush=True)

if __name__=='__main__':main()
