#!/usr/bin/env bash
set -euo pipefail
python -m torch.distributed.run --standalone --nproc_per_node="${NPROC_PER_NODE:-1}" generate_bank.py "$@"
