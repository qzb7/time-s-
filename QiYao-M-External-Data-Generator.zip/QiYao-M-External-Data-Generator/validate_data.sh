#!/usr/bin/env bash
set -euo pipefail
python validate_data.py "$@"
