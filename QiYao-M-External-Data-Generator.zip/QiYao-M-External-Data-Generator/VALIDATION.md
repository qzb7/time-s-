# 检查记录（2026-10-29）

## 已完成

- 只读连接207，下载原始代码与来源清单，确认最终V11训练读取的bank根目录为 `/public_data/toto2_external_rag_longhistory_v10`。
- 读取207环境依赖版本，整理单一requirements.txt；没有安装、升级或修改207环境。
- 所有整理版Python文件AST语法检查通过，start_generator.sh通过bash语法检查。
- 本地 `tests/test_local.py`：8项通过。包括命令dry-run、核心辅助函数哈希一致、固定seed采样确定性/窗口边界/缺失处理、差分及scaled-fp16还原、独立SH参数透传，以及合并SH五步执行顺序/含空格路径/中途失败停止、registry断点参数保护。SH执行测试使用临时Python桩，不初始化GPU。
- `build_cases`、`encode_modalities`、`calibrate_source` 三个核心函数的AST与从207下载的原始对应函数完全相同。
- 图像渲染5个函数、patch辅助3个函数的源码哈希与207提取段完全相同，签名见 `reference/extracted_function_sha256.json`。

## 尚未完成

- 当前本地Python环境没有Torch、CLIP、GluonTS等完整依赖，`tests/test_cpu.py`（包括真实GluonTS划分、Torch渲染和合成V11校准）尚未执行。
- 回传代码包到207进行CPU验证被安全检查拦截，因为本次授权为下载和本地整理；没有绕过拦截，也未成功回传此新代码包。
- 没有启动正式GPU生成、多卡整链生成或外源训练，不能声称已完成新生成数据与原数据逐样本一致验证。

使用者可在具有requirements环境的服务器上先运行 `CUDA_VISIBLE_DEVICES='' python tests/test_cpu.py`；通过后用较小 `--cases-per-source` 和适合磁盘的 `--min-free-gib` 检查完整生成，再启动正式规模。测试脚本不加载训练权重、不使用GPU。
