# QiYao-M 外源训练数据生成

这是 207 最终外源 V11 训练所用数据流程的可移植整理版，不是下游评测 bank 生成器，也不会启动模型训练。原始数据目录为 `/public_data/toto2_external_rag_longhistory_v10`；V11 训练在 V10 长历史数值/多模态 bank 上重新校准权重与候选。

## 1. 需要准备什么

- Linux、Python 3.11、CUDA GPU；依赖版本取自 207 的 `toto2mm`，在 `requirements.txt` 中。已有 toto2mm 不要反复安装或升级；新服务器建议新建环境后安装依赖。
- GIFTEvalPretrain、GIFT-Eval 两个原始数据根目录。这里要求 Hugging Face `save_to_disk` 布局，即子目录含 `dataset_info.json`、`state.json` 和 Arrow 文件；不是任意一个 CSV/Parquet 文件。
- 冻结的数值 TS encoder checkpoint：207 之前用数值 `checkpoint-27000`，不是内源22000或外源1000。目录需含原始数值权重与 config.json，patch=32、隐藏维度1024。
- CLIP `ViT-B-32.pt`。权重和原始训练数据不在代码包内。

本包自带数值模型、unit-scaling 扩展、GIFT-Eval 数据划分、模板与渲染代码，不需要原服务器上的那些源码目录。保留第三方版权与许可证声明。数据生成不调用 NorMuon/Dion 优化器，不要求安装 Dion。

## 2. 一个 SH 完成五步（推荐）

激活 Python 环境后，运行解压目录中的 `start_generator.sh` 即可。它在 SH 内明确依次调用五个对应 Python 文件，不通过 `run_generator.py`，任一步失败都会立即停止：

```bash
CUDA_VISIBLE_DEVICES=0,1,2,3,4,5 bash start_generator.sh \
  --pretrain-root /data/GIFTEvalPretrain \
  --gifteval-root /data/GIFTEval \
  --ts-checkpoint /models/numerical-checkpoint-27000 \
  --clip-checkpoint /models/ViT-B-32.pt \
  --output /data/qiyaom_external_train \
  --cases-per-source 2000 \
  --nproc-per-node 6 \
  --workers 6 \
  --seed 260918
```

自动顺序：**来源清单 → 训练 bank/序列级表示 → patch 编码 → V11 校准/候选 → 数据检查**。无需手动运行五次。

- `--nproc-per-node` 是卡数/进程数，不是编号；默认 `NPROC_PER_NODE` 环境变量的值，未设置时为 **1**。GPU编号通过 `CUDA_VISIBLE_DEVICES` 指定。单机运行一次即可，不要再在外面套torchrun。
- SH使用当前环境的 `python`。可用SH绝对路径从任意目录运行；用户传入的相对路径仍相对于当前终端目录解析。
- 加 `--dry-run` 只打印五条命令，不读取数据、不创建输出、不初始化GPU；`--full-arrays` 对最终patch数据做完整有限值扫描。
- 可选批量参数：`--image-batch 32 --text-batch 256 --ts-batch 16 --sample-batch 64 --clip-batch 16384`。`--workers 6` 是每GPU进程的worker数。
- 默认保留150 GiB可用磁盘；小规模检查可显式调小 `--min-free-gib`。序列级编码继承原版OOM回退，显存不足可降低相应batch。
- 相同命令可继续未完成阶段：第一步只检查已经存在的来源清单，不覆盖它。会核对数据根目录、数量、seed及模型路径；后续阶段跳过已完成来源。旧版分阶段输出若未记录模型路径，继续用原阶段命令，或为合并版选择新输出目录，不静默混合。
- 默认前台运行，不自动创建后台任务，不启动模型训练，不停止其他进程。

### 可选：仍然保留各阶段独立 SH

先 `cd` 到解压后的代码目录，激活环境。每个 SH 都直接调用同名 Python 文件，`"$@"` 将命令行参数原样传入，不经过 CLI 或 `run_generator.py` 总调度。

| SH 文件 | 作用 |
| --- | --- |
| `prepare_registry.sh` | 扫描来源、指定每来源样本数 |
| `generate_bank.sh` | 生成数值历史/未来与序列级检索表示 |
| `generate_patch_tokens.sh` | 生成历史的 patch 图像/文本 token |
| `calibrate_weights.sh` | 计算 V11 离线权重和最终候选 |
| `validate_data.sh` | 只读检查生成的数据 |

例如 `prepare_registry.sh` 就是：

```bash
#!/usr/bin/env bash
set -euo pipefail
python prepare_registry.py "$@"
```

按顺序运行下面五步。路径换成自己的；第二至第四步需等待上一步成功结束后再启动。

```bash
# 1. 生成来源清单，每个来源最多目标 2000 条
bash prepare_registry.sh \
  --pretrain-root /data/GIFTEvalPretrain \
  --gifteval-root /data/GIFTEval \
  --output-root /data/qiyaom_external_train \
  --cases-per-source 2000 \
  --seed 260918

# 2. 生成 bank 与序列级 TS/图像/文本表示
CUDA_VISIBLE_DEVICES=0,1,2,3,4,5 NPROC_PER_NODE=6 bash generate_bank.sh \
  --root /data/qiyaom_external_train \
  --gift-root /data/GIFTEval \
  --ts-checkpoint /models/numerical-checkpoint-27000 \
  --clip /models/ViT-B-32.pt \
  --workers 6 \
  --image-batch 32 \
  --text-batch 256 \
  --ts-batch 16

# 3. 生成 patch 级图像/文本 token
CUDA_VISIBLE_DEVICES=0,1,2,3,4,5 NPROC_PER_NODE=6 bash generate_patch_tokens.sh \
  --root /data/qiyaom_external_train \
  --clip-checkpoint /models/ViT-B-32.pt \
  --sample-batch 64 \
  --clip-batch 16384 \
  --workers 6

# 4. V11 离线权重校准与候选选择
CUDA_VISIBLE_DEVICES=0,1,2,3,4,5 NPROC_PER_NODE=6 bash calibrate_weights.sh \
  --root /data/qiyaom_external_train

# 5. 检查数据
bash validate_data.sh --root /data/qiyaom_external_train
```

三个 GPU 阶段的 SH 结构都是下面这样，没有复杂的 Bash 参数解析：

```bash
python -m torch.distributed.run --standalone \
  --nproc_per_node="${NPROC_PER_NODE:-1}" generate_bank.py "$@"
```

- `NPROC_PER_NODE` 省略时为 **1**，即单卡；多卡时显式设置进程数量，不能超过可见卡数。
- GPU 编号用 `CUDA_VISIBLE_DEVICES` 指定，例如 `CUDA_VISIBLE_DEVICES=2,5 NPROC_PER_NODE=2`，仅使用物理2、5卡。SH 内部的 LOCAL_RANK 会映射到可见卡。
- 不要再给这些 SH 外面套一层 `torchrun`，也不要把 `--nproc-per-node` 传给阶段 Python；卡数用上述环境变量，其他命名参数直接跟在 SH 后面。
- 查看对应参数：`python generate_bank.py --help` 等。所有 SH 使用当前环境的 `python`，不自动安装依赖或切换环境。
- 第二步未指定 `--seed` 时读取来源清单中的 seed。第一步不能对已有 registry 覆盖重建；第二至第四步可用相同命令继续未完成来源，原输入/模型/seed 不应变化。
- 分阶段调用不会生成总入口专用的 `generation_config.json`，不要在同一输出中途切换到总入口；始终沿用这五步命令即可。

旧版 `run_generator.py` 暂时保留兼容，但不是现在推荐的运行入口；它使用独立的 `generation_config.json` 检查机制，不要在未确认配置时混用不同入口。

## 3. 处理流程

1. `prepare_registry.py`：扫描两个数据根目录，按 `corpus/dataset/frequency` 定义来源，每来源目标2000条；这不是总共2000条，也不是每个变量各2000条。去重保留规则与207原版一致。
2. `generate_bank.py`：只在训练范围采样历史—未来对；生成整段历史的图像、文本、TS key。80%采样偏向较长历史、20%覆盖完整训练位置范围。历史最长8192，未来6–192，未来保存容器固定192。单变量/多变量都可输入，多变量逐通道采样并混入同一来源bank。
3. `generate_patch_tokens.py`：历史每32点一个patch，总共256个位置，生成模型训练时需要的patch级图像/文本编码，保存scaled-fp16 token与float32 scale。
4. `calibrate_weights.py`：使用训练未来做离线V11校准；三个模态各召回最多1500个，计算未来标准化后的聚合误差，再按 `softmax(-mean_MSE / 1.0)` 得到来源级权重。各模态Top10并集，按加权映射余弦相似度重排序，最终取Top24。不是此前下游SP500的温度0.1、Top16设置。
5. `validate_data.py`：只读核对必要文件、形状、有限值、计数、候选索引、权重等。完整扫描patch数据可运行 `python validate_data.py --root /data/qiyaom_external_train --full-arrays`。

GIFT-Eval 来源通过内置官方 `training_dataset` 划分，按配置选择该数据集支持的最长term，排除对应验证/测试后缀；Pretrain来源使用传入的预训练语料全部记录，所以它必须确实是允许的训练语料。本流程不读取 `test_data.input` 或 `test_data.label`。训练未来用于监督和校准是必要的，但检索key只从历史构建。

### 和原实验保持一致的细节

- 同一来源同一序列的预测起点不重复；不保证所有采样窗口互不重叠。候选合法性另按V11原有时间区间规则排除自身及与Query未来区间相交的同序列参考窗口。
- 正常历史最低32点；整个来源都不够时，原版允许短序列回退到6点历史。长度不足8192左补齐，mask区分观测与padding。可用未来不足192右补齐，不计入有效监督。
- 每条记录随机任务长度为6–32、33–96、97–192三个段轮换抽取；保存的可用未来长度可能大于这条记录的任务长度，两者不是同一个字段。
- TS key使用最后一个patch的Transformer表示做归一化，而不是mean pooling或额外可学习MLP；序列图像/文本的key同样L2归一化。
- 图像为数值、一阶差分 `x[t]-x[t-1]`、两步差分 `x[t]-x[t-2]` 的RGB叠图。最后一个不是 `x[t]-2*x[t-1]+x[t-2]` 二阶导差分。差分在整段历史上先算，再切patch；无效点不连线。
- 文本是统计模板，不调用LLM；CLIP ViT-B/32 标准tokenizer最多77 token，原有截断行为保留，没有擅自改变文本编码。
- V11权重是每来源一个三维向量（image、text、TS），由该来源的不同Query任务长度误差汇总而来，不是每个H单独一个权重；余弦softmax温度由来源内相似度标准差决定，和权重softmax温度1.0不同。
- 若校准完全无有效Query，原V11会输出均匀权重并明确写入fallback。整理版保留这个历史行为，验证报告会列出这些来源，训练前应人工检查。

## 4. 输出格式与训练衔接

```text
output/
  generation_config.json           # 仅旧版Python总入口生成
  source_registry.json
  sources/<sha1(source_id)前16位>/
    bank_arrays.npz
    records.jsonl
    source.json
    source_weight.json             # 仅为旧格式占位，不是最终校准权重
    mined_candidates.npz           # 仅为旧格式占位，不用于V11训练
    .complete
    internal_patch_tokens.zarr/
    .internal_patch_tokens_complete
  calibration_v11/<source_slug>.npz # 最终V11候选、权重、Query索引
  calibration_v11/<source_slug>.json
  logs/
```

`bank_arrays.npz` 核心字段：

| 字段 | 形状 | 含义 |
| --- | --- | --- |
| history_values / history_valid_mask | N×8192 | 历史数值及有效mask |
| future_values / future_valid_mask | N×192 | 合法训练未来及有效mask |
| image_token / text_token | N×512 | scaled-fp16序列特征，需乘各自scale恢复 |
| timeseries_token | N×1024 | scaled-fp16 TS特征，需乘timeseries_scale恢复 |
| image_key / text_key | N×512 | L2归一化检索key，存float16 |
| timeseries_key | N×1024 | L2归一化TS检索key，存float16 |

Patch Zarr保存 `image_global_fp16/text_global_fp16 [N,256,512]`、`image_scale/text_scale [N,256,1]`、`padding_patch_mask [N,256]`；恢复特征需使用 `token.astype(float32)*scale`，不要再次做L2归一化后送入内源融合。

最终校准NPZ字段包括 `candidate_ids [N,24]`（-1表示空位）、`weights [3]`、`temperature [3]`、`eligible_query_ids`、`per_query_mse [N,3]`。训练器应使用这个文件和patch Zarr，不要使用bank根部的占位均匀权重。数据布局保持原207 V11 sampler需要的命名；此包不包含外源训练器或旧版本候选缓存。

## 5. 断点续跑与可复现性

合并版 `start_generator.sh` 将模型路径记入来源清单的 `model_inputs`，重跑时第一步会检查模型路径、输入根目录、数量和seed；不覆盖已有清单。独立阶段SH由使用者保持输入一致。两种方式均允许调整卡数、worker和batch；不要在同一输出中更换数据/模型、seed或每来源数量，也不要同时对同一output启动两个生成器。失败的临时目录保留以便排查，不自动删除已有目录或覆盖未完成的正式输出。

整理版变更仅涉及路径、torchrun rank映射、参数化、错误检查/失败退出和安全临时目录；核心采样/编码/权重算法保留。删掉未调用的旧oracle候选挖掘函数及旧训练/监控启动链。`reference/` 保存207原来源清单、readiness和原文件哈希；新机器实际发现的来源数取决于安装的数据，来源不足容量时不会用重复起点强行填满2000。

207原readiness快照：207来源（Pretrain152、GIFT-Eval55），399,620条样本，历史中位数6439点，117,672条达到8192点；它是原数据集快照，不是对本次新生成数据的承诺。

## 6. 小规模CPU检查

```bash
CUDA_VISIBLE_DEVICES='' python tests/test_cpu.py
```

只测试模板/渲染函数一致性、固定种子采样、官方训练后缀排除、合成数据V11校准，不加载大模型、不启动GPU或完整生成。
