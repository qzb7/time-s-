"""NumPy-only structural and sampling checks, suitable for a laptop without torch."""
import ast
from collections import OrderedDict
import hashlib
import json
import math
from pathlib import Path
import random
import subprocess
import sys
import os
import tempfile
import unittest
from types import SimpleNamespace
import numpy as np

ROOT=Path(__file__).resolve().parents[1]


def functions(path, names, env):
    tree=ast.parse(path.read_text())
    selected=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in names]
    exec(compile(ast.Module(body=selected,type_ignores=[]),str(path),'exec'),env)
    return env


class LocalChecks(unittest.TestCase):
    def test_merged_shell_order_forwarding_and_failure(self):
        import shlex
        args=['--pretrain-root','/data/pre train','--gifteval-root','/data/gift',
              '--ts-checkpoint','/models/ts','--clip-checkpoint','/models/clip.pt',
              '--output','/data/out put','--nproc-per-node','2']
        command=['bash',str(ROOT/'start_generator.sh')]+args
        subprocess.run(['bash','-n',str(ROOT/'start_generator.sh')],check=True)
        env=os.environ.copy();env.pop('WORLD_SIZE',None)
        run=subprocess.run(command+['--dry-run'],env=env,text=True,capture_output=True,check=True)
        lines=[shlex.split(s) for s in run.stdout.splitlines()]
        self.assertEqual(len(lines),5)
        names=['prepare_registry.py','generate_bank.py','generate_patch_tokens.py','calibrate_weights.py','validate_data.py']
        for tokens,name in zip(lines,names):
            self.assertTrue(any(t.endswith('/'+name) for t in tokens))
        self.assertIn('/data/pre train',lines[0])
        self.assertIn('/data/out put',lines[-1])
        with tempfile.TemporaryDirectory(prefix='qiyaom-merged-sh-') as tmp:
            stub=Path(tmp)/'python';log=Path(tmp)/'calls.jsonl'
            stub.write_text('#!'+sys.executable+'\n'
                'import os,sys,json\n'
                'with open(os.environ["CAPTURE_LOG"],"a") as f:f.write(json.dumps(sys.argv[1:])+"\\n")\n'
                'if os.environ.get("FAIL_STAGE") and any(a.endswith(os.environ["FAIL_STAGE"]) for a in sys.argv[1:]):sys.exit(9)\n')
            stub.chmod(0o755)
            env.update(PATH=tmp+os.pathsep+env.get('PATH',''),CAPTURE_LOG=str(log))
            subprocess.run(command,env=env,check=True,capture_output=True)
            calls=[json.loads(s) for s in log.read_text().splitlines()]
            self.assertEqual(len(calls),5)
            for tokens,name in zip(calls,names):self.assertTrue(any(t.endswith('/'+name) for t in tokens))
            env['FAIL_STAGE']='generate_patch_tokens.py'
            before=len(calls)
            run=subprocess.run(command,env=env,capture_output=True)
            self.assertEqual(run.returncode,9)
            self.assertEqual(len(log.read_text().splitlines())-before,3)
        invalid=subprocess.run(command+['--unknown'],env=env,capture_output=True)
        self.assertEqual(invalid.returncode,2)

    def test_resume_registry_guards(self):
        namespace=functions(ROOT/'prepare_registry.py',{'check_resume'},dict(json=json,Path=Path))
        with tempfile.TemporaryDirectory(prefix='qiyaom-registry-') as tmp:
            root=Path(tmp);reg=root/'source_registry.json'
            args=SimpleNamespace(pretrain_root=str(root/'pre'),gifteval_root=str(root/'gift'),
                                 cases_per_source=2000,seed=260918,ts_checkpoint=str(root/'ts'),clip_checkpoint=str(root/'clip.pt'))
            saved={'seed':args.seed,'sources':[{'corpus':'pretrain','dataset_relpath':'demo',
                    'dataset_path':str(root/'pre/demo'),'quota':2000}],
                    'model_inputs':{'ts_checkpoint':args.ts_checkpoint,'clip_checkpoint':args.clip_checkpoint}}
            reg.write_text(json.dumps(saved))
            namespace['check_resume'](reg,args)
            args.seed+=1
            with self.assertRaises(ValueError):namespace['check_resume'](reg,args)
            args.seed-=1;args.ts_checkpoint=str(root/'different-model')
            with self.assertRaises(ValueError):namespace['check_resume'](reg,args)

    def test_simple_shell_forwarding(self):
        gpu_stages={'generate_bank','generate_patch_tokens','calibrate_weights'}
        stages=['prepare_registry','generate_bank','generate_patch_tokens','calibrate_weights','validate_data']
        with tempfile.TemporaryDirectory(prefix='qiyaom-sh-test-') as temporary:
            stub=Path(temporary)/'python'
            stub.write_text('#!/bin/sh\nprintf "%s\\n" "$@"\n')
            stub.chmod(0o755)
            env=os.environ.copy()
            env['PATH']=temporary+os.pathsep+env.get('PATH','')
            env['NPROC_PER_NODE']='2'
            for stage in stages:
                subprocess.run(['bash','-n',str(ROOT/(stage+'.sh'))],check=True)
                run=subprocess.run(['bash',str(ROOT/(stage+'.sh')),'--root','/data/path with spaces'],
                    cwd=ROOT,env=env,text=True,capture_output=True,check=True)
                args=run.stdout.splitlines()
                self.assertEqual(args[-3:],[stage+'.py','--root','/data/path with spaces'])
                if stage in gpu_stages:
                    self.assertEqual(args[:4],['-m','torch.distributed.run','--standalone','--nproc_per_node=2'])
            env.pop('NPROC_PER_NODE')
            run=subprocess.run(['bash',str(ROOT/'generate_bank.sh'),'--help'],
                cwd=ROOT,env=env,text=True,capture_output=True,check=True)
            self.assertIn('--nproc_per_node=1',run.stdout)

    def test_all_python_syntax(self):
        for path in ROOT.rglob('*.py'):
            ast.parse(path.read_text(),filename=str(path))

    def test_exact_extracted_helpers(self):
        signatures=json.loads((ROOT/'reference/extracted_function_sha256.json').read_text())
        for module,expected in signatures.items():
            text=(ROOT/'vendor'/(module+'.py')).read_text();lines=text.splitlines(keepends=True)
            found={}
            for node in ast.parse(text).body:
                if isinstance(node,ast.FunctionDef):
                    found[node.name]=hashlib.sha256(''.join(lines[node.lineno-1:node.end_lineno]).encode()).hexdigest()
            for name,digest in expected.items():self.assertEqual(found[name],digest)

    def test_sampler_bounds_determinism_and_missing(self):
        namespace=dict(np=np,OrderedDict=OrderedDict,hashlib=hashlib,math=math,random=random)
        functions(ROOT/'generate_bank.py',{'slug','fp','valid_target','target_channels','build_cases'},namespace)
        raw=np.arange(11000,dtype=np.float32)
        raw[100]=np.nan
        series=[raw.copy(),raw*.5+3,raw*2-1]
        def load_series(source,gift_root,quota,terms):
            getter=lambda i:{'target':series[i]}
            return series,getter,[(i,0,len(v)) for i,v in enumerate(series)],32
        namespace['load_series']=load_series
        source=dict(source_id='pretrain/synthetic/D',corpus='pretrain',dataset_name='synthetic',frequency='D',quota=25)
        arrays,records,status=namespace['build_cases'](source,'unused',260918,{})
        repeated,records2,_=namespace['build_cases'](source,'unused',260918,{})
        self.assertEqual(records,records2)
        self.assertEqual(status,'complete')
        self.assertEqual(arrays['history_values'].shape,(25,8192))
        self.assertEqual(arrays['future_values'].shape,(25,192))
        for key,v in arrays.items():
            self.assertTrue(np.isfinite(v).all())
            np.testing.assert_array_equal(v,repeated[key])
        self.assertEqual(len(set((r['row_id'],r['channel_id'],r['forecast_cutoff']) for r in records)),25)
        for i,r in enumerate(records):
            cut=r['forecast_cutoff'];length=r['lookback_length'];av=r['available_future_length']
            original=series[r['row_id']]
            self.assertLessEqual(cut+av,len(original))
            self.assertLessEqual(r['prediction_length'],av)
            np.testing.assert_array_equal(arrays['history_values'][i,-length:],np.nan_to_num(original[cut-length:cut]))
            np.testing.assert_array_equal(arrays['future_values'][i,:av],np.nan_to_num(original[cut:cut+av]))

    def test_patch_differences_and_scaling(self):
        namespace=functions(ROOT/'vendor/patch_helpers.py',{'_compute_differences','_scaled_fp16'},dict(np=np))
        x=np.array([[1,4,9,16]],np.float32)
        a,b=namespace['_compute_differences'](x,np.ones_like(x,bool))
        np.testing.assert_array_equal(a[0,1:],[3,5,7])
        np.testing.assert_array_equal(b[0,2:],[8,12])
        x=np.random.default_rng(7).normal(size=(3,256,512)).astype(np.float32)
        q,s=namespace['_scaled_fp16'](x)
        np.testing.assert_allclose(q.astype(np.float32)*s,x,atol=.002)

    def test_dry_run_does_not_need_torch(self):
        completed=subprocess.run([sys.executable,str(ROOT/'run_generator.py'),
            '--pretrain-root','/data/pretrain','--gifteval-root','/data/gift',
            '--ts-checkpoint','/models/ts','--clip-checkpoint','/models/clip.pt',
            '--output','/data/output','--nproc-per-node','2','--dry-run'],
            capture_output=True,text=True,check=True)
        self.assertEqual(len(completed.stdout.splitlines()),5)
        self.assertIn('torch.distributed.run',completed.stdout)


if __name__=='__main__':unittest.main(verbosity=2)
