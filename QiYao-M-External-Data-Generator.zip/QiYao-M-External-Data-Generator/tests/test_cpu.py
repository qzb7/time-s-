"""Small synthetic CPU checks. No GPU, pretrained weights, or formal data job."""
import ast
import hashlib
import json
from pathlib import Path
import sys
import tempfile
import unittest

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import bootstrap
import numpy as np
import torch
torch.set_num_threads(1)
from datasets import Dataset
import generate_bank as gen
from calibrate_weights import calibrate_source
import patch_helpers
import rendering


class CPUChecks(unittest.TestCase):
    def test_extracted_functions_unchanged(self):
        expected=json.loads((ROOT/'reference/extracted_function_sha256.json').read_text())
        for mod in ['rendering','patch_helpers']:
            path=ROOT/'vendor'/(mod+'.py')
            text=path.read_text();lines=text.splitlines(keepends=True)
            for node in ast.parse(text).body:
                if isinstance(node,ast.FunctionDef) and node.name in expected[mod]:
                    content=''.join(lines[node.lineno-1:node.end_lineno])
                    self.assertEqual(hashlib.sha256(content.encode()).hexdigest(),expected[mod][node.name])

    def test_differences_and_scaled_fp16(self):
        x=np.array([[1,4,9,16]],np.float32);mask=np.ones_like(x,bool)
        a,b=rendering.compute_differences(x,mask)
        np.testing.assert_array_equal(a[0,1:],[3,5,7])
        np.testing.assert_array_equal(b[0,2:],[8,12]) # lag-two difference, not second derivative
        y=np.random.default_rng(1).normal(size=(2,3,512)).astype(np.float32)
        q,s=patch_helpers._scaled_fp16(y)
        np.testing.assert_allclose(q.astype(np.float32)*s,y,atol=.002)

    def test_renderer_and_patch_text(self):
        x=np.arange(32,dtype=np.float32)[None];mask=np.ones_like(x,bool)
        a,b=rendering.compute_differences(x,mask)
        image=rendering.render_rgb_overlay(*[torch.from_numpy(v) for v in [x,mask,a,b]])
        self.assertEqual(tuple(image.shape),(1,3,224,224))
        self.assertEqual(image.dtype,torch.uint8)
        padded=np.zeros(8192,np.float32);padded[-32:]=x[0]
        valid=np.zeros(8192,bool);valid[-32:]=True
        desc,flags=patch_helpers._describe_row_worker((padded,valid,32,32))
        self.assertEqual(len(desc),256)
        self.assertEqual(int(flags.sum()),255)

    def test_training_windows_and_v11(self):
        with tempfile.TemporaryDirectory(prefix='qiyaom-generator-cpu-') as tmp:
            root=Path(tmp)
            pre=root/'pre';pre.mkdir()
            series=[(np.arange(10000,dtype=np.float32)*.01+10+i+np.sin(np.arange(10000)*.08)).tolist() for i in range(5)]
            Dataset.from_dict({'target':series,'freq':['D']*5}).save_to_disk(str(pre/'demo'))
            source=dict(corpus='pretrain',frequency='D',dataset_name='demo',
                        dataset_path=str(pre/'demo'),dataset_relpath='demo',source_id='pretrain/demo/D',quota=12)
            arrays,records,status=gen.build_cases(source,str(root),260918,{})
            arrays2,records2,status2=gen.build_cases(source,str(root),260918,{})
            self.assertEqual(records,records2)
            self.assertEqual(status,'complete')
            np.testing.assert_array_equal(arrays['history_values'],arrays2['history_values'])
            self.assertEqual(arrays['history_values'].shape,(12,8192))
            self.assertEqual(arrays['future_values'].shape,(12,192))
            self.assertEqual(len(set((r['row_id'],r['channel_id'],r['forecast_cutoff']) for r in records)),12)
            for r in records:
                self.assertLessEqual(r['forecast_cutoff']+r['available_future_length'],r['raw_series_length'])
                self.assertLessEqual(r['prediction_length'],r['available_future_length'])
            # Prove official GIFT-Eval train prefix excludes its held-out suffix.
            gift=root/'gift';gift.mkdir()
            Dataset.from_dict({'target':[list(range(100))],'freq':['A'],'start':[np.datetime64('1900-01-01')],
                               'item_id':['demo']}).save_to_disk(str(gift/'m4_yearly'))
            gs=dict(corpus='gifteval',frequency='A',dataset_name='m4_yearly',
                    dataset_path=str(gift/'m4_yearly'),dataset_relpath='m4_yearly',source_id='gifteval/m4_yearly/A',quota=3)
            ga,gr,_=gen.build_cases(gs,str(gift),260918,{'m4_yearly':'short'})
            self.assertTrue(all(r['raw_series_length']==88 for r in gr))
            self.assertTrue(all(r['forecast_cutoff']+r['available_future_length']<=88 for r in gr))
            # V11 calibration on synthetic training labels only.
            rng=np.random.default_rng(4)
            for name,d in [('image_key',512),('text_key',512),('timeseries_key',1024)]:
                v=rng.normal(size=(12,d)).astype(np.float32)
                arrays[name]=v/np.linalg.norm(v,axis=-1,keepdims=True)
            bank=root/'bank';bank.mkdir()
            np.savez(bank/'bank_arrays.npz',**arrays)
            (bank/'records.jsonl').write_text(''.join(json.dumps(r)+'\n' for r in records))
            calibrated,report=calibrate_source(bank,torch.device('cpu'))
            self.assertEqual(calibrated['candidate_ids'].shape,(12,24))
            self.assertTrue(np.isfinite(calibrated['weights']).all())
            self.assertAlmostEqual(float(calibrated['weights'].sum()),1.,places=5)
            self.assertGreater(report['calibration_queries'],0)
            self.assertEqual(report['weight_temperature'],1.)
            self.assertFalse((calibrated['candidate_ids']==np.arange(12)[:,None]).any())


if __name__=='__main__':
    unittest.main(verbosity=2)
