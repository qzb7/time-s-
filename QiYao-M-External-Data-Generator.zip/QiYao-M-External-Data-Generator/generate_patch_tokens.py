#!/usr/bin/env python3
"""Add TIME-200k-compatible patch-level image/text tokens to RAG query banks."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import sys
import time
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

import numpy as np
import torch
import zarr
from numcodecs import Blosc

from bootstrap import rank_info, new_work_directory, resolve_device
from patch_helpers import (
    _compute_differences,
    _describe_row_worker,
    _scaled_fp16,
)
from rendering import render_rgb_overlay


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--rank", type=int)
    p.add_argument("--world", type=int)
    p.add_argument("--root", required=True)
    p.add_argument("--clip-checkpoint", required=True)
    p.add_argument("--sample-batch", type=int, default=64)
    p.add_argument("--clip-batch", type=int, default=16384)
    p.add_argument("--workers", type=int, default=16)
    p.add_argument("--write-chunk", type=int, default=8)
    p.add_argument("--device", default="auto", choices=["auto", "cuda", "npu", "cpu"])
    return p.parse_args()


def slug(source_id: str) -> str:
    return hashlib.sha1(source_id.encode()).hexdigest()[:16]


def initialize_store(path: Path, n: int, chunk: int):
    group = zarr.open_group(str(path), mode="w")
    compressor = Blosc(cname="zstd", clevel=5, shuffle=Blosc.BITSHUFFLE)
    specs = {
        "image_global_fp16": ((n, 256, 512), "f2"),
        "image_scale": ((n, 256, 1), "f4"),
        "text_global_fp16": ((n, 256, 512), "f2"),
        "text_scale": ((n, 256, 1), "f4"),
        "padding_patch_mask": ((n, 256), "u1"),
    }
    for name, (shape, dtype) in specs.items():
        group.create_dataset(
            name, shape=shape, chunks=(min(chunk, n),) + shape[1:],
            dtype=dtype, compressor=compressor, overwrite=True,
        )
    group.attrs.update({
        "format": "rag_query_internal_patch_tokens_v1",
        "reference_protocol": "207 patch-token encoding protocol; actual input is this training bank",
        "patch_size": 32,
        "patch_count": 256,
        "image_renderer": "rgb_overlay_raw_independent_diff_shared_q01_q99_v1",
        "image_renderer_function": "rewrite_zarr_image_tokens_rgb.render_rgb_overlay",
        "text_template": "toto2_stats_template.describe_patch",
        "clip_model": "ViT-B-32",
        "clip_checkpoint": "recorded_per_store_at_runtime",
        "token_dtype": "float16",
        "scale_dtype": "float32",
        "token_scale_axis": "per_patch_max_abs",
        "query_order": "identical_to_bank_arrays_and_records_jsonl",
    })
    return group


def main():
    args = parse_args()
    # Start CPU workers before CUDA initialization, matching the proven TIME
    # generator and avoiding fork-after-CUDA failures.
    import multiprocessing as mp
    args.rank, args.world, local = rank_info(args.rank, args.world)
    if min(args.workers,args.sample_batch,args.clip_batch,args.write_chunk) < 1:
        raise ValueError("workers and batch/chunk sizes must be positive")
    executor = ProcessPoolExecutor(max_workers=args.workers, mp_context=mp.get_context('spawn'))
    list(executor.map(int, range(args.workers)))
    device, _backend = resolve_device(local, args.device)
    import open_clip

    clip, _, _ = open_clip.create_model_and_transforms(
        "ViT-B-32", pretrained=args.clip_checkpoint, device=device
    )
    clip.eval()
    tokenizer = open_clip.get_tokenizer("ViT-B-32")
    clip_mean = torch.tensor((0.48145466, 0.4578275, 0.40821073), device=device).view(1, 3, 1, 1)
    clip_std = torch.tensor((0.26862954, 0.26130258, 0.27577711), device=device).view(1, 3, 1, 1)

    root = Path(args.root)
    registry = json.loads((root / "source_registry.json").read_text())["sources"]
    assigned = [source for index, source in enumerate(registry) if index % args.world == args.rank]
    log_path = root / "logs" / f"patch-token-rank-{args.rank:02d}.jsonl"
    padding_image_feature = None
    padding_text_cache: dict[str, np.ndarray] = {}

    log_path.parent.mkdir(parents=True,exist_ok=True)
    failures=[]
    for source_pos, source in enumerate(assigned):
        source_dir = root / "sources" / slug(source["source_id"])
        complete = source_dir / ".internal_patch_tokens_complete"
        if complete.exists():
            continue
        started = time.time()
        if not (source_dir / '.complete').is_file():
            raise RuntimeError(f"Bank generation incomplete: {source_dir}")
        final = source_dir / "internal_patch_tokens.zarr"
        if final.exists():
            raise FileExistsError(f"Incomplete patch output exists; inspect before retry: {final}")
        tmp = new_work_directory(source_dir, 'internal_patch_tokens.zarr')
        try:
            bank_file = np.load(source_dir / "bank_arrays.npz")
            values = bank_file["history_values"].astype(np.float32)
            masks = bank_file["history_valid_mask"].astype(bool)
            records = [json.loads(line) for line in (source_dir / "records.jsonl").read_text().splitlines()]
            lengths = np.asarray([int(row["lookback_length"]) for row in records], dtype=np.int64)
            n = len(values)
            if len(masks) != n or len(lengths) != n:
                raise RuntimeError(f"row mismatch values={n} masks={len(masks)} records={len(lengths)}")
            group = initialize_store(tmp, n, args.write_chunk)
            group.attrs['clip_checkpoint'] = str(Path(args.clip_checkpoint).resolve())

            for left in range(0, n, args.sample_batch):
                right = min(n, left + args.sample_batch)
                rows = values[left:right]
                row_masks = masks[left:right]
                row_lengths = lengths[left:right]
                padding = np.arange(8192)[None] < (8192 - row_lengths)[:, None]
                futures = [
                    executor.submit(_describe_row_worker, (row, mask, int(length), 32))
                    for row, mask, length in zip(rows, row_masks, row_lengths)
                ]
                description_results = [future.result() for future in futures]
                descriptions = [description for result in description_results for description in result[0]]
                padding_text_flags = np.concatenate([result[1] for result in description_results])

                diff1, diff2 = _compute_differences(rows, row_masks)
                patches = rows.reshape(-1, 32)
                valid_patches = (row_masks & ~padding & np.isfinite(rows)).reshape(-1, 32)
                diff1_patches = diff1.reshape(-1, 32)
                diff2_patches = diff2.reshape(-1, 32)
                full_padding = padding.reshape(-1, 32).all(-1)
                image_features = np.empty((len(patches), 512), np.float32)

                with torch.inference_mode():
                    encode_indices = np.flatnonzero(~full_padding)
                    if padding_image_feature is None and full_padding.any():
                        encode_indices = np.concatenate([encode_indices, np.flatnonzero(full_padding)[:1]])
                    for offset in range(0, len(encode_indices), args.clip_batch):
                        indices = encode_indices[offset:offset + args.clip_batch]
                        raw = torch.from_numpy(patches[indices]).to(device, non_blocking=True)
                        valid = torch.from_numpy(valid_patches[indices]).to(device, non_blocking=True)
                        d1 = torch.from_numpy(diff1_patches[indices]).to(device, non_blocking=True)
                        d2 = torch.from_numpy(diff2_patches[indices]).to(device, non_blocking=True)
                        images = render_rgb_overlay(raw, valid, d1, d2).float().div_(255.0)
                        encoded = clip.encode_image((images - clip_mean) / clip_std).float().cpu().numpy()
                        image_features[indices] = encoded
                        if padding_image_feature is None:
                            for idx, feature in zip(indices, encoded):
                                if full_padding[idx]:
                                    padding_image_feature = feature.copy()
                                    break
                    if padding_image_feature is not None:
                        image_features[full_padding] = padding_image_feature

                    unique_text, inverse = np.unique(np.asarray(descriptions, dtype=object), return_inverse=True)
                    unique_features = np.empty((len(unique_text), 512), np.float32)
                    encode_text_indices = []
                    for idx, description in enumerate(unique_text):
                        is_padding = bool(np.any(padding_text_flags[inverse == idx]))
                        cached = padding_text_cache.get(str(description)) if is_padding else None
                        if cached is None:
                            encode_text_indices.append(idx)
                        else:
                            unique_features[idx] = cached
                    for offset in range(0, len(encode_text_indices), args.clip_batch):
                        indices = encode_text_indices[offset:offset + args.clip_batch]
                        tokenized = tokenizer([str(unique_text[idx]) for idx in indices]).to(device, non_blocking=True)
                        encoded = clip.encode_text(tokenized).float().cpu().numpy()
                        unique_features[indices] = encoded
                        for idx, feature in zip(indices, encoded):
                            if bool(np.any(padding_text_flags[inverse == idx])):
                                padding_text_cache[str(unique_text[idx])] = feature.copy()
                    text_features = unique_features[inverse]

                batch_n = right - left
                image_features = image_features.reshape(batch_n, 256, 512)
                text_features = text_features.reshape(batch_n, 256, 512)
                image16, image_scale = _scaled_fp16(image_features)
                text16, text_scale = _scaled_fp16(text_features)
                group["image_global_fp16"][left:right] = image16
                group["image_scale"][left:right] = image_scale
                group["text_global_fp16"][left:right] = text16
                group["text_scale"][left:right] = text_scale
                group["padding_patch_mask"][left:right] = full_padding.reshape(batch_n, 256).astype(np.uint8)

            group.attrs["written_count"] = n
            group.attrs["source_id"] = source["source_id"]
            os.rename(tmp, final)
            complete.write_text("ok\n")
            event = {"status": "complete", "rank": args.rank, "source_id": source["source_id"],
                     "cases": n, "elapsed": time.time() - started,
                     "assigned_progress": f"{source_pos + 1}/{len(assigned)}"}
        except Exception as exc:
            failures.append(source['source_id'])
            import traceback
            event = {"status": "error", "rank": args.rank, "source_id": source["source_id"],
                     "error": repr(exc), "traceback": traceback.format_exc(),
                     "elapsed": time.time() - started}
        with log_path.open("a") as handle:
            handle.write(json.dumps(event) + "\n")
        print(json.dumps(event), flush=True)
    executor.shutdown(wait=True)
    if failures:
        raise RuntimeError(f"{len(failures)} source(s) failed; see {log_path}")


if __name__ == "__main__":
    main()
