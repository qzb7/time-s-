#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import random
import sys
import time
import traceback
from collections import OrderedDict
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
import multiprocessing as mp

CPU_POOL = None

def describe_cpu(item):
    vals,mask,length=item
    return describe_sequence(vals,mask,original_length=length,crop='window')[0]

def prepare_cpu(source,gift_root,seed,terms):
    started=time.time()
    result=build_cases(source,gift_root,seed,terms)
    print(json.dumps(dict(event='cpu_source_prepared',source=source['source_id'],seconds=time.time()-started)),flush=True)
    return result

import numpy as np
import torch
from datasets import load_from_disk

from bootstrap import ROOT as HERE, rank_info, new_work_directory, resolve_device, device_util

from sequence_text_template import describe_sequence
from rendering import (CLIP_MEAN, CLIP_STD, compute_differences,
                                            render_rgb_overlay, scaled_fp16)
from toto2 import Toto2Model


def slug(source_id: str) -> str:
    return hashlib.sha1(source_id.encode()).hexdigest()[:16]


def fp(values: np.ndarray, mask: np.ndarray) -> str:
    x = np.nan_to_num(values[mask], nan=0.0).astype(np.float32)
    return hashlib.sha1(x.tobytes()).hexdigest()


def target_channels(target) -> list[np.ndarray]:
    x = np.asarray(target, dtype=np.float32)
    if x.ndim == 1:
        return [x]
    if x.ndim == 2:
        return [x[i] for i in range(x.shape[0])]
    return []


def valid_target(x: np.ndarray) -> np.ndarray:
    x = np.asarray(x, dtype=np.float32).reshape(-1)
    x[~np.isfinite(x)] = np.nan
    return x


def evenly_spaced_indices(n: int, count: int) -> list[int]:
    if n <= count:
        return list(range(n))
    return sorted(set(np.linspace(0, n - 1, count).round().astype(int).tolist()))


def load_gifteval_terms(config_path: str) -> dict[str, str]:
    """Map each official GIFTEval dataset path to its longest available term."""
    priority = {"short": 0, "medium": 1, "long": 2}
    result: dict[str, str] = {}
    try:
        import yaml
        config = yaml.safe_load(Path(config_path).read_text())

        def visit(node):
            if isinstance(node, dict):
                name, term = node.get("name"), node.get("term")
                if isinstance(name, str) and term in priority:
                    key = name.strip().lower()
                    if key not in result or priority[term] > priority[result[key]]:
                        result[key] = term
                for value in node.values():
                    visit(value)
            elif isinstance(node, list):
                for value in node:
                    visit(value)

        visit(config)
    except Exception as exc:
        raise ValueError(f"Cannot load official GIFT-Eval task configuration: {config_path}") from exc
    if not result:
        raise ValueError("Empty GIFT-Eval task configuration")
    return result


def load_series(source: dict, gift_root: str, quota: int, gifteval_terms: dict[str, str]):
    corpus = source["corpus"]
    freq = source["frequency"]
    descriptors = []
    fallback_descriptors = []
    records = None
    if corpus == "gifteval":
        os.environ["GIFT_EVAL"] = gift_root
        from gift_eval.data import Dataset
        # Not every official dataset exposes medium/long. Forcing `long` makes
        # GIFT-Eval assert while constructing those splits. Use the longest
        # term that actually exists for this dataset; fall back to universal
        # `short` when the configuration cannot be resolved.
        name = source["dataset_relpath"].strip().lower()
        if name not in gifteval_terms:
            raise ValueError(f"No official training split setting for {name}")
        term = gifteval_terms[name]
        source["gifteval_training_term"] = term
        gd = Dataset(name=source["dataset_relpath"], term=term, to_univariate=False)
        records = list(gd.training_dataset)
        indices = list(range(len(records)))
        getter = lambda i: records[i]
    else:
        # Avoid materializing long Arrow sequences as Python float lists.
        records = load_from_disk(source["dataset_path"]).with_format('numpy')
        indices = evenly_spaced_indices(len(records), max(1024, min(len(records), quota * 2)))
        getter = lambda i: records[int(i)]
    for row_idx in indices:
        row = getter(row_idx)
        row_freq = str(row.get("freq", freq)).upper().replace("1H", "H").replace("1D", "D")
        if corpus == "pretrain" and row_freq != freq:
            continue
        channels = target_channels(row["target"])
        for channel_idx, values in enumerate(channels):
            values = valid_target(values)
            if len(values) >= 38 and np.isfinite(values).sum() >= 32:
                descriptors.append((int(row_idx), int(channel_idx), int(len(values))))
            if len(values) >= 12 and np.isfinite(values).sum() >= 8:
                fallback_descriptors.append((int(row_idx), int(channel_idx), int(len(values))))
    # A few monthly/weekly sources contain only 27 training points. They still
    # support a valid 6-step future, but cannot satisfy the normal 32-point
    # history floor. Use short-context generation only when the entire source
    # would otherwise be empty.
    if descriptors:
        return records, getter, descriptors, 32
    return records, getter, fallback_descriptors, 6


def build_cases(source: dict, gift_root: str, seed: int, gifteval_terms: dict[str, str]):
    quota = int(source["quota"])
    records, getter, desc, min_history = load_series(source, gift_root, quota, gifteval_terms)
    if not desc:
        return None, [], "no_eligible_series"
    rng = random.Random(seed ^ int(slug(source["source_id"]), 16))
    rng.shuffle(desc)
    cache: OrderedDict[tuple[int, int], np.ndarray] = OrderedDict()

    def series(row_idx, channel_idx):
        key = (row_idx, channel_idx)
        if key in cache:
            cache.move_to_end(key)
            return cache[key]
        x = valid_target(target_channels(getter(row_idx)["target"])[channel_idx])
        cache[key] = x
        if len(cache) > 32:
            cache.popitem(last=False)
        return x

    history = []
    hmask = []
    future = []
    fmask = []
    metadata = []
    seen = set()
    attempts = 0
    per_series_round: dict[tuple[int, int], int] = {}
    while len(history) < quota and attempts < quota * 50:
        row_idx, channel_idx, length = desc[attempts % len(desc)]
        attempts += 1
        key = (row_idx, channel_idx)
        round_idx = per_series_round.get(key, 0)
        per_series_round[key] = round_idx + 1
        x = series(row_idx, channel_idx)
        band = len(history) % 3
        lo, hi = ((6, 32), (33, 96), (97, 192))[band]
        max_h = min(192, len(x) - min_history)
        if max_h < 6:
            continue
        if max_h < lo:
            lo, hi = 6, max_h
        else:
            hi = min(hi, max_h)
        H = rng.randint(lo, hi)
        max_cut = len(x) - H
        if max_cut < min_history:
            continue
        # A stable full-range phase per series prevents the old first-5% bias.
        phase = int(hashlib.sha1(f'{seed}|{source["source_id"]}|{key}'.encode()).hexdigest()[:13],16)/float(16**13)
        frac = (phase + round_idx * 0.6180339887498948949) % 1.0
        # 80% long-context cases, 20% full-range cases. Never extend beyond train.
        long_context = rng.random() < .8
        lower = max(min_history, min(8192, int(math.ceil(.75*max_cut)))) if long_context else min_history
        cutoff = lower + int(frac * max(1, max_cut - lower + 1))
        cutoff = min(max_cut, max(min_history, cutoff))
        # Changing H alone does not create another independent bank case.
        unique = (row_idx, channel_idx, cutoff)
        if unique in seen:
            continue
        seen.add(unique)
        hs = max(0, cutoff - 8192)
        hv = x[hs:cutoff]
        hm = np.isfinite(hv)
        if hm.sum() < min(32, min_history):
            continue
        av = min(192, len(x) - cutoff)
        fv = x[cutoff:cutoff + av]
        fm = np.isfinite(fv)
        if fm.sum() == 0:
            continue
        hp = np.zeros(8192, np.float32)
        hmp = np.zeros(8192, np.uint8)
        hp[-len(hv):] = np.nan_to_num(hv, nan=0.0)
        hmp[-len(hv):] = hm
        fpv = np.zeros(192, np.float32)
        fmp = np.zeros(192, np.uint8)
        fpv[:av] = np.nan_to_num(fv, nan=0.0)
        fmp[:av] = fm
        obs = hv[hm]
        loc = float(np.median(obs))
        q25, q75 = np.percentile(obs, [25, 75])
        scale = float(max(q75 - q25, np.std(obs), 1e-6))
        case_id = hashlib.sha1(f"{source['source_id']}|{row_idx}|{channel_idx}|{cutoff}|{H}".encode()).hexdigest()
        history.append(hp); hmask.append(hmp); future.append(fpv); fmask.append(fmp)
        metadata.append({
            "case_id": case_id, "source_id": source["source_id"], "corpus": source["corpus"],
            "dataset_name": source["dataset_name"], "frequency": source["frequency"],
            "row_id": row_idx, "channel_id": channel_idx, "series_id": f"{row_idx}:{channel_idx}",
            "window_start": hs, "forecast_cutoff": cutoff, "lookback_length": len(hv),
            "prediction_length": H, "available_future_length": av,
            "sampling_version": 10, "raw_series_length": len(x),
            "long_context_draw": long_context, "cutoff_lower_bound": lower,
            "context_loc": loc, "context_scale": scale,
            "history_fingerprint": fp(hv, hm), "future_fingerprint": fp(fv, fm),
            "split": "train", "query_role": True, "bank_role": True,
        })
    if not history:
        return None, [], "capacity_zero"
    arrays = {
        "history_values": np.stack(history), "history_valid_mask": np.stack(hmask),
        "future_values": np.stack(future), "future_valid_mask": np.stack(fmask),
    }
    status = "complete" if len(history) == quota else "exhausted"
    return arrays, metadata, status


@torch.inference_mode()
def encode_modalities(arrays, metadata, clip_model, tokenizer, ts_model, device,
                      image_batch, text_batch, ts_batch):
    n = len(metadata)
    image_out = np.empty((n, 512), np.float32)
    for start in range(0, n, image_batch):
        stop = min(n, start + image_batch)
        raw_np = arrays["history_values"][start:stop]
        valid_np = arrays["history_valid_mask"][start:stop].astype(bool)
        d1_np, d2_np = compute_differences(raw_np, valid_np)
        raw = torch.from_numpy(raw_np).to(device)
        valid = torch.from_numpy(valid_np).to(device)
        d1 = torch.from_numpy(d1_np).to(device)
        d2 = torch.from_numpy(d2_np).to(device)
        images = render_rgb_overlay(raw, valid, d1, d2).float().div_(255.0)
        mean = torch.tensor(CLIP_MEAN, device=device).view(1, 3, 1, 1)
        std = torch.tensor(CLIP_STD, device=device).view(1, 3, 1, 1)
        image_out[start:stop] = clip_model.encode_image((images - mean) / std).float().cpu().numpy()

    text_jobs = []
    for i, meta in enumerate(metadata):
        L = int(meta["lookback_length"])
        vals = arrays["history_values"][i, -L:]
        mask = arrays["history_valid_mask"][i, -L:].astype(bool)
        text_jobs.append((vals,mask,L))
    texts = list(CPU_POOL.map(describe_cpu,text_jobs,chunksize=16)) if CPU_POOL is not None else [describe_cpu(x) for x in text_jobs]
    text_out = np.empty((n, 512), np.float32)
    for start in range(0, n, text_batch):
        stop = min(n, start + text_batch)
        tok = tokenizer(texts[start:stop]).to(device)
        text_out[start:stop] = clip_model.encode_text(tok).float().cpu().numpy()

    ts_out = np.empty((n, 1024), np.float32)
    patch = int(ts_model.config.patch_size)
    for start in range(0, n, ts_batch):
        stop = min(n, start + ts_batch)
        target = torch.from_numpy(arrays["history_values"][start:stop]).to(device).unsqueeze(1)
        mask = torch.from_numpy(arrays["history_valid_mask"][start:stop].astype(bool)).to(device).unsqueeze(1)
        scaled, _, _ = ts_model.scaler(target, mask)
        scaled = torch.where(mask, scaled.asinh(), torch.zeros_like(scaled))
        x = ts_model._embed_patches(scaled, mask, patch)
        group_ids = torch.zeros(x.shape[:-1], dtype=torch.long, device=device)
        empty = mask.reshape(mask.shape[0], 1, -1, patch).sum(-1) == 0
        group_ids[empty] = -1
        hidden = ts_model.transformer(x, group_ids=group_ids)
        ts_out[start:stop] = hidden[:, 0, -1].float().cpu().numpy()
    return image_out, text_out, ts_out, texts


def normalized(x):
    x = np.asarray(x, np.float32)
    return x / np.maximum(np.linalg.norm(x, axis=-1, keepdims=True), 1e-8)






def main():
    global CPU_POOL
    ap = argparse.ArgumentParser()
    ap.add_argument("--rank", type=int); ap.add_argument("--world", type=int)
    ap.add_argument("--root", required=True)
    ap.add_argument("--gift-root", required=True)
    ap.add_argument("--gift-config-yaml", default=str(HERE/'configs/gifteval_tasks.yaml'))
    ap.add_argument("--clip", required=True)
    ap.add_argument("--ts-checkpoint", required=True)
    ap.add_argument("--seed", type=int, default=None); ap.add_argument("--image-batch", type=int, default=32)
    ap.add_argument("--text-batch", type=int, default=256)
    ap.add_argument("--ts-batch", type=int, default=16)
    ap.add_argument("--workers", type=int, default=6)
    ap.add_argument("--min-free-gib", type=float, default=150)
    ap.add_argument("--device", default="auto", choices=["auto", "cuda", "npu", "cpu"])
    args = ap.parse_args(); root = Path(args.root)
    gifteval_terms = load_gifteval_terms(args.gift_config_yaml)
    args.rank, args.world, local = rank_info(args.rank, args.world)
    config = json.loads((root / "source_registry.json").read_text())
    registry = config["sources"]
    args.seed = config.get("seed", 260918) if args.seed is None else args.seed
    if args.workers < 1 or min(args.image_batch,args.text_batch,args.ts_batch) < 1 or args.min_free_gib < 0:
        ap.error("Batch sizes/workers must be positive; min-free-gib must be nonnegative")
    assigned = [s for i, s in enumerate(registry) if i % args.world == args.rank]
    assigned = [s for s in assigned if not (root/'sources'/slug(s['source_id'])/'.complete').exists()]
    if not assigned:
        print(json.dumps(dict(rank=args.rank,status='no_pending_sources')),flush=True)
        return
    # Spawn avoids inheriting any CUDA context. Two sources prepared ahead;
    # remaining CPU workers process descriptions while the GPU encodes.
    CPU_POOL=ProcessPoolExecutor(max_workers=args.workers,mp_context=mp.get_context('spawn'))
    pending={}
    def submit(pos):
        if pos<len(assigned):
            pending[pos]=CPU_POOL.submit(prepare_cpu,assigned[pos],args.gift_root,args.seed,gifteval_terms)
    submit(0);submit(1)
    device, backend = resolve_device(local, args.device)
    util = device_util(backend)
    if backend == "cuda":
        torch.cuda.set_per_process_memory_fraction(.85, device)
    import open_clip
    clip_model, _, _ = open_clip.create_model_and_transforms("ViT-B-32", pretrained=args.clip, device=device)
    clip_model.eval(); tokenizer = open_clip.get_tokenizer("ViT-B-32")
    ts_model = Toto2Model.from_pretrained(args.ts_checkpoint, map_location="cpu").to(device).eval()
    if ts_model.config.patch_size != 32 or ts_model.config.d_model != 1024:
        raise ValueError('This training-bank format requires patch_size=32 and TS dimension=1024')
    sources_root = root / "sources"; sources_root.mkdir(parents=True, exist_ok=True)
    log_path = root / "logs" / f"rank-{args.rank:02d}.jsonl"; log_path.parent.mkdir(parents=True, exist_ok=True)
    failures=[]
    for pos, source in enumerate(assigned):
        import shutil
        if shutil.disk_usage(root).free < args.min_free_gib*1024**3:
            raise RuntimeError(f'Less than {args.min_free_gib} GiB free; choose storage or lower --min-free-gib')
        sd = sources_root / slug(source["source_id"]); complete = sd / ".complete"
        if complete.exists(): continue
        if sd.exists():
            raise FileExistsError(f"Incomplete source exists; inspect it or use a new output: {sd}")
        started = time.time(); tmp = new_work_directory(sources_root, sd.name)
        try:
            future=pending.pop(pos)
            submit(pos+2)
            arrays, metadata, capacity = future.result()
            if arrays is None: raise RuntimeError(capacity)
            build_seconds=time.time()-started
            if util is not None:
                util.reset_peak_memory_stats()
            encode_started=time.time()
            image, text, ts, descriptions = encode_modalities(
                arrays, metadata, clip_model, tokenizer, ts_model, device,
                args.image_batch, args.text_batch, args.ts_batch)
            encode_seconds=time.time()-encode_started
            keys = [normalized(image), normalized(text), normalized(ts)]
            # Bootstrap schema only; final Top10->24 GRW is rebuilt by the
            # audited v5 miner AFTER patch tokens exist. Never train on this.
            mined = dict(final_top32_ids=np.full((len(metadata),32),-1,np.int32),
                         modality_weights=np.full(3,1/3,np.float32),
                         similarity_temperatures=np.ones(3,np.float32))
            image16, image_scale = scaled_fp16(image); text16, text_scale = scaled_fp16(text); ts16, ts_scale = scaled_fp16(ts)
            np.savez(tmp / "bank_arrays.npz", **arrays, image_token=image16, image_scale=image_scale,
                     text_token=text16, text_scale=text_scale, timeseries_token=ts16, timeseries_scale=ts_scale,
                     image_key=keys[0].astype(np.float16), text_key=keys[1].astype(np.float16), timeseries_key=keys[2].astype(np.float16))
            np.savez(tmp / "mined_candidates.npz", **mined)
            with (tmp / "records.jsonl").open("w") as f:
                for m, t in zip(metadata, descriptions):
                    m["text_description"] = t; f.write(json.dumps(m, ensure_ascii=False) + "\n")
            weight = {"source_id": source["source_id"], "w_image": float(mined["modality_weights"][0]),
                      "w_text": float(mined["modality_weights"][1]), "w_time": float(mined["modality_weights"][2]),
                      "tau_image": float(mined["similarity_temperatures"][0]), "tau_text": float(mined["similarity_temperatures"][1]),
                      "tau_time": float(mined["similarity_temperatures"][2]), "num_queries": len(metadata), "top_k": 32}
            weight['bootstrap_only'] = True
            weight['training_weights_file'] = 'calibration_v11/<source_slug>.npz'
            (tmp / "source_weight.json").write_text(json.dumps(weight, indent=2) + "\n")
            (tmp / "source.json").write_text(json.dumps({**source, "realized_cases": len(metadata), "capacity_status": capacity}, indent=2) + "\n")
            (tmp / ".complete").write_text("ok\n")
            os.rename(tmp, sd)
            event = {"status": "complete", "rank": args.rank, "source_id": source["source_id"], "cases": len(metadata), "elapsed": time.time()-started,
                     "build_seconds":build_seconds,"encode_seconds":encode_seconds,
                     "peak_allocated_mib": (util.max_memory_allocated() if util is not None else 0.0)/2**20,
                     "peak_reserved_mib": (util.max_memory_reserved() if util is not None else 0.0)/2**20}
        except Exception as exc:
            failures.append(source['source_id'])
            event = {"status": "error", "rank": args.rank, "source_id": source["source_id"],
                     "error": repr(exc), "traceback": traceback.format_exc(),
                     "elapsed": time.time()-started}
        with log_path.open("a") as f: f.write(json.dumps(event) + "\n")
        print(json.dumps({**event, "assigned_progress": f"{pos+1}/{len(assigned)}"}), flush=True)
    CPU_POOL.shutdown(wait=True)
    if failures:
        raise RuntimeError(f"{len(failures)} source(s) failed; see {log_path}")


if __name__ == "__main__":
    from oom_batches_v10 import protect_modalities
    encode_modalities = protect_modalities(encode_modalities)
    main()
