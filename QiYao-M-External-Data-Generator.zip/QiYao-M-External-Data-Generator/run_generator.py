"""Explicit four-stage data generation, never launches model training."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT=Path(__file__).resolve().parent


def commands(a, nproc):
    python=sys.executable
    dist=[python,'-m','torch.distributed.run','--standalone',f'--nproc_per_node={nproc}']
    return [
        [python,str(ROOT/'prepare_registry.py'),'--pretrain-root',a.pretrain_root,
         '--gifteval-root',a.gifteval_root,'--output-root',a.output,
         '--cases-per-source',str(a.cases_per_source),'--seed',str(a.seed)],
        dist+[str(ROOT/'generate_bank.py'),'--root',a.output,'--gift-root',a.gifteval_root,
              '--clip',a.clip_checkpoint,'--ts-checkpoint',a.ts_checkpoint,'--seed',str(a.seed),
              '--workers',str(a.workers),'--min-free-gib',str(a.min_free_gib),
              '--image-batch',str(a.image_batch),'--text-batch',str(a.text_batch),
              '--ts-batch',str(a.ts_batch)],
        dist+[str(ROOT/'generate_patch_tokens.py'),'--root',a.output,
              '--clip-checkpoint',a.clip_checkpoint,'--workers',str(a.workers),
              '--sample-batch',str(a.sample_batch),'--clip-batch',str(a.clip_batch)],
        dist+[str(ROOT/'calibrate_weights.py'),'--root',a.output],
        [python,str(ROOT/'validate_data.py'),'--root',a.output],
    ]


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--pretrain-root',required=True)
    p.add_argument('--gifteval-root',required=True)
    p.add_argument('--ts-checkpoint',required=True)
    p.add_argument('--clip-checkpoint',required=True)
    p.add_argument('--output',required=True)
    p.add_argument('--cases-per-source',type=int,default=2000)
    p.add_argument('--nproc-per-node',default='auto',help='Process count, not device id list; use ASCEND_RT_VISIBLE_DEVICES / CUDA_VISIBLE_DEVICES for ids')
    p.add_argument('--device',default='auto',choices=['auto','cuda','npu','cpu'],help='Device backend')
    p.add_argument('--workers',type=int,default=6,help='CPU workers per GPU process')
    p.add_argument('--seed',type=int,default=260918)
    p.add_argument('--min-free-gib',type=float,default=150)
    p.add_argument('--image-batch',type=int,default=32)
    p.add_argument('--text-batch',type=int,default=256)
    p.add_argument('--ts-batch',type=int,default=16)
    p.add_argument('--sample-batch',type=int,default=64)
    p.add_argument('--clip-batch',type=int,default=16384)
    p.add_argument('--dry-run',action='store_true',help='Only print commands; no torch import or output creation')
    a=p.parse_args()
    for key in ['pretrain_root','gifteval_root','ts_checkpoint','clip_checkpoint','output']:
        setattr(a,key,str(Path(getattr(a,key)).expanduser().resolve()))
    if min(a.cases_per_source,a.workers,a.image_batch,a.text_batch,a.ts_batch,a.sample_batch,a.clip_batch)<1 or a.min_free_gib<0:
        p.error('Batch/count/worker parameters must be positive; min-free-gib >= 0')
    if int(os.getenv('WORLD_SIZE','1'))>1:
        p.error('Do not launch this orchestrator with torchrun; it launches stage workers itself')
    if a.nproc_per_node=='auto':
        if a.dry_run:
            visible=os.getenv('ASCEND_RT_VISIBLE_DEVICES') or os.getenv('CUDA_VISIBLE_DEVICES')
            nproc=sum(bool(x.strip()) for x in visible.split(',')) if visible and visible not in ('','-1') else 'auto'
        else:
            from bootstrap import device_count
            nproc=device_count(a.device)
    else:
        try:nproc=int(a.nproc_per_node)
        except ValueError:p.error('--nproc-per-node must be auto or a positive integer (not GPU ids)')
        if nproc<1:p.error('--nproc-per-node must be positive')
    cmds=commands(a,nproc)
    if a.dry_run:
        import shlex
        for c in cmds:print(shlex.join(c))
        return
    from bootstrap import device_count
    if not 0<int(nproc)<=device_count(a.device):
        p.error('Not enough visible devices; check ASCEND_RT_VISIBLE_DEVICES / CUDA_VISIBLE_DEVICES')
    for name in ['pretrain_root','gifteval_root','ts_checkpoint']:
        if not Path(getattr(a,name)).is_dir():raise FileNotFoundError(getattr(a,name))
    if not Path(a.clip_checkpoint).is_file():raise FileNotFoundError(a.clip_checkpoint)
    ckpt=Path(a.ts_checkpoint)
    if not (ckpt/'config.json').is_file() or not any(ckpt.glob('*.safetensors')):
        p.error('TS encoder directory needs config.json and original numerical model.safetensors weights')
    out=Path(a.output)
    registry=out/'source_registry.json'
    config_path=out/'generation_config.json'
    config=vars(a).copy();config.pop('dry_run')
    # nproc and batching may change when resuming; scientific inputs must not.
    protected=['pretrain_root','gifteval_root','ts_checkpoint','clip_checkpoint','cases_per_source','seed']
    resume=registry.exists()
    if out.exists() and any(out.iterdir()) and not config_path.is_file():
        p.error('Nonempty output has no generation_config.json; choose a fresh output')
    if config_path.exists():
        old=json.loads(config_path.read_text())
        if any(old[k]!=config[k] for k in protected):
            p.error('Cannot resume with changed data/model paths, quota or seed; choose a new output')
    out.mkdir(parents=True,exist_ok=True)
    config_path.write_text(json.dumps(config,indent=2)+'\n')
    env=os.environ.copy();env.setdefault('OMP_NUM_THREADS','1')
    env.setdefault('TOKENIZERS_PARALLELISM','false')
    for i,c in enumerate(cmds):
        if i==0 and resume:continue
        subprocess.run(c,check=True,cwd=ROOT,env=env)


if __name__=='__main__':
    main()
