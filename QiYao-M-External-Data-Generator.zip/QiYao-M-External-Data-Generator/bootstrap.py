"""Resolve bundled implementation paths without depending on /home layouts."""
from pathlib import Path
import os
import sys

ROOT = Path(__file__).resolve().parent
VENDOR = ROOT / "vendor"
sys.path.insert(0, str(VENDOR))
# Spawned text workers can import the same local template modules.
os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")


def rank_info(rank=None, world=None):
    rank = int(os.getenv("RANK", "0")) if rank is None else rank
    world = int(os.getenv("WORLD_SIZE", "1")) if world is None else world
    local = int(os.getenv("LOCAL_RANK", "0"))
    if world < 1 or not 0 <= rank < world:
        raise ValueError("Require world >= 1 and 0 <= rank < world")
    return rank, world, local


def new_work_directory(parent, prefix):
    """Never erase or reuse an unresolved .tmp directory left by another run."""
    import tempfile
    return Path(tempfile.mkdtemp(prefix=prefix + ".tmp-", dir=parent))


def resolve_device(local, requested="auto"):
    """Resolve the per-rank device and backend.

    `requested` is one of 'auto' (prefer NPU, then CUDA, then CPU), 'cuda',
    'npu', or 'cpu'. Sets the current device on the selected backend and
    returns ``(device, backend)``.
    """
    import torch
    if requested == "cpu":
        return torch.device("cpu"), "cpu"
    if requested in ("npu", "auto"):
        try:
            import torch_npu
            if torch_npu.npu.is_available():
                torch_npu.npu.set_device(local)
                return torch.device("npu", local), "npu"
        except Exception:
            if requested == "npu":
                raise
    if requested in ("cuda", "auto"):
        if torch.cuda.is_available():
            torch.cuda.set_device(local)
            return torch.device("cuda", local), "cuda"
    if requested == "auto":
        return torch.device("cpu"), "cpu"
    raise RuntimeError(f"Device backend '{requested}' is not available")


def device_util(backend):
    """Return the memory/device utility module for a backend (None for cpu)."""
    if backend == "cuda":
        import torch
        return torch.cuda
    if backend == "npu":
        import torch_npu
        return torch_npu.npu
    return None


def device_count(requested="auto"):
    """Number of visible devices for the selected backend (0 for cpu)."""
    if requested == "cpu":
        return 0
    if requested in ("npu", "auto"):
        try:
            import torch_npu
            n = torch_npu.npu.device_count()
            if n:
                return n
        except Exception:
            if requested == "npu":
                raise
    if requested in ("cuda", "auto"):
        import torch
        return torch.cuda.device_count()
    return 0
