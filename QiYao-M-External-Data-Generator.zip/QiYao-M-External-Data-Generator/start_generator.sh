#!/usr/bin/env bash
set -euo pipefail

# Five explicit Python commands; no CLI or Python orchestration layer.
script_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
pretrain_root=""; gifteval_root=""; ts_checkpoint=""; clip_checkpoint=""; output=""
cases_per_source=2000; nproc="${NPROC_PER_NODE:-1}"; workers=6; seed=260918
image_batch=32; text_batch=256; ts_batch=16; sample_batch=64; clip_batch=16384
min_free_gib=150; dry_run=0; full_arrays=0; device=auto

usage() {
  echo "Usage: bash start_generator.sh --pretrain-root PATH --gifteval-root PATH"
  echo "  --ts-checkpoint PATH --clip-checkpoint FILE --output PATH [options]"
  echo "Options: --cases-per-source 2000 --nproc-per-node 1 --workers 6 --seed 260918"
  echo "  --image-batch 32 --text-batch 256 --ts-batch 16"
  echo "  --sample-batch 64 --clip-batch 16384 --min-free-gib 150"
  echo "  --device auto|cuda|npu|cpu (default auto; auto prefers NPU then CUDA)"
  echo "  --dry-run (print commands only) --full-arrays (full final validation)"
  echo "Select device ids with ASCEND_RT_VISIBLE_DEVICES (NPU) or CUDA_VISIBLE_DEVICES (GPU)."
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    -h|--help) usage; exit 0 ;;
    --dry-run) dry_run=1; shift; continue ;;
    --full-arrays) full_arrays=1; shift; continue ;;
    --pretrain-root|--gifteval-root|--ts-checkpoint|--clip-checkpoint|--output|\
    --cases-per-source|--nproc-per-node|--workers|--seed|--image-batch|--text-batch|\
    --ts-batch|--sample-batch|--clip-batch|--min-free-gib|--device)
      if [[ $# -lt 2 || "$2" == --* ]]; then
        echo "Missing value for $1" >&2; exit 2
      fi ;;
    *) echo "Unknown option: $1" >&2; usage >&2; exit 2 ;;
  esac
  case "$1" in
    --pretrain-root) pretrain_root="$2" ;;
    --gifteval-root) gifteval_root="$2" ;;
    --ts-checkpoint) ts_checkpoint="$2" ;;
    --clip-checkpoint) clip_checkpoint="$2" ;;
    --output) output="$2" ;;
    --cases-per-source) cases_per_source="$2" ;;
    --nproc-per-node) nproc="$2" ;;
    --workers) workers="$2" ;;
    --seed) seed="$2" ;;
    --image-batch) image_batch="$2" ;;
    --text-batch) text_batch="$2" ;;
    --ts-batch) ts_batch="$2" ;;
    --sample-batch) sample_batch="$2" ;;
    --clip-batch) clip_batch="$2" ;;
    --min-free-gib) min_free_gib="$2" ;;
    --device) device="$2" ;;
  esac
  shift 2
done

if [[ -z "$pretrain_root" || -z "$gifteval_root" || -z "$ts_checkpoint" || -z "$clip_checkpoint" || -z "$output" ]]; then
  echo "All five data/model/output paths are required." >&2; usage >&2; exit 2
fi
for value in "$cases_per_source" "$nproc" "$workers" "$image_batch" "$text_batch" "$ts_batch" "$sample_batch" "$clip_batch"; do
  if [[ ! "$value" =~ ^[1-9][0-9]*$ ]]; then
    echo "Counts, batches, workers and nproc-per-node must be positive integers." >&2; exit 2
  fi
done
if [[ ! "$seed" =~ ^[0-9]+$ || ! "$min_free_gib" =~ ^[0-9]+([.][0-9]+)?$ ]]; then
  echo "seed must be a nonnegative integer; min-free-gib must be nonnegative." >&2; exit 2
fi
if [[ "${WORLD_SIZE:-1}" != 1 ]]; then
  echo "Run this SH once on one node; do not wrap it in torchrun." >&2; exit 2
fi

# Keep relative user paths relative to the invoking terminal, even though Python
# entry files are resolved relative to this SH.
run() {
  if [[ "$dry_run" == 1 ]]; then
    printf '%q ' "$@"; printf '\n'
  else
    "$@"
  fi
}
export OMP_NUM_THREADS="${OMP_NUM_THREADS:-1}"
export TOKENIZERS_PARALLELISM="${TOKENIZERS_PARALLELISM:-false}"

# 1. Source registry. A matching existing registry is checked, not overwritten.
run python "$script_dir/prepare_registry.py" \
  --pretrain-root "$pretrain_root" --gifteval-root "$gifteval_root" \
  --output-root "$output" --cases-per-source "$cases_per_source" --seed "$seed" \
  --ts-checkpoint "$ts_checkpoint" --clip-checkpoint "$clip_checkpoint" --resume

# 2. Numerical bank + sequence-level TS/image/text representations.
run python -m torch.distributed.run --standalone --nproc_per_node="$nproc" \
  "$script_dir/generate_bank.py" --root "$output" --gift-root "$gifteval_root" \
  --ts-checkpoint "$ts_checkpoint" --clip "$clip_checkpoint" --seed "$seed" \
  --workers "$workers" --min-free-gib "$min_free_gib" --device "$device" \
  --image-batch "$image_batch" --text-batch "$text_batch" --ts-batch "$ts_batch"

# 3. Historical patch-level image/text features.
run python -m torch.distributed.run --standalone --nproc_per_node="$nproc" \
  "$script_dir/generate_patch_tokens.py" --root "$output" \
  --clip-checkpoint "$clip_checkpoint" --workers "$workers" \
  --sample-batch "$sample_batch" --clip-batch "$clip_batch" --device "$device"

# 4. Offline V11 weights + final candidate selection.
run python -m torch.distributed.run --standalone --nproc_per_node="$nproc" \
  "$script_dir/calibrate_weights.py" --root "$output" --device "$device"

# 5. Read-only validation.
if [[ "$full_arrays" == 1 ]]; then
  run python "$script_dir/validate_data.py" --root "$output" --full-arrays
else
  run python "$script_dir/validate_data.py" --root "$output"
fi
