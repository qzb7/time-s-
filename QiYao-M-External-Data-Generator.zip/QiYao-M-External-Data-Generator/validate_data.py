"""Read-only validation of V10 banks, patch tokens and V11 calibration files."""
import argparse
import hashlib
import json
from pathlib import Path
import numpy as np


def validate(root, full_arrays=False):
    import zarr
    root = Path(root)
    sources = json.loads((root/'source_registry.json').read_text())['sources']
    if not sources:
        raise ValueError('Empty source registry')
    total = eligible = usable = 0
    lengths = []
    fallbacks = []
    for source in sources:
        sid = source['source_id']
        slug = hashlib.sha1(sid.encode()).hexdigest()[:16]
        path = root/'sources'/slug
        for marker in ['.complete','.internal_patch_tokens_complete']:
            if not (path/marker).is_file():
                raise ValueError(f'Missing {marker}: {sid}')
        records = [json.loads(s) for s in (path/'records.jsonl').read_text().splitlines()]
        n = len(records)
        if not n or n > source['quota']:
            raise ValueError(f'Invalid bank size {n}: {sid}')
        with np.load(path/'bank_arrays.npz', allow_pickle=False) as bank:
            specs = {'history_values':(n,8192),'history_valid_mask':(n,8192),
                     'future_values':(n,192),'future_valid_mask':(n,192),
                     'image_key':(n,512),'text_key':(n,512),'timeseries_key':(n,1024)}
            for key, shape in specs.items():
                arr = bank[key]
                if arr.shape != shape or not np.isfinite(arr).all():
                    raise ValueError(f'Invalid {key}: {sid}')
            for key in ['image_key','text_key','timeseries_key']:
                if (np.linalg.norm(bank[key].astype(np.float32),axis=-1) < 1e-8).any():
                    raise ValueError(f'Zero key {key}: {sid}')
        for r in records:
            if (r['split'] != 'train' or r['sampling_version'] != 10 or
                r['forecast_cutoff']+r['available_future_length'] > r['raw_series_length'] or
                not 6 <= r['prediction_length'] <= r['available_future_length'] <= 192 or
                not 1 <= r['lookback_length'] <= 8192):
                raise ValueError(f'Invalid train window: {r["case_id"]}')
        g = zarr.open_group(str(path/'internal_patch_tokens.zarr'),mode='r')
        if g.attrs.get('written_count') != n or g.attrs.get('source_id') != sid:
            raise ValueError(f'Patch store identity/count mismatch: {sid}')
        patch_specs={'image_global_fp16':(n,256,512),'text_global_fp16':(n,256,512),
                     'image_scale':(n,256,1),'text_scale':(n,256,1),'padding_patch_mask':(n,256)}
        for key, shape in patch_specs.items():
            if g[key].shape != shape:
                raise ValueError(f'Invalid patch shape {key}: {sid}')
            if full_arrays:
                for begin in range(0,n,16):
                    if not np.isfinite(g[key][begin:begin+16]).all():
                        raise ValueError(f'Nonfinite patch array {key}: {sid}')
        report=json.loads((root/'calibration_v11'/(slug+'.json')).read_text())
        if report['version'] != 'v11_top1500_aggregate_futurez_common80_meanmse_softmax_T1':
            raise ValueError(f'Unexpected calibration protocol: {sid}')
        if report['cases'] != n or report['source_id'] != sid:
            raise ValueError(f'Calibration identity/count mismatch: {sid}')
        if report.get('fallback'):
            fallbacks.append(sid)
        with np.load(root/'calibration_v11'/(slug+'.npz'),allow_pickle=False) as c:
            candidates=c['candidate_ids']; w=c['weights']; q=c['eligible_query_ids']
            if candidates.shape != (n,24) or ((candidates < -1)|(candidates >= n)).any():
                raise ValueError(f'Invalid candidate ids: {sid}')
            if (candidates==np.arange(n)[:,None]).any():
                raise ValueError(f'Self-retrieval candidate: {sid}')
            if (w.shape!=(3,) or not np.isfinite(w).all() or (w<0).any() or
                    not np.isclose(w.sum(),1,atol=1e-5)):
                raise ValueError(f'Invalid modality weights: {sid}')
            if q.ndim!=1 or ((q<0)|(q>=n)).any() or len(np.unique(q))!=len(q):
                raise ValueError(f'Invalid eligible query ids: {sid}')
            effective_q=q[(candidates[q]>=0).any(-1)]
            usable+=int(len(effective_q)>0)
            eligible+=len(effective_q)
        total+=n
        lengths.extend(r['lookback_length'] for r in records)
    return dict(status='ready',sources=len(sources),cases=total,
                usable_sources=usable,eligible_queries_with_candidates=eligible,
                history_quantiles=np.quantile(lengths,[0,.25,.5,.75,1]).tolist(),
                history_ge8192=int((np.array(lengths)>=8192).sum()),
                uniform_fallback_sources=fallbacks,full_patch_arrays_checked=full_arrays,
                note='Original V11 allows flagged uniform fallback; inspect before training. This is not a train launch.')


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--root',required=True)
    p.add_argument('--full-arrays',action='store_true')
    a=p.parse_args()
    print(json.dumps(validate(a.root,a.full_arrays),indent=2))


if __name__=='__main__':
    main()
