# 验证记录

验证日期：2026-09-29；环境：207 的 toto2mm，Torch 2.4.1 / Python 3.11。
只运行小样本推理，不执行训练，不停止其他用户任务。

## 真实权重加载与指标

- 纯单模态：从已有纯数值 checkpoint-27000 加载模型，无图文缓存，M4 yearly 两个窗口完成 11 项指标。
- 内源多模态：22000 骨干/图文模块 + 1000 shared_head，M4 yearly 两个窗口完成相同指标。
- 共享头的 6 个 tensor 严格加载、逐 tensor 验证；未启用外源 attention。
- 5 项协议单元测试通过（掩码、填补、截断、97 配置、迭代器）。
- 双 GPU torchrun 小测通过：两个配置各两个窗口，两个 worker 分别推理，父进程自动汇总 4 条预测的配置结果。

## 对照原始 207 实现

对三个配置各两个窗口，使用同一 GPU、相同预处理和 native forecast 参数：

| 配置 | 单模态预测最大绝对差 | 内源预测最大绝对差 |
|---|---:|---:|
| m4_yearly/short | 0.0 | 0.0 |
| ett1/W/short | 0.0 | 0.0 |
| solar/W/short | 0.0 | 0.0 |

全部九个分位点及全部预测位置纳入比较。此结论限于上述抽检，
不是全部 371,330 窗口结果的重新验证，也不保证换 GPU/依赖版本后逐 bit 一致。

## 原始权重 SHA-256

```text
c0114a2a90fac0b92126911bc24be4f1cf81953339f270529d5b047ff39b23a7  internal-22000/model.safetensors
ebe0ca3e2bfa9ef0a781947f938f6abbdbf0476e7d39bd1f343a09369af46a1f  internal-22000/layer16_concat_additive_state.pt
1050fa6b72ec1afdc101309840291d1627943afa33d0ae1df3c1935161ebe924  joint-1000/shared_head_state.pt
b1d5426bafbe1bc458e2414f1cd78d012de54d0bdab5bbba53be954537c18178  joint-1000/external_rag_state.pt
```

没有合并、量化、精度转换或修改任何权重 tensor；打包沿用原始文件字节。
附带权重的测试输入适配历史详见 README 和原始 provenance，不应声称严格 clean zero-shot。
