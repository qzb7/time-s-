"""Vendored reference GIFT-Eval split implementation."""
