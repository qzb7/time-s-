#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
MODE="${1:?Usage: bash run_eval.sh unimodal|endogenous [arguments]}"
shift
case "$MODE" in unimodal|endogenous) ;; *) echo 'Mode must be unimodal or endogenous' >&2; exit 2 ;; esac
SCRIPT="$SCRIPT_DIR/evaluate_${MODE}.py"
PYTHON_BIN="${EVAL_PYTHON:-python}"
export OMP_NUM_THREADS="${OMP_NUM_THREADS:-1}"
export MKL_NUM_THREADS="${MKL_NUM_THREADS:-1}"
if [[ -n "${RANK:-}" && -n "${WORLD_SIZE:-}" ]]; then
    exec "$PYTHON_BIN" "$SCRIPT" "$@"
fi
CPU_ONLY=false
PREVIOUS=""
for ARG in "$@"; do
    if [[ "$ARG" == --plan-only || "$ARG" == --finalize-only ]]; then exec "$PYTHON_BIN" "$SCRIPT" "$@"; fi
    if [[ "$ARG" == --device=cpu || ( "$PREVIOUS" == --device && "$ARG" == cpu ) ]]; then CPU_ONLY=true; fi
    PREVIOUS="$ARG"
done
COUNT="$("$PYTHON_BIN" -c 'import torch; print(torch.cuda.device_count())')"
NPROC="${NPROC_PER_NODE:-auto}"
if [[ "$NPROC" == auto ]]; then
    NPROC="$COUNT"
    if [[ "$CPU_ONLY" == true || "$COUNT" -eq 0 ]]; then NPROC=1; fi
fi
if [[ ! "$NPROC" =~ ^[1-9][0-9]*$ ]]; then echo 'Invalid NPROC_PER_NODE' >&2; exit 2; fi
if [[ "$CPU_ONLY" == false && "$COUNT" -gt 0 && "$NPROC" -gt "$COUNT" ]]; then
    echo 'NPROC_PER_NODE exceeds visible LOCAL GPU count' >&2; exit 2
fi
if [[ "$NPROC" -eq 1 ]]; then exec "$PYTHON_BIN" "$SCRIPT" "$@"; fi
"$PYTHON_BIN" -m torch.distributed.run --standalone --nproc_per_node="$NPROC" "$SCRIPT" "$@"
"$PYTHON_BIN" "$SCRIPT" "$@" --finalize-only
