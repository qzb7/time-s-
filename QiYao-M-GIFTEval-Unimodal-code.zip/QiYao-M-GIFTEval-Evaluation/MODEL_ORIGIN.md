# Third-party notices

The numerical backbone in `qiyaom/backbone_qiyaom.py` and its configuration
in `qiyaom/configuration_backbone.py` are derived from the Toto 2.0
implementation developed by Datadog, Inc.

Copyright 2026 Datadog, Inc.

Upstream source: https://github.com/DataDog/toto

These two files are distributed under the Apache License, Version 2.0.
The full license is included in `licenses/Apache-2.0.txt`; the original
copyright notices are retained in the source files.

Changes in this distribution: the backbone and configuration classes are
exposed under the QiYao-M namespace, and imports point to the bundled local
modules. Numerical operations and checkpoint parameter names are unchanged.
The backbone snapshot also retains the existing project's attention and
checkpoint-loading compatibility adaptations.

The third-party project name appears here for attribution only. It is not
an external model dependency, import, or runtime call in this release.
Backbone weights are not redistributed in this source archive.
