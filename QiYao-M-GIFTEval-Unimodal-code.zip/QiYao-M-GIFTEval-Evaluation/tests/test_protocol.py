import json
from pathlib import Path
import unittest

import numpy as np

from eval_common import align_history, impute, HEADER, METRICS, Limited


class ProtocolTests(unittest.TestCase):
    def test_masks(self):
        x, m, p = align_history([0., np.nan, 2.], 32)
        self.assertEqual(m[-3:].tolist(), [True, False, True])
        self.assertFalse(p[-3:].any())
        self.assertTrue(p[:-3].all())
        np.testing.assert_array_equal(impute(x[None], m[None])[0, -3:], [0, 0, 2])

    def test_fill(self):
        x = np.array([[np.nan, 2, np.nan, 3], [np.nan] * 4], np.float32)
        np.testing.assert_array_equal(impute(x, np.isfinite(x)), [[2, 2, 2, 3], [0, 0, 0, 0]])

    def test_crop(self):
        x, m, p = align_history(np.arange(100), 32)
        np.testing.assert_array_equal(x, np.arange(68, 100))
        self.assertTrue(m.all()); self.assertFalse(p.any())

    def test_catalogue(self):
        tasks = json.loads((Path(__file__).resolve().parents[1] / 'catalogue.json').read_text())
        self.assertEqual(len(tasks), 97)
        self.assertEqual(sum(x['written_samples'] for x in tasks), 371330)
        self.assertEqual(len({x['official_dataset'] for x in tasks}), 97)
        self.assertEqual(len(HEADER), 15)
        self.assertEqual(len(METRICS), 11)

    def test_reiterable(self):
        x = Limited(range(10), 2)
        self.assertEqual(list(x), [0, 1]); self.assertEqual(list(x), [0, 1])


if __name__ == '__main__':
    unittest.main()
