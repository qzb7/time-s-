#!/usr/bin/env python3
"""Evaluate compatible numerical-only checkpoints without multimodal caches."""
from eval_common import main

if __name__ == '__main__':
    main('unimodal')
