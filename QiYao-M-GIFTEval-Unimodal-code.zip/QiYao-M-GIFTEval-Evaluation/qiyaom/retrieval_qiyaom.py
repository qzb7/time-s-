"""Exogenous candidate-aware retrieval enhancer used by QiYao-M."""

from __future__ import annotations

import math

import torch
from torch import nn


class TargetEncoder(nn.Module):
    """Encode a normalized 32-point target patch plus its missingness mask."""

    def __init__(self, d_model: int):
        super().__init__()
        self.skip = nn.Linear(64, d_model)
        self.norm = nn.LayerNorm(64)
        self.fc1 = nn.Linear(64, 4 * d_model)
        self.fc2 = nn.Linear(4 * d_model, d_model)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.skip(x) + self.fc2(torch.nn.functional.gelu(self.fc1(self.norm(x))))


class RelationAttention(nn.Module):
    """Cross-attend from query patches to retrieved target patches."""

    def __init__(self, d_model: int, heads: int):
        super().__init__()
        if d_model % heads:
            raise ValueError("d_model must be divisible by heads")
        self.heads = heads
        self.hd = d_model // heads
        self.q_norm = nn.LayerNorm(d_model)
        self.kv_norm = nn.LayerNorm(d_model)
        self.q_proj = nn.Linear(d_model, d_model)
        self.k_proj = nn.Linear(d_model, d_model)
        self.v_proj = nn.Linear(d_model, d_model)
        self.relation = nn.Sequential(
            nn.Linear(4, 128), nn.GELU(), nn.Linear(128, d_model)
        )
        self.modality_type = nn.Embedding(2, d_model)
        self.null_key = nn.Parameter(torch.zeros(heads, self.hd))
        # The null branch has no value; a null-only decision cannot change h.
        self.out_proj = nn.Linear(d_model, d_model, bias=False)
        nn.init.zeros_(self.out_proj.weight)
        self.last_null_mass = None

    def forward(self, hidden, target, relation, other, valid, query_mask):
        batch, patches, dim = hidden.shape
        candidates = target.shape[1]
        query = self.q_proj(self.q_norm(hidden)).reshape(
            batch, patches, self.heads, self.hd
        )
        content = self.kv_norm(target)
        relation_key = self.relation(relation) + self.modality_type(other)
        key = (self.k_proj(content) + relation_key[:, :, None]).reshape(
            batch, candidates, patches, self.heads, self.hd
        )
        value = self.v_proj(content).reshape(
            batch, candidates, patches, self.heads, self.hd
        )
        logits = torch.einsum("bphd,bkphd->bhpk", query, key) / math.sqrt(self.hd)
        logits = logits.masked_fill(~valid.permute(0, 2, 1)[:, None], -torch.inf)
        null_logits = torch.einsum("bphd,hd->bhp", query, self.null_key) / math.sqrt(
            self.hd
        )
        attention = torch.cat([logits, null_logits[..., None]], dim=-1)
        attention = attention.float().softmax(-1).to(hidden.dtype)
        delta = torch.einsum(
            "bhpk,bkphd->bphd", attention[..., :candidates], value
        ).reshape(batch, patches, dim)
        self.last_null_mass = attention[..., -1].detach().mean()
        return hidden + self.out_proj(delta).masked_fill(~query_mask[..., None], 0)


class ExoMultimodalRetrievalEnhancer(nn.Module):
    """Five-layer candidate-aware exogenous retrieval module.

    Similarity and source weights use modality order ``[image, text, time]``.
    Retrieved future values, rather than retrieval embeddings, form values.
    """

    def __init__(self, d_model: int = 1024, heads: int = 16, num_layers: int = 5):
        super().__init__()
        self.target_encoder = TargetEncoder(d_model)
        self.layers = nn.ModuleList(
            [RelationAttention(d_model, heads) for _ in range(num_layers)]
        )

    def forward(
        self,
        query,
        candidate_target_input,
        cosine_similarity,
        source_weight,
        candidate_mask,
        candidate_patch_mask,
        forecast_patch_mask,
    ):
        weights = source_weight / source_weight.sum(-1, keepdim=True).clamp_min(1e-12)
        similarity = cosine_similarity.clamp(-1, 1)
        # Among image and text, retain the strongest weighted relation for K.
        other = (
            weights[:, None, :2] * ((similarity[:, :, :2] + 1) / 2)
        ).argmax(-1)
        other_weight = (
            weights[:, None, :2]
            .expand(-1, similarity.shape[1], -1)
            .gather(-1, other[..., None])[..., 0]
        )
        other_similarity = similarity[:, :, :2].gather(
            -1, other[..., None]
        )[..., 0]
        relation = torch.stack(
            [
                weights[:, 2, None].expand_as(other_weight),
                similarity[:, :, 2],
                other_weight,
                other_similarity,
            ],
            dim=-1,
        )
        valid = candidate_mask.bool()[..., None] & candidate_patch_mask.bool()
        target = self.target_encoder(
            candidate_target_input.masked_fill(~valid[..., None], 0)
        ).masked_fill(~valid[..., None], 0)
        hidden = query
        for layer in self.layers:
            hidden = layer(
                hidden,
                target,
                relation,
                other,
                valid,
                forecast_patch_mask.bool(),
            )
        return hidden.masked_fill(~forecast_patch_mask[..., None].bool(), 0)


# Backward-compatible name used by the released V11 checkpoints.
ExternalRAG = ExoMultimodalRetrievalEnhancer
