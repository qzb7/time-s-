"""Retrieval utilities shared by QiYao-M inference applications."""

from __future__ import annotations

import torch


def select_candidates(
    cosine_similarity: torch.Tensor,
    source_weight: torch.Tensor,
    per_modality_topk: int = 10,
    final_topk: int = 16,
) -> torch.Tensor:
    """Select candidates by per-modality union followed by weighted fusion.

    Parameters use modality order ``[image, text, time]``. The operation is
    deterministic for a fixed input and returns ``-1`` in unused positions.
    """
    if cosine_similarity.ndim != 3:
        raise ValueError("cosine_similarity must have shape [batch, bank, modality]")
    batch, bank_size, modalities = cosine_similarity.shape
    if source_weight.shape != (batch, modalities):
        raise ValueError("source_weight must have shape [batch, modality]")
    per_modality_topk = min(int(per_modality_topk), bank_size)
    output = torch.full(
        (batch, int(final_topk)), -1, dtype=torch.long, device=cosine_similarity.device
    )
    weights = source_weight / source_weight.sum(-1, keepdim=True).clamp_min(1e-12)
    for row in range(batch):
        union = torch.cat(
            [
                torch.topk(
                    cosine_similarity[row, :, modality],
                    per_modality_topk,
                    sorted=False,
                ).indices
                for modality in range(modalities)
            ]
        ).unique()
        fused = (((cosine_similarity[row, union] + 1) / 2) * weights[row]).sum(-1)
        take = union[torch.argsort(fused, descending=True, stable=True)[:final_topk]]
        output[row, : take.numel()] = take
    return output


def ensure_patch_aligned(length: int, patch_size: int = 32) -> None:
    if int(length) % int(patch_size):
        raise ValueError(
            f"Context length {length} must be divisible by patch size {patch_size}"
        )
