"""Minimal inference pipeline for QiYao-M."""

from __future__ import annotations

from pathlib import Path
from typing import Optional

import torch
from einops import rearrange

from .modeling_qiyaom import QiYaoMForPrediction
from .utils import ensure_patch_aligned


class QiYaoMPipeline:
    """Run endogenous or retrieval-enhanced probabilistic forecasts.

    Image and text inputs are patch-aligned 512-dimensional embeddings. Their
    deterministic construction/encoding is intentionally separate from the
    forecasting model so users may cache them once and reuse them.
    """

    def __init__(self, model: QiYaoMForPrediction, device: str = "cuda"):
        self.model = model.to(device).eval()
        self.device = torch.device(device)

    @classmethod
    def from_pretrained(
        cls,
        model_dir: str | Path,
        external_dir: str | Path | None = None,
        device: str = "cuda",
    ) -> "QiYaoMPipeline":
        model = QiYaoMForPrediction.from_pretrained(
            model_dir, external_dir=external_dir, map_location="cpu"
        )
        return cls(model, device=device)

    def _prepare_context(self, history, history_mask, image_tokens, text_tokens):
        history = torch.as_tensor(history, dtype=torch.float32, device=self.device)
        if history.ndim == 2:
            history = history[:, None]
        if history.ndim != 3:
            raise ValueError("history must have shape [batch, time] or [batch, variate, time]")
        ensure_patch_aligned(history.shape[-1], self.model.patch_size)
        if history_mask is None:
            history_mask = torch.isfinite(history)
        else:
            history_mask = torch.as_tensor(history_mask, dtype=torch.bool, device=self.device)
            if history_mask.ndim == 2:
                history_mask = history_mask[:, None]
        history = torch.nan_to_num(history)
        image_tokens = torch.as_tensor(image_tokens, dtype=torch.float32, device=self.device)
        text_tokens = torch.as_tensor(text_tokens, dtype=torch.float32, device=self.device)
        if image_tokens.ndim == 3:
            image_tokens = image_tokens[:, None]
        if text_tokens.ndim == 3:
            text_tokens = text_tokens[:, None]
        patches = history.shape[-1] // self.model.patch_size
        expected_image = history.shape[:-1] + (patches, 512)
        if tuple(image_tokens.shape) != expected_image:
            raise ValueError(f"image_tokens must have shape {expected_image}")
        if tuple(text_tokens.shape) != expected_image:
            raise ValueError(f"text_tokens must have shape {expected_image}")
        return history, history_mask, image_tokens, text_tokens

    @torch.inference_mode()
    def predict(
        self,
        history,
        image_tokens,
        text_tokens,
        prediction_length: int,
        history_mask=None,
    ) -> torch.Tensor:
        """Return endogenous quantile forecasts with shape [Q, B, V, H]."""
        context = self._prepare_context(
            history, history_mask, image_tokens, text_tokens
        )
        return self.model.forecast_endogenous(
            *context,
            horizon=int(prediction_length),
        )

    @torch.inference_mode()
    def predict_with_retrieval(
        self,
        history,
        image_tokens,
        text_tokens,
        prediction_length: int,
        candidate_values,
        candidate_valid_mask,
        cosine_similarity,
        source_weight,
        candidate_mask,
        history_mask=None,
    ) -> torch.Tensor:
        """Return retrieval-enhanced univariate forecasts [Q, B, 1, H].

        ``candidate_values`` and ``candidate_valid_mask`` have shape
        ``[B, K, ceil(H/32)*32]``. Similarities have shape ``[B, K, 3]`` in
        image/text/time order. Candidate selection is performed before this
        call, making the inference protocol explicit and reproducible.
        """
        history, history_mask, image_tokens, text_tokens = self._prepare_context(
            history, history_mask, image_tokens, text_tokens
        )
        if history.shape[1] != 1:
            raise ValueError("retrieval-enhanced inference currently expects one variate")
        patch = self.model.patch_size
        patches = (int(prediction_length) + patch - 1) // patch
        padded_horizon = patches * patch
        query_mask = torch.ones(
            history.shape[0], patches, dtype=torch.bool, device=self.device
        )
        hidden, future_loc, future_scale = self.model.endogenous.forecast_parallel_hidden(
            history,
            history_mask,
            image_tokens,
            text_tokens,
            padded_horizon,
            forecast_patch_mask=query_mask,
        )
        candidate_values = torch.as_tensor(
            candidate_values, dtype=torch.float32, device=self.device
        )[..., :padded_horizon]
        candidate_valid_mask = torch.as_tensor(
            candidate_valid_mask, dtype=torch.bool, device=self.device
        )[..., :padded_horizon]
        batch, candidates, _ = candidate_values.shape
        encoded = self.model.endogenous.normalize_known_target_patches(
            candidate_values.reshape(batch * candidates, padded_horizon),
            candidate_valid_mask.reshape(batch * candidates, padded_horizon),
        ).reshape(batch, candidates, patches, 2 * patch)
        candidate_patch_mask = candidate_valid_mask.reshape(
            batch, candidates, patches, patch
        ).any(-1)
        enhanced = self.model.enhance_hidden(
            hidden[:, 0],
            encoded,
            torch.as_tensor(cosine_similarity, dtype=torch.float32, device=self.device),
            torch.as_tensor(source_weight, dtype=torch.float32, device=self.device),
            torch.as_tensor(candidate_mask, dtype=torch.bool, device=self.device),
            candidate_patch_mask,
            query_mask,
        )
        base = self.model.endogenous.base_model
        quantiles = base.output_head(enhanced[:, None], q=None)
        quantiles = quantiles[..., :: base.config.num_output_patches, :]
        quantiles = quantiles.sinh() * future_scale + future_loc
        quantiles = base._clamp_nonfinite(quantiles).sort(dim=0).values
        return rearrange(quantiles, "q b v p s -> q b v (p s)")[
            ..., : int(prediction_length)
        ]
