"""Configuration helpers for the source-only QiYao-M release."""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from pathlib import Path


@dataclass
class QiYaoMConfig:
    model_type: str = "qiyao-m"
    backbone: str = "QiYao-M-313M"
    patch_size: int = 32
    d_model: int = 1024
    d_ff: int = 2736
    num_layers: int = 24
    num_heads: int = 16
    fusion_after_layer: int = 16
    image_dim: int = 512
    text_dim: int = 512
    retrieval_layers: int = 5
    retrieval_heads: int = 16
    relation_dim: int = 4
    relation_hidden_dim: int = 128
    modality_order: tuple[str, ...] = ("image", "text", "time")

    @classmethod
    def from_json_file(cls, path: str | Path) -> "QiYaoMConfig":
        data = json.loads(Path(path).read_text())
        fields = cls.__dataclass_fields__
        values = {key: value for key, value in data.items() if key in fields}
        if "modality_order" in values:
            values["modality_order"] = tuple(values["modality_order"])
        return cls(**values)

    def to_json_file(self, path: str | Path) -> None:
        data = asdict(self)
        data["modality_order"] = list(self.modality_order)
        Path(path).write_text(json.dumps(data, indent=2) + "\n")
