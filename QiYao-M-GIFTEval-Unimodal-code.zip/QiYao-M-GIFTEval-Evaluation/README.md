# QiYao-M：可移植 GIFT-Eval 评测包

此包包含两个独立入口，不需要训练代码、Dion、CLIP 模型或 207 的源码目录。

| 入口 | 用途 | 必需输入 |
|---|---|---|
| `evaluate_unimodal.py` / `run_eval.sh unimodal` | 纯数值模型评测 | 原始 GIFT-Eval 数据、兼容数值权重 |
| `evaluate_endogenous.py` / `run_eval.sh endogenous` | QiYao-M 内源图文模型评测 | 原始数据、patch 图文缓存、22000 骨干/图文权重和 1000 共享头 |

两个入口沿用同一版官方 Dataset、同样的 97 个配置和 371,330 个测试输入。
本包不运行外源检索，也不会将图文特征置零来假装纯单模态。

## 1. 安装环境

推荐 Python 3.11，新建环境，不覆盖正在训练的环境。先按驱动安装 PyTorch 2.4.1，再安装依赖：

```bash
cd QiYao-M-GIFTEval-Evaluation
python -m pip install 'torch==2.4.1'
python -m pip install -r requirements.txt
python -m unittest discover -s tests -v
```

已有 Torch 2.4.1 可跳过第一条安装。GPU 服务器应使用适配驱动的 CUDA wheel。
不要执行原来开源包的 `pip install -e` 来覆盖本包锁定的 GluonTS 版本。
运行时目录已包含 `qiyaom/`、`gift_eval/` 和推理所需的 `dd_unit_scaling/`。
`dd_unit_scaling` 保留原计算实现，但移除了优化器导出，所以不依赖 Dion。
离线服务器另需准备这些 Python 依赖 wheel；本包不是整个 Conda 环境。

## 2. 纯单模态：测试同学自己训练的权重

```bash
CUDA_VISIBLE_DEVICES=0,1 \
bash run_eval.sh unimodal \
  --checkpoint /models/my-numerical-checkpoint \
  --model-name My-Numerical-Model \
  --gift-eval-dir /data/GIFTEval \
  --output /results/my_numerical_gifteval \
  --context-length 8192 \
  --batch-size 32
```

权重目录至少需要：

```text
my-numerical-checkpoint/
├── config.json
└── model.safetensors
```

支持 `model.safetensors.index.json` 引用的多分片 safetensors。
这里“同学训练好的单模态权重”指 **兼容本包数值骨干、patch size=32、九分位输出** 的权重，
例如在其他服务器训练的同结构 checkpoint；不是任意模型架构都能直接加载。
Chronos、PatchTST 等其他架构须实现各自预测适配器，不能仅换权重路径。
加载采用 strict=True，不会忽略缺失参数后用随机权重补齐。
只加载数值骨干，不读取图文 projector、共享头覆盖文件或外源模块。
默认原生并行预测、`scaler_fallback_min_obs=8`、不额外限制预测幅值。
数值骨干原生 forecast 会保持自己的最后 context patch 掩码策略；
它与内源 forecast_parallel 不是相同函数，不能把两者描述成仅“是否给图文”的开关。

## 3. 内源多模态：测试你的最终联合训练权重

完整权重包的目录为：

```text
checkpoints/
├── internal-22000/
│   ├── config.json
│   ├── model.safetensors
│   ├── layer16_concat_additive_config.json
│   └── layer16_concat_additive_state.pt
└── joint-1000/
    ├── external_rag_config.json
    ├── external_rag_state.pt
    └── shared_head_state.pt
```

**最终 checkpoint-1000 是增量检查点，不是完整的 313M 骨干。**
内源评测先加载 22000 骨干和图文模块，再严格覆盖 1000 共享预测头，
与原 GIFT-Eval 结果的 `weight_provenance.json` 一致。
外源注意力权重也按要求附在包内，但此入口不加载、不使用它们；不需要外源 bank。
没有包含 `training_state.pt` 或优化器状态，不能直接用于无损恢复训练。

```bash
CUDA_VISIBLE_DEVICES=0,1 \
bash run_eval.sh endogenous \
  --gift-eval-dir /data/GIFTEval \
  --cache-dir /data/QiYao-M_gifteval_patch32_grouped_npz \
  --output /results/QiYao-M_gifteval \
  --model-name QiYao-M \
  --batch-size 32
```

默认从包内 `checkpoints/` 加载；也可显式传：

```bash
--checkpoint /models/internal-22000 \
--shared-head /models/joint-1000/shared_head_state.pt
```

原始 `/data/GIFTEval` 必须为各数据集 `load_from_disk` 目录，而不是预训练数据。
`--cache-dir` 指向之前提供的 **QiYao-M-GIFTEval-Patch-Generator** 全量输出；
也兼容 207 原 grouped-NPZ 缓存。缓存需 8192 点左补齐、patch32、256×512 的图文向量。
缓存中的历史值/观测掩码/补齐掩码会逐窗口与官方数据精确核对，
不匹配时停止，避免图文窗口与标签错位。全量模式不接受 preview 缓存。
同学必须另行准备原始数据和图文缓存，权重包不包含约数百 GB 的缓存。

## 4. 验证输入和小样本运行

在上述命令尾部加 `--plan-only`：只核对配置和样本数量，不加载模型。
在上述命令尾部加以下选项：只测两个输入，验证环境与接口：

```bash
--include m4_yearly/short --max-samples 2 --batch-size 2
```

可重复 `--include` 选择多个配置，例如 `--include ett1/W/short`。
预览使用独立输出目录，不可拿来与完整榜单比较；完成后生成 `preview_results.csv`。
只选择部分配置而不限制样本，生成 `partial_results.csv`。
只有全部 97 配置完成且没有 `--max-samples`，才生成 `all_results.csv`。

## 5. 多卡、后台与续跑

- 默认每张可见本机 GPU 一个进程；卡之间不传特征、不进行 DDP 梯度同步。
- `CUDA_VISIBLE_DEVICES` 限制卡范围，`NPROC_PER_NODE` 可限制本机进程数。
- `EVAL_PYTHON=/path/to/python` 可选；默认当前环境 `python`。
- 不传 `--gpus`、`--master-port`、`--launch-mode`。单机 rendezvous 端口自动选择。
- 平台已配置 torchrun 时直接使用 rank 环境，不嵌套启动。
- 多机需要一致的数据/缓存/代码以及共享输出目录，全部进程结束后执行同一命令加 `--finalize-only`。

后台示例：

```bash
CUDA_VISIBLE_DEVICES=0,1 nohup bash run_eval.sh endogenous \
  --gift-eval-dir /data/GIFTEval \
  --cache-dir /data/QiYao-M_gifteval_patch32_grouped_npz \
  --output /results/QiYao-M_gifteval \
  --batch-size 32 > gifteval.log 2>&1 &
```

重复执行相同命令可按**已完成的数据集配置**续跑，进行到一半的配置重新计算。
不同权重、上下文长度、batch size、数据版本或代码不能混进同一输出目录。
允许调整卡数。发生 OOM 可减小 batch size，但应换新输出目录，避免混合数值协议。
模型始终 eval + inference_mode；没有更新参数，也不修改输入权重文件。

## 6. 输出与指标

```text
output/
├── protocol.json         # 权重哈希、代码哈希、运行协议
├── tasks/*.json          # 每个配置的独立指标/样本数，可续跑
├── summary.json          # 完整性信息
└── all_results.csv       # 97 个配置完成后才发布
```

CSV 为已核对的官方 15 列格式：dataset、model、11 个 eval_metrics 字段、domain、num_variates。
数据集名称/别名/频率和顺序使用官方 CHARM 参考 CSV 的 97 配置快照；不添加 checkpoint/term 列。
其中 CRPS 对应 `eval_metrics/mean_weighted_sum_quantile_loss`，
沿用 GluonTS 的九分位加权分位损失近似，不是从分布采样 100 次计算。
MASE 使用官方季节性及历史尺度；不额外除以 TAOBAO/TIANCHI 或其他训练集标准差。
QuantileForecast 未单独提供预测均值，GluonTS 的 `mean` 字段回退到中位数，
这一点沿用原评测方式；不能把此列解释为分布均值的无偏估计。
预测非有限值、错位、缺失窗口或非有限指标会报错，不通过删除困难样本改善结果。
这里不直接计算排行榜归一化 Overall/Rank；那需要官方完整 baseline/seasonal-naive 汇总协议，
不是简单平均 CSV 中的原始 MASE 或 CRPS。

## 7. 训练暴露与复现边界

保留原结果中的 `weight_provenance.original.json`。
其中明确记录：**这些附带权重使用过 GIFT-Eval/TIME 测试输入适配，不属于严格 clean zero-shot。**
这与当前预测不读取未来标签是两件不同的事，公开提交/论文比较时必须分别披露。
本包不根据现有材料声称这些权重满足某个榜单的无泄漏资格。
替换为同学的数值权重后，需另行披露其训练来源，不能沿用本权重的声明。

## 8. 包的区别与来源

- `QiYao-M-GIFTEval-Unimodal-code.zip`：数值评测代码，无权重。
- `QiYao-M-GIFTEval-Endogenous-code.zip`：内源评测代码，无权重。
- `QiYao-M-GIFTEval-Evaluation-with-weights.tar.gz`：两种入口和所有上列推理权重。

各源码 ZIP 保留共同模块；对应入口不同。正式内源使用完整权重包最方便。
原始 GIFT-Eval Dataset 源码来自 Salesforce；数值骨干及 scaling 源码的 Datadog 归属和
Apache-2.0 声明保留。详见 `MODEL_ORIGIN.md` 和 `licenses/Apache-2.0.txt`。
QiYao-M 重命名不改变上游代码归属；此处打包不主张原模型架构的独立原创性。
本包不含账号密码、密钥、训练优化器状态或原始数据。
