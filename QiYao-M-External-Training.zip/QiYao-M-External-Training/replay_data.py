import math
import numpy as np
import torch
from torch.utils.data import IterableDataset
from replay_config import two_group_counts


class TwoGroupReplayDataset(IterableDataset):
    """One merged test-history group plus one clean training group."""
    def __init__(self, dataset_cls, test_dirs, clean_dirs, batch_size, test_ratio, seed):
        super().__init__()
        self.dataset_cls = dataset_cls
        self.test_dirs, self.clean_dirs = test_dirs, clean_dirs
        self.batch_size, self.test_ratio, self.seed = batch_size, test_ratio, seed

    def __iter__(self):
        test = iter(self.dataset_cls(self.test_dirs, seed=self.seed + 11)) if self.test_ratio > 0 else None
        clean = iter(self.dataset_cls(self.clean_dirs, seed=self.seed + 37)) if self.test_ratio < 1 else None
        step = 0
        while True:
            counts = two_group_counts(step, self.batch_size, self.test_ratio)
            for stream, count, label in zip([test, clean], counts, ['test_input', 'clean']):
                for _ in range(count):
                    row = next(stream)
                    row['mix_group'] = label
                    yield row
            step += 1

class TimeGiftCleanFixedHorizonDataset(IterableDataset):
    """Fixed source mix with an exact horizon mix inside GIFTEval test input."""

    def __init__(
        self,
        dataset_cls,
        clean_dirs,
        earlier_context_dirs,
        previous_targeted_dir,
        new_targeted_dir,
        time_test_dir,
        batch_size,
        source_ratios,
        gift_horizon_ratios,
        seed,
    ):
        super().__init__()
        self.dataset_cls = dataset_cls
        self.clean_dirs = tuple(clean_dirs)
        self.earlier_context_dirs = tuple(earlier_context_dirs)
        self.previous_targeted_dir = str(previous_targeted_dir)
        self.new_targeted_dir = str(new_targeted_dir)
        self.time_test_dir = str(time_test_dir)
        self.batch_size = int(batch_size)
        self.source_ratios = tuple(float(x) for x in source_ratios)
        self.gift_horizon_ratios = tuple(float(x) for x in gift_horizon_ratios)
        self.seed = int(seed)
        if len(self.source_ratios) != 3 or not math.isclose(sum(self.source_ratios), 1.0):
            raise ValueError(f"TIME/GIFTEval/clean ratios must sum to 1, got {self.source_ratios}")
        if len(self.gift_horizon_ratios) != 3 or not math.isclose(sum(self.gift_horizon_ratios), 1.0):
            raise ValueError(
                f"GIFTEval short/medium/long ratios must sum to 1, got {self.gift_horizon_ratios}"
            )

    @staticmethod
    def _take(iterator, count, group):
        for _ in range(count):
            row = next(iterator)
            row["mix_group"] = group
            yield row

    @staticmethod
    def _take_gifteval_horizon_balanced(iterator, counts):
        """Fill exact S/M/L quotas while reading the combined banks once.

        Legacy rows without a short/medium/long source_term and surplus rows
        for an already-full term are skipped.  The stored term distribution is
        close to 60/15/25, so rejection overhead stays small and no large tensor
        queues accumulate in host memory.
        """
        terms = ("short", "medium", "long")
        remaining = dict(zip(terms, counts))
        while any(remaining.values()):
            row = next(iterator)
            term = str(row.get("source_term", "")).lower()
            if term not in remaining or remaining[term] <= 0:
                continue
            row["mix_group"] = "gifteval_test"
            remaining[term] -= 1
            yield row

    def _mixed_forever(self, iterators, groups):
        previous = [0] * len(self.source_ratios)
        local_step = 0
        while True:
            counts = []
            for index, ratio in enumerate(self.source_ratios[:-1]):
                cumulative = round((local_step + 1) * self.batch_size * ratio)
                counts.append(cumulative - previous[index])
                previous[index] = cumulative
            counts.append(self.batch_size - sum(counts))
            yield from self._take(iterators[0], counts[0], groups[0])
            # Preserve the stored GIFTEval test-input distribution.  Do not
            # reject/resample rows to impose a short/medium/long quota.
            yield from self._take(iterators[1], counts[1], groups[1])
            yield from self._take(iterators[2], counts[2], groups[2])
            local_step += 1

    def __iter__(self):
        gifteval_test_dirs = [
            *self.earlier_context_dirs,
            self.previous_targeted_dir,
            self.new_targeted_dir,
        ]
        iterators = (
            iter(self.dataset_cls([self.time_test_dir], seed=self.seed + 11)),
            iter(self.dataset_cls(gifteval_test_dirs, seed=self.seed + 23)),
            iter(self.dataset_cls(self.clean_dirs, seed=self.seed + 37)),
        )
        groups = ("time_test", "gifteval_test", "clean")
        yield from self._mixed_forever(iterators, groups)

def sample_tail_first_patch_mask(
    target_mask, *, patch_size, max_span_patches, max_mask_probability
):
    """Always mask a random 1--K patch suffix, then fill up to <=40% elsewhere."""
    if max_span_patches < 1:
        raise ValueError("max_span_patches must be positive")
    if not 0.0 < max_mask_probability <= 1.0:
        raise ValueError("max_mask_probability must be in (0, 1]")
    if target_mask.shape[-1] % patch_size:
        raise ValueError("target length must be patch aligned")
    patch_valid = target_mask.unflatten(
        -1, (target_mask.shape[-1] // patch_size, patch_size)
    ).any(dim=-1)
    masked = torch.zeros_like(patch_valid)
    flat_valid = patch_valid.reshape(-1, patch_valid.shape[-1])
    flat_masked = masked.reshape(-1, masked.shape[-1])
    for row in range(flat_valid.shape[0]):
        valid = torch.where(flat_valid[row])[0]
        # The first valid patch must remain visible because output patch t-1
        # supervises target patch t.
        if valid.numel() < 2:
            continue
        eligible = valid[1:]
        # Preserve the original CPM coverage distribution: draw p uniformly
        # from [0, max_mask_probability] and round p * eligible_count.
        probability = float(torch.rand((), device=target_mask.device).item())
        probability *= max_mask_probability
        target_count = max(1, int(round(probability * eligible.numel())))
        target_count = min(target_count, max(1, int(math.floor(max_mask_probability * eligible.numel()))))
        # The only semantic addition to the old CPM sampler: guarantee that a
        # random 1--4-patch suffix is selected first.
        tail_span = int(torch.randint(
            1, min(max_span_patches, target_count, eligible.numel()) + 1,
            (), device=target_mask.device,
        ).item())
        flat_masked[row, eligible[-tail_span:]] = True

        interior = eligible[:-tail_span]
        attempts = 0
        while int(flat_masked[row].sum().item()) < target_count and interior.numel() and attempts < 8 * flat_valid.shape[-1]:
            remaining = target_count - int(flat_masked[row].sum().item())
            span = int(torch.randint(
                1, min(max_span_patches, remaining) + 1,
                (), device=target_mask.device,
            ).item())
            start_pos = int(torch.randint(0, interior.numel(), (), device=target_mask.device).item())
            chosen = interior[start_pos : min(interior.numel(), start_pos + span)]
            chosen = chosen[~flat_masked[row, chosen]][:remaining]
            flat_masked[row, chosen] = True
            attempts += 1
    cpm_mask = (~masked).repeat_interleave(patch_size, dim=-1)
    return cpm_mask, masked

def prepare_tail_first_batch(batch, device, *, patch_size, max_span_patches, max_mask_probability):
    target = batch["target"].to(device, non_blocking=True).unsqueeze(1)
    target_mask = batch["target_mask"].to(device, non_blocking=True).unsqueeze(1).bool()
    cpm_mask, masked_patches = sample_tail_first_patch_mask(
        target_mask,
        patch_size=patch_size,
        max_span_patches=max_span_patches,
        max_mask_probability=max_mask_probability,
    )
    # Only the newly generated bank uses horizon-aware suffix supervision.
    # The old banks retain their proven 1--4 suffix + random CPM behavior.
    source_banks = batch.get("source_bank", [])
    source_terms = batch.get("source_term", [])
    source_datasets = batch.get("source_dataset", [])
    mix_groups = batch.get("mix_group", [])
    flat_valid = target_mask.unflatten(
        -1, (target_mask.shape[-1] // patch_size, patch_size)
    ).any(dim=-1).reshape(-1, target_mask.shape[-1] // patch_size)
    flat_masked = masked_patches.reshape(-1, masked_patches.shape[-1])
    for row in range(flat_valid.shape[0]):
        dataset_name = (
            source_datasets[row].lower() if row < len(source_datasets) else ""
        )
        is_m4_short = dataset_name in {
            "m4_yearly",
            "m4_quarterly",
            "m4_monthly",
            "m4_weekly",
            "m4_daily",
            "m4_hourly",
        }
        is_new = (
            (row < len(mix_groups) and mix_groups[row] == "new")
            or (
                row < len(source_banks)
                and source_banks[row]
                == "toto2_multimodal_gifteval_test_context_nonsolar_targeted_400k"
            )
            or is_m4_short
        )
        if not is_new:
            continue
        valid = torch.where(flat_valid[row])[0]
        if valid.numel() < 2:
            flat_masked[row].zero_()
            continue
        eligible = valid[1:]
        term = source_terms[row].lower() if row < len(source_terms) else "short"
        if dataset_name == "m4_hourly":
            low, high = (2, 2)
        elif is_m4_short:
            low, high = (1, 1)
        else:
            low, high = {
                "short": (1, 4),
                "medium": (4, 8),
                "long": (8, 12),
            }.get(term, (1, 4))
        high = min(high, int(eligible.numel()))
        low = min(low, high)
        span = int(torch.randint(low, high + 1, (), device=target_mask.device).item())
        flat_masked[row].zero_()
        flat_masked[row, eligible[-span:]] = True
    cpm_mask = (~masked_patches).repeat_interleave(patch_size, dim=-1)
    if not masked_patches.any():
        raise RuntimeError("distributed micro-batch has no valid CPM patch")
    return {
        "target": target,
        "target_mask": target_mask,
        "cpm_mask": cpm_mask,
        "masked_patches": masked_patches,
        "series_ids": torch.zeros(target.shape[:-1], dtype=torch.long, device=device),
    }
