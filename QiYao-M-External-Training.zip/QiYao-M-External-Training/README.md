# QiYao-M 外源训练（V11）

把之前 `train_joint_v11.py` 使用的训练路径整理为独立代码包。
不包含数据、模型权重或历史实验结果，不自动生成 bank、不自动校准权重、不启动远程任务。

## 推荐：只有 test_datainput、cleantrain 和外源数据三个文件夹

现在已支持这种简化结构，不需要再区分 earlier/previous/new 等历史批次。
编辑包内 `replay_config.simple.json`：

```json
{
  "test_input_data_dirs": ["/data/test_datainput"],
  "clean_data_dirs": ["/data/cleantrain"],
  "test_input_ratio": 0.3,
  "clean_ratio": 0.7,
  "cpm_max_span_patches": 4,
  "cpm_max_mask_probability": 0.4
}
```

然后运行：

```bash
CUDA_VISIBLE_DEVICES=0,1,2,3,4,5 NPROC_PER_NODE=6 \
bash start_external.sh \
  --internal-checkpoint /models/checkpoint-22000 \
  --bank-root /data/qiyaom_external_train \
  --replay-config ./replay_config.simple.json \
  --output-dir /data/output/qiyaom_external_simple \
  --max-steps 200000 --stop-after-steps 1000 \
  --loss-weights 0.6 0.1 0.3
```

`test_datainput` 和 `cleantrain` 必须是已生成 patch 级图文特征的 Zarr 数据目录，
不是原始 `test_data.input` Python 对象、Arrow/CSV 或只有数值的文件夹。
外源文件夹通过独立的 `--bank-root` 指定，必须完成之前的五步生成流程。

简化模式把所有测试历史合成一个 replay 组，按 30% 测试历史 + 70% clean 分配样本，
逐 batch 采用累计配额取整，避免小数截断造成长期比例偏移。
不再强制把测试历史拆成 TIME 20% 和 GIFT 10%，二者在合并目录中的占比由现有数据决定。
这是 replay 的**采样比例**，与 `--loss-weights` 的 replay **损失权重 0.6** 不同。
原五字段配置仍兼容；如需区分 TIME/GIFT 的独立比例，继续使用原配置方式。

## 1. 需要准备什么

1. **内源 checkpoint**：例如内源 `checkpoint-22000`，包含 `config.json`、`model.safetensors`
   （或 safetensors 分片及索引）、`layer16_concat_additive_state.pt`。
2. **外源训练 bank**：之前 `QiYao-M-External-Data-Generator` 五步流程全部完成的输出。
   不能只提供序列级检索 key；还必须有 query 历史的 patch 图文特征以及 V11 校准结果。
3. **Replay 数据**：之前内源训练用的 patch 级多模态 Zarr 数据，或对应路径配置。
   外源 bank 和 replay 数据是两类输入，不要混为一个参数。

训练时直接读取已有特征，因此 **不需要加载 CLIP，也不需要 TS 检索编码器权重**。
数值骨干、内源模块和外源模块代码均已内置，不需要安装 `/home/toto-main`。

## 2. 环境

先激活已有 CUDA Torch 环境，参考之前 207 的 `toto2mm`（Torch 2.4.1）。
已有环境不要盲目升级；新环境自行安装匹配驱动的 Torch wheel，再运行：

```bash
pip install -r requirements.txt
```

V11 使用 PyTorch **AdamW**，不是 NorMuon/Dion；本训练路径不构造 Dion 优化器。
推荐 Python 3.11。本次未重新在完整 CUDA 环境安装依赖验证。

## 3. 直接启动命令

进入解压后的本目录。`start_external.sh` 只是一个 torchrun 启动命令，参数直接传给 `train_external.py`。

### 简单方式：指定 replay 数据路径

```bash
CUDA_VISIBLE_DEVICES=0,1,2,3,4,5 NPROC_PER_NODE=6 \
bash start_external.sh \
  --internal-checkpoint /models/checkpoint-22000 \
  --bank-root /data/qiyaom_external_train \
  --replay-data-dir /data/qiyaom_endogenous_train \
  --output-dir /data/output/qiyaom_external_v11 \
  --batch-size 512 \
  --old-batch-size 224 \
  --stage1-steps 500 \
  --max-steps 200000 \
  --stop-after-steps 1000 \
  --save-steps 500 \
  --external-lr 1e-4 5e-5 \
  --head-lr 2e-5 5e-6 \
  --warmup-steps 500 \
  --weight-decay 0.01 \
  --max-grad-norm 1.0 \
  --loss-weights 0.6 0.1 0.3 \
  --seed 260912
```

这个例子**运行到第 1000 步停止**，但学习率仍使用 200000 步的原余弦计划；
不是把整个余弦周期压缩到 1000 步。需要继续跑更长的新实验时改 `--stop-after-steps`。
本整理版只支持全新运行，不实现历史中间断点的完整 optimizer/RNG 恢复；输出目录必须是新的。

`--replay-data-dir` 可接多个数据根目录。此模式把这些存储作为一个 shuffled-cycle 数据流，
**不保证原来的 TIME/GIFT/clean 20/10/70 比例**。严格复现原比例应使用下一种方式。
路径下应有 `block-*.zarr` 或 `block-*/block-*.rank-*.zarr`；有 `generation/` 时会选该目录。
请明确选 merged 或 rank 输出中的一份，别把相同数据两份重复传入。

### 复现原 replay 混合比例

把 `replay_config.example.json` 的路径改为实际数据路径，然后将上面命令的
`--replay-data-dir ...` 替换为：

```bash
--replay-config /data/configs/replay_config.json
```

也可以直接使用内源 checkpoint 中原来的 `training_args.json`，但必须先修正里面的旧服务器数据路径。
不传两种 replay 参数时，默认读取 `--internal-checkpoint/training_args.json`；缺失就报错，不会静默跳过 replay。
两种方式不能同时传。

配置模式沿用原数据流及 TIME/GIFT/clean 比例，GIFT 内部保持已有数据的自然 short/medium/long 分布。
配置里的 `gift_*_ratio` 为兼容原构造函数保留，不额外强制重采样到这些 horizon 比例。
使用原测试历史适配数据时，要如实披露 transductive/test-history adaptation，不能称为严格未接触测试数据的 zero-shot。

### 单卡与 GPU 编号

不设置 `NPROC_PER_NODE` 默认 **1 个进程**，不自动占满 GPU。
例如只使用物理卡 3：

```bash
CUDA_VISIBLE_DEVICES=3 NPROC_PER_NODE=1 bash start_external.sh [上述训练参数]
```

也可以直接 `CUDA_VISIBLE_DEVICES=3 python train_external.py ...`。GPU 编号由 `CUDA_VISIBLE_DEVICES` 选，
`NPROC_PER_NODE` 是卡数/进程数，不是编号。此 sh 是单机多卡入口；不应直接拿去启动多机。

## 4. 数据检查（不启动训练）

```bash
python train_external.py \
  --internal-checkpoint /models/checkpoint-22000 \
  --bank-root /data/qiyaom_external_train \
  --replay-data-dir /data/qiyaom_endogenous_train \
  --output-dir /data/output/qiyaom_external_check \
  --check-data
```

只做 CPU 元数据预检查、不创建训练输出：检查 checkpoint 必需文件、全部 bank 完成标记、
patch token/scale 形状、校准候选及权重、可用来源数、replay 块及可分片的 chunk 数。
它不是完整数组校验，也不证明 GPU 前反向已跑通。

外源数据结构：

```text
qiyaom_external_train/
  source_registry.json
  sources/<source_hash>/
    .complete
    bank_arrays.npz
    records.jsonl
    mined_candidates.npz
    source_weight.json
    internal_patch_tokens.zarr/
    .internal_patch_tokens_complete
  calibration_v11/<source_hash>.npz
```

`mined_candidates.npz` 和根部 `source_weight.json` 是原 sampler 的兼容输入；
最终候选及离线权重读取 `calibration_v11/`，不是沿用占位均匀权重。
本包不重新搜索 TopK 或重算离线权重。

## 5. 默认训练逻辑与参数

| 项目 | 默认设置 |
|---|---|
| 内源骨干/融合层 | 全程冻结，eval 模式 |
| 第 1–500 步 | 只训练外源 TargetEncoder、5 层 relation cross-attention 等参数 |
| 第 501 步起 | 继续训练外源模块，同时解冻共享输出 head |
| 外源初始化 | 残差输出投影置零，初始不改变内部预测隐状态；learnable null key + zero null value |
| Query 历史 | 8192 点，patch=32，原 CPM query 路径，不新增尺度回填 |
| Future 存储 | 192 点/6 patch，实际 query horizon 和缺失有效性由 mask 限制 |
| 每卡外源 batch | **512 = 16 个不同来源 × 每来源 32 条 query** |
| 每卡 replay batch | 224 |
| 候选 | 已离线生成的 per-modality Top10 union → final24 |
| 优化器 | fused AdamW，默认 betas=(0.9,0.999)，eps=1e-8，weight_decay=0.01 |
| 外源 LR | 1e-4 → 5e-5，独立余弦衰减 |
| 共享 head LR | 解冻后 2e-5 → 5e-6，独立 warmup/余弦 |
| warmup | 两个参数组各自启动后 500 步 |
| 损失 | 阶段1只有外源预测 pinball；阶段2为 0.6 replay + 0.1 bank-query 内源 + 0.3 bank-query 外源 |
| 损失归约 | 跨卡 global valid masked patch mean；每个非空 patch 内先按有效点平均 |
| 数值精度 | FP32；未提供 bf16 混合精度开关 |

采样器保持原版固定 16×32 逻辑，所以 **`--batch-size` 目前只能为 512**；
显存不足不能只把它改为 64，应先改 sampler 并另行验证。`--old-batch-size` 可调整。
`--loss-weights`、两组 LR、warmup、保存频率等可传参，不再写死在脚本里。
更改这些参数得到的是新实验配置，不应声称与原 checkpoint-1000 的数值完全相同。

## 6. 输出和推理使用

```text
output/
  training_args.json
  checkpoint-500/
    external_rag_state.pt
    external_rag_config.json
    shared_head_state.pt
    training_state.pt
    .checkpoint_complete
  checkpoint-1000/...
```

内源 checkpoint 不在每个保存点重复拷贝。推理时仍需提供原内源目录，
再加载 `external_rag_state.pt` 和对应 `shared_head_state.pt`。
只用内源 checkpoint 自带的 head，不等于这里联合训练后的共享 head。
保存的 training_state 用于记录 optimizer 状态；不要据此误以为本入口已实现严格断点续训。

## 7. 调用关系和验证范围

```text
start_external.sh
  → torchrun train_external.py（参数解析、预检查）
    → v11_training.py（原V11训练循环，两阶段）
      → bank_sampler.py（原16来源采样、V11离线候选/权重）
      → external_model.py（候选future编码、relation cross-attention）
      → cpm_features.py + qiyaom/（冻结内源特征）
      → replay_data.py + load_replay_zarr.py（旧数据与CPM）
```

历史的 V4/V7/V8 导入链已折叠为上述模块，不需要运行旧测试、评测或监控脚本。
`reference/` 保留原 V11 相关源文件便于核对，但运行时不导入它们。

测试：`python -m unittest discover -s tests -p test_local.py -v`。
另有 `python tests/check_torch.py` 检查小型外源模块前反向，需实际 Torch 环境。
验证范围见 `VALIDATION.md`；本次未启动 207 训练，也未验证完整多卡训练结果。
