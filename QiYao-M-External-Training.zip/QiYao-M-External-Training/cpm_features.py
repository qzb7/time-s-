import math
import torch

@torch.no_grad()
def forecast_cpm_hidden(self,target,target_mask,image_tokens,text_tokens,horizon,
                        has_missing_values=True,scaler_fallback_min_obs=0,forecast_patch_mask=None):
    if scaler_fallback_min_obs:raise ValueError('CPM parity forbids extra scale backfill')
    patch=self.patch_size;L=target.shape[-1];P=math.ceil(horizon/patch)
    if L%patch:raise ValueError('History must be patch aligned')
    if forecast_patch_mask is None:
        forecast_patch_mask=torch.ones(target.shape[:-2]+(P,),dtype=torch.bool,device=target.device)
    active=forecast_patch_mask.to(device=target.device,dtype=torch.bool)
    if active.shape!=target.shape[:-2]+(P,):raise ValueError('Invalid forecast patch mask')
    data=torch.cat([target,torch.zeros(target.shape[:-1]+(P*patch,),device=target.device,dtype=target.dtype)],-1)
    valid=torch.cat([target_mask,torch.zeros(target_mask.shape[:-1]+(P*patch,),device=target.device,dtype=torch.bool)],-1)
    # True = visible. Unknown active future = masked; inactive future = padding.
    cpm=torch.ones_like(valid)
    cpm[...,L:]=~active.unsqueeze(-2).expand(target.shape[:-1]+(P,)).repeat_interleave(patch,-1)
    x,loc,scale=self._time_embed(data,valid,cpm)
    sid=torch.zeros(data.shape[:-1],dtype=torch.long,device=data.device)
    groups=self._group_ids(valid,cpm,sid,x.shape[-2])
    image=torch.cat([image_tokens,torch.zeros(image_tokens.shape[:-2]+(P,image_tokens.shape[-1]),device=image_tokens.device,dtype=image_tokens.dtype)],-2)
    text=torch.cat([text_tokens,torch.zeros(text_tokens.shape[:-2]+(P,text_tokens.shape[-1]),device=text_tokens.device,dtype=text_tokens.dtype)],-2)
    visible=cpm.unflatten(-1,(x.shape[-2],patch)).any(-1)
    h=self._encode(x,groups,image,text,visible,has_missing_values)
    return h[...,L//patch-1:L//patch-1+P,:],loc[...,L:].unflatten(-1,(P,patch)),scale[...,L:].unflatten(-1,(P,patch))
