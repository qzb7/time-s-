"""Replay configuration parsing and deterministic two-group batch quotas."""
import json
import math
from pathlib import Path


def load_replay_config(path, span=4, probability=.4):
    cfg = json.loads(Path(path).read_text())
    cfg.setdefault('cpm_max_span_patches', span)
    cfg.setdefault('cpm_max_mask_probability', probability)
    if 'test_input_data_dirs' in cfg:
        for key in ['test_input_data_dirs', 'clean_data_dirs']:
            if not isinstance(cfg.get(key), list) or not cfg[key] or any(not isinstance(v, str) or not v for v in cfg[key]):
                raise ValueError(f'{key} must be a nonempty list of paths')
        cfg.setdefault('test_input_ratio', .3)
        cfg.setdefault('clean_ratio', 1. - cfg['test_input_ratio'])
        ratios = [cfg['test_input_ratio'], cfg['clean_ratio']]
        if any(not math.isfinite(v) or not 0 <= v <= 1 for v in ratios) or not math.isclose(sum(ratios), 1.):
            raise ValueError('test_input_ratio + clean_ratio must equal 1, with nonnegative finite ratios')
        test = {str(Path(p).expanduser().resolve()) for p in cfg['test_input_data_dirs']}
        clean = {str(Path(p).expanduser().resolve()) for p in cfg['clean_data_dirs']}
        if test & clean:
            raise ValueError('Do not put the same directory in both replay groups')
    return cfg


def two_group_counts(step, batch_size, test_ratio):
    test = round((step + 1) * batch_size * test_ratio) - round(step * batch_size * test_ratio)
    return test, batch_size - test
