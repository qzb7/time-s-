import numpy as np
import torch
from qiyaom import EndoMultimodalPredictor

def masked_patch_sum_count(point_loss, point_mask):
    """Return differentiable sum of patch means and count of nonempty patches.

    The last axis is points within a patch. Quantiles have already been averaged.
    """
    mask=point_mask.bool()
    counts=mask.sum(-1)
    patch_loss=torch.where(mask,point_loss,torch.zeros_like(point_loss)).sum(-1,dtype=torch.float32)/counts.clamp_min(1)
    return patch_loss.sum(),(counts>0).sum(dtype=torch.float32)

def to_device(batch, device):
    out = {}
    for key, value in batch.items():
        if isinstance(value, np.ndarray):
            out[key] = torch.from_numpy(value).to(device, non_blocking=True)
        else:
            out[key] = value
    return out
