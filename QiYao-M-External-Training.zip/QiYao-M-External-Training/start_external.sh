#!/usr/bin/env bash
set -euo pipefail
# Activate the desired Python environment first. NPROC_PER_NODE is a COUNT.
python -m torch.distributed.run \
  --standalone --nproc_per_node="${NPROC_PER_NODE:-1}" \
  "$(dirname "$0")/train_external.py" "$@"
