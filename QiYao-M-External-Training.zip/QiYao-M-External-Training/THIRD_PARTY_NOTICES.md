# Sources and licenses

Training logic is reorganized from the user's previously retrieved V11 source
snapshot (`rag_v11_review/`), not from an invented new training recipe.
External attention, candidate packing, CPM query features, global patch loss,
and the old natural replay mix were extracted with their original formulas.
`reference/` contains the relevant historical source files for auditing only.

`qiyaom/`, `dd_unit_scaling/` and the Apache license are copied from the
previous QiYao-M-Endogenous-Training delivery. The numerical backbone and unit
scaling components include Datadog software. Original notices are retained.
No model weights, observations, tokens or server credentials are bundled.
