import ast
import importlib.util
import json
import os
from pathlib import Path
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from train_external import parse_args, preflight
from replay_config import load_replay_config, two_group_counts


def definition(path, name):
    return next(n for n in ast.parse(path.read_text()).body if getattr(n, 'name', '') == name)


class LocalTests(unittest.TestCase):
    def test_two_group_config(self):
        cfg = load_replay_config(ROOT / 'replay_config.simple.json')
        self.assertEqual(cfg['test_input_ratio'], .3)
        counts = [two_group_counts(i, 224, .3) for i in range(100)]
        self.assertTrue(all(a + b == 224 for a, b in counts))
        self.assertEqual(sum(a for a, b in counts), 6720)
        self.assertEqual(two_group_counts(0, 224, 0), (0, 224))
        self.assertEqual(two_group_counts(0, 224, 1), (224, 0))

    def test_two_group_config_invalid(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / 'config.json'
            cfg = dict(test_input_data_dirs=['/data/test'], clean_data_dirs=['/data/clean'],
                       test_input_ratio=.3, clean_ratio=.8)
            path.write_text(json.dumps(cfg))
            with self.assertRaises(ValueError):
                load_replay_config(path)
            cfg.update(clean_ratio=.7, clean_data_dirs=['/data/test'])
            path.write_text(json.dumps(cfg))
            with self.assertRaises(ValueError):
                load_replay_config(path)

    def test_two_group_stream_without_torch(self):
        # Exercise only the dataset's Python iteration, without pretending to test Torch.
        source = (ROOT / 'replay_data.py').read_text()
        tree = ast.parse(source)
        cls = next(n for n in tree.body if getattr(n, 'name', '') == 'TwoGroupReplayDataset')
        scope = dict(IterableDataset=object, two_group_counts=two_group_counts)
        exec(compile(ast.Module(body=[cls], type_ignores=[]), 'dataset-iteration-fixture', 'exec'), scope)
        def fixture(paths, seed):
            while True:
                yield dict(path=paths[0], seed=seed)
        ds = scope['TwoGroupReplayDataset'](fixture, ['test'], ['clean'], 224, .3, 7)
        from itertools import islice
        rows = list(islice(iter(ds), 22400))
        self.assertEqual(sum(r['mix_group'] == 'test_input' for r in rows), 6720)
        self.assertEqual(sum(r['mix_group'] == 'clean' for r in rows), 15680)
        self.assertTrue(all(r['path'] == ('test' if r['mix_group'] == 'test_input' else 'clean') for r in rows))
    def args(self, extra=()):
        return parse_args(['--internal-checkpoint', '/tmp/internal', '--bank-root', '/tmp/bank',
                           '--output-dir', '/tmp/qiyaom-external-unused-test-output', *extra])

    def test_defaults(self):
        a = self.args()
        self.assertEqual(a.stage1_steps, 500)
        self.assertEqual(a.loss_weights, [.6, .1, .3])
        self.assertEqual(a.stop_after_steps, a.max_steps)
        self.assertEqual(a.external_lr, [1e-4, 5e-5])
        self.assertEqual(a.head_lr, [2e-5, 5e-6])

    def test_stop_does_not_change_schedule(self):
        a = self.args(['--stop-after-steps', '1000'])
        self.assertEqual(a.max_steps, 200000)
        self.assertEqual(a.stop_after_steps, 1000)

    def test_invalid_batch_rejected(self):
        with self.assertRaises(SystemExit):
            self.args(['--batch-size', '64'])

    def test_output_not_overwritten(self):
        with tempfile.TemporaryDirectory() as tmp:
            with self.assertRaises(SystemExit):
                self.args(['--output-dir', tmp])
            self.args(['--output-dir', tmp, '--check-data'])

    def test_preserved_mechanisms(self):
        for file, source, names in [
            ('external_model.py', 'external_relation_v11.py', ['RelationAttention', 'ExternalRAG']),
            ('cpm_features.py', 'cpm_rag_v7.py', ['forecast_cpm_hidden']),
            ('bank_sampler.py', 'sampler16_v8.py', ['SixteenSourceSampler']),
            ('bank_sampler.py', 'sampler_v11.py', ['RelationSampler']),
        ]:
            for name in names:
                self.assertEqual(ast.dump(definition(ROOT / file, name)),
                                 ast.dump(definition(ROOT / 'reference' / source, name)))

    def test_no_remote_imports(self):
        for name in ['train_external.py', 'v11_training.py', 'bank_sampler.py',
                     'external_model.py', 'cpm_features.py', 'training_core.py']:
            text = (ROOT / name).read_text()
            ast.parse(text)
            self.assertNotIn('/home/', text)
        original = definition(ROOT / 'reference/train_joint_v11.py', 'rag_features')
        new = definition(ROOT / 'v11_training.py', 'rag_features')
        self.assertEqual(ast.dump(original), ast.dump(new))

    @unittest.skipUnless(importlib.util.find_spec('zarr'), 'Zarr required for metadata fixture')
    def test_preflight_requires_ready_calibration(self):
        import numpy as np
        import zarr
        import hashlib
        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp); model = base / 'model'; model.mkdir()
            for name in ['config.json', 'model.safetensors', 'layer16_concat_additive_state.pt']:
                (model / name).write_text('{}')
            bank = base / 'bank'; bank.mkdir(); (bank / 'calibration_v11').mkdir()
            sources = [dict(source_id=f'test/{i}/H') for i in range(16)]
            (bank / 'source_registry.json').write_text(json.dumps(dict(sources=sources)))
            for source in sources:
                slug = hashlib.sha1(source['source_id'].encode()).hexdigest()[:16]
                path = bank / 'sources' / slug; path.mkdir(parents=True)
                for name in ['.complete', '.internal_patch_tokens_complete', 'bank_arrays.npz',
                             'records.jsonl', 'mined_candidates.npz', 'source_weight.json']:
                    (path / name).write_text('metadata fixture only')
                np.savez(bank / 'calibration_v11' / (slug + '.npz'),
                         weights=np.ones(3), candidate_ids=np.full((2, 24), -1), eligible_query_ids=np.array([0]))
                g = zarr.open_group(str(path / 'internal_patch_tokens.zarr'), mode='w')
                for mod in ['image', 'text']:
                    g.create_dataset(f'{mod}_global_fp16', shape=(2, 256, 512), dtype='f2')
                    g.create_dataset(f'{mod}_scale', shape=(2, 256, 1), dtype='f4')
            replay = base / 'replay'; replay.mkdir()
            g = zarr.open_group(str(replay / 'block-000000.zarr'), mode='w')
            for field in ['time_series_8192', 'target_mask_8192', 'image_global_fp16', 'image_scale', 'text_global_fp16', 'text_scale']:
                dims = (256, 512) if 'fp16' in field else (256, 1) if 'scale' in field else (8192,)
                g.create_dataset(field, shape=(4,) + dims, chunks=(1,) + dims, dtype='f4')
            a = parse_args(['--internal-checkpoint', str(model), '--bank-root', str(bank),
                            '--replay-data-dir', str(replay), '--output-dir', str(base / 'out'), '--check-data'])
            self.assertEqual(preflight(a)['usable_sources'], 16)
            cal = next((bank / 'calibration_v11').glob('*.npz'))
            cal.unlink()  # Only a synthetic fixture inside TemporaryDirectory.
            with self.assertRaises(FileNotFoundError):
                preflight(a)


if __name__ == '__main__':
    unittest.main()
