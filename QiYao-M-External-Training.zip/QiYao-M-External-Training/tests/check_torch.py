"""Optional actual CPU forward/backward check; requires Torch. No real weights."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import torch
from external_model import ExternalRAG

torch.set_num_threads(1)
torch.manual_seed(3)
model = ExternalRAG(d_model=16, heads=2)
h = torch.randn(2, 6, 16)
target = torch.randn(2, 3, 6, 64)
valid = torch.ones(2, 3, dtype=torch.bool)
patch = torch.ones(2, 3, 6, dtype=torch.bool)
querymask = torch.ones(2, 6, dtype=torch.bool)
qargs = [h, torch.zeros(2, 3, 512), torch.zeros(2, 3, 512), torch.zeros(2, 3, 1024),
         target, torch.rand(2, 3, 3), torch.ones(2, 3), torch.ones(2, 3), valid, patch, querymask]
y = model(*qargs)
torch.testing.assert_close(y, h)  # zero-initialized residual projections
(y - 1).square().mean().backward()
assert all(torch.isfinite(p.grad).all() for p in model.parameters() if p.grad is not None)
assert model.layers[0].out_proj.weight.grad.abs().sum() > 0
print('EXTERNAL_CPU_FORWARD_BACKWARD_OK')
