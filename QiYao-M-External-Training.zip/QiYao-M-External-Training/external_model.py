import math
import torch
from torch import nn

class TargetEncoder(nn.Module):
    def __init__(self,d):
        super().__init__()
        self.skip=nn.Linear(64,d);self.norm=nn.LayerNorm(64)
        self.fc1=nn.Linear(64,4*d);self.fc2=nn.Linear(4*d,d)
    def forward(self,x):
        return self.skip(x)+self.fc2(torch.nn.functional.gelu(self.fc1(self.norm(x))))

class RelationAttention(nn.Module):
    def __init__(self,d,heads):
        super().__init__();self.heads=heads;self.hd=d//heads
        self.q_norm=nn.LayerNorm(d);self.kv_norm=nn.LayerNorm(d)
        self.q_proj=nn.Linear(d,d);self.k_proj=nn.Linear(d,d);self.v_proj=nn.Linear(d,d)
        self.relation=nn.Sequential(nn.Linear(4,128),nn.GELU(),nn.Linear(128,d))
        self.modality_type=nn.Embedding(2,d)
        self.null_key=nn.Parameter(torch.zeros(heads,self.hd))
        # No bias or FFN: choosing only null cannot change the internal hidden.
        self.out_proj=nn.Linear(d,d,bias=False)
        nn.init.zeros_(self.out_proj.weight)

    def forward(self,h,target,relation,other,valid,qmask):
        b,p,d=h.shape;k=target.shape[1]
        q=self.q_proj(self.q_norm(h)).reshape(b,p,self.heads,self.hd)
        content=self.kv_norm(target)
        rel=self.relation(relation)+self.modality_type(other)
        key=(self.k_proj(content)+rel[:,:,None]).reshape(b,k,p,self.heads,self.hd)
        value=self.v_proj(content).reshape(b,k,p,self.heads,self.hd)
        logits=torch.einsum('bphd,bkphd->bhpk',q,key)/math.sqrt(self.hd)
        logits=logits.masked_fill(~valid.permute(0,2,1)[:,None],-torch.inf)
        null=torch.einsum('bphd,hd->bhp',q,self.null_key)/math.sqrt(self.hd)
        att=torch.cat([logits,null[...,None]],-1).float().softmax(-1).to(h.dtype)
        delta=torch.einsum('bhpk,bkphd->bphd',att[...,:k],value).reshape(b,p,d)
        self.last_null_mass=att[...,-1].detach().mean()
        return h+self.out_proj(delta).masked_fill(~qmask[...,None],0)

class ExternalRAG(nn.Module):
    def __init__(self,d_model=1024,heads=16,num_layers=5):
        super().__init__();self.target_encoder=TargetEncoder(d_model)
        self.layers=nn.ModuleList([RelationAttention(d_model,heads) for _ in range(num_layers)])
    def forward(self,query,image_key,text_key,ts_key,candidate_target_input,
                cosine_similarity,source_weight,temperature,candidate_mask,
                candidate_patch_mask,forecast_patch_mask):
        # Stored modality order: image, text, TS. Raw target content enters V.
        w=source_weight/source_weight.sum(-1,keepdim=True).clamp_min(1e-12)
        s=cosine_similarity.clamp(-1,1)
        other=(w[:,None,:2]*((s[:,:,:2]+1)/2)).argmax(-1)
        wo=w[:,None,:2].expand(-1,s.shape[1],-1).gather(-1,other[...,None])[...,0]
        so=s[:,:,:2].gather(-1,other[...,None])[...,0]
        relation=torch.stack([w[:,2,None].expand_as(wo),s[:,:,2],wo,so],-1)
        valid=candidate_mask.bool()[...,None]&candidate_patch_mask.bool()
        target=self.target_encoder(candidate_target_input.masked_fill(~valid[...,None],0)).masked_fill(~valid[...,None],0)
        h=query
        for layer in self.layers:h=layer(h,target,relation,other,valid,forecast_patch_mask.bool())
        return h.masked_fill(~forecast_patch_mask[...,None].bool(),0)
