#!/usr/bin/env python3
"""QiYao-M V11 external training: explicit paths, local modules, no hidden jobs."""
import argparse
import json
import math
import os
from pathlib import Path


def parse_args(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--internal-checkpoint', required=True)
    p.add_argument('--bank-root', required=True)
    p.add_argument('--output-dir', required=True)
    replay = p.add_mutually_exclusive_group()
    replay.add_argument('--replay-data-dir', nargs='+', help='Explicit replay Zarr roots; uniform shuffled cycling')
    replay.add_argument('--replay-config', help='Simple test_input/clean JSON or original endogenous training_args.json')
    p.add_argument('--batch-size', type=int, default=512, help='Fixed 16 sources x 32 queries per rank')
    p.add_argument('--old-batch-size', type=int, default=224)
    p.add_argument('--stage1-steps', type=int, default=500)
    p.add_argument('--max-steps', type=int, default=200000, help='Cosine schedule endpoint')
    p.add_argument('--stop-after-steps', type=int, help='Stop early without changing LR schedule endpoint')
    p.add_argument('--save-steps', type=int, default=500)
    p.add_argument('--external-lr', type=float, nargs=2, default=[1e-4, 5e-5], metavar=('PEAK', 'MIN'))
    p.add_argument('--head-lr', type=float, nargs=2, default=[2e-5, 5e-6], metavar=('PEAK', 'MIN'))
    p.add_argument('--warmup-steps', type=int, default=500)
    p.add_argument('--weight-decay', type=float, default=.01)
    p.add_argument('--max-grad-norm', type=float, default=1.)
    p.add_argument('--loss-weights', type=float, nargs=3, default=[.6, .1, .3], metavar=('REPLAY', 'INTERNAL', 'EXTERNAL'))
    p.add_argument('--cpm-max-span-patches', type=int, default=4)
    p.add_argument('--cpm-max-mask-probability', type=float, default=.4)
    p.add_argument('--seed', type=int, default=260912)
    p.add_argument('--device', default='auto', choices=['auto', 'cuda', 'npu', 'cpu'],
                   help='auto picks NPU then CUDA; cpu is for tiny verification models only')
    p.add_argument('--check-data', action='store_true', help='CPU metadata preflight only; no training/output')
    a = p.parse_args(argv)
    a.stop_after_steps = a.max_steps if a.stop_after_steps is None else a.stop_after_steps
    a.probe = False
    if a.batch_size != 512:
        p.error('The original V11 sampler requires --batch-size 512 (16 x 32)')
    if min(a.old_batch_size, a.max_steps, a.stop_after_steps, a.save_steps, a.cpm_max_span_patches) < 1:
        p.error('Counts must be positive')
    if not 0 <= a.stage1_steps <= a.max_steps or a.stop_after_steps > a.max_steps or a.warmup_steps < 0:
        p.error('Invalid stage, stop, or warmup steps')
    for peak, floor in [a.external_lr, a.head_lr]:
        if not all(math.isfinite(x) for x in [peak, floor]) or not 0 <= floor <= peak or peak <= 0:
            p.error('Require 0 <= minimum LR <= positive peak LR')
    if any(not math.isfinite(w) or w < 0 for w in a.loss_weights) or a.loss_weights[2] <= 0:
        p.error('Loss weights must be finite, nonnegative, and external loss positive')
    if not math.isfinite(a.max_grad_norm) or a.max_grad_norm <= 0 or not math.isfinite(a.weight_decay) or a.weight_decay < 0:
        p.error('Invalid gradient norm or weight decay')
    if not 0 < a.cpm_max_mask_probability <= 1:
        p.error('Invalid CPM mask probability')
    for key in ['internal_checkpoint', 'bank_root', 'output_dir']:
        setattr(a, key, str(Path(getattr(a, key)).expanduser().resolve()))
    if a.replay_data_dir:
        a.replay_data_dir = [str(Path(x).expanduser().resolve()) for x in a.replay_data_dir]
    else:
        a.replay_config = str(Path(a.replay_config or Path(a.internal_checkpoint) / 'training_args.json').expanduser().resolve())
    if not a.check_data and Path(a.output_dir).exists():
        p.error('Fresh runs require a NEW --output-dir. Full optimizer/RNG resume is not implemented here.')
    return a


def preflight(a):
    """Inspect all source markers and replay chunks before allocating any GPU."""
    import hashlib
    import numpy as np
    import zarr
    model = Path(a.internal_checkpoint)
    for name in ['config.json', 'layer16_concat_additive_state.pt']:
        if not (model / name).is_file():
            raise FileNotFoundError(model / name)
    index = model / 'model.safetensors.index.json'
    weight_files = (set(json.loads(index.read_text())['weight_map'].values()) if index.is_file()
                    else ['model.safetensors'])
    for name in weight_files:
        if not (model / name).is_file():
            raise FileNotFoundError(model / name)
    root = Path(a.bank_root)
    sources = json.loads((root / 'source_registry.json').read_text())['sources']
    usable = 0
    for source in sources:
        slug = hashlib.sha1(source['source_id'].encode()).hexdigest()[:16]
        path = root / 'sources' / slug
        for name in ['.complete', '.internal_patch_tokens_complete', 'bank_arrays.npz',
                     'records.jsonl', 'mined_candidates.npz', 'source_weight.json']:
            if not (path / name).is_file():
                raise FileNotFoundError(path / name)
        with np.load(root / 'calibration_v11' / (slug + '.npz'), allow_pickle=False) as cal:
            if cal['candidate_ids'].ndim != 2 or cal['candidate_ids'].shape[1] != 24:
                raise ValueError(f'{slug}: V11 requires 24 candidate positions')
            if cal['weights'].shape != (3,) or not np.isfinite(cal['weights']).all() or cal['weights'].sum() <= 0:
                raise ValueError(f'{slug}: invalid offline weights')
            if len(cal['eligible_query_ids']):
                usable += 1
        group = zarr.open_group(str(path / 'internal_patch_tokens.zarr'), mode='r')
        for mod in ['image', 'text']:
            if group[f'{mod}_global_fp16'].shape[1:] != (256, 512):
                raise ValueError(f'{slug}: incompatible patch tokens')
            if group[f'{mod}_scale'].shape != group[f'{mod}_global_fp16'].shape[:-1] + (1,):
                raise ValueError(f'{slug}: incompatible patch scales')
    if usable < 16:
        raise ValueError(f'Need 16 usable distinct sources, found {usable}')
    cfg = None
    if a.replay_data_dir:
        replay_roots = a.replay_data_dir
    else:
        from replay_config import load_replay_config
        cfg = load_replay_config(a.replay_config, a.cpm_max_span_patches, a.cpm_max_mask_probability)
        if 'test_input_data_dirs' in cfg:
            replay_roots = [*cfg['test_input_data_dirs'], *cfg['clean_data_dirs']]
        else:
            replay_roots = [*cfg['clean_data_dirs'], *cfg['earlier_context_data_dirs'],
                            cfg['previous_targeted_data_dir'], cfg['new_targeted_data_dir'], cfg['time_test_data_dir']]
            if not math.isclose(sum(cfg[k] for k in ['time_test_ratio', 'gifteval_test_ratio', 'clean_ratio']), 1.):
                raise ValueError('Replay source ratios must sum to 1')
    world = int(os.getenv('WORLD_SIZE', '1'))
    for entry in replay_roots:
        path = Path(entry)
        if (path / 'generation').is_dir():
            path = path / 'generation'
        blocks = sorted(path.glob('block-*.zarr')) + sorted(path.glob('block-*/block-*.rank-*.zarr'))
        if not blocks:
            raise FileNotFoundError(f'No replay block stores under {path}')
        chunks = 0
        for block in blocks:
            g = zarr.open_group(str(block), mode='r')
            for key in ['time_series_8192', 'target_mask_8192', 'image_global_fp16', 'image_scale', 'text_global_fp16', 'text_scale']:
                if key not in g:
                    raise ValueError(f'Missing {block}/{key}')
            if g['time_series_8192'].shape[1:] != (8192,):
                raise ValueError('Replay history must be 8192 points')
            n = int(g.attrs.get('written_count', len(g['time_series_8192'])))
            if not 0 < n <= len(g['time_series_8192']):
                raise ValueError(f'{block}: invalid written_count')
            for mod in ['image', 'text']:
                if g[f'{mod}_global_fp16'].shape[1:] != (256, 512) or g[f'{mod}_scale'].shape[1:] != (256, 1):
                    raise ValueError(f'{block}: incompatible replay patch features')
            chunks += math.ceil(n / g['time_series_8192'].chunks[0])
        if chunks < world:
            raise ValueError(f'{path}: too few chunks for {world} ranks; loader could stall')
    return dict(sources=len(sources), usable_sources=usable, replay_roots=replay_roots,
                replay_mode=('custom_data' if cfg is None else 'test_input_clean' if 'test_input_data_dirs' in cfg else 'original_config'), world_size=world,
                note='Metadata inspection only; no GPU forward/backward verification')


def main():
    a = parse_args()
    report = preflight(a)
    if int(os.getenv('RANK', '0')) == 0:
        print(json.dumps(dict(event='preflight', **report)), flush=True)
    if a.check_data:
        return
    # Imports that need Torch are deferred so --help works without an ML environment.
    from v11_training import main as train
    train()


if __name__ == '__main__':
    main()
