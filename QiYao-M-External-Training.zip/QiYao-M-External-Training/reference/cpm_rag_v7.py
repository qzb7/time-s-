"""Exact endogenous CPM query path and eight-source sampling. No launch side effects."""
import math
import numpy as np
import torch
from train_external_rag_residual5_targetkv_v4 import SourceBankSampler

@torch.no_grad()
def forecast_cpm_hidden(self,target,target_mask,image_tokens,text_tokens,horizon,
                        has_missing_values=True,scaler_fallback_min_obs=0,forecast_patch_mask=None):
    if scaler_fallback_min_obs:raise ValueError('CPM parity forbids extra scale backfill')
    patch=self.patch_size;L=target.shape[-1];P=math.ceil(horizon/patch)
    if L%patch:raise ValueError('History must be patch aligned')
    if forecast_patch_mask is None:
        forecast_patch_mask=torch.ones(target.shape[:-2]+(P,),dtype=torch.bool,device=target.device)
    active=forecast_patch_mask.to(device=target.device,dtype=torch.bool)
    if active.shape!=target.shape[:-2]+(P,):raise ValueError('Invalid forecast patch mask')
    data=torch.cat([target,torch.zeros(target.shape[:-1]+(P*patch,),device=target.device,dtype=target.dtype)],-1)
    valid=torch.cat([target_mask,torch.zeros(target_mask.shape[:-1]+(P*patch,),device=target.device,dtype=torch.bool)],-1)
    # True = visible. Unknown active future = masked; inactive future = padding.
    cpm=torch.ones_like(valid)
    cpm[...,L:]=~active.unsqueeze(-2).expand(target.shape[:-1]+(P,)).repeat_interleave(patch,-1)
    x,loc,scale=self._time_embed(data,valid,cpm)
    sid=torch.zeros(data.shape[:-1],dtype=torch.long,device=data.device)
    groups=self._group_ids(valid,cpm,sid,x.shape[-2])
    image=torch.cat([image_tokens,torch.zeros(image_tokens.shape[:-2]+(P,image_tokens.shape[-1]),device=image_tokens.device,dtype=image_tokens.dtype)],-2)
    text=torch.cat([text_tokens,torch.zeros(text_tokens.shape[:-2]+(P,text_tokens.shape[-1]),device=text_tokens.device,dtype=text_tokens.dtype)],-2)
    visible=cpm.unflatten(-1,(x.shape[-2],patch)).any(-1)
    h=self._encode(x,groups,image,text,visible,has_missing_values)
    return h[...,L//patch-1:L//patch-1+P,:],loc[...,L:].unflatten(-1,(P,patch)),scale[...,L:].unflatten(-1,(P,patch))

class EightSourceSampler(SourceBankSampler):
    def sample(self,batch_size):
        if batch_size!=512:raise ValueError('v7 requires 8 sources x 64 = 512')
        pieces=[];report=[]
        for si in self.rng.permutation(len(self.sources)):
            source=self.sources[int(si)];bank=self._load(source)
            eligible=np.unique(bank['eligible_query_ids'])
            if not len(eligible):continue
            if len(eligible)>=64:qi=self.rng.choice(eligible,64,replace=False)
            else:
                qi=np.concatenate([self.rng.permutation(eligible),self.rng.choice(eligible,64-len(eligible),replace=True)])
                self.rng.shuffle(qi)
            pieces.append(self.pack(source,bank,qi))
            report.append(dict(source_id=source['source_id'],eligible=int(len(eligible)),count=64,unique=int(len(np.unique(qi))),repeats=int(64-len(np.unique(qi)))))
            if len(pieces)==8:break
        if len(pieces)!=8:raise RuntimeError('Fewer than 8 usable distinct sources')
        out={k:np.concatenate([p[k] for p in pieces],axis=0) for k in pieces[0]}
        out['source_id']=[r['source_id'] for r in report];out['sampling_report']=report
        self.last_report=report
        return out

    def pack(self,source,bank,qi):
        n=len(qi);ids=bank['candidate_ids'][qi].astype(np.int64);cm=ids>=0;safe=np.maximum(ids,0)
        h=bank['history_values'][qi].astype(np.float32);hm=bank['history_valid_mask'][qi].astype(bool)
        future=bank['future_values'][qi].astype(np.float32);fm=bank['future_valid_mask'][qi].astype(bool)
        lengths=bank['prediction_length'][qi]
        qpm=np.arange(6)[None]*32<lengths[:,None]
        target=np.concatenate([h,np.zeros((n,192),np.float32)],axis=1)
        labelmask=fm&(np.arange(192)[None]<lengths[:,None])
        mask=np.concatenate([hm,labelmask],axis=1)
        cpm=np.concatenate([np.ones_like(hm),np.repeat(~qpm,32,axis=-1)],axis=1)
        sims=np.stack([np.einsum('bd,bkd->bk',bank[k][qi],bank[k][safe]) for k in ['image_key','text_key','timeseries_key']],axis=-1).astype(np.float32)
        cfm=bank['bank_future_mask'][safe]&cm[...,None]
        return dict(target=target,target_mask=mask,cpm_mask=cpm,future=future,future_mask=fm,
            prediction_length=lengths,forecast_patch_mask=qpm,
            image=self._decode_internal_patch(bank,'image_global_fp16',qi),
            text=self._decode_internal_patch(bank,'text_global_fp16',qi),
            candidate_image=self._decode(bank,'image_token',safe),candidate_text=self._decode(bank,'text_token',safe),
            candidate_ts=self._decode(bank,'timeseries_token',safe),candidate_future=bank['future_values'][safe].astype(np.float32),
            candidate_future_mask=cfm,candidate_mask=cm,candidate_patch_mask=cfm.reshape(n,safe.shape[1],6,32).any(-1),
            similarity=sims,source_weight=np.repeat(bank['source_weight'][None],n,axis=0),
            temperature=np.repeat(bank['temperature'][None],n,axis=0),query_ids=qi)
