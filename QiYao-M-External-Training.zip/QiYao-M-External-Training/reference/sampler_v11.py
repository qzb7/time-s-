import numpy as np
from train_external_rag_residual5_targetkv_v4 import BaseSourceBankSamplerV3
from sampler16_v8 import SixteenSourceSampler

class RelationSampler(SixteenSourceSampler):
    def _load(self,source):
        bank=BaseSourceBankSamplerV3._load(self,source)
        if bank.get('_v11'):return bank
        with np.load(self.root/'calibration_v11'/(self._slug(source['source_id'])+'.npz')) as saved:
            for key in ['candidate_ids','temperature','eligible_query_ids']:bank[key]=saved[key]
            bank['source_weight']=saved['weights']
        for key in ['image_key','text_key','timeseries_key']:
            v=bank[key].astype(np.float32);bank[key]=v/np.maximum(np.linalg.norm(v,axis=-1,keepdims=True),1e-12)
        bank['_v11']=True
        return bank
