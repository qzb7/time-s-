"""Frozen endogenous backbone; staged shared-head / retrieval joint training."""
import argparse, json, os, time, math, random
from pathlib import Path
from types import SimpleNamespace
import numpy as np
import torch
import torch.distributed as dist
from torch.nn.parallel import DistributedDataParallel as DDP
from torch.utils.data import DataLoader
import zarr
import train_external_rag_residual5_targetkv_v4 as base
from load_toto2_multimodal_zarr import Toto2MultimodalZarrDataset
import pretrain_toto2_nonmetadata_natural_mix as old
from pretrain_toto2_short_balanced import toto_pinball_loss
from cpm_rag_v7 import forecast_cpm_hidden
from sampler_v11 import RelationSampler as SixteenSourceSampler
from external_relation_v11 import ExternalRAG

ROOT='/home/toto-main/output/toto2-313m-multimodal-layer16-nometadata-optresume-from14000-time20gift10clean70-natural/checkpoint-22000'
OUT='/home/toto-main/output/toto2-external-rag-grwmean-relation-null-v11-from22000'

class SourceDataset(Toto2MultimodalZarrDataset):
    def _read_chunk(self,path,left,right,order):
        g=zarr.open_group(str(path),mode='r')
        def texts(key):
            if key not in g:return ['']*(right-left)
            return [(v.decode() if isinstance(v,bytes) else str(v)).rstrip('\x00') for v in g[key][left:right]]
        terms,datasets=texts('source_term'),texts('source_dataset')
        for idx,row in zip(order,super()._read_chunk(path,left,right,order)):
            term,dataset=terms[int(idx)],datasets[int(idx)]
            if term.startswith('test_input_') and dataset.lower() in {'m4_yearly','m4_hourly'}:term='short'
            row.update(source_term=term,source_dataset=dataset,source_bank=path.parent.name)
            yield row

def make_loader(a):
    cfg=json.loads((Path(a.internal_checkpoint)/'training_args.json').read_text())
    def resolve(p):
        p=Path(p);return str(p/'generation' if (p/'generation').is_dir() else p)
    ds=old.TimeGiftCleanFixedHorizonDataset(SourceDataset,
        clean_dirs=[resolve(p) for p in cfg['clean_data_dirs']],
        earlier_context_dirs=[resolve(p) for p in cfg['earlier_context_data_dirs']],
        previous_targeted_dir=resolve(cfg['previous_targeted_data_dir']),
        new_targeted_dir=resolve(cfg['new_targeted_data_dir']),
        time_test_dir=resolve(cfg['time_test_data_dir']),batch_size=a.old_batch_size,
        source_ratios=(cfg['time_test_ratio'],cfg['gifteval_test_ratio'],cfg['clean_ratio']),
        gift_horizon_ratios=(cfg['gift_short_ratio'],cfg['gift_medium_ratio'],cfg['gift_long_ratio']),seed=a.seed)
    # This imported loader's actual iteration uses natural S/M/L, not quotas.
    return iter(DataLoader(ds,batch_size=a.old_batch_size,num_workers=0,pin_memory=True,drop_last=True)),cfg

def schedule(step,total,peak,floor,start=0,warmup=500):
    if step<start:return 0.
    n=step-start+1
    if n<=warmup:return peak*n/warmup
    progress=min(1.,(n-warmup)/max(1,total-start-warmup))
    return floor+(peak-floor)*.5*(1+math.cos(math.pi*progress))

def global_patch_loss(pred,wanted,mask,world):
    q=torch.arange(1,10,device=pred.device,dtype=pred.dtype).view(9,1,1,1,1)/10
    err=wanted[None]-pred
    point=torch.maximum(q*err,(q-1)*err).mean(0,dtype=torch.float32)
    s,n=base.masked_patch_sum_count(point,mask)
    count=n.detach().clone();logged=s.detach().clone()
    if world>1:dist.all_reduce(count);dist.all_reduce(logged)
    if count.item()==0:raise RuntimeError('No valid global future patches')
    return s*world/count,logged/count

def rag_loss(pred,wanted,mask,world):
    return global_patch_loss(pred,wanted[:,None],mask[:,None],world)

def cpm_loss(outputs,prepared,world):
    truth=torch.asinh((prepared['target']-outputs.loc)/outputs.scale).unflatten(-1,(256,32))[...,1:,:]
    valid=prepared['target_mask'].unflatten(-1,(256,32))[...,1:,:]&prepared['masked_patches'][...,1:,None]
    return global_patch_loss(outputs.quantiles[...,:-1,:],truth,valid,world)

@torch.no_grad()
def rag_features(model,batch):
    query,loc,scale=model.forecast_parallel_hidden(batch['target'][:,:8192,None].transpose(1,2),
        batch['target_mask'][:,:8192,None].transpose(1,2),batch['image'][:,None],batch['text'][:,None],
        horizon=192,forecast_patch_mask=batch['forecast_patch_mask'])
    target=torch.cat([model.normalize_known_target_patches(batch['candidate_future'][:,s:s+4],
        batch['candidate_future_mask'][:,s:s+4]) for s in range(0,batch['candidate_future'].shape[1],4)],dim=1)
    valid=batch['future_mask']&(torch.arange(192,device=query.device)[None]<batch['prediction_length'][:,None])
    wanted=torch.asinh((batch['future']-loc[:,0].flatten(-2))/scale[:,0].flatten(-2).clamp_min(1e-6)).unflatten(-1,(6,32))
    mask=valid.unflatten(-1,(6,32))&batch['forecast_patch_mask'][...,None]
    return query[:,0],target,wanted,mask

@torch.no_grad()
def old_features(model,batch,cfg,device):
    p=old.prepare_tail_first_batch(batch,device,patch_size=32,max_span_patches=cfg['cpm_max_span_patches'],max_mask_probability=cfg['cpm_max_mask_probability'])
    # Reproduce model.forward up to (but not through) output_head.
    x,loc,scale=model._time_embed(p['target'],p['target_mask'],p['cpm_mask'])
    n=x.shape[-2];visible=p['cpm_mask'].unflatten(-1,(n,32)).any(-1)
    groups=model._group_ids(p['target_mask'],p['cpm_mask'],p['series_ids'],n)
    h=model._encode(x,groups,batch['image_tokens'].to(device)[:,None],batch['text_tokens'].to(device)[:,None],visible)
    return h,loc,scale,p

def save(out,step,external,head,optim,a):
    ck=out/f'checkpoint-{step}';ck.mkdir(parents=True,exist_ok=False)
    torch.save(external.state_dict(),ck/'external_rag_state.pt')
    torch.save(head.state_dict(),ck/'shared_head_state.pt')
    torch.save(dict(optimizer=optim.state_dict(),step=step,scheduler=dict(step=step,policy='two_group_cosine',args=vars(a)),
        torch_rng_state=torch.get_rng_state(),cuda_rng_state=torch.cuda.get_rng_state_all()),ck/'training_state.pt')
    (ck/'external_rag_config.json').write_text(json.dumps(vars(a),indent=2))
    (ck/'.checkpoint_complete').write_text('ok\n')

def main():
    p=argparse.ArgumentParser();p.add_argument('--internal-checkpoint',default=ROOT);p.add_argument('--output-dir',default=OUT)
    p.add_argument('--bank-root',default='/public_data/toto2_external_rag_longhistory_v10')
    p.add_argument('--batch-size',type=int,default=512);p.add_argument('--old-batch-size',type=int,default=224)
    p.add_argument('--max-steps',type=int,default=200000);p.add_argument('--save-steps',type=int,default=500)
    p.add_argument('--seed',type=int,default=260912);p.add_argument('--probe',action='store_true')
    a=p.parse_args();a.protocol_version=11;a.training_version=11;a.shared_head_file='shared_head_state.pt'
    a.attention_prior='relation_encoding_K_only_nullK_zeroV';a.candidate_selection='GRW_meanaggregate1500_T1_times_mappedcos_top10_union24'
    a.query_normalization='original_cpm_no_backfill';a.sampling='16_distinct_sources_x32_without_replacement_when_possible'
    a.stage1_steps=500;a.num_heads=16;a.loss_weights=[.6,.1,.3];a.loss_reduction='global_valid_masked_patch_mean'
    a.external_lr=[1e-4,5e-5];a.head_lr=[2e-5,5e-6];a.warmup_steps=500;a.max_grad_norm=1.;a.weight_decay=.01
    rank=int(os.environ.get('RANK',0));local=int(os.environ.get('LOCAL_RANK',0));world=int(os.environ.get('WORLD_SIZE',1))
    torch.cuda.set_device(local);device=torch.device('cuda',local)
    if world>1:dist.init_process_group('nccl')
    torch.manual_seed(a.seed);np.random.seed(a.seed+rank);random.seed(a.seed+rank)
    model=base.Toto2Layer16ConcatAdditiveMultimodalModel.from_pretrained(a.internal_checkpoint,map_location='cpu').to(device).eval()
    model.requires_grad_(False);head=model.base_model.output_head
    import types
    model.forecast_parallel_hidden=types.MethodType(forecast_cpm_hidden,model)
    a.num_heads=int(model.base_model.config.num_heads)
    ext=ExternalRAG(d_model=model.d_model,heads=a.num_heads).to(device)
    ext_ddp=DDP(ext,device_ids=[local],broadcast_buffers=False) if world>1 else ext
    opt=torch.optim.AdamW([dict(params=ext.parameters(),lr=1e-4),dict(params=head.parameters(),lr=0.)],weight_decay=.01,fused=True)
    sampler=SixteenSourceSampler(a.bank_root,a.seed,rank)
    loader,cfg=make_loader(a)
    a.old_data_config=cfg;a.old_sampling='time20_gift10_clean70_natural';out=Path(a.output_dir)
    if rank==0:
        out.mkdir(parents=True,exist_ok=a.probe)
        (out/'training_args.json').write_text(json.dumps(vars(a),indent=2))
        print(json.dumps(dict(event='initialized',args=vars(a))),flush=True)
    if world>1:dist.barrier()
    params=list(ext.parameters())+list(head.parameters());head_runner=head
    steps=[499,500] if a.probe else range(a.max_steps)
    initial_head={k:v.detach().clone() for k,v in head.state_dict().items()} if a.probe else None
    for step in steps:
        start=time.time();joint=step>=500
        if joint and not next(head.parameters()).requires_grad:
            head.requires_grad_(True)
            head_runner=DDP(head,device_ids=[local],broadcast_buffers=False) if world>1 else head
            if rank==0:print(json.dumps(dict(event='head_unfrozen',step=step+1,optimizer_reset=False,backbone_frozen=True)),flush=True)
        opt.zero_grad(set_to_none=True)
        opt.param_groups[0]['lr']=schedule(step,a.max_steps,1e-4,5e-5)
        opt.param_groups[1]['lr']=schedule(step,a.max_steps,2e-5,5e-6,start=500)
        logs={}
        if joint:
            h,loc,scale,prepared=old_features(model,next(loader),cfg,device)
            outputs=SimpleNamespace(quantiles=head_runner(h,q=None),loc=loc,scale=scale)
            loss,metric=cpm_loss(outputs,prepared,world)
            (.6*loss).backward();logs['loss_old']=float(metric)
            del h,loc,scale,prepared,outputs,loss
        b=base.to_device(sampler.sample(a.batch_size),device)
        if step%50==0 or a.probe:print(json.dumps(dict(event='sampling',rank=rank,step=step+1,sources=sampler.last_report)),flush=True)
        h,target,wanted,mask=rag_features(model,b)
        if joint:
            loss,metric=rag_loss(head_runner(h[:,None],q=None),wanted,mask,world)
            (.1*loss).backward();logs['loss_rag_internal']=float(metric);del loss
        enhanced=ext_ddp(h,b['candidate_image'],b['candidate_text'],b['candidate_ts'],target,b['similarity'],b['source_weight'],b['temperature'],b['candidate_mask'],b['candidate_patch_mask'],b['forecast_patch_mask'])
        loss,metric=rag_loss(head_runner(enhanced[:,None],q=None),wanted,mask,world)
        ((.3 if joint else 1.)*loss).backward();logs['loss_rag_external']=float(metric)
        if any(p.grad is not None for n,p in model.named_parameters() if not n.startswith('base_model.output_head.')):raise AssertionError('Frozen backbone received gradient')
        grad=torch.nn.utils.clip_grad_norm_(params,1.,error_if_nonfinite=True)
        opt.step()
        if a.probe:
            changed=any(not torch.equal(v,initial_head[k]) for k,v in head.state_dict().items())
            assert changed==joint,(changed,joint)
        if rank==0:
            print(json.dumps(dict(step=step+1,joint=joint,**logs,loss=(.6*logs['loss_old']+.1*logs['loss_rag_internal']+.3*logs['loss_rag_external']) if joint else logs['loss_rag_external'],grad_norm=float(grad),external_lr=opt.param_groups[0]['lr'],head_lr=opt.param_groups[1]['lr'],seconds=time.time()-start,peak_mib=torch.cuda.max_memory_allocated()/2**20)),flush=True)
        if (step+1)%a.save_steps==0 or a.probe:
            if world>1:dist.barrier()
            if rank==0:save(out,step+1,ext,head,opt,a)
            if world>1:dist.barrier()
        del b,h,target,wanted,mask,enhanced,loss
    if a.probe and rank==0:print('JOINT_STAGE_TRANSITION_PROBE_OK',flush=True)
    if world>1:dist.destroy_process_group()

if __name__=='__main__':main()
