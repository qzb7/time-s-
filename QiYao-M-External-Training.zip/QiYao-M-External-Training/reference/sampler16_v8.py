"""Sixteen distinct sources, 32 queries each; reuse audited v7 packing."""
import numpy as np
from cpm_rag_v7 import EightSourceSampler

class SixteenSourceSampler(EightSourceSampler):
    def sample(self,batch_size):
        if batch_size!=512:raise ValueError('Requires 16 x 32 = 512')
        pieces=[];report=[]
        for si in self.rng.permutation(len(self.sources)):
            source=self.sources[int(si)];bank=self._load(source)
            eligible=np.unique(bank['eligible_query_ids'])
            if not len(eligible):continue
            if len(eligible)>=32:qi=self.rng.choice(eligible,32,replace=False)
            else:
                qi=np.concatenate([self.rng.permutation(eligible),self.rng.choice(eligible,32-len(eligible),replace=True)])
                self.rng.shuffle(qi)
            pieces.append(self.pack(source,bank,qi))
            report.append(dict(source_id=source['source_id'],eligible=int(len(eligible)),count=32,unique=int(len(np.unique(qi))),repeats=int(32-len(np.unique(qi)))))
            if len(pieces)==16:break
        if len(pieces)!=16:raise RuntimeError('Fewer than 16 usable sources')
        out={k:np.concatenate([p[k] for p in pieces],axis=0) for k in pieces[0]}
        out['source_id']=[r['source_id'] for r in report];out['sampling_report']=report
        self.last_report=report
        return out
