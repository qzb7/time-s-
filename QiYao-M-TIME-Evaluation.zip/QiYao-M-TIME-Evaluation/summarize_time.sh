#!/usr/bin/env bash
set -e
python "$(dirname "$0")/summarize_time.py" "$@"
