"""Deterministic historical patch modalities."""
