# Sources and licenses

- `timebench/evaluation/{data,metrics,saver,utils}.py` and
  `timebench/config/datasets.yaml` were downloaded read-only from the user's
  `/home/TIME` on 207 on 2026-11-03. These files are included unchanged.
  `data.py` retains the original Salesforce Apache notice and TIME modifications.
  The exact source archive is in `reference207/time-original.tar.gz`.
- `qiyaom/` and `dd_unit_scaling/` are copied from the previously delivered
  QiYao-M GIFT-Eval inference package. The numerical backbone includes Datadog
  code; existing copyright notices are retained. Apache-2.0 is included.
- `patch_encoder/{core,encoder,render,text_template}.py` are copied unchanged
  from the previous QiYao-M GIFT-Eval patch generator. The deterministic
  templates/rendering are from the user's established evaluation workflow.
  OpenCLIP is an installed dependency. No CLIP weights are bundled.
  The CLIP MIT license is included.
- This package includes no dataset observations, forecasting weights, server
  credentials, API tokens, or training/evaluation job launch on a remote host.
