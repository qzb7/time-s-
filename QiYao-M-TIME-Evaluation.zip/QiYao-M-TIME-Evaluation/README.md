# QiYao-M：TIME 内源多模态数据生成与测评

本包用于 **TIME benchmark，不是 TIME-MMD**。两个主要入口：

- `generate_time.sh` → `generate_time.py`：生成 TIME 测试历史的 patch 级图像、文本编码。
- `evaluate_time.sh` → `evaluate_time.py`：加载内源模型，按 TIME 官方窗口预测并保存指标。

sh 只是 `python 对应文件.py "$@"`，所有路径通过命令行传递；不使用 CLI 子命令、不启动训练。

## 1. 环境与所需文件

建议 Python 3.11，使用之前的 `toto2mm` 环境。已有环境无需重新安装；新环境：

```bash
pip install -r requirements.txt
```

Torch/torchvision 的 CUDA wheel 请按服务器选择；参考环境为 Torch 2.4.1。
本地无需再安装 `/home/toto-main` 或 TIME 仓库，所需模型代码及 TIME 的数据划分、指标、保存代码已内置。
模型权重、CLIP 权重和数据集不随包提供。

准备以下路径：

1. TIME 数据根目录，例如 `/public_data/TIME`。其下是按 `数据集/频率` 保存的 Hugging Face `save_to_disk` 数据；不是单个 CSV。
2. CLIP 权重，例如 `/models/ViT-B-32.pt`。
3. 内源模型目录，须含 `config.json`、`model.safetensors`（或分片和索引）、`layer16_concat_additive_state.pt`。
4. 可选的联合训练 `checkpoint-1000/shared_head_state.pt`。

相对路径以启动终端的当前目录为准。先进入解压后的本目录。

## 2. 生成内源测评缓存

```bash
CUDA_VISIBLE_DEVICES=0 bash generate_time.sh \
  --time-data /public_data/TIME \
  --clip-checkpoint /models/ViT-B-32.pt \
  --output /data/qiyaom_time_eval_cache \
  --sample-batch 8 \
  --clip-batch 256 \
  --workers 4
```

默认处理附带 YAML 中全部 98 个任务（short 50、medium 24、long 24）。仅跑一个任务可追加：

```bash
--include Water_Quality_Darwin/15T/short
```

可重复 `--include`。`--plan-only` 只读取数据划分、打印任务及样本数，不加载 CLIP、不生成输出。

生成规则：

- 从原 TIME `Dataset.test_data.input` 逐窗口读取，**不读取或编码对应 label**。
- 多变量按原 TIME 的 `MultivariateToUnivariate` 拆为单变量窗口，不改变官方窗口顺序。
- 历史取最近最多 **8192** 点；不足时左 padding，观测有效 mask 与 padding mask 分开。
- 每 **32 点**一个 patch，共 **256** 个位置。文本为确定性统计模板，不调用 LLM。
- 每个 patch 的图像沿用原渲染：红色数值、绿色一阶差分 `x[t]-x[t-1]`、蓝色两步差分 `x[t]-x[t-2]`。
  注意蓝色不是 `x[t]-2*x[t-1]+x[t-2]` 的二阶导差分。差分先在历史上计算，再分 patch。
- CLIP ViT-B/32 图文特征各 512 维，**不做 L2 归一化**，按 patch 保存 scaled-fp16 和 float32 scale。
- 这一步是内源 patch 数据，不需要 TS 检索编码器，也不构造外源 bank。

输出为 `block-<任务hash>.zarr`、对应 `.complete.json`。一个任务一个 block，包含原评测代码需要的
数值、mask、图文特征、样本身份。与旧 207 缓存的 block 粒度不同，但字段和读取接口兼容。
同参数重跑会跳过完整任务；更换数据、CLIP、batch 或代码后请换新输出目录。
中断留下的隐藏 `.block-...-work-*` 目录不会被当作完整缓存；可检查后手动清理。
50 万个长历史样本的两套 fp16 patch 特征未压缩约 262 GB，本 TIME 测试集数量以计划输出为准。

### 可选：六卡生成

默认 sh 是单进程。需要多卡时直接用 torchrun 运行同一 Python 文件：

```bash
CUDA_VISIBLE_DEVICES=0,1,2,3,4,5 python -m torch.distributed.run \
  --standalone --nproc_per_node=6 generate_time.py \
  --time-data /public_data/TIME \
  --clip-checkpoint /models/ViT-B-32.pt \
  --output /data/qiyaom_time_eval_cache \
  --sample-batch 8 --clip-batch 256 --workers 4
```

按完整任务分配，`workers` 是每卡 CPU worker 数。不要让两个不相关的作业写同一输出目录。

## 3. 运行内源模型测评

### A. 仅使用内源 checkpoint-22000

```bash
CUDA_VISIBLE_DEVICES=0 bash evaluate_time.sh \
  --time-data /public_data/TIME \
  --cache-dir /data/qiyaom_time_eval_cache \
  --checkpoint /models/endogenous/checkpoint-22000 \
  --output-dir /data/time_results/QiYao-M-internal22000 \
  --model-name QiYao-M-internal22000 \
  --batch-size 32 \
  --scaler-fallback-min-obs 8
```

### B. 对齐之前“internal22000 + 联合训练1000共享head”的结果

```bash
CUDA_VISIBLE_DEVICES=0 bash evaluate_time.sh \
  --time-data /public_data/TIME \
  --cache-dir /data/qiyaom_time_eval_cache \
  --checkpoint /models/endogenous/checkpoint-22000 \
  --shared-head /models/external/checkpoint-1000/shared_head_state.pt \
  --output-dir /data/time_results/QiYao-M \
  --model-name QiYao-M \
  --batch-size 32 \
  --scaler-fallback-min-obs 8
```

**不传 `--shared-head` 就只用内源 checkpoint 自带的 head；不会自动寻找或加载其他权重。**
传入的 1000 共享 head 只替换输出 head，仍然不启用外源 cross-attention、不进行检索。

推理为 FP32、原模型 `forecast_parallel`、原生逆归一化和分位数排序，不额外裁剪预测。
预测长度、测试区间、窗口数全部来自附带的 TIME YAML，不统一改成 96 或 192。
`--scaler-fallback-min-obs 8` 沿用原测评设置：短 patch 观测不足时回填尺度，0 为禁用。
显存允许可把 batch 提高到之前的 192；batch 不同可能有浮点差异，严格复现应使用相同 batch。
模型不读取真实未来，标签仅在预测后由原 TIME saver 计算指标。

评测器也支持之前 `/public_data/toto2_multimodal_time_eval_history_111177` 的旧 Zarr 缓存。
它会核对每个任务样本数、样本身份和数值历史，不会静默丢弃缓存缺失的任务。
新缓存与旧缓存的图文特征尚未在 GPU 上逐项比对，不承诺 bitwise 一致。

同配置完成的任务可跳过；更换权重、缓存、batch 等请使用新的结果目录。
支持 `--include`、`--plan-only` 和 `--shard-id 0 --num-shards 2`。
多卡评测也可像生成一样用 torchrun 调用 `evaluate_time.py`，不再同时传显式 shard 参数。

## 4. 结果格式与归一化汇总

结果沿用原 TIME 格式：

```text
/data/time_results/QiYao-M/
  Water_Quality_Darwin/15T/short/
    predictions.npz
    metrics.npz
    config.json
    evaluation_complete.json
  ...
```

`metrics.npz` 含逐序列/窗口/变量的 MSE、MAE、MASE、CRPS 等。
MSE/MAE 按原 TIME 的中位数预测计算；CRPS 是原实现的九个分位数加权损失近似。
MASE 的尺度分母使用官方窗口的历史季节差分，**不是把误差除以训练标准差**。
`predictions.npz` 沿用官方 fp16 保存方式，读取时应乘 `config.json` 的 `prediction_scale_factor`；
指标由保存前的浮点预测计算，不是从压缩后的预测重新计算。

如有对应的官方 `seasonal_naive` 结果：

```bash
bash summarize_time.sh \
  --results-dir /data/time_results/QiYao-M \
  --seasonal-naive-dir /home/TIME/output/results/seasonal_naive \
  --output /data/time_summary/QiYao-M
```

输出 `per_task.csv` 和 `summary.json`。先在任务内按原 TIME 的 `nanmean` 聚合指标，
然后 MASE/CRPS 分别除以相同任务的 seasonal_naive，再对任务取几何平均，汇总 Overall/Short/Medium/Long。
默认要求 98 个任务齐全，不完整就报错；单任务调试可显式传 `--expected-tasks 1`。
不传 seasonal-naive 路径只输出原始逐任务指标，不伪装成归一化总榜结果。
本包不自动下载 baseline，也不计算缺少明确对比模型池的“排名”。

## 5. 验证与复现边界

- TIME 数据划分、saver、metrics、utils 和 YAML 从 207 只读下载并原样保留，见 `reference207/`。
- 模型代码和图文编码器复用之前交付的 QiYao-M 推理与 GIFT-Eval 生成包。
- 本次仅本地整理及 CPU 单元验证，没有在服务器启动训练/测评，未重新跑完整 98 任务。
- 使用之前的权重时需如实声明：其训练接触过 TIME/GIFT-Eval 的测试历史，不能称为完全未接触测试数据的严格 zero-shot。
- 自检命令：`python -m unittest discover -s tests -v`。更多验证范围见 `VALIDATION.md`。
