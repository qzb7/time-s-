"""TIME evaluation subset, copied from the user's 207 snapshot."""
