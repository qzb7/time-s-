#!/usr/bin/env bash
set -e
python "$(dirname "$0")/generate_time.py" "$@"
