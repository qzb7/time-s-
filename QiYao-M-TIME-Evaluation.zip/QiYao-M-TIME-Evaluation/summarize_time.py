#!/usr/bin/env python3
"""Aggregate original TIME metrics, optionally normalized by seasonal_naive."""
import argparse
import csv
import json
from pathlib import Path

import numpy as np

from time_common import write_json


def read_results(root):
    result = {}
    for cfg_path in sorted(Path(root).rglob('config.json')):
        metric_path = cfg_path.parent / 'metrics.npz'
        if not metric_path.is_file() or any(p.startswith('.') for p in cfg_path.relative_to(root).parts):
            continue
        cfg = json.loads(cfg_path.read_text())
        key = cfg['dataset_config']
        if key in result:
            raise ValueError(f'Duplicate task {key}')
        with np.load(metric_path, allow_pickle=False) as data:
            result[key] = {m: float(np.nanmean(data[m])) for m in ['MSE', 'MAE', 'MASE', 'CRPS']}
    return result


def summarize(results, baseline=None):
    rows = []
    for key, values in sorted(results.items()):
        row = dict(dataset=key, **values)
        if baseline is not None:
            if key not in baseline:
                raise ValueError(f'Missing seasonal-naive task: {key}')
            for metric in ['MASE', 'CRPS']:
                numerator, denominator = values[metric], baseline[key][metric]
                if not np.isfinite(numerator) or numerator < 0 or not np.isfinite(denominator) or denominator <= 0:
                    raise ValueError(f'{key}: invalid {metric} for normalization')
                row['normalized_' + metric] = numerator / denominator
        rows.append(row)
    scopes = []
    if baseline is not None:
        for scope in ['overall', 'short', 'medium', 'long']:
            selected = [r for r in rows if scope == 'overall' or r['dataset'].endswith('/' + scope)]
            if not selected:
                continue
            record = dict(scope=scope, tasks=len(selected))
            for metric in ['MASE', 'CRPS']:
                values = np.array([r['normalized_' + metric] for r in selected])
                record[metric] = 0. if np.any(values == 0) else float(np.exp(np.mean(np.log(values))))
            scopes.append(record)
    return rows, scopes


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--results-dir', type=Path, required=True, help='ONE model directory')
    p.add_argument('--seasonal-naive-dir', type=Path, help='Matching TIME seasonal_naive result directory')
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--expected-tasks', type=int, default=98)
    a = p.parse_args()
    result = read_results(a.results_dir)
    if len(result) != a.expected_tasks:
        raise ValueError(f'Incomplete results: {len(result)} tasks, expected {a.expected_tasks}')
    baseline = read_results(a.seasonal_naive_dir) if a.seasonal_naive_dir else None
    rows, scopes = summarize(result, baseline)
    a.output.mkdir(parents=True, exist_ok=True)
    with (a.output / 'per_task.csv').open('w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader(); writer.writerows(rows)
    write_json(a.output / 'summary.json', dict(configurations=len(rows), scopes=scopes,
               normalization='geometric mean of per-task ratios to seasonal_naive' if baseline is not None else None,
               note='No leaderboard rank: rank requires a specified comparison-model pool.'))
    print(json.dumps(dict(configurations=len(rows), scopes=scopes), indent=2))
    if baseline is None:
        print('Raw per-task metrics exported. Supply --seasonal-naive-dir for normalized aggregate MASE/CRPS.')


if __name__ == '__main__':
    main()
