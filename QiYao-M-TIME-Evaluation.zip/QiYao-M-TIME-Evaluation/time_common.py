"""Shared history-only alignment and original TIME sample identities."""
from collections import defaultdict
import hashlib
import json
import os
from pathlib import Path
import re

import numpy as np

ROOT = Path(__file__).resolve().parent
DEFAULT_CONFIG = ROOT / 'timebench/config/datasets.yaml'
CONTEXT = 8192
DIM_RE = re.compile(r'^(.*)_dim(\d+)$')


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(4 * 1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def signature(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True).encode()).hexdigest()


def write_json(path, value):
    from patch_encoder.core import atomic_json
    atomic_json(Path(path), value)


def tasks(config_path, includes):
    from timebench.evaluation.data import load_dataset_config
    from timebench.evaluation.utils import get_available_terms
    config = load_dataset_config(Path(config_path))
    result = [(name, term) for name in config.get('datasets', {})
              for term in get_available_terms(name, config)]
    if not result:
        raise ValueError('Empty TIME task configuration')
    unknown = set(includes) - {f'{n}/{t}' for n, t in result}
    if unknown:
        raise ValueError(f'Unknown task keys: {sorted(unknown)}')
    return config, [(n, t) for n, t in result if not includes or f'{n}/{t}' in includes]


def dataset(name, term, config, data_root):
    from timebench.evaluation.data import Dataset, get_dataset_settings
    kw = get_dataset_settings(name, term, config)
    meta = Dataset(name=name, term=term, storage_path=data_root,
                   to_univariate=False, **kw)
    if meta.target_dim == 1:
        return meta
    return Dataset(name=name, term=term, storage_path=data_root,
                   to_univariate=True, **kw)


def sample_count(ds):
    return len(ds.hf_dataset) * int(ds.target_dim) * int(ds.windows)


def task_metadata(ds):
    return dict(fingerprint=str(ds.hf_dataset._fingerprint),
                samples=sample_count(ds), prediction_length=int(ds.prediction_length),
                windows=int(ds.windows), num_variates=int(ds.target_dim), freq=str(ds.freq))


def align(series):
    x = np.asarray(series, dtype=np.float32)
    if x.ndim == 2 and x.shape[0] == 1:
        x = x[0]
    if x.ndim != 1:
        raise ValueError('Expected an officially flattened univariate input')
    x = x[-CONTEXT:]
    values = np.full(CONTEXT, np.nan, np.float32)
    padding = np.ones(CONTEXT, bool)
    if len(x):
        values[-len(x):] = x
        padding[-len(x):] = False
    valid = ~padding & np.isfinite(values)
    return values, valid, padding


def category(name, term, item, counters):
    item_id = str(item['item_id'])
    match = DIM_RE.match(item_id)
    base, variate = (match.group(1), int(match.group(2))) if match else (item_id, 0)
    window = counters[item_id]
    counters[item_id] += 1
    key = f'{name}|{term}|{base}|{window}|{variate}'
    return 'timeeval_' + hashlib.sha1(key.encode()).hexdigest()[:23]


def history_batches(ds, name, term, batch_size):
    counters = defaultdict(int)
    rows, masks, padding, keys = [], [], [], []
    # Never iterate .label here. Every target is from test_data.input only.
    for item in ds.test_data.input:
        x, m, p = align(item['target'])
        rows.append(x); masks.append(m); padding.append(p)
        keys.append(category(name, term, item, counters))
        if len(rows) == batch_size:
            yield np.stack(rows), np.stack(masks), np.stack(padding), keys
            rows, masks, padding, keys = [], [], [], []
    if rows:
        yield np.stack(rows), np.stack(masks), np.stack(padding), keys


def _npu_available():
    try:
        import torch_npu
        return torch_npu.npu.is_available()
    except Exception:
        return False


def rank_info(device):
    rank, world, local = (int(os.getenv(k, d)) for k, d in
                          [('RANK', '0'), ('WORLD_SIZE', '1'), ('LOCAL_RANK', '0')])
    if not 0 <= rank < world:
        raise ValueError('Invalid distributed rank')
    if device == 'auto':
        import torch
        if _npu_available():
            device = f'npu:{local}'
        elif torch.cuda.is_available():
            device = f'cuda:{local}'
        else:
            device = 'cpu'
    if device.startswith('npu'):
        import torch_npu  # register the 'npu' device type before any tensor move
    if world > 1 and ':' in device and device != f'{device.split(":")[0]}:{local}':
        raise ValueError('Use --device auto under torchrun to avoid device collisions')
    return rank, world, device


def scaled_fp16(features):
    scale = np.maximum(np.max(np.abs(features), axis=-1, keepdims=True), 1e-12).astype(np.float32)
    return (features / scale).astype(np.float16), scale


class Cache:
    """Read new task blocks or the old 207 block-*.zarr cache."""
    def __init__(self, root):
        import zarr
        self.groups = []
        self.index = {}
        self.counts = defaultdict(int)
        self.receipts = {}
        self.root = Path(root)
        for path in sorted(self.root.glob('block-*.zarr')):
            if not (path / '.zgroup').is_file():
                continue
            g = zarr.open_group(str(path), mode='r')
            if g.attrs.get('format') == 'qiyaom_time_history_patch_v1':
                receipt = path.with_suffix('.complete.json')
                if not receipt.is_file():
                    raise ValueError(f'Incomplete new cache: {path}')
                saved = json.loads(receipt.read_text())
                if saved.get('signature') != g.attrs.get('signature'):
                    raise ValueError(f'Cache signature mismatch: {path}')
                self.receipts[path.name] = saved
            else:
                self.receipts[path.name] = {'legacy_cache': True}
            idx = len(self.groups)
            self.groups.append(g)
            for row, (key, name, term) in enumerate(zip(g['target_category'][:],
                                                       g['source_dataset'][:], g['source_term'][:])):
                key, name, term = [v.decode() if isinstance(v, bytes) else str(v)
                                    for v in (key, name, term)]
                if key in self.index:
                    raise ValueError(f'Duplicate cache sample: {key}')
                self.index[key] = (idx, row)
                self.counts[name, term] += 1
        if not self.groups:
            raise FileNotFoundError(f'No complete block-*.zarr in {root}')

    def fetch(self, keys):
        out = dict(target=np.empty((len(keys), CONTEXT), np.float32),
                   mask=np.empty((len(keys), CONTEXT), bool),
                   image=np.empty((len(keys), 256, 512), np.float32),
                   text=np.empty((len(keys), 256, 512), np.float32))
        blocks = defaultdict(list)
        for dest, key in enumerate(keys):
            block, row = self.index[key]
            blocks[block].append((dest, row))
        for block, pairs in blocks.items():
            dest, rows = np.asarray(sorted(pairs, key=lambda x: x[1])).T
            g = self.groups[block]
            x = np.asarray(g['time_series_8192'].oindex[rows], dtype=np.float32)
            m = np.asarray(g['target_mask_8192'].oindex[rows], dtype=bool)
            p = np.asarray(g['padding_mask_8192'].oindex[rows], dtype=bool)
            out['target'][dest] = np.nan_to_num(x, nan=0., posinf=0., neginf=0.)
            out['mask'][dest] = m & ~p & np.isfinite(x)
            for mod in ['image', 'text']:
                out[mod][dest] = (np.asarray(g[f'{mod}_global_fp16'].oindex[rows], np.float32)
                                 * np.asarray(g[f'{mod}_scale'].oindex[rows], np.float32))
        return out
