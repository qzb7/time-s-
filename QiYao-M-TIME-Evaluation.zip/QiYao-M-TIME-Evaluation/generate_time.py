#!/usr/bin/env python3
"""Generate TIME test-history-only patch caches; no forecasting labels encoded."""
import argparse
from collections import defaultdict
import json
import os
from pathlib import Path
import tempfile

import numpy as np

from time_common import (DEFAULT_CONFIG, ROOT, dataset, digest, history_batches,
                         rank_info, sample_count, scaled_fp16, signature,
                         task_metadata, tasks, write_json)


def arguments():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--time-data', type=Path, required=True)
    p.add_argument('--config', type=Path, default=DEFAULT_CONFIG)
    p.add_argument('--clip-checkpoint', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--device', default='auto')
    p.add_argument('--sample-batch', type=int, default=8)
    p.add_argument('--clip-batch', type=int, default=256)
    p.add_argument('--workers', type=int, default=4)
    p.add_argument('--include', action='append', default=[], help='Exact key, e.g. Water_Quality_Darwin/15T/short')
    p.add_argument('--plan-only', action='store_true', help='Read data splits/counts only; no CLIP/output')
    a = p.parse_args()
    if min(a.sample_batch, a.clip_batch) < 1 or a.workers < 0:
        p.error('Batch sizes must be positive; workers >= 0')
    return a


def main():
    a = arguments()
    rank, world, device = rank_info(a.device)
    config, selected = tasks(a.config, a.include)
    plans = []
    for name, term in selected:
        ds = dataset(name, term, config, a.time_data)
        plans.append(dict(name=name, term=term, **task_metadata(ds)))
    print(json.dumps(dict(event='plan', tasks=len(plans), rank=rank, world=world,
                          samples=sum(x['samples'] for x in plans), plans=plans)), flush=True)
    if a.plan_only:
        return
    if not a.clip_checkpoint.is_file():
        raise FileNotFoundError(a.clip_checkpoint)
    from patch_encoder.encoder import PatchEncoder
    from patch_encoder.core import lock_file
    import zarr
    from numcodecs import Blosc
    protocol = dict(version=1, history_length=8192, patch_size=32,
                    split='test_data.input only', feature_dtype='scaled-fp16',
                    clip_sha256=digest(a.clip_checkpoint), config_sha256=digest(a.config),
                    code_sha256={f: digest(ROOT / f) for f in
                                 ['generate_time.py', 'time_common.py', 'patch_encoder/encoder.py',
                                  'patch_encoder/render.py', 'patch_encoder/text_template.py',
                                  'timebench/evaluation/data.py']},
                    data_root=str(a.time_data.resolve()),
                    clip_batch=a.clip_batch, sample_batch=a.sample_batch, device_type=device.split(':')[0])
    a.output.mkdir(parents=True, exist_ok=True)
    encoder = None
    try:
        for index, task in enumerate(plans):
            if index % world != rank:
                continue
            name, term = task['name'], task['term']
            key = f'{name}/{term}'
            stem = 'block-' + signature(key)[:16]
            path = a.output / (stem + '.zarr')
            receipt = a.output / (stem + '.complete.json')
            sig = signature(dict(protocol=protocol, task=task))
            with lock_file(a.output / (stem + '.lock')):
                if path.exists():
                    if not receipt.is_file() or json.loads(receipt.read_text()).get('signature') != sig:
                        raise ValueError(f'Incompatible/incomplete output: {path}; use a NEW output')
                    g = zarr.open_group(str(path), mode='r')
                    if g.attrs.get('signature') != sig or len(g['target_category']) != task['samples']:
                        raise ValueError(f'Invalid existing cache: {path}')
                    print(f'SKIP {key}', flush=True)
                    continue
                if encoder is None:
                    encoder = PatchEncoder(a.clip_checkpoint, device, a.clip_batch, a.workers)
                ds = dataset(name, term, config, a.time_data)
                n = sample_count(ds)
                # Hidden work directory is not picked up by evaluators after an interruption.
                work = Path(tempfile.mkdtemp(prefix='.' + stem + '-work-', dir=a.output))
                g = zarr.open_group(str(work), mode='w')
                compressor = Blosc(cname='zstd', clevel=5, shuffle=Blosc.BITSHUFFLE)
                specs = dict(time_series_8192=((n, 8192), 'f4'),
                             target_mask_8192=((n, 8192), 'u1'), padding_mask_8192=((n, 8192), 'u1'),
                             image_global_fp16=((n, 256, 512), 'f2'), text_global_fp16=((n, 256, 512), 'f2'),
                             image_scale=((n, 256, 1), 'f4'), text_scale=((n, 256, 1), 'f4'),
                             target_category=((n,), 'S32'), source_dataset=((n,), f'S{len(name.encode())}'),
                             source_term=((n,), 'S6'))
                for field, (shape, dtype) in specs.items():
                    g.create_dataset(field, shape=shape, dtype=dtype,
                                     chunks=(min(a.sample_batch, n),) + shape[1:], compressor=compressor)
                seen = set()
                start = 0
                for values, masks, pads, categories in history_batches(ds, name, term, a.sample_batch):
                    if len(set(categories)) != len(categories) or seen.intersection(categories):
                        raise ValueError('Duplicate official sample identities')
                    seen.update(categories)
                    image, text = encoder.encode(values, masks, pads)
                    end = start + len(values)
                    if end > n:
                        raise ValueError('Official input count exceeds plan')
                    for field, arr in [('time_series_8192', values), ('target_mask_8192', masks),
                                       ('padding_mask_8192', pads), ('target_category', np.asarray(categories, dtype='S32'))]:
                        g[field][start:end] = arr
                    g['source_dataset'][start:end] = name.encode()
                    g['source_term'][start:end] = term.encode()
                    for mod, features in [('image', image), ('text', text)]:
                        token, scale = scaled_fp16(features)
                        g[f'{mod}_global_fp16'][start:end] = token
                        g[f'{mod}_scale'][start:end] = scale
                    start = end
                    print(f'[{rank}] {key}: {start}/{n}', flush=True)
                if start != n:
                    raise ValueError(f'Official count mismatch: {start} != {n}')
                g.attrs.update(dict(format='qiyaom_time_history_patch_v1', signature=sig,
                                    protocol=protocol, task=task))
                os.rename(work, path)
                write_json(receipt, dict(signature=sig, samples=n, task=task, protocol=protocol))
    finally:
        if encoder is not None:
            encoder.close()
    print(f'DONE rank={rank}', flush=True)


if __name__ == '__main__':
    main()
