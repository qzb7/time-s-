#!/usr/bin/env python3
"""Evaluate layer-16 additive multimodal Toto-2 on the official TIME tasks."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import sys
import traceback
from collections import defaultdict
from pathlib import Path

import numpy as np
import torch
import zarr
from gluonts.time_feature import get_seasonality

TIME_ROOT = Path("/home/TIME")
sys.path[:0] = [
    "/home/toto-main/dd_unit_scaling",
    str(TIME_ROOT / "src"),
    "/home/toto-main",
    "/home/toto-main/toto2",
]

from timebench.evaluation.data import Dataset, get_dataset_settings, load_dataset_config
from timebench.evaluation.saver import save_window_predictions
from timebench.evaluation.utils import get_available_terms
from toto2_layer16_concat_additive_model import Toto2Layer16ConcatAdditiveMultimodalModel

QUANTILES = [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9]
DIM_RE = re.compile(r"^(.*)_dim(\d+)$")


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--checkpoint", required=True)
    p.add_argument("--cache-dir", required=True)
    p.add_argument("--output-dir", required=True)
    p.add_argument("--model-name", required=True)
    p.add_argument("--time-data", default="/public_data/TIME")
    p.add_argument("--config", default=str(TIME_ROOT / "src/timebench/config/datasets.yaml"))
    p.add_argument("--device", default="cuda:0")
    p.add_argument("--batch-size", type=int, default=192)
    p.add_argument("--shard-id", type=int, default=0)
    p.add_argument("--num-shards", type=int, default=1)
    return p.parse_args()


def move_model_unique(model, device, dtype):
    with torch.no_grad():
        for parameter in model.parameters():
            parameter.data = parameter.data.to(device=device, dtype=dtype)
            parameter.grad = None
        for buffer in model.buffers():
            target_dtype = dtype if buffer.is_floating_point() else buffer.dtype
            buffer.data = buffer.data.to(device=device, dtype=target_dtype)
    return model


class MultimodalCache:
    def __init__(self, root: str):
        self.groups = [zarr.open_group(str(p), mode="r") for p in sorted(Path(root).glob("block-*.zarr"))]
        if not self.groups:
            raise FileNotFoundError(f"No block-*.zarr found under {root}")
        self.index = {}
        self.config_counts = defaultdict(int)
        for block_id, group in enumerate(self.groups):
            cats = group["target_category"][:]
            names = group["source_dataset"][:]
            terms = group["source_term"][:]
            for row, (cat, name, term) in enumerate(zip(cats, names, terms)):
                key = cat.decode("utf-8")
                if key in self.index:
                    raise RuntimeError(f"Duplicate target_category: {key}")
                self.index[key] = (block_id, row)
                self.config_counts[(name.decode("utf-8"), term.decode("utf-8"))] += 1

    def fetch(self, categories):
        locations = [self.index[c] for c in categories]
        out = {}
        specs = {
            "target": (len(categories), 8192),
            "target_mask": (len(categories), 8192),
            "image": (len(categories), 256, 512),
            "text": (len(categories), 256, 512),
        }
        for name, shape in specs.items():
            out[name] = np.empty(shape, dtype=np.float32 if name != "target_mask" else np.bool_)
        by_block = defaultdict(list)
        for output_row, (block_id, row) in enumerate(locations):
            by_block[block_id].append((output_row, row))
        for block_id, pairs in by_block.items():
            group = self.groups[block_id]
            output_rows = np.asarray([x[0] for x in pairs])
            rows = np.asarray([x[1] for x in pairs])
            order = np.argsort(rows)
            rows_sorted = rows[order]
            destinations = output_rows[order]
            target = np.asarray(group["time_series_8192"].oindex[rows_sorted], dtype=np.float32)
            mask = np.asarray(group["target_mask_8192"].oindex[rows_sorted], dtype=np.bool_)
            padding = np.asarray(group["padding_mask_8192"].oindex[rows_sorted], dtype=np.bool_)
            out["target"][destinations] = np.nan_to_num(target, nan=0.0, posinf=0.0, neginf=0.0)
            out["target_mask"][destinations] = mask & ~padding & np.isfinite(target)
            for modality in ("image", "text"):
                fp16 = np.asarray(group[f"{modality}_global_fp16"].oindex[rows_sorted], dtype=np.float32)
                scale = np.asarray(group[f"{modality}_scale"].oindex[rows_sorted], dtype=np.float32)
                out[modality][destinations] = fp16 * scale
        return out


def category_for_pair(item, counters):
    item_id = str(item["item_id"])
    match = DIM_RE.match(item_id)
    if match:
        base_id, variate = match.group(1), int(match.group(2))
    else:
        base_id, variate = item_id, 0
    window = counters[item_id]
    counters[item_id] += 1
    raw = f"{base_id}|{window}|{variate}"
    return base_id, window, variate, raw


def main():
    a = parse_args()
    os.environ["TIME_DATASET"] = a.time_data
    config = load_dataset_config(Path(a.config))
    cache = MultimodalCache(a.cache_dir)
    tasks = []
    for name in config.get("datasets", {}):
        for term in get_available_terms(name, config):
            count = cache.config_counts.get((name, term), 0)
            if count:
                tasks.append((name, term, count))
    bins = [[] for _ in range(a.num_shards)]
    loads = [0] * a.num_shards
    for task in sorted(tasks, key=lambda x: x[2], reverse=True):
        worker = min(range(a.num_shards), key=lambda i: (loads[i], i))
        bins[worker].append(task)
        loads[worker] += task[2]
    tasks = sorted(bins[a.shard_id])
    print(f"cache={len(cache.index)} tasks={len(tasks)} balanced_loads={loads}", flush=True)

    device = torch.device(a.device)
    model = Toto2Layer16ConcatAdditiveMultimodalModel.from_pretrained(a.checkpoint, map_location="cpu")
    model = move_model_unique(model, device, torch.float32).eval()
    for task_index, (name, term, expected) in enumerate(tasks, 1):
        try:
            settings = get_dataset_settings(name, term, config)
            meta = Dataset(
                name=name,
                term=term,
                to_univariate=False,
                prediction_length=settings["prediction_length"],
                test_length=settings["test_length"],
                val_length=settings["val_length"],
                storage_path=a.time_data,
            )
            dataset = Dataset(
                name=name,
                term=term,
                to_univariate=meta.target_dim != 1,
                prediction_length=settings["prediction_length"],
                test_length=settings["test_length"],
                val_length=settings["val_length"],
                storage_path=a.time_data,
            )
            pairs = list(zip(dataset.test_data.input, dataset.test_data.label))
            if len(pairs) != expected:
                raise RuntimeError(f"{name}/{term}: official={len(pairs)} cache={expected}")
            counters = defaultdict(int)
            categories = []
            for item, _ in pairs:
                base_id, window, variate, _ = category_for_pair(item, counters)
                key = f"{name}|{term}|{base_id}|{window}|{variate}"
                categories.append("timeeval_" + hashlib.sha1(key.encode()).hexdigest()[:23])
            missing = [c for c in categories if c not in cache.index]
            if missing:
                raise RuntimeError(f"{name}/{term}: {len(missing)} cache keys missing")

            forecasts = []
            horizon = int(dataset.prediction_length)
            for start in range(0, len(categories), a.batch_size):
                stop = min(start + a.batch_size, len(categories))
                batch = cache.fetch(categories[start:stop])
                target = torch.from_numpy(batch["target"]).to(device).unsqueeze(1)
                mask = torch.from_numpy(batch["target_mask"]).to(device).unsqueeze(1)
                image = torch.from_numpy(batch["image"]).to(device).unsqueeze(1)
                text = torch.from_numpy(batch["text"]).to(device).unsqueeze(1)
                with torch.inference_mode():
                    q = model.forecast_parallel(
                        target, mask, image, text, horizon,
                        has_missing_values=True, scaler_fallback_min_obs=8,
                    )
                if q.is_sparse:
                    q = q.to_dense()
                if q.ndim == 5:
                    q = q.flatten(-2, -1)
                forecasts.append(q.permute(1, 2, 0, 3)[:, 0].float().cpu().numpy())
                print(f"[{task_index}/{len(tasks)}] {name}/{term} {stop}/{len(categories)}", flush=True)
            fc_quantiles = np.concatenate(forecasts, axis=0)
            configured_freq = name.rsplit("/", 1)[-1]
            ds_config = f"{name}/{term}" if configured_freq.lower() == str(dataset.freq).lower() else f"{name}/{dataset.freq}/{term}"
            save_window_predictions(
                dataset=dataset,
                fc_quantiles=fc_quantiles,
                ds_config=ds_config,
                output_base_dir=a.output_dir,
                seasonality=get_seasonality(dataset.freq),
                model_hyperparams={
                    "model_name": a.model_name,
                    "checkpoint": a.checkpoint,
                    "cache_dir": a.cache_dir,
                    "dtype": "float32",
                    "multimodal": True,
                },
                quantile_levels=QUANTILES,
            )
        except Exception:
            traceback.print_exc()
            raise
    print("DONE", flush=True)


if __name__ == "__main__":
    main()
