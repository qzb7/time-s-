#!/usr/bin/env python3
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import pandas as pd
from scipy.stats import gmean


EXPECTED = {"short": 50, "medium": 24, "long": 24, "overall": 98}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--results-root", default="/home/TIME/output/results")
    parser.add_argument("--model-name", required=True)
    parser.add_argument("--output-dir", required=True)
    args = parser.parse_args()

    sys.path.insert(0, "/home/TIME")
    from scripts.compute_local_leaderboard import get_all_datasets_results

    results = get_all_datasets_results(Path(args.results_root))
    keys = ["dataset_id", "horizon"]
    baseline = results[results["model"] == "seasonal_naive"][keys + ["MASE", "CRPS"]].copy()
    baseline = baseline.rename(columns={"MASE": "MASE_baseline", "CRPS": "CRPS_baseline"})
    if len(baseline) != 98 or baseline[keys].duplicated().any():
        raise RuntimeError(f"Expected 98 unique seasonal-naive configurations, got {len(baseline)}")

    pool = results.merge(baseline, on=keys, how="inner", validate="many_to_one")
    pool["MASE_normalized"] = pool["MASE"] / pool["MASE_baseline"]
    pool["CRPS_normalized"] = pool["CRPS"] / pool["CRPS_baseline"]
    pool["MASE_dataset_rank"] = pool.groupby(keys)["MASE_normalized"].rank(method="first")
    pool["CRPS_dataset_rank"] = pool.groupby(keys)["CRPS_normalized"].rank(method="first")

    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    target_rows = []
    for scope, expected in EXPECTED.items():
        scoped = pool if scope == "overall" else pool[pool["horizon"] == scope]
        records = []
        for model, group in scoped.groupby("model"):
            records.append(
                {
                    "model": model,
                    "num_configurations": int(len(group)),
                    "MASE": float(gmean(group["MASE_normalized"])),
                    "MASE_Rank": float(group["MASE_dataset_rank"].mean()),
                    "CRPS": float(gmean(group["CRPS_normalized"])),
                    "CRPS_Rank": float(group["CRPS_dataset_rank"].mean()),
                }
            )
        table = pd.DataFrame(records)
        table["Average_Rank"] = (table["MASE_Rank"] + table["CRPS_Rank"]) / 2.0
        table["Leaderboard_Rank"] = table["Average_Rank"].rank(method="min").astype(int)
        table = table.sort_values(["Leaderboard_Rank", "Average_Rank", "model"])
        table.to_csv(output_dir / f"leaderboard_{scope}.csv", index=False)
        target = table[table["model"] == args.model_name]
        if len(target) != 1 or int(target.iloc[0]["num_configurations"]) != expected:
            count = 0 if target.empty else int(target.iloc[0]["num_configurations"])
            raise RuntimeError(f"{scope}: target coverage is {count}, expected {expected}")
        row = target.iloc[0].to_dict()
        row["scope"] = scope
        target_rows.append(row)

    candidate = pool[pool["model"] == args.model_name].copy()
    candidate.to_csv(output_dir / "per_configuration_vs_seasonal_naive.csv", index=False)
    summary = pd.DataFrame(target_rows)
    summary.to_csv(output_dir / "target_summary.csv", index=False)
    print(summary.to_string(index=False))


if __name__ == "__main__":
    main()
