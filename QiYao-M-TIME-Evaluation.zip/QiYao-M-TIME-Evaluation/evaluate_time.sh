#!/usr/bin/env bash
set -e
python "$(dirname "$0")/evaluate_time.py" "$@"
