import ast
from collections import defaultdict
import importlib.util
import json
from pathlib import Path
import tempfile
import types
import unittest
from unittest.mock import patch

import numpy as np
import yaml

from time_common import align, category, history_batches, scaled_fp16, ROOT, signature
from summarize_time import read_results, summarize
from timebench.evaluation.metrics import compute_per_window_metrics_from_quantiles


class Tests(unittest.TestCase):
    def test_align(self):
        x, m, p = align([0., np.nan, 2.])
        self.assertEqual(x.shape, (8192,))
        self.assertEqual(m[-3:].tolist(), [True, False, True])
        self.assertTrue(p[:-3].all()); self.assertFalse(p[-3:].any())
        x, m, p = align(np.arange(9000))
        self.assertEqual(x[0], 808); self.assertTrue(m.all()); self.assertFalse(p.any())

    def test_identity(self):
        c = defaultdict(int)
        a = category('X/H', 'short', {'item_id': 'series_dim2'}, c)
        b = category('X/H', 'short', {'item_id': 'series_dim2'}, c)
        d = category('X/H', 'short', {'item_id': 'series_dim3'}, c)
        self.assertEqual(len({a, b, d}), 3)
        import hashlib
        self.assertEqual(a, 'timeeval_' + hashlib.sha1(b'X/H|short|series|0|2').hexdigest()[:23])

    def test_history_never_requests_label(self):
        class InputOnly:
            input = [dict(item_id='x', target=np.array([1, 2, 3]))] * 3
            @property
            def label(self):
                raise AssertionError('Label leakage')
        class Dataset:
            test_data = InputOnly()
        batches = list(history_batches(Dataset(), 'X/H', 'short', 2))
        self.assertEqual([len(b[0]) for b in batches], [2, 1])
        self.assertEqual(len({k for b in batches for k in b[3]}), 3)
        for file in ['generate_time.py', 'time_common.py', 'patch_encoder/encoder.py']:
            tree = ast.parse((ROOT / file).read_text())
            self.assertFalse(any(isinstance(n, ast.Attribute) and n.attr == 'label' for n in ast.walk(tree)))

    def test_fp16(self):
        x = np.random.default_rng(0).normal(size=(2, 256, 512)).astype(np.float32) * 1000
        t, s = scaled_fp16(x)
        self.assertEqual(t.dtype, np.float16)
        self.assertEqual(s.shape, (2, 256, 1))
        self.assertTrue(np.all(np.abs(t.astype(np.float32) * s - x) <= .001 * np.max(np.abs(x), axis=-1, keepdims=True)))

    def test_reference_byte_identical(self):
        import hashlib
        for path in sorted((ROOT / 'reference207/src/timebench').rglob('*')):
            if path.is_file():
                copy = ROOT / 'timebench' / path.relative_to(ROOT / 'reference207/src/timebench')
                self.assertEqual(hashlib.sha256(path.read_bytes()).hexdigest(), hashlib.sha256(copy.read_bytes()).hexdigest())
        cfg = yaml.safe_load((ROOT / 'timebench/config/datasets.yaml').read_text())
        terms = [t for d in cfg['datasets'].values() for t in ['short', 'medium', 'long']
                 if t in d and d[t].get('prediction_length') is not None]
        self.assertEqual(len(terms), 98)
        self.assertEqual([terms.count(t) for t in ['short', 'medium', 'long']], [50, 24, 24])

    def test_metrics_and_summary(self):
        gt = np.array([[[[2., 4.]]]])
        ctx = np.array([[[[0., 1., 2., 3.]]]])
        pred = np.broadcast_to(np.array([1., 3.]), (1, 1, 9, 1, 2)).copy()
        metrics = compute_per_window_metrics_from_quantiles(pred, gt, ctx, seasonality=1)
        for key in ['MSE', 'MAE', 'MASE']:
            self.assertEqual(metrics[key].item(), 1.)
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / 'X/H/short'; path.mkdir(parents=True)
            (path / 'config.json').write_text(json.dumps(dict(dataset_config='X/H/short')))
            np.savez_compressed(path / 'metrics.npz', **metrics)
            results = read_results(Path(tmp))
            rows, scopes = summarize(results, {'X/H/short': {m: 2 * v for m, v in results['X/H/short'].items()}})
            self.assertAlmostEqual(rows[0]['normalized_MASE'], .5)
            self.assertAlmostEqual(scopes[0]['CRPS'], .5)
            with self.assertRaises(ValueError):
                summarize(results, {})

    def test_original_saver_multivariate_layout(self):
        from timebench.evaluation.saver import save_window_predictions
        inputs = [dict(target=np.array([0., 1., 2., 3.])) for _ in range(4)]
        labels = [dict(target=np.array([float(i + 1), float(i + 2)])) for i in range(4)]
        class Dataset:
            windows = 2
            target_dim = 2
            prediction_length = 2
            freq = 'H'
            test_data = list(zip(inputs, labels))
        pred = np.stack([np.broadcast_to(row['target'], (9, 2)) for row in labels])
        with tempfile.TemporaryDirectory() as tmp:
            save_window_predictions(Dataset(), pred, 'X/H/short', tmp)
            with np.load(Path(tmp) / 'X/H/short/predictions.npz') as data:
                self.assertEqual(data['predictions_quantiles'].shape, (1, 2, 9, 2, 2))
                np.testing.assert_array_equal(data['predictions_quantiles'][0, 1, 4, 1], labels[3]['target'])
            with np.load(Path(tmp) / 'X/H/short/metrics.npz') as data:
                self.assertEqual(data['MSE'].shape, (1, 2, 2))
                self.assertTrue((data['MSE'] == 0).all())

    @unittest.skipUnless(importlib.util.find_spec('zarr'), 'Optional Zarr test dependency is not installed')
    def test_real_zarr_generation_resume_and_cache(self):
        import generate_time
        from time_common import Cache
        class HF:
            _fingerprint = 'cpu-fixture'
            def __len__(self):
                return 1
        class InputOnly:
            input = [dict(item_id=f'fixture_dim{v}', target=np.array([v, np.nan, w + 1.], np.float32))
                     for v in range(2) for w in range(2)]
            @property
            def label(self):
                raise AssertionError('Generation must not read labels')
        class Dataset:
            hf_dataset = HF()
            test_data = InputOnly()
            target_dim = 2
            windows = 2
            prediction_length = 2
            freq = 'H'
        class FakeEncoder:
            def __init__(self, *args):
                pass
            def encode(self, values, masks, padding):
                n = len(values)
                x = np.arange(n * 256 * 512, dtype=np.float32).reshape(n, 256, 512) / 1000
                return x, -x
            def close(self):
                pass
        fake = types.ModuleType('patch_encoder.encoder')
        fake.PatchEncoder = FakeEncoder
        with tempfile.TemporaryDirectory() as tmp:
            clip = Path(tmp) / 'fake-clip.pt'; clip.write_bytes(b'no-real-weights')
            output = Path(tmp) / 'cache'
            argv = ['generate_time.py', '--time-data', tmp, '--clip-checkpoint', str(clip),
                    '--output', str(output), '--device', 'cpu', '--workers', '0', '--sample-batch', '2']
            with patch.dict('sys.modules', {'patch_encoder.encoder': fake}), \
                 patch.object(generate_time, 'rank_info', return_value=(0, 1, 'cpu')), \
                 patch.object(generate_time, 'tasks', return_value=({}, [('X/H', 'short')])), \
                 patch.object(generate_time, 'dataset', return_value=Dataset()), \
                 patch('sys.argv', argv):
                generate_time.main()
                generate_time.main()  # completed task is reused, not overwritten
            cache = Cache(output)
            self.assertEqual(cache.counts['X/H', 'short'], 4)
            batches = list(history_batches(Dataset(), 'X/H', 'short', 3))
            for values, masks, pads, keys in batches:
                read = cache.fetch(keys[::-1])  # exercise reordered orthogonal indexing
                np.testing.assert_array_equal(read['mask'], masks[::-1])
                np.testing.assert_array_equal(read['target'][read['mask']], values[::-1][masks[::-1]])
                self.assertTrue(np.isfinite(read['image']).all())
                np.testing.assert_allclose(read['text'], -read['image'])


if __name__ == '__main__':
    unittest.main()
