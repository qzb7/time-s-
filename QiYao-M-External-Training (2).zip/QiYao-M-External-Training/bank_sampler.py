from collections import OrderedDict
from pathlib import Path
import json
import numpy as np
import zarr

class BaseSourceBankSamplerV3:
    # cache_size must be >= the number of distinct sources a single sample()
    # touches (RelationSampler draws 16 sources per step). With the old default
    # of 3, every step re-np.load-ed ~13 full bank_arrays.npz files from the LRU
    # thrash, which dominates step time when banks sit on OBS/NFS.
    def __init__(self, root: str, seed: int, rank: int, cache_size: int = 64):
        self.root = Path(root)
        payload = json.loads((self.root / "source_registry.json").read_text())
        self.sources = [s for s in payload["sources"] if (self.root / "sources" / self._slug(s["source_id"]) / ".complete").exists()]
        if not self.sources:
            raise RuntimeError(f"No completed source banks found under {self.root}")
        self.rng = np.random.default_rng(seed + rank * 100003)
        self.cache_size = cache_size
        self.cache = OrderedDict()

    @staticmethod
    def _slug(source_id):
        import hashlib
        return hashlib.sha1(source_id.encode()).hexdigest()[:16]

    def _load(self, source):
        sid = source["source_id"]
        if sid in self.cache:
            self.cache.move_to_end(sid)
            return self.cache[sid]
        path = self.root / "sources" / self._slug(sid)
        bank_npz = np.load(path / "bank_arrays.npz")
        mined_npz = np.load(path / "mined_candidates.npz")
        bank = {key: bank_npz[key] for key in bank_npz.files}
        bank["candidate_ids"] = mined_npz["final_top32_ids"]
        weight = json.loads((path / "source_weight.json").read_text())
        bank["source_weight"] = np.asarray([weight["w_image"], weight["w_text"], weight["w_time"]], np.float32)
        bank["temperature"] = np.asarray([weight["tau_image"], weight["tau_text"], weight["tau_time"]], np.float32)
        records = [json.loads(line) for line in (path / "records.jsonl").read_text().splitlines()]
        bank["prediction_length"] = np.asarray([x["prediction_length"] for x in records], np.int64)
        bank["available_future_length"] = np.asarray([x["available_future_length"] for x in records], np.int64)
        # A case's query-task H must never restrict its role as a known bank case.
        bank["bank_future_mask"] = (
            bank["future_valid_mask"].astype(bool)
            & np.isfinite(bank["future_values"])
            & (np.arange(192)[None, :] < bank["available_future_length"][:, None])
        )
        bank["context_loc"] = np.asarray([x["context_loc"] for x in records], np.float32)
        bank["context_scale"] = np.asarray([x["context_scale"] for x in records], np.float32)
        # A query is trainable only when every patch in its actual forecast
        # horizon has at least one real candidate target. This prevents padded
        # candidate id -1 (whose safe array index is 0) from silently becoming
        # a fake candidate when an entire attention row is masked.
        candidate_ids = bank["candidate_ids"].astype(np.int64)
        candidate_valid = candidate_ids >= 0
        safe_ids = np.maximum(candidate_ids, 0)
        candidate_point_mask = bank["bank_future_mask"][safe_ids]
        candidate_patch_mask = candidate_point_mask.reshape(
            candidate_ids.shape[0], candidate_ids.shape[1], 6, 32
        ).any(-1)
        candidate_patch_mask &= candidate_valid[..., None]
        any_candidate_per_patch = candidate_patch_mask.any(axis=1)
        required_patches = (
            np.arange(6, dtype=np.int64)[None, :]
            < np.ceil(bank["prediction_length"][:, None] / 32.0).astype(np.int64)
        )
        eligible = np.all(any_candidate_per_patch | ~required_patches, axis=1)
        bank["eligible_query_ids"] = np.flatnonzero(eligible).astype(np.int64)
        patch_path = path / "internal_patch_tokens.zarr"
        marker = path / ".internal_patch_tokens_complete"
        if not patch_path.exists() or not marker.exists():
            raise RuntimeError(f"Internal patch tokens are incomplete for {sid}: {patch_path}")
        bank["internal_patch"] = zarr.open_group(str(patch_path), mode="r")
        self.cache[sid] = bank
        while len(self.cache) > self.cache_size:
            self.cache.popitem(last=False)
        return bank

    @staticmethod
    def _decode(bank, name, indices):
        return bank[name][indices].astype(np.float32) * bank[name.replace("token", "scale")][indices].astype(np.float32)

    @staticmethod
    def _zarr_take(array, indices):
        unique, inverse = np.unique(indices, return_inverse=True)
        selected = array.get_orthogonal_selection((unique, slice(None), slice(None)))
        return np.asarray(selected)[inverse]

    @classmethod
    def _decode_internal_patch(cls, bank, name, indices):
        group = bank["internal_patch"]
        values = cls._zarr_take(group[name], indices).astype(np.float32)
        scales = cls._zarr_take(group[name.replace("global_fp16", "scale")], indices).astype(np.float32)
        return values * scales

    def sample(self, batch_size: int):
        # Usually the first source is usable. Keep resampling defensively in
        # case a very small source has no query with complete candidate cover.
        for _ in range(max(16, len(self.sources) * 2)):
            source = self.sources[int(self.rng.integers(len(self.sources)))]
            bank = self._load(source)
            eligible = bank["eligible_query_ids"]
            if len(eligible):
                break
        else:
            raise RuntimeError("No source contains a query with valid candidates for every forecast patch")
        qi = eligible[self.rng.integers(0, len(eligible), size=batch_size)]
        ids = bank["candidate_ids"][qi].astype(np.int64)
        candidate_mask = ids >= 0
        safe = np.maximum(ids, 0)
        h = bank["history_values"][qi].astype(np.float32)
        hm = bank["history_valid_mask"][qi].astype(bool)
        future = bank["future_values"][qi].astype(np.float32)
        fm = bank["future_valid_mask"][qi].astype(bool)
        pred_len = bank["prediction_length"][qi]
        # The internal model sees all 8192 history points followed by six
        # contiguous masked future patches (192 points): 8384 points total.
        target = np.zeros((batch_size, 8192 + 192), np.float32)
        target_mask = np.zeros((batch_size, 8192 + 192), bool)
        cpm_mask = np.ones((batch_size, 8192 + 192), bool)
        target[:, :8192] = h
        target_mask[:, :8192] = hm
        cpm_mask[:, 8192:] = False
        forecast_patch_mask = np.zeros((batch_size, 6), bool)
        for i, length in enumerate(pred_len):
            patches = int(math.ceil(int(length) / 32))
            # Future values are deliberately not copied into model input.
            # target_mask records which future labels exist, while cpm_mask
            # prevents all six future patches from being observed.
            target_mask[i, 8192:8192 + int(length)] = fm[i, :int(length)]
            forecast_patch_mask[i, :patches] = True
        image_full = self._decode_internal_patch(bank, "image_global_fp16", qi)
        text_full = self._decode_internal_patch(bank, "text_global_fp16", qi)
        image = image_full
        text = text_full
        image_c = self._decode(bank, "image_token", safe)
        text_c = self._decode(bank, "text_token", safe)
        ts_c = self._decode(bank, "timeseries_token", safe)
        image_q = bank["image_key"][qi].astype(np.float32)
        text_q = bank["text_key"][qi].astype(np.float32)
        ts_q = bank["timeseries_key"][qi].astype(np.float32)
        sims = np.stack([
            np.einsum("bd,bkd->bk", image_q, bank["image_key"][safe].astype(np.float32)),
            np.einsum("bd,bkd->bk", text_q, bank["text_key"][safe].astype(np.float32)),
            np.einsum("bd,bkd->bk", ts_q, bank["timeseries_key"][safe].astype(np.float32)),
        ], axis=-1)
        candidate_future_mask = bank["bank_future_mask"][safe] & candidate_mask[..., None]
        candidate_patch_mask = candidate_future_mask.reshape(batch_size, safe.shape[1], 6, 32).any(-1)
        return {
            "target": target, "target_mask": target_mask, "cpm_mask": cpm_mask,
            "future": future, "future_mask": fm, "prediction_length": pred_len,
            "forecast_patch_mask": forecast_patch_mask, "image": image, "text": text,
            "candidate_image": image_c, "candidate_text": text_c, "candidate_ts": ts_c,
            "candidate_future": bank["future_values"][safe].astype(np.float32),
            "candidate_future_mask": candidate_future_mask,
            "candidate_mask": candidate_mask, "candidate_patch_mask": candidate_patch_mask,
            "similarity": sims,
            "source_weight": np.repeat(bank["source_weight"][None], batch_size, axis=0),
            "temperature": np.repeat(bank["temperature"][None], batch_size, axis=0),
            "source_id": source["source_id"],
        }

class EightSourceSampler(BaseSourceBankSamplerV3):
    def pack(self,source,bank,qi):
            n=len(qi);ids=bank['candidate_ids'][qi].astype(np.int64);cm=ids>=0;safe=np.maximum(ids,0)
            h=bank['history_values'][qi].astype(np.float32);hm=bank['history_valid_mask'][qi].astype(bool)
            future=bank['future_values'][qi].astype(np.float32);fm=bank['future_valid_mask'][qi].astype(bool)
            lengths=bank['prediction_length'][qi]
            qpm=np.arange(6)[None]*32<lengths[:,None]
            target=np.concatenate([h,np.zeros((n,192),np.float32)],axis=1)
            labelmask=fm&(np.arange(192)[None]<lengths[:,None])
            mask=np.concatenate([hm,labelmask],axis=1)
            cpm=np.concatenate([np.ones_like(hm),np.repeat(~qpm,32,axis=-1)],axis=1)
            sims=np.stack([np.einsum('bd,bkd->bk',bank[k][qi],bank[k][safe]) for k in ['image_key','text_key','timeseries_key']],axis=-1).astype(np.float32)
            cfm=bank['bank_future_mask'][safe]&cm[...,None]
            return dict(target=target,target_mask=mask,cpm_mask=cpm,future=future,future_mask=fm,
                prediction_length=lengths,forecast_patch_mask=qpm,
                image=self._decode_internal_patch(bank,'image_global_fp16',qi),
                text=self._decode_internal_patch(bank,'text_global_fp16',qi),
                candidate_image=self._decode(bank,'image_token',safe),candidate_text=self._decode(bank,'text_token',safe),
                candidate_ts=self._decode(bank,'timeseries_token',safe),candidate_future=bank['future_values'][safe].astype(np.float32),
                candidate_future_mask=cfm,candidate_mask=cm,candidate_patch_mask=cfm.reshape(n,safe.shape[1],6,32).any(-1),
                similarity=sims,source_weight=np.repeat(bank['source_weight'][None],n,axis=0),
                temperature=np.repeat(bank['temperature'][None],n,axis=0),query_ids=qi)

class SixteenSourceSampler(EightSourceSampler):
    def sample(self,batch_size):
        if batch_size!=512:raise ValueError('Requires 16 x 32 = 512')
        pieces=[];report=[]
        for si in self.rng.permutation(len(self.sources)):
            source=self.sources[int(si)];bank=self._load(source)
            eligible=np.unique(bank['eligible_query_ids'])
            if not len(eligible):continue
            if len(eligible)>=32:qi=self.rng.choice(eligible,32,replace=False)
            else:
                qi=np.concatenate([self.rng.permutation(eligible),self.rng.choice(eligible,32-len(eligible),replace=True)])
                self.rng.shuffle(qi)
            pieces.append(self.pack(source,bank,qi))
            report.append(dict(source_id=source['source_id'],eligible=int(len(eligible)),count=32,unique=int(len(np.unique(qi))),repeats=int(32-len(np.unique(qi)))))
            if len(pieces)==16:break
        if len(pieces)!=16:raise RuntimeError('Fewer than 16 usable sources')
        out={k:np.concatenate([p[k] for p in pieces],axis=0) for k in pieces[0]}
        out['source_id']=[r['source_id'] for r in report];out['sampling_report']=report
        self.last_report=report
        return out

class RelationSampler(SixteenSourceSampler):
    def _load(self,source):
        bank=BaseSourceBankSamplerV3._load(self,source)
        if bank.get('_v11'):return bank
        with np.load(self.root/'calibration_v11'/(self._slug(source['source_id'])+'.npz')) as saved:
            for key in ['candidate_ids','temperature','eligible_query_ids']:bank[key]=saved[key]
            bank['source_weight']=saved['weights']
        for key in ['image_key','text_key','timeseries_key']:
            v=bank[key].astype(np.float32);bank[key]=v/np.maximum(np.linalg.norm(v,axis=-1,keepdims=True),1e-12)
        bank['_v11']=True
        return bank
