"""Replay configuration parsing and deterministic two-group batch quotas."""
import json
import math
from pathlib import Path


def _parse_dirs(entries, key):
    """Normalize a directory list into [(path, frac), ...].

    Each entry is either a bare path string (frac defaults to 1.0) or a
    [path, fraction] pair where fraction in (0, 1] keeps that fraction of rows.
    """
    if not isinstance(entries, list) or not entries:
        raise ValueError(f'{key} must be a nonempty list')
    out = []
    for entry in entries:
        if isinstance(entry, str) and entry:
            out.append((entry, 1.0))
        elif (isinstance(entry, (list, tuple)) and len(entry) == 2
              and isinstance(entry[0], str) and entry[0]
              and isinstance(entry[1], (int, float))):
            frac = float(entry[1])
            if not math.isfinite(frac) or not 0.0 < frac <= 1.0:
                raise ValueError(f'{key}: fraction must be in (0, 1], got {entry[1]!r}')
            out.append((entry[0], frac))
        else:
            raise ValueError(f'{key}: each entry must be a path string or [path, fraction]')
    return out


def load_replay_config(path, span=4, probability=.4):
    cfg = json.loads(Path(path).read_text())
    cfg.setdefault('cpm_max_span_patches', span)
    cfg.setdefault('cpm_max_mask_probability', probability)
    if 'test_input_data_dirs' in cfg:
        cfg['test_input_data_dirs'] = _parse_dirs(cfg['test_input_data_dirs'], 'test_input_data_dirs')
        cfg['clean_data_dirs'] = _parse_dirs(cfg['clean_data_dirs'], 'clean_data_dirs')
        cfg.setdefault('test_input_ratio', .3)
        cfg.setdefault('clean_ratio', 1. - cfg['test_input_ratio'])
        ratios = [cfg['test_input_ratio'], cfg['clean_ratio']]
        if any(not math.isfinite(v) or not 0 <= v <= 1 for v in ratios) or not math.isclose(sum(ratios), 1.):
            raise ValueError('test_input_ratio + clean_ratio must equal 1, with nonnegative finite ratios')
        test = {str(Path(p).expanduser().resolve()) for p, _ in cfg['test_input_data_dirs']}
        clean = {str(Path(p).expanduser().resolve()) for p, _ in cfg['clean_data_dirs']}
        if test & clean:
            raise ValueError('Do not put the same directory in both replay groups')
    return cfg


def two_group_counts(step, batch_size, test_ratio):
    test = round((step + 1) * batch_size * test_ratio) - round(step * batch_size * test_ratio)
    return test, batch_size - test
